Independent CalculiX 2.23 / Wing AeroStruct comparison

Units: mm, N, MPa. Original solid runs: 26 October 2026.
Each input deck runs directly: ccx_static -i ccx-h5-uniform
Repeat for h8/h5 and uniform/torque. The .dat files and *-solution.npz contain
the original nodal displacement and integration-point stress output. The
NPZ files also retain coordinates and C3D10 connectivity for postprocessing.

source/ contains the original deck adapter, matched-point comparison, summary
and beam bridge. They are source-level tools for the Aerospace-Structures
repository, not standalone executables. Place the included source files in
scripts/validation/ of that repository, with the matching production modules
in computational/printed-wing-solver/web/. Keep these benchmark data together
in a separate output folder. NumPy and Matplotlib are required for comparison;
scikit-fem is required only to regenerate a deck from the admitted mesh.

The original beam bridge imports web/engine.js. The publication recheck instead
evaluated the actual embedded WingEngine block from the AeroStruct page, using
the same shared dependencies, and injected that engine into the bridge. The
exact source identity and hashes are recorded in comparison.json on the
validation page. The selected finite-tip results were unchanged.

No general validation, local stress accuracy, physical tip-twist, experimental
agreement, buckling, fracture or printed-material qualification is claimed.
