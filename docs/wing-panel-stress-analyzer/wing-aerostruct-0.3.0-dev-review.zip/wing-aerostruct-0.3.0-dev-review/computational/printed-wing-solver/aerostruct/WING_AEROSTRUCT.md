# Wing AeroStruct (development): coupled panel aerodynamics and spatial-beam structure

Status: development build for review. Not published. Wing AeroStruct is a separate application with its own
site (`site-aerostruct/`), its own browser storage and its own study-file version. Wing Lab is unchanged: the
published site (`docs/`) and the Wing Lab 1.3 sources (`computational/printed-wing-solver/web/`) are not
modified, and the test runner reports the number of changed files there (zero in the logs of this build).

Scope in one sentence: steady, incompressible, inviscid, attached potential flow on the finite-thickness
wing surface (symmetric flight, rigid wing), delivered as an extrapolated six-component strip load to the
small-displacement spatial beam of the Wing Lab structural engine, and admitted to the structural result
only when an executed mesh-refinement study shows that the force and bending it delivers are resolved and
that its torque is either resolved relative to itself (then torque and twist are shown) or too small to
matter through the structure's own torsional compliance (then torque and twist are withheld).

## 1. Review history and what changed

### 1.1 Second review (Wing AeroStruct 0.2.0): torque admission and twist claims

The reviewer confirmed the six-component transfer and found that the Fine sequence admitted the editable course
fixture with root torque 1.950 ± 0.955 N mm (49% of the torque), 1.241 ± 0.860 at 25% span (69%), 0.474 ± 0.610
at 50% (129%, sign indeterminate) and -0.188 ± 0.339 at 75% (181%, sign indeterminate), only because every error
was divided by a fixed floor of 10.667 N mm (0.01 q S c). That is not 10% torque accuracy.

| Review item | What Wing AeroStruct does now | Section |
|---|---|---|
| No silent normalization with q S c | The floor is removed. A torque is resolved only if U_T <= 10% of its own magnitude and every mesh that carries weight in the load gives the same sign. The four torques above are now reported as "magnitude not resolved" (root, 25%) and "sign not resolved" (50%, 75%; at 75% the meshes give torques of both signs) | 7.1 |
| Gate relative torque when claiming accurate twist | Torque and twist values are shown only when every reported torque is resolved and the twist uncertainty dtheta is within 10% of the twist | 7.2 |
| Near-zero torque: justified absolute tolerance from torsional compliance, or explicit warning and withheld twist | Both. The twist uncertainty dtheta is computed with the structure's own torsional compliance (frame elements' GJ); when the torque is not resolved, the load is admitted only if the bound on the true twist, abs(theta) + dtheta, is aerodynamically negligible (it could change the lift by at most 1%). Then torque and twist are withheld from every result view (diagrams, charts, tip and reaction tables, 3-D colouring, reports) and appear only in the admission record with their uncertainty and the status "magnitude not resolved" or "sign not resolved"; otherwise the coupled result is refused | 7.2, 7.5 |
| Test low-GJ structures and opposite-sign mesh cases | New suite `test_aerostruct_twist`: the fixture, a low-GJ fixture (refused), forward-spar structures with resolved twist at three stiffnesses (the softest refused by the one-way-coupling check), twist error against a much finer reference load on every structure; synthetic and real opposite-sign meshes in `test_wing_aero_admission`; the reference study checks every resolved sign | 8.1, 8.3, 8.5 |
| Capped browser runtime: refuse rather than overclaim | No new or larger sequence; the Fine sequence (about 20 s in the browser on the test machine) is the largest. An unresolved, non-negligible twist withholds the coupled result even on Fine | 7.5 |
| Preserve the conservative six-vector transfer | Unchanged (section 5); the reviewer measured 2.7e-15 N and 2.3e-13 N mm | 5 |

### 1.2 First review (Wing Lab 1.4 package)

| Review item | What Wing AeroStruct does | Section |
|---|---|---|
| (1) Only the vertical force reached the structure (z-only table); with dihedral part of the root bending was lost | Every strip carries its full force vector and its full moment. The spatial beam receives a uniform force intensity on the quarter-chord line plus the uniform couple that restores the strip moment exactly, so all six root-wrench components (and the wrench of every outboard part) equal the aerodynamic values for any sweep, dihedral and twist | 5 |
| (2) Root torque -3.8 N mm on the Standard mesh against about -8.0 N mm converged | The single-mesh result is no longer applied. Every applied load is a Richardson extrapolation of an executed seven-mesh refinement sequence (chordwise and spanwise) with an uncertainty, and the admission test of section 7 decides what is shown | 6, 7 |
| Flat-tip pressure omission | Investigated: the flat cap's trailing corner is an edge singularity; its pressure and side force do not converge (section 4). The default tip is now rounded, the surface closes on itself and every panel pressure is integrated. The flat cap remains only as a diagnostic option and is refused for structural loads | 4 |
| Physical consistency of global loads | Pressure lift and Trefftz-plane lift of the extrapolated solution must agree within 2%; pressure drag is compared with induced drag; the delivered strips sum exactly to the extrapolated root wrench; the structural engine reports the applied wrench of the aerodynamic part | 5, 7, 8 |
| Exact approximations documented and validated | Sections 3 to 7 state the formulas; section 8 gives the validation | 3 to 8 |

All solver changes were written by the author of this package; the reviewer only reviews and tests.

## 2. The application

Wing AeroStruct is the Wing Lab page (same workspaces, structural engine, CAD exports) built from a separate
template, with:

* an **Aerodynamics** section in the input column (Wing workspace): speed, density, angle of attack or target
  lift, viscosity and speed of sound (Reynolds and Mach screens only), and the mesh sequence (Standard or Fine);
* "Run mesh sequence": seven panel solves in a Web Worker (main-thread fallback without Workers), then the
  extrapolated coefficients and loads with their uncertainties, the global-consistency checks, a spanwise force
  figure, chordwise Cp of the base mesh, the meshes and their weights, and a CSV download;
* "Apply to structure and solve": replaces the structural load case with the aerodynamic load (the factor of safety
  and the self-weight setting are kept), solves the spatial beam and runs the admission test; "Remove
  aerodynamic load" takes it off again;
* the admission table (one row per check, with value, uncertainty, error and limit, marked resolved, withheld or
  failed) and its verdict; when torque and twist are withheld, the twist and torque views are disabled and the
  results show only the twist bound (section 7.5).

Structural engine: `aerostruct/engine.js` is a fork of `web/engine.js` whose only changes are listed in
section 5.3 and reproduced in `engine_fork.diff` (the test suite regenerates the diff and checks that it is
current). Without an aerodynamic load every engine result is identical to Wing Lab 1.3 (tested on the course
fixtures). The shared Wing Lab modules (geometry, airfoils, spatial frame, section geometry, load profiles,
spars) are loaded unchanged from `web/`.

Separation from Wing Lab: storage keys start with `wing-aerostruct:` (a Wing Lab autosave is never read or
overwritten), the page is marked `noindex`, its title and header say "Wing AeroStruct (development)" and "development
build, separate from Wing Lab", study files with
an applied aerodynamic load are version 4 (Wing Lab refuses them with its normal "saved by a newer version"
message), and the build script refuses to write into `docs/`.

## 3. Aerodynamic formulation (`wing_aero_panel.js`)

1. **Surface.** The right semi-wing is built from the Wing Lab geometry module (`stationAt`,
   `transformPoint`: chord law, sweep, dihedral, spanwise airfoil and incidence stations, NACA four- and
   five-digit and DAT airfoils). Each section uses the airfoil module's cosine sampling with the printed
   trailing-edge thickness closed (`te = 0`): the aerodynamic trailing edge is sharp. Spanwise stations are
   sine-spaced (clustered at the tip) and include every geometry station. The tip is rounded (section 4), or
   collapses to a point for the exact elliptic and delta zero-chord tips.
2. **Singularities.** Constant-strength source and doublet on each quadrilateral. The doublet influence is the
   solid angle of the two triangles of the true (possibly non-planar) quad (Van Oosterom and Strackee), so
   neighbouring panels share edges exactly and the surface is watertight. The source influence is the
   closed-form planar-polygon integral (Hess and Smith; Newman) on the quad's mean plane. Beyond six panel
   diameters both use point singularities (largest relative error 1.1e-3 at six diameters).
3. **Boundary condition.** Internal Dirichlet condition (zero perturbation potential inside the closed wing,
   as in VSAERO, Maskew 1987) at the panel centroids; doublet self term -1/2; source strength
   sigma = n . V_inf. The doublet strength then equals the surface perturbation potential.
4. **Kutta condition and wake.** Morino condition: on each spanwise strip the wake doublet equals the upper
   minus the lower trailing-edge panel doublet. The wake is a flat sheet of semi-infinite constant-strength
   strips leaving the trailing edge along body +x. It is not aligned with the freestream and not relaxed
   (measured effect 0.19% in CL at 5 deg).
5. **Symmetry.** The left half is the mirror image of the right half (symmetric flight only).
6. **Superposition and caching.** The system is solved once for unit freestreams along x and z; any alpha, V and
   rho is then a linear combination, so a new angle of attack, speed or density needs no new linear solve.
   Prepared models are cached by geometry and mesh (eight models, enough for one sequence).
7. **Linear solver.** Dense LU with partial pivoting up to 900 panels; above that, restarted GMRES(60) with
   strip block-Jacobi preconditioning. The true residual is checked (at most 1e-9 relative) and LU is used if
   GMRES does not meet it.
8. **Surface velocity and pressure.** Tangential gradient of the doublet from three-point Lagrange differences
   along the chordwise and spanwise panel lines (mirror stencil at the root, one-sided at the trailing edge and
   tip) plus the tangential freestream; incompressible Bernoulli Cp = 1 - (V/V_inf)^2.
9. **Loads.** Panel force -Cp q A n; semi-wing force and moment; CL, pressure drag and Cm by pressure
   integration; strip loads (section 5.1). With the rounded tip every panel is a wing-surface panel, so every
   pressure is integrated.
10. **Trefftz plane.** Lift from the Kutta-Joukowski sum of the wake; induced drag from a continuous
    piecewise-linear reconstruction of the strip circulation (16 sub-segments per strip).
11. **Target lift.** A secant iteration on the cached unit solutions of all seven meshes finds the angle of
    attack at which the *extrapolated* pressure lift equals the requested lift; it refuses answers outside
    |alpha| <= 15 deg.

Units: geometry mm, speed m/s, density kg/m^3, pressure Pa, force N, moment N mm. Axes: x aft, y along the
right semi-span, z up. The freestream (air relative to the wing) is V (cos alpha, 0, sin alpha).

Inputs and guards (unchanged from the 1.4 review build): speed 0.001 to 200 m/s with Mach at most 0.3
(warning above 0.2; no compressibility correction), density 0.001 to 5 kg/m^3, angle of attack -15 to 15 deg
(warning when a local geometric angle exceeds 8 deg), speed of sound 290 to 360 m/s (so the Mach guard cannot be
bypassed), sideslip refused, misnamed geometry fields refused, low-Reynolds-number warning below 5e5 (the
course wing at 15 m/s is about 1.3e5: inviscid results are optimistic there). Mesh limits per solve: 6 to 96
panels per surface, 4 to 48 strips, at most 4,800 panels.

## 4. Tip closure: the flat-cap investigation and the rounded tip

**Flat cap (diagnostic option `tipClosure: 'flat'`).** Wing Lab sections lie in planes y = const, so a flat
cap has its normal exactly along +y and its pressure force is purely spanwise. Its trailing corner is where the
side edge of the wake (the tip vortex) leaves the wing, a potential-flow edge singularity. Measured on the
course planform (450 mm semi-span, 160 to 100 mm chord, NACA 2412, alpha 4 deg, 16 strips):

| Panels per surface | 16 | 32 | 48 |
|---|---|---|---|
| Lowest cap Cp | -1,721 | -28,371 | -145,608 |
| Side force of the cap if integrated (N) | 0.134 | 0.161 | 0.177 |

Neither converges, so in the 1.4 build the cap pressure was left out of every load, which also left out the
true small side force of the tip. The flat cap is now only a diagnostic: a mesh sequence with the flat cap is
refused for structural use, both when it is combined into a load and when a study file is read.

**Rounded tip (default).** Over the last ell of span, ell = min(t_tip / 2, L / 4) with t_tip the largest
distance between paired upper and lower points of the tip section and L the semi-span, each section is
thinned about its camber line:

    tau(y) = sqrt(1 - ((y - y0) / ell)^2),   y0 = L - ell,
    p_i(y) -> c_i + tau(y) (p_i - c_i),   c_i = (p_i + p_(2n - i)) / 2,

where p_i and p_(2n - i) are the paired lower and upper points of the section loop (n panels per surface). In
every chordwise plane the tip is therefore a semi-ellipse with semi-axes ell (spanwise) and half the local
thickness; at y = L the section collapses onto its camber line and the surface closes on itself, with no cap.
The planform (chord law, sweep, dihedral, twist) is unchanged. The rounding zone gets
m = max(2, round(s / 4)) strips at y0 + ell sin(pi k / (2 m)), k = 0 to m (s = spanwise strips of the mesh), so
spanwise refinement also refines the rounding; regular stations closer than ell / (4 m) to y0 are dropped. On
the course wing ell = 6.0 mm (1.3% of the semi-span). With this closure the semi-wing force is the sum of all
panel pressures and the side force converges (the test log of `test_wing_aero_wing` lists Fy on four chordwise
and four spanwise refinements).

What this approximates: a printed wing with a flat (cut-off) end is replaced, aerodynamically, by the same wing
with a short rounded end. The structural model keeps the printed geometry; the delivered loads cover 0 to L
with the rounding zone merged into the last strip.

## 5. Six-component load transfer (exact algebra)

### 5.1 Strip loads of one mesh

For a mesh with spanwise stations y_0 = 0 < y_1 < ... < y_n = L, strip j is the set of wing-surface panels between
y_j and y_(j+1). Its load is the row

    [y_j, y_(j+1), F_x, F_y, F_z, M_x, M_y, M_z],   F = sum of panel forces,   M = sum of (centroid x panel force),

with M about the aircraft origin. Nothing is dropped: the rows of a mesh sum exactly to the semi-wing force and
moment (`stripWrenches`, checked against `resultantOfPanels`).

### 5.2 How a strip enters the spatial beam

A strip row with width h = y_(j+1) - y_j is carried as

    force intensity    f = F / h                                   (N/mm, uniform in the strip)
    on the load line   r(y) = transformPoint(g, y, [0.25 c(y), 0])  (the quarter-chord line of the real wing)
    couple intensity   m = (M - (integral of r dy over the strip) x f) / h   (N mm/mm, uniform)

so that integral f dy = F and integral (r x f + m) dy = (integral r dy) x f + M - (integral r dy) x f = M
exactly, and the force and the moment about ANY point equal those of the panel pressures. The integral of r is
an adaptive Gauss-Legendre quadrature with tolerance 1e-13. The quarter-chord line only distributes the load
inside a strip; the couple m makes the result independent of that choice at strip resolution. Because the
strip moments are carried in full, the spanwise force Fy and its contribution to the bending moment with
dihedral, the chordwise force Fx, and the pitching couple of every section all reach the structure.

### 5.3 Structural engine fork (`engine.js`, diff in `engine_fork.diff`)

* `input.aeroLoad = {kind: 'aeroStrips', lineFraction, strips: [[y0, y1, Fx, Fy, Fz, Mx, My, Mz], ...], label}`
  is validated: at most 96 strips, each at least 0.1 mm wide, ordered without overlap inside 0 to L, finite
  numbers, unknown fields refused, and every strip station either equal to a structural station (rib, seam,
  geometry station, spar end, load station) or at least 0.1 mm away from it (the engine's rule against
  degenerate elements).
* An aerodynamic load always uses the spatial beam (the fast prismatic route cannot carry couples). Exact
  zero-chord tips refuse it (their structural model is a section-stress study without the beam); external rods,
  partial-span spars and dry seams are refused exactly as for any spatial-beam load; a prescribed flight lift
  cannot be combined with it (the aerodynamic load replaces it).
* Each strip becomes a line-load item. Its consistent element loads use the engine's existing normal-foot work
  integration: at every point r(y) the force f and the moment (r - A) x f + m about the foot A on the element
  axis are distributed to the element degrees of freedom by the beam shape functions. Cut resultants, the
  applied wrench and the support equilibrium include the force vector and couple of every strip.
* `analysis3D.aeroLoad` reports the aerodynamic part: the strips, the applied wrench integrated from the line
  loads, the given wrench summed from the rows, their difference (`transferResidual`) and `cutAt(y)`, the
  outboard wrench and torque of the aerodynamic part on the engine's own normal cut plane.
* Without `input.aeroLoad` the fork returns exactly the Wing Lab 1.3 results (`test_aerostruct_engine_fork`
  compares complete results on the course fixtures).

Measured transfer accuracy (logs of `test_wing_aero_transfer` and `test_aerostruct_engine_fork`):

* the strip rows of a solve sum to the semi-wing pressure resultant within 5.8e-16 (relative), with the rounded
  and with the flat tip;
* the strip representation (uniform force on an independently coded quarter-chord line plus the couple)
  reproduces all six components of every strip within 5.4e-15 (Simpson quadrature, not the solver's);
* delivered strips against the extrapolated root wrench: 3.3e-14 on a manufactured sequence whose error is
  quadratic in 1/c and 1/s; 1.1e-13 (Standard) and 6.5e-12 (Fine) on the course wing;
* end to end on a swept (20 deg), dihedral (7 deg), twisted wing with 39 delivered strips: the beam's applied force
  and moment about the root node equal the weighted sum of the seven meshes within 1.8e-15 N and 1.6e-12 N mm;
* the engine fork against independent references (own load-line geometry, Simpson quadrature and plane
  crossing) for 9 strips with all six components on a swept, dihedral, twisted wing: the applied wrench and 8
  normal-cut resultants agree within 2.8e-12 N mm, and the support reactions balance them;
* z-only strips on the quarter-chord line reproduce the Wing Lab 1.3 distributed-load results (deflection, twist,
  shear, bending, torque, skin stress) to 1.1e-11 relative; a pure pitching couple twists the beam exactly like
  the equivalent force pair (1.6e-15 relative) and neither deflects nor shears it;
* editable course fixture: the beam's applied wrench differs from the strip sums by 5.3e-15 N and 3.4e-13 N mm
  (Fine, `test_aerostruct_browser`), and its cut torques of the aerodynamic load equal the admission's delivered
  torques within 5.7e-14 N mm at all four cuts (Standard, `test_aerostruct_aero_ui`);
* without an aerodynamic load, seven inputs give results identical to Wing Lab 1.3 (deep comparison of every
  number).

## 6. Mesh-refinement sequence and Richardson extrapolation

### 6.1 Meshes

A sequence refines the chordwise panels at a fixed spanwise mesh and the spanwise strips at a fixed chordwise
mesh, with 1/n in the ratios 6 : 4 : 3 : 2 in each direction. Seven solves (the base mesh is shared):

| Sequence | Chordwise refinement (panels per surface, at 16 strips) | Spanwise refinement (strips, at 32 panels per surface) | Base | Panels on the course wing |
|---|---|---|---|---|
| Standard | 16, 24, 32, 48 | 8, 12, 16, 24 | 32 x 16 | 7,888 in total, largest mesh 1,824 |
| Fine | 32, 48, 64, 96 | 16, 24, 32, 48 | 32 x 16 | 16,800 in total, largest mesh 3,648 |

Measured time for a whole sequence on the course wing (logs of this build): Standard about 4.5 s in Node and 7 s in
a Chromium Worker; Fine about 12 s in Node and 20 s in the Worker (two shared cores, software rendering). A new
angle of attack, speed or density on the same wing reuses all seven cached influence systems.

### 6.2 Extrapolation

For a quantity Q that is linear in the strip loads, with Q(c, s) its value on c panels per surface and s strips:

    Q_chord = sum over the three finest chordwise levels of w_i Q(c_i, 16),
    Q_span  = sum over the three finest spanwise levels of v_i Q(32, s_i),
    Q_ext   = Q_chord + Q_span - Q(32, 16),

where w_i and v_i are the Lagrange weights of the quadratic polynomial in h = 1/n through the three levels,
evaluated at h = 0 (Richardson extrapolation removing the first- and second-order terms of each direction).
For levels in the ratio 4 : 3 : 2 of h the weights are 3, -8 and 6. The resulting fixed level weights (meshes
written as panels around the section x strips):

* Standard: 48 x 16: 3, 64 x 16: -17, 96 x 16: 6, 64 x 12: 3, 64 x 24: 6;
* Fine: 96 x 16: 3, 128 x 16: -8, 192 x 16: 6, 64 x 24: 3, 64 x 32: -8, 64 x 48: 6, 64 x 16: -1.

The same weights apply to every quantity, so the extrapolated coefficients, root wrench, strip loads and cut
loads are one consistent load set: Q_ext of any linear quantity equals the same quantity of the delivered load.
The additive combination assumes that the discretization error is separable, E(c, s) = A(c) + B(s); section
8.2 measures the cross term.

### 6.3 Delivered strips

The meshes of a sequence have different spanwise stations, so they are combined through their cumulative
(outboard) wrench. For level k, C_k(y) is the exact sum of the strip rows outboard of each of its stations,
and a monotone piecewise-cubic Hermite interpolant (PCHIP, Fritsch and Carlson) between them, for each of the
six components. With the level weights w_k,

    C(y) = sum over k of w_k C_k(y),   delivered strip [y_a, y_b]: W = C(y_a) - C(y_b),   C(L) = 0.

C(0) is an exact sum on every level, so the delivered strips add up exactly to Q_ext of the root wrench. The
delivery stations are the strip boundaries of the finest spanwise mesh with its rounding zone merged into one
last strip that starts at y0; stations within 0.25 mm of a structural station are moved onto it; strips wider
than L / 32 are halved once; every station keeps at least 0.1 mm from all others. Inside a delivered strip the
load is uniform (section 5.2), so a cut inside a strip sees an interpolated part of it; this interpolation
difference is measured at every admission cut and added to that cut's uncertainty.

### 6.4 Uncertainty

For each direction (chordwise and spanwise) with four levels n_1 < n_2 < n_3 < n_4:

* quadratic: the extrapolation above through n_2, n_3, n_4;
* linear: Richardson through the two finest levels (first order);
* observed order: p from the three finest levels by the fixed-point iteration of Celik et al. (2008) for
  non-uniform ratios, bounded to 0.5 <= p <= 2 (first order if the sequence oscillates), and the
  extrapolation f_4 + (f_4 - f_3) / (r^p - 1);
* spread: the largest difference among the linear, quadratic and observed-order values;
* stability: the change of the quadratic extrapolation when the three coarser levels n_1, n_2, n_3 are used;
* correction: the quadratic extrapolation minus the finest level (what the extrapolation added).

Then

    U = 1.25 x [ max(spread_c + stability_c, 0.5 |correction_c|) + max(spread_s + stability_s, 0.5 |correction_s|) ].

The first term measures how much the possible convergence orders disagree and how much the extrapolation moves
when the coarser levels are used. The second term (added after the reference study of section 8 showed that
the first term alone under-covered the Fine sequence's force and bending) prevents U from claiming that the
extrapolation removed more than half of its own correction: on the Fine sequence the levels can agree closely
with each other while the spanwise observed order still falls from about 0.9 to about 0.7 between 32 and 96
strips, so the finest levels are not yet asymptotic. The factor 1.25 is the factor of safety that Roache and
Celik et al. use with three-level studies.

## 7. Admission test

The admission test runs after the spatial beam has been solved with the delivered load, on cut planes taken from the
structural result itself:

* the root: all aerodynamic loads, moments about the root node of the beam axis, torque about the axis direction at
  the root (the shear-centre axis of the beam model);
* normal cuts at 25%, 50% and 75% of the span: the engine's own section plane, reference point (shear centre) and
  normal; the aerodynamic load line is cut at its intersection with the plane;
* for the twist bound, 16 cuts of the same kind at y = k L / 16, k = 0 to 15.

There is no absolute torque floor and no normalization with q S c anywhere in the test.

### 7.1 Torque at a cut

For each cut the delivered torque T, its uncertainty and its status are

    U_T = U(sequence estimate of the cut torque) + |T(delivered) - T(sequence estimate)|,
    resolved        if U_T <= 0.10 |T|  and every mesh that carries weight in the load gives a torque of the sign of T,
    sign resolved   if U_T < |T|        and those meshes agree in sign,

so a torque is "resolved", "magnitude not resolved" or "sign not resolved". The meshes that carry weight are the five
(Standard) or seven (Fine) meshes of section 6.2. The sequence estimate uses each mesh's own cumulative wrench at the
same plane, so U_T covers the extrapolation and the interpolation of the delivered strips. If the additive
combination of the finest meshes, Q(c_4, 16) + Q(32, s_4) - Q(32, 16), has the sign opposite to T, then
|correction_c| + |correction_s| >= |T|, so the correction term of section 6.4 alone makes U_T at least 62.5% of |T|
and the torque cannot be resolved; if any weighted mesh has the opposite sign, its sign is not resolved either (both
tested). Torque values (the cut torques and the torque diagram) are shown only
if all four reported torques are resolved. The engine's own cut torque of the delivered load is compared with T at
every cut (transfer residual, at most 5.7e-14 N mm on the editable fixture, Standard sequence).

### 7.2 Twist claim from the structure's torsional compliance

Twist is the integral of torque times torsional compliance, so its uncertainty follows from U_T and the structure:

    k_e = (length of frame element e / its projected span) / GJ_e      (twist per unit torque per unit projected span)
    Ubar = on each interval between the 16 cuts, the larger of the two U_T values (zero at the tip)
    dtheta(y) = integral from 0 to y of Ubar k dy                         (largest twist error that torque errors within U_T can cause)
    bound on the true twist at y: |theta(y)| + dtheta(y)                   (theta: twist of the coupled solution)

The compliance is the beam model's own: integrating the beam's internal torque times k reproduces the frame's twist
within 0.73% on the editable fixture and within 0.46% on a swept (20 deg), dihedral (7 deg), twisted two-spar wing
(`test_aerostruct_twist`). The twist claim is one of three:

* **resolved**: every reported torque is resolved and dtheta <= 10% of |theta| at 25%, 50%, 75% span and at the tip.
  Twist and torque are shown, with the twist uncertainty.
* **negligible**: otherwise, if the bound on the true twist, applied as an incidence change, could change the lift by
  at most 1%:

      q a0 * integral from 0 to L of c(y) (|theta(y)| + dtheta(y)) dy <= 0.01 |L_semi|,   a0 = 2 pi per radian.

  The load is admitted, but the twist is withheld, and the torque too unless every torque is resolved (section 7.5):
  only the bound is reported.
* **unresolved**: otherwise. The coupled result is withheld.

Why this absolute tolerance: the aerodynamic load is computed on the rigid wing, so the twist matters to the coupled
problem through the incidence change it would cause. The lift change that a twist distribution delta(y) causes on
the finite wing is q * integral of c(y) cl_alpha(y) delta(y) dy, where c cl_alpha is the wing's span loading per
unit angle of attack (reciprocity of lifting-line theory); the induced angle makes cl_alpha smaller than the section
lift slope. The criterion uses a0 = 2 pi, the thin-airfoil section lift slope, and |theta| + dtheta, which bounds
the true twist everywhere: on the course wing the panel method's own lift slope is 4.7 per rad (CL at 4 and 8 deg,
section 8.6), 75% of 2 pi, which also covers the increase of the 2-D potential-flow slope with section thickness
(about 9% for a 12% thick section). 1% is half of the 2% lift-consistency tolerance that the extrapolated solution
must meet anyway (section 7.4). In twist terms the criterion is an area-weighted mean twist of 0.01 C_L / a0, 0.047
deg on the course wing at 4 deg; the tolerance follows from the structure's actual compliance and the load, never
from a torque scale. On the editable fixture the bound is 0.0008 deg on Fine (lift effect 0.011%); on the same
fixture with a 10 MPa shell and spars the bound is 0.16 deg (lift effect 2.2%) and the load is refused (section
8.5).

### 7.3 One-way coupling

Because the load ignores the structure's twist, the computed twist itself must be small enough for that to be
consistent: q a0 * integral of c |theta| dy <= 2% of |L_semi| (the lift-consistency tolerance). A more flexible wing
is refused even when its twist is resolved (example: the forward-spar structure with GJ / 40 twists 0.45 deg, which
would change the lift by 5.6%). Aeroelastic redistribution itself is not modelled.

### 7.4 Force, bending and lift

Root force |F| and root bending moment |M_b| (the moment component normal to the axis), each with U from the three
component estimates plus their interpolation differences, are admitted if U / magnitude <= 5%. Lift consistency: the
extrapolated pressure lift against the extrapolated Trefftz-plane lift, |CL - CL_Trefftz| / max(|CL|, 0.05) <= 2%. The
drag comparison (pressure drag against induced drag) is shown but is not a criterion, because the pressure drag of a
panel method converges more slowly than the Trefftz-plane value.

### 7.5 Decision and what the user sees

The load is admitted if force, bending, lift and the one-way coupling pass and the twist claim is resolved or
negligible. In the admission table every row is marked ✓ (resolved), ! (not resolved, value withheld) or ✗ (fails).

* **Admitted, twist resolved**: the coupled result is shown with torque and twist; the result record gives the root
  torque and the tip twist with their uncertainties.
* **Admitted, torque and twist withheld**: the verdict names every unresolved cut and the twist bound. The unresolved
  torques appear only in the admission record (the admission table, the results record, the report and the CSV),
  each with its uncertainty and the status "magnitude not resolved" or "sign not resolved", never as a result. The
  twist and torque views (More results) are disabled with the reason, the 3-D result record shows the bending rotations (the
  rotation without its component about the beam axis) and states "twist withheld" with the bound, the torque curve
  and the twist chart are not drawn, and the text report says WITHHELD instead of giving a value. Every moment that
  contains the unresolved torque is shown without it: the root reactions, the applied wrench in the results record
  and the load status line, the cut-moment chart and the report give the bending part (the moment minus its
  component about the beam axis) and mark the torque about the axis as withheld. Bending, shear force, normal stress
  and displacement are shown; surface displacements contain at most (bound x root chord) from the unresolved twist
  (0.002 mm on the editable fixture with the Fine sequence, 0.0035 mm with Standard). The applied strip loads are
  listed in full in the report as the load data, marked as not resolved about the beam axis. If every torque is
  resolved but the twist is not resolved to 10% of itself, only the twist is withheld: the verdict, the results
  record and the report say so, and the torque values are shown.
* **Not admitted**: the coupled result is withheld; the previous result stays on screen marked out of date and the
  error dialog names the failed checks. On the Standard sequence the message suggests the Fine sequence; on the Fine
  sequence it states that this is the finest sequence offered in the browser and that the load is refused rather than
  shown with an unresolved twist.

## 8. Validation

All numbers come from the logs in `test-logs/` and from `validation/reference_study.log` and
`validation/midspan_example.log` of this build.

### 8.1 Reference study (`validation/reference_study.mjs`)

Seven wings: the course wing at 4 and 8 deg, with 6 deg dihedral, with 25 deg sweep, a rectangular NACA 0012
wing (AR 6, 5 deg), a washout wing (incidence 2 to -2 deg) and a combined wing (sweep 15, dihedral 5, taper 160 to
70 mm, NACA 4412 root to 0012 tip with 1 to -1 deg incidence, 18 m/s, 6 deg). For each wing, three straight
torque axes (the 25%, 35% and 45% chord lines from root to tip, standing in for structural shear-centre axes;
the 35% axis lies near the centre of pressure and gives near-zero torques) and cuts at the root and at 25%, 50%
and 75% of the span: 84 torques, 21 root forces and 21 root bending moments per sequence.

Reference values: much finer meshes, 48 to 192 panels per surface at 16 strips and 24 to 96 strips at 32 panels per
surface (up to about 7,300 panels), extrapolated per force and moment component with the observed order of the
three finest levels of each direction and combined additively; the reference uncertainty u_ref is the change
when the next-coarser triple is used. The script shares no extrapolation code with the solver (its own
load-line geometry, cut integration and order iteration). The torque tolerance is 10% of the reference torque
itself; there is no floor.

| Sequence and quantity | Within U | Largest abs(error) / U | Within U with u_ref and the cross term added | Resolved | Resolved with error above tolerance | Sign resolved (of which wrong) |
|---|---|---|---|---|---|---|
| Standard, torque | 84 of 84 | 0.59 | 83 of 84 (largest ratio 1.06) | 49 | 0 | 69 (0) |
| Standard, root force | 21 of 21 | 0.28 | 21 of 21 | 21 | 0 | |
| Standard, root bending | 21 of 21 | 0.15 | 21 of 21 | 21 | 0 | |
| Fine, torque | 84 of 84 | 0.54 | 77 of 84 (largest ratio 1.31) | 61 | 0 | 73 (0) |
| Fine, root force | 21 of 21 | 0.35 | 21 of 21 | 21 | 0 | |
| Fine, root bending | 21 of 21 | 0.16 | 21 of 21 | 21 | 0 | |

"Error" is the estimate minus the reference. The fourth column is a stress test that also adds the reference's
own uncertainty and the estimated cross-term error of section 8.2 to the error; where it exceeds U, the
reference itself is not more precise than U (for example 0.23 N mm reference uncertainty against a Fine U of
0.55 N mm on a near-zero torque of the NACA 0012 wing). The sixth column uses that pessimistic error: no
resolved quantity of either sequence has an error above its tolerance (for torque, 10% of the torque).

Torques not resolved: Standard 35 (20 "magnitude not resolved", 15 "sign not resolved"), Fine 23 (12 and 11). By
axis: about the 45% axis all 28 torques are resolved in both sequences; about the 25% axis 12 (Standard) and 5
(Fine) are not, including the four near-zero torques of the symmetric NACA 0012 wing (centre of pressure at the
quarter chord); about the 35% axis 23 (Standard) and 18 (Fine) are not.

Signs: every torque reported with a resolved sign has the sign of the reference (69 Standard, 73 Fine). Two
estimates per sequence have the wrong sign; both are flagged "sign not resolved". The weighted meshes give torques of
both signs in 8 (Standard) and 10 (Fine) of the 84 cases; those are never resolved. In two cases the Standard and
Fine estimates have opposite signs (course wing at 4 deg, 35% axis, root: -0.041 and 0.147 N mm against a reference
of 0.335 N mm; NACA 0012 wing, 25% axis, root: 0.065 and -0.080 N mm against 0.218 N mm); both sequences flag both
as sign not resolved.

History of the estimator, stated because it changed during this work: with U = 1.25 x (spread + stability) alone,
the same study covered every Standard estimate but only 83 of 84 Fine torques (largest ratio 1.45), 12 of 21 Fine
forces (1.59) and 18 of 21 Fine bending moments (1.14). The true errors were small (at most 0.3% of the force,
0.2% of the bending moment), far inside the tolerances, but U was not conservative. The correction term of
section 6.4 was added and the study rerun; the table above is the rerun with the admission of section 7.

Run: `node validation/reference_study.mjs` (about 13 minutes; `REF_ONLY=course4` for one wing). The log lists
every case; `admission_reference.json` stores the references, the cross-term estimates, the summary and the
reference load used for the twist validation of section 8.5, and `test_wing_aero_admission` checks the Standard and
Fine sequences of three wings against them in every run (every estimate within U, every resolved torque within 10%
of itself including the reference uncertainty and the cross term, every resolved sign equal to the reference sign).

### 8.2 Separability of the discretization error

Both the app and the reference combine the two directions additively (section 6.2), which is exact only if
the discretization error is separable. The reference study tests this with three meshes refined in both
directions, 96 x 24, 128 x 32 and 192 x 48 panels (around x strips; up to 10,752 panels), through the mixed
second difference

    D = Q(c, s) - Q(32, s) - Q(c, 16) + Q(32, 16),

which is zero for a separable error. The error of the additive combination is X(32, 16), the cross term at the
base mesh; for a cross term k / (c s) it equals 9 D, 4 D and 2.25 D for the three meshes. For force and bending
the three estimates grow with refinement (the cross term decays more slowly than 1 / (c s)), so the largest
magnitude of the three is used. Largest estimates on the seven wings (torque: largest over the three axes and
four cuts):

| Wing | Torque (N mm) | Root force | Root bending |
|---|---|---|---|
| course, 4 deg | 0.10 | 0.0072 N (0.17%) | 1.77 N mm (0.22%) |
| course, 8 deg | 0.18 | 0.0114 N (0.17%) | 2.77 N mm (0.21%) |
| dihedral 6 deg | 0.12 | 0.0070 N (0.17%) | 1.77 N mm (0.21%) |
| sweep 25 deg | 0.09 | 0.0059 N (0.14%) | 1.60 N mm (0.17%) |
| NACA 0012, AR 6 | 0.07 | 0.0042 N (0.18%) | 0.81 N mm (0.22%) |
| washout | 0.11 | 0.0075 N (0.17%) | 1.76 N mm (0.22%) |
| combined | 0.15 | 0.0107 N (0.14%) | 2.69 N mm (0.18%) |

U does not contain this cross term (it would need meshes refined in both directions in every sequence). For
force and bending it is at most 0.22%, against the 5% tolerance. For torque it is at most 0.18 N mm, which can
matter only for small torques; section 8.1 therefore adds it to the error of every resolved torque, and no resolved
torque exceeds 10% of itself with it. Its effect on a withheld twist bound is discussed in section 12.

### 8.3 Synthetic convergence and admission tests

`test_wing_aero_admission` checks the formulas on manufactured sequences: the weights remove an error that is
quadratic in 1/c and 1/s exactly (to 1e-12); the observed-order iteration recovers orders 0.8, 1.3 and 2.0
exactly; for 240 synthetic power laws with orders 0.6 to 2.5 in each direction and both signs, the estimate
is within U in every case (largest |error| / U in the log); the uncertainty formula is reproduced directly. The
admission logic is checked on a synthetic wing whose strip loads carry a mesh-dependent error:

* no floor: the relative error is U / |T| itself; a torque of exactly zero is "sign not resolved" and never
  admitted as a resolved torque; a nose-down couple well above its uncertainty is resolved;
* opposite signs (a): a couple that is negative on every mesh of the sequence and positive in the limit, so every
  weighted mesh has the sign opposite to the extrapolated torque: the torque is "sign not resolved", and the
  correction term alone makes U at least 62.5% of |T|;
* opposite signs (b): weighted meshes of both signs: "sign not resolved";
* the twist claim with a constructed structure (uniform torsional compliance k): with the unresolved torque of (a)
  a stiff structure (k = 1e-10 per N mm per mm) is admitted with torque and twist withheld (negligible) and a
  flexible one (k = 1e-4) is refused (unresolved); the bound integral and its lift effect are reproduced by an
  independent calculation; a resolved torque on a stiff structure is shown with its twist; the same load with a
  tip twist of 0.08 rad fails the one-way-coupling check; with every torque resolved but a twist too small to be
  resolved to 10% of itself, the load is admitted with only the twist withheld and the verdict names the twist,
  not the torque; on a flexible structure the same case is refused with the twist named as the reason;
* the decision is the conjunction of all rows, failures are named, the transfer residual is reported.

### 8.4 Two worked examples

**Editable course fixture** (`tests/fixtures/wing_lab_editable_browser.json`: course wing with bonded seams and
spars, alpha 4 deg, 15 m/s). The torque about this structure's shear-centre axis is a small difference of large
lift and pitching-moment terms, and it is not resolved by either sequence:

| Check | Standard | Fine |
|---|---|---|
| Root torque (N mm) | 1.767 ± 1.919 (109%: sign not resolved) | 1.950 ± 0.955 (49%: magnitude not resolved) |
| Torque at 25% span | 1.061 ± 1.690 (159%: sign not resolved) | 1.241 ± 0.860 (69%: magnitude not resolved) |
| Torque at 50% span | 0.347 ± 0.987 (285%: sign not resolved) | 0.474 ± 0.610 (129%: sign not resolved) |
| Torque at 75% span | -0.289 ± 0.824 (285%: sign not resolved) | -0.188 ± 0.339 (181%: sign not resolved; meshes of both signs) |
| Root force (N) | 4.201 ± 0.093 (2.2%) | 4.189 ± 0.038 (0.9%) |
| Root bending (N mm) | 816.1 ± 22.0 (2.7%) | 814.2 ± 9.0 (1.1%) |
| Lift consistency | 0.63% | 0.69% |
| Twist | bound 0.00125 deg; lift effect 0.016%: negligible | bound 0.00080 deg; lift effect 0.011%: negligible |
| One-way coupling | 0.004% | 0.005% |
| Verdict | admitted, torque and twist withheld | admitted, torque and twist withheld |

At the 75% cut the seven Fine meshes give -0.464, -0.555, -0.641, -0.116, -0.022, +0.086 and -0.265 N mm. The root
torque converges slowly under chordwise refinement: 9.77, 6.28, 4.78, 3.45, 2.84 and 2.29 N mm at 16, 24, 32, 48, 64
and 96 panels per surface (16 strips), while spanwise refinement changes it by less than 0.5 N mm (4.66 to 5.12 N mm
at 8 to 48 strips). This is the
behaviour behind the first review's finding (-3.8 against about -8.0 N mm on the 1.4 Standard mesh for the default
structure). The 0.2.0 build admitted the Fine load through the 10.67 N mm floor and refused the Standard load;
now neither torque is claimed, and both loads are admitted only because this structure's torsional stiffness makes
any twist the unresolved torque could cause negligible (at most 0.0008 deg on Fine), with torque and twist withheld
from all results. The per-mesh torques and the refinement series are printed by `test_aerostruct_twist`; the
engine's own cut torque of the delivered load differs from the admission value by at most 5.7e-14 N mm at the four
cuts (`test_aerostruct_aero_ui`).

**Wing with a mid-span station and its own structure** (400 mm semi-span, 160 to 90 mm chord, sweep 20 deg,
dihedral 7 deg, incidence 2, 0.5 and -2 deg at eta 0, 0.5 and 1, NACA 2412 to 0012, two bonded spars at 30% and
62% chord, 18 m/s, alpha 5 deg; torque about the structure's shear-centre axis; `validation/midspan_example.mjs`, log in
`validation/midspan_example.log`; the Standard admission of the same wing is also checked by `test_wing_aero_transfer`):

| Check | Standard | Fine |
|---|---|---|
| Root torque (N mm) | 22.35 ± 3.31 (14.8%: magnitude not resolved) | 22.58 ± 1.35 (6.0%: resolved) |
| Torque at 25% span | 19.47 ± 4.27 (22.0%: magnitude not resolved) | 19.59 ± 0.82 (4.2%: resolved) |
| Torque at 50% span | 12.64 ± 1.98 (15.7%: magnitude not resolved) | 12.77 ± 1.06 (8.3%: resolved) |
| Torque at 75% span | 5.93 ± 0.62 (10.5%: magnitude not resolved) | 5.92 ± 0.15 (2.6%: resolved) |
| Root force (N) | 6.05 ± 0.33 (5.5%, fails) | 6.02 ± 0.08 (1.4%) |
| Root bending (N mm) | 1050 ± 92 (8.7%, fails) | 1040 ± 23 (2.2%) |
| Lift consistency | 0.11% | 0.22% |
| Twist | negligible (lift effect of the bound 0.135%) | resolved: tip 0.0120 ± 0.0007 deg (largest dtheta / abs(theta) 7.2%) |
| One-way coupling | 0.114% | 0.116% |
| Verdict | NOT admitted (force, bending) | admitted, torque and twist shown |

On the Standard sequence the chordwise levels of this wing are not yet asymptotic, so U is large and the load is
refused; the Fine sequence resolves the torque at every cut and the twist at every station, and the coupled result
is shown with both.

### 8.5 Twist claims on real structures (`test_aerostruct_twist`)

The course wing's load (alpha 4 deg, 15 m/s) on five structures with its outer shape, both sequences. "Bound" is
the largest |theta| + dtheta along the span, "lift effect" its effect on the lift (criterion 1%), "one-way" the
lift effect of the computed twist itself (criterion 2%):

| Structure | Standard | Fine |
|---|---|---|
| Editable fixture (shell and spars 2000 MPa) | withheld: no torque resolved; bound 0.00125 deg, lift effect 0.016% | withheld: no torque resolved; bound 0.00080 deg, lift effect 0.011% |
| Low-GJ fixture (shell and spars 10 MPa) | refused: bound 0.25 deg, lift effect 3.19% | refused: bound 0.16 deg, lift effect 2.24% |
| Forward spars (12% and 35% chord) | withheld: root torque resolved (8%), 25 to 75% cuts not (11 to 16%); lift effect 0.157% | shown: torques resolved (4, 6, 5, 7%); tip twist -0.01133 ± 0.00072 deg; one-way 0.139% |
| Forward spars, GJ / 4 (500 MPa) | withheld: lift effect 0.63% | shown: tip twist -0.0453 ± 0.0029 deg; one-way 0.56% |
| Forward spars, GJ / 40 (50 MPa) | refused: one-way 5.6%, lift effect 6.3% | refused: twist resolved (-0.453 ± 0.029 deg) but one-way 5.6% |

The low-GJ fixture has exactly the same unresolved torques as the editable fixture: the difference between
"withheld" and "refused" comes only from the structure's torsional compliance, as the review asked. The softest
forward-spar structure has a resolved twist that is too large for a load computed on the rigid wing.

Validation of the bound: `validation/reference_study.mjs` stores the course wing's reference load (references of
section 8.1, delivered on the fixture's strips) with its uncertainty. On every structure and sequence the suite
solves the beam under that reference load and checks at the 16 cut stations and the tip that
|theta - theta_ref| <= dtheta + dtheta_ref (largest ratio 0.42) and the stricter |theta - theta_ref| + dtheta_ref <=
dtheta (largest ratio 0.74), so the delivered bound covers the twist error even when the reference's own
uncertainty is counted as error. The Standard and Fine twists agree within the sum of their bounds on every
structure. The compliance used by the bound reproduces the beam's own twist within 0.73% (editable fixture) and
0.46% (the swept, dihedral, twisted two-spar wing of section 8.4) when integrated with the beam's internal torque.

### 8.6 Physical consistency of the global loads

Extrapolated pressure lift against Trefftz-plane lift (the admission criterion, at most 2%) and pressure drag
against induced drag (reported), from the reference study log:

| Wing | CL pressure / Trefftz, Standard | Fine | CDp / CDi, Standard | Fine |
|---|---|---|---|---|
| course, 4 deg | 0.5208 / 0.5241 (0.63%) | 0.5193 / 0.5229 (0.69%) | 0.01259 / 0.01269 (-0.8%) | 0.01259 / 0.01267 (-0.6%) |
| course, 8 deg | 0.8499 / 0.8585 (1.01%) | 0.8475 / 0.8568 (1.10%) | 0.03318 / 0.03403 (-2.5%) | 0.03346 / 0.03399 (-1.6%) |
| dihedral 6 deg | 0.5232 / 0.5257 (0.48%) | 0.5219 / 0.5246 (0.52%) | 0.01273 / 0.01274 (-0.1%) | 0.01272 / 0.01273 (-0.1%) |
| sweep 25 deg | 0.5026 / 0.5040 (0.28%) | 0.5020 / 0.5037 (0.34%) | 0.01225 / 0.01210 (+1.2%) | 0.01220 / 0.01214 (+0.5%) |
| NACA 0012, AR 6 | 0.3925 / 0.3948 (0.59%) | 0.3919 / 0.3944 (0.64%) | 0.00815 / 0.00840 (-3.0%) | 0.00833 / 0.00839 (-0.7%) |
| washout | 0.5420 / 0.5454 (0.63%) | 0.5404 / 0.5442 (0.70%) | 0.01388 / 0.01399 (-0.8%) | 0.01388 / 0.01394 (-0.4%) |
| combined | 0.7632 / 0.7657 (0.33%) | 0.7622 / 0.7653 (0.41%) | 0.02481 / 0.02466 (+0.6%) | 0.02478 / 0.02458 (+0.8%) |

In exact potential flow the pressure drag equals the induced drag and the pressure lift equals the Trefftz-plane
lift; the agreement to about 1% (lift) and 3% (drag) is a global check of the discrete solution, its wake and its
extrapolation. The delivered strips sum to the extrapolated root wrench to rounding (largest difference
6.5e-12 on the course wing, Fine), and the structural engine reports the wrench of the line loads it actually
applies (section 5.3).

The side force with dihedral and the chordwise force reach the structure in full (section 5); on the course
wing at 4 deg the extrapolated semi-wing Fx is about -0.19 N and Fy about 0.077 N.

### 8.7 Independent checks of the panel method (unchanged from the 1.4 review build, rerun here)

| Suite | Checks | Independent reference and key result |
|---|---|---|
| `test_wing_aero_kernels` | 21 | Adaptive quadrature and a polar self-integral: source and doublet influences agree to 1.2e-14; solid-angle closure 6.7e-16; far-field approximation 1.1e-3 at six diameters |
| `test_wing_aero_closed_bodies` | 34 | Exact potential flow on a sphere and on Lamb ellipsoids (including a 1:3:0.12 wing-like ellipsoid): the area-RMS doublet error converges at observed order 1.9 to 2.1; net force on the closed bodies at most 4.2e-15 q |
| `test_wing_aero_trefftz` | 23 | Exact elliptic loading: induced-drag error -0.46% with 16 sine strips for the reconstruction against -3.64% for the midpoint rule; with 10 deg dihedral the lift scales with cos(dihedral) |
| `test_wing_aero_conformal` | 28 | Exact Karman-Trefftz and Joukowski sections on elliptic wings, AR 8 to 64: thickness-flow Cp RMS error 3.5e-3 at 64 panels per surface; extrapolated 2-D lift slope (pressure) -0.85% to -0.94% from the exact value at 48 to 80 panels; cambered zero-lift angle -1.815 deg against -1.843 deg exact |
| `test_wing_aero_vlm` | 7 | Independent thin-wing vortex-lattice method on a rectangular AR 6 wing (Richardson limit 4.214 per rad): the Trefftz-plane lift slopes of NACA 0006 to 0015 extrapolated to zero thickness give 4.215 per rad (+0.03%); thickness effect d ln(CL_alpha)/d(t/c) = 0.539 against about 0.554 |
| `test_wing_aero_wing` | 65 | Mirror image against an explicit full span (1.9e-12); angle of attack against geometric incidence (0.2%, the body-axis wake); six wings (rectangular, course, elliptic closed and open tip, delta, swept with dihedral, twist and a DAT airfoil) on three meshes; both course fixtures with the target-lift angle; input guards; tip closure (section 4: flat-cap divergence, rounded-tip side force 0.0740, 0.0750, 0.0756, 0.0761 N at 16 to 48 panels per surface and 0.0773, 0.0751, 0.0756, 0.0757 N at 8 to 24 strips) |

## 9. Study files

The study IO module is the Wing Lab 1.3 module plus two optional blocks:

* `study.aerodynamics` (version 3): speed, density, angle of attack, optional viscosity and speed of sound, and
  the sequence (`"standard"` or `"fine"`); limits equal the solver's.
* `study.aeroLoad` (version 4): the applied aerodynamic load, stored as the solved levels of the sequence
  (kind `"panelSequence"`, label, sequence, the flow, the SHA-256 of the outer wing shape, and for each of the
  seven meshes its strip rows and coefficients). The extrapolated strips and the admission are recomputed from
  them when the study is opened. On import: exactly the seven meshes of the named sequence, contiguous strips
  from 0 to the semi-span, at most 80 strips per mesh, finite numbers, a rounded-tip record for every mesh
  that ends at the tip (a flat-cap load is refused), and the shape hash must equal that of the study's own
  geometry (a load solved for another wing is refused). A prescribed flight load cannot be combined with an
  applied aerodynamic load.

A study is written as version 4 only when an aerodynamic load is applied, as version 3 when only aerodynamic
settings are present, and otherwise exactly as Wing Lab 1.3 writes it. Share links never carry an applied
aerodynamic load (its size); the link is refused with a message. The 1.3 study-IO regression suite (1062
checks) passes against this module.

The shape hash covers exactly the inputs of the aerodynamic surface: planform, semi-span, root and tip chord,
sweep, dihedral, sweep and twist reference fractions, and the airfoil and incidence stations (canonical JSON,
defaults written out). Structural changes (ribs, skins, spars, materials) keep an applied load valid; any change
of the outer shape marks it stale, and the structural solve refuses it until the sequence is run again.

## 10. The separate site

`build_wing_aerostruct.py` writes `site-aerostruct/` and refuses to write into `docs/`:

| Path | Content |
|---|---|
| `index.html`, `wing-lab.html` | the standalone Wing AeroStruct page (the second name keeps the Truss Lab's links inside this site) |
| `truss-lab.html` | the stable Truss Lab page, copied unchanged |
| `wing-aero/` | `aero_bundle.js` (airfoils, geometry, panel core) and `wing_aero_worker.js`, loaded by a content hash |
| `wing-print/` | the unchanged STL/DXF/STEP Worker and its vendored files |
| `BUILD.json` | version, build time, worker hashes and SHA-256 of every source file |

Nothing has been published. To publish later, copy the contents of `site-aerostruct/` to the root of a new
site; do not copy it into `docs/`.

## 11. Tests and logs

`run_tests.sh [log-directory]` builds the site and runs every suite; each writes its full output to
`<suite>.log` and `SUMMARY.txt` lists exit code, time and last line. The real-browser suite runs when Playwright
with Chromium is available. The slow reference study runs only with `WING_AEROSTRUCT_REFERENCE=1`; its stored
results are checked in every run by `test_wing_aero_admission`.

| Suite | Checks | What it covers |
|---|---|---|
| `test_wing_aero_kernels` | 21 | influence kernels against adaptive quadrature (section 8.7) |
| `test_wing_aero_closed_bodies` | 34 | sphere and ellipsoids against exact potential flow (section 8.7) |
| `test_wing_aero_trefftz` | 23 | Trefftz-plane lift and induced drag against exact elliptic loading (section 8.7) |
| `test_wing_aero_conformal` | 28 | exact conformal sections on elliptic wings (section 8.7) |
| `test_wing_aero_wing` | 65 | wing-level properties, six wings, course fixtures, input guards, tip closure (sections 4 and 8.7) |
| `test_wing_aero_vlm` | 7 | independent vortex-lattice method (section 8.7) |
| `test_wing_aero_admission` | 259 | weights, observed order, the uncertainty formula, 240 synthetic power laws, admission logic without a floor (zero torque, opposite-sign meshes of both kinds, a constructed structure: negligible, unresolved and resolved twist, twist withheld with resolved torque, one-way coupling), validation of the Standard and Fine sequences of three wings against the stored references (estimates within U, resolved torques within 10% of themselves, resolved signs correct), the stored seven-wing summary including the sign checks, cross-term size (sections 6 to 8) |
| `test_wing_aero_transfer` | 28 | strip wrenches, the six-component representation against an independent load line, cut wrenches, PCHIP, delivery stations, a manufactured sequence, refusal of a flat-cap sequence, end to end through the engine fork with sweep, dihedral and twist (sections 5 and 6) |
| `test_aerostruct_engine_fork` | 128 | identical to Wing Lab 1.3 without an aerodynamic load; six-component strips against independent references; equivalences with 1.3 loads; refusals; `engine_fork.diff` current (section 5.3) |
| `test_aerostruct_twist` | 96 | the compliance integral against the beam's own twist; five structures on both sequences (withheld, refused, shown as expected); no floor; the resolved and sign rules; the twist bound against the reference load (both the plain and the strict form); Standard against Fine; the reviewer's Fine case with its per-mesh torques; the per-mesh root torques of the fixture; the withheld twist with the cross term added (sections 8.4, 8.5 and 12) |
| `test_wing_aero_worker` | 18 | the built Worker in a VM: sequence requests equal direct calls, progress, cached models, target lift on the extrapolated lift, errors |
| `test_aerostruct_study_io` | 51 | runs the unchanged Wing Lab 1.3 study-IO suite (1062 checks) against this module; version 3 and 4 round trips; every refusal rule of the applied load; share links; size (section 9) |
| `test_aerostruct_aero_ui` | 35 | the Aerodynamics panel in jsdom with the real engines: sequence, results, apply, admission table without a floor, withheld marks, small percentages, status line, a low-GJ structure refused, CSV, stale shape, unsupported structure, target lift, refusals, restore |
| `test_aerostruct_page` | 44 | the built page in jsdom, driven like a user on the editable course fixture: Standard admitted with torque and twist withheld (views disabled, charts, tip table, reactions and cut moments without the torque, report, status line), the low-GJ structure refused and restored, Fine admitted with the root torque reported as not resolved, version-4 autosave, undo and redo, stale shape, removal, share link, self-contained site, Wing Lab unchanged |
| `test_aerostruct_browser` | 64 | real Chromium over HTTP at 390, 768 and 1440 px: the sequence in the Worker, cached second angle, no overflow (also with the admission table and the withheld reaction rows), Standard admitted with torque and twist withheld (views disabled, reactions without the torque), Fine admitted with all six components in the beam and the torque reported as not resolved, storage keys, links, no page errors; screenshots |
| `validation/reference_study.mjs` | 252 cases | sections 8.1, 8.2 and the reference load of section 8.5 (run with `WING_AEROSTRUCT_REFERENCE=1`) |

All 15 suites pass in the included run (901 checks, plus the 1062 checks of the Wing Lab 1.3 study-IO suite),
and the reference study passes; `test-logs/SUMMARY.txt` gives the exit codes and times. The review archive was
also checked on a clean clone of commit `5ab2498` with only the two new folders added (all suites pass, `git
status` shows only those folders, the rebuilt site is byte-identical) and as a standalone folder without git, where
the page suite skips its git check of Wing Lab and reports 43 checks (`test-logs/PACKAGE_VERIFICATION.txt`).

## 12. Limitations and what is not verified

* Potential flow only: no stall, separation, transition, viscous drag or leading-edge vortex lift; Mach at most
  0.3 without compressibility correction; symmetric flight; the course wings fly at Reynolds numbers near 1e5,
  where real printed wings lose lift slope and maximum lift (shown as a warning).
* Rigid wing: no aeroelastic redistribution. The one-way-coupling check (section 7.3) refuses a load whose computed
  twist would change the lift by more than 2%; below that the redistribution is neglected, not computed.
* Flat wake along body +x; sharp aerodynamic trailing edge; rounded aerodynamic tip (section 4).
* The tolerances (10% for torque and twist, 5% for force and bending, 2% lift consistency, 1% lift effect for a
  withheld twist bound, 2% one-way coupling) and the section lift slope 2 pi of the twist criteria are engineering
  choices for a teaching tool, stated in section 7; they are not standards.
* U is an estimate validated on the seven wings of section 8.1, on synthetic sequences and on the structures of
  section 8.5; it is not a proof of an error bound for every possible wing. Wings far from the validated set (very
  thin sections, very high sweep, many stations) are covered only by the same estimator.
* U does not contain the separability cross term of section 8.2 (at most 0.18 N mm of torque on the seven wings).
  The stress test of section 8.1 adds it to every resolved torque. For a withheld twist, `test_aerostruct_twist`
  adds the largest estimate (0.184 N mm) to U_T on the whole span of the editable fixture: dtheta at the tip grows
  from 0.00058 to 0.00079 deg (Fine) and from 0.00119 to 0.00140 deg (Standard), and the lift effect of the bound
  from 0.011% to 0.013% (Fine) and from 0.016% to 0.018% (Standard), far below 1%.
* The lift is the denominator of the twist criteria (sections 7.2 and 7.3), so near zero lift the coupled result is
  refused for any unresolved torque and for any non-zero computed twist.
* The twist bound integrates the upper envelope of U_T between 16 cuts; U_T is not evaluated between the cuts. It
  uses the beam model's torsional compliance (St-Venant torsion of the projected sections, as in Wing Lab), so it
  inherits that model's limits (no warping restraint at the root, no local joint flexibility).
* With torque and twist withheld, the displayed displacements still contain the computed twist, at most the bound
  times the chord (0.002 mm on the editable fixture with Fine, 0.0035 mm with Standard); the root reactions, cut
  moments and reports show only the bending part of the moment.
* Not run: comparison with wind-tunnel data for low-Reynolds-number printed wings; comparison with an external
  panel code (for example VSPAERO or the 3-D panel mode of XFLR5); a relaxed wake; aeroelastic iteration.

## 13. Provenance and licensing

All aerodynamic code in this folder is original and implements published theory: Hess and Smith (1967),
Morino and Kuo (1974), Maskew (1987, NASA CR-4023), Katz and Plotkin (2001), Van Oosterom and Strackee (1983),
Newman (1986), Richardson (1911), Roache (1998), Celik et al. (2008), Fritsch and Carlson (1980); the test
references use Lamb (ellipsoids), Carlson (elliptic integrals), the Karman-Trefftz and Joukowski conformal maps,
Glauert lifting-line theory and a standard vortex-lattice method. No code, header, binary or documentation from
AirFrame, Apame or Afeme (or any other panel program) was used or consulted; the AirFrame archive was treated only
as capability context. The structural engine is the repository's own Wing Lab engine with the changes listed in
`engine_fork.diff`; the shared Wing Lab modules are reused unchanged; the vendored third-party files in
`site-aerostruct/wing-print/` are the Wing Lab copies with their licence files.

## 14. Files

| File | Role |
|---|---|
| `wing_aero_panel.js` | panel core, rounded tip, strip loads, mesh sequences, extrapolation, uncertainty, admission (browser global `WingAeroPanel`, Node module) |
| `engine.js`, `engine_fork.diff` | structural engine fork (six-component aerodynamic strip loads) and its complete difference from `web/engine.js` |
| `wing_aero_worker.js` | Web Worker: sequence and single-mesh requests, progress, cached models |
| `wing_aero_ui.js` | Aerodynamics panel (`WingAeroUI.mount(host, adapter)`) and pure helpers (record, delivered load, structural cuts, admission) |
| `wing_study_io.js` | Wing Lab 1.3 study IO plus the version 3 and version 4 blocks |
| `wing_aerostruct_template.html` | the page template |
| `build_wing_aerostruct.py` | builds `site-aerostruct/` |
| `validation/reference_study.mjs`, `admission_reference.json`, `reference_study.log` | reference study, stored references and its log |
| `validation/midspan_example.mjs`, `midspan_example.log` | the mid-span-station worked example of section 8.4 and its output |
| `aero_test_support.mjs`, `test_*.mjs`, `run_tests.sh` | independent references, test suites, runner |
| `ci/wing-aerostruct-tests.yml` | proposed CI workflow (not installed in `.github/workflows/`) |
| `test-logs/` | logs of the run reported here |
