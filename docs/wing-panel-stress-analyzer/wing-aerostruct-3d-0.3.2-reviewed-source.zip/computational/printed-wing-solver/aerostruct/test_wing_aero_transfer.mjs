// Six-component aerodynamic-to-structural transfer (aero side and end to end):
//  1. strip wrenches of a solve sum exactly to the semi-wing pressure resultant (all six components);
//  2. the strip representation (uniform force on the quarter-chord line + uniform couple) reproduces every strip's
//     force and moment: checked with an INDEPENDENT load line (own geometry convention) and Simpson quadrature;
//  3. outboard (cut) wrenches: exact sums at strip boundaries, independent partial-strip integrals inside strips;
//  4. PCHIP cumulative functions are exact at the level's stations and keep monotone data monotone;
//  5. delivery stations: rounded-tip zone merged, snapped onto structural stations, 0.1 mm rule, wide strips halved;
//  6. sequence combination: on synthetic levels whose error is a quadratic polynomial in 1/c and 1/s, the delivered
//     root wrench is exact and interior cut loads match the exact distribution; a flat-cap sequence is refused;
//  7. end to end through the structural engine fork: the beam's applied wrench equals the delivered load and the
//     extrapolation of the levels exactly, and its normal-cut torques equal the admission's delivered torques.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js'), EF = require('./engine.js'), UI = require('./wing_aero_ui.js'), Sp = require('../web/wing_spars.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], sub = (a, b) => a.map((v, i) => v - b[i]), dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
// independent load line (x aft, y span, z up; incidence about the twist reference, LE sweep with the reference shift)
function physicalPoint(g, y, x) {
  const L = g.semiSpan, c = g.rootChord + (g.tipChord - g.rootChord) * y / L, eta = y / L, ss = g.stations || []; let inc = 0;
  if (ss.length) { let j = 0; while (j < ss.length - 2 && eta > ss[j + 1].eta) j++; const t = (eta - ss[j].eta) / (ss[j + 1].eta - ss[j].eta); inc = (1 - t) * ss[j].incidenceDeg + t * ss[j + 1].incidenceDeg; }
  const a = inc * Math.PI / 180, p = (g.twistReferenceFraction ?? .25) * c, xle = y * Math.tan((g.sweepDeg || 0) * Math.PI / 180) + (g.sweepReferenceFraction || 0) * (g.rootChord - c), zle = y * Math.tan((g.dihedralDeg || 0) * Math.PI / 180);
  return [xle + p + (x - p) * Math.cos(a), y, zle - (x - p) * Math.sin(a)];
}
const lineAt = (g, y) => physicalPoint(g, y, .25 * (g.rootChord + (g.tipChord - g.rootChord) * y / g.semiSpan));
const simpson = (fn, a, b, n = 400) => { const out = fn(a).map(() => 0); for (let k = 0; k <= n; k++) { const w = k === 0 || k === n ? 1 : k % 2 ? 4 : 2, v = fn(a + (b - a) * k / n); for (let i = 0; i < v.length; i++) out[i] += w * v[i]; } return out.map(v => v * (b - a) / (3 * n)); };

// 1. strip wrenches = semi-wing resultant
const raw = { semiSpan: 400, rootChord: 160, tipChord: 90, naca: '2412', sweepDeg: 20, dihedralDeg: 7, sweepReferenceFraction: 0.25, twistEnabled: true, twistReferenceFraction: 0.25, stations: [{ eta: 0, airfoil: '2412', incidenceDeg: 2 }, { eta: 0.5, airfoil: '2412', incidenceDeg: 0.5 }, { eta: 1, airfoil: '0012', incidenceDeg: -2 }] };
const g = W.aeroGeometry(raw);
for (const tipClosure of ['rounded', 'flat']) {
  const r = W.solve(g, { speed: 18, alphaDeg: 5 }, { chordPanels: 16, spanPanels: 12, tipClosure }), rows = W.stripWrenches(r), sum = rows.reduce((t, w) => t.map((v, i) => v + w[2 + i]), [0, 0, 0, 0, 0, 0]);
  const F = r.semiWing.force_N, M = r.semiWing.momentAboutRootOrigin_Nmm, e = Math.max(...F.map((v, i) => Math.abs(v - sum[i]) / Math.hypot(...F)), ...M.map((v, i) => Math.abs(v - sum[3 + i]) / Math.hypot(...M)));
  log(`${tipClosure} tip: ${rows.length} strip wrenches sum to the semi-wing resultant within ${e.toExponential(1)} (relative); F = [${F.map(v => v.toFixed(4)).join(', ')}] N`);
  ok(e < 1e-13 && rows[0][0] === 0 && Math.abs(rows.at(-1)[1] - g.semiSpan) < 1e-9 && rows.every((w, i) => !i || w[0] === rows[i - 1][1]), `${tipClosure}: strips contiguous from root to tip and conservative`);
}
const res = W.solve(g, { speed: 18, alphaDeg: 5 }, { chordPanels: 16, spanPanels: 12 }), rows = W.stripWrenches(res);
// 2. representation reproduces every strip (independent line and quadrature)
{
  const rep = W.stripRepresentation(g, rows); let worst = 0;
  for (let j = 0; j < rows.length; j++) {
    const s = rep[j], br = [s.y0, ...g.stations.map(t => t.eta * g.semiSpan).filter(y => y > s.y0 && y < s.y1), s.y1];
    const W6 = [0, 0, 0, 0, 0, 0];
    for (let k = 1; k < br.length; k++) { const v = simpson(y => [...s.f, ...cross(lineAt(g, y), s.f).map((m, d) => m + s.m[d])], br[k - 1], br[k]); for (let d = 0; d < 6; d++) W6[d] += v[d]; }
    for (let d = 0; d < 6; d++) worst = Math.max(worst, Math.abs(W6[d] - rows[j][2 + d]) / Math.max(1, Math.abs(rows[j][2 + d])));
  }
  log(`representation: Simpson integrals of f and r x f + m on an independent quarter-chord line reproduce all ${rows.length} strips' six components within ${worst.toExponential(1)}`);
  ok(worst < 1e-9, 'uniform force on the load line plus the restoring couple reproduces each strip exactly');
  // the library's own load line equals the independent one
  let dl = 0; for (const y of [0, 37, 150, 200, 333, 400]) dl = Math.max(dl, Math.hypot(...sub(W.loadLinePoint(g, y), lineAt(g, y))));
  ok(dl < 1e-10, `load line agrees with the independent geometry convention (${dl.toExponential(1)} mm)`);
}
// 3. outboard wrenches
{
  const rep = W.stripRepresentation(g, rows), total = rows.reduce((t, w) => t.map((v, i) => v + w[2 + i]), [0, 0, 0, 0, 0, 0]);
  ok(W.outboardOfStation(g, rep, 0).every((v, i) => Math.abs(v - total[i]) < 1e-12 * Math.max(1, Math.abs(total[i]))), 'outboard of the root = total');
  for (const k of [3, 7]) { const y = rows[k][0], tail = rows.slice(k).reduce((t, w) => t.map((v, i) => v + w[2 + i]), [0, 0, 0, 0, 0, 0]), o = W.outboardOfStation(g, rep, y); ok(o.every((v, i) => Math.abs(v - tail[i]) < 1e-11 * Math.max(1, Math.abs(tail[i]))), `outboard of strip boundary ${k} = sum of the strips beyond`); }
  const j = 5, s = rep[j], ys = s.y0 + 0.37 * (s.y1 - s.y0), tail = rows.slice(j + 1).reduce((t, w) => t.map((v, i) => v + w[2 + i]), [0, 0, 0, 0, 0, 0]);
  const part = simpson(y => [...s.f, ...cross(lineAt(g, y), s.f).map((m, d) => m + s.m[d])], ys, s.y1), o = W.outboardOfStation(g, rep, ys);
  ok(o.every((v, i) => Math.abs(v - tail[i] - part[i]) < 1e-9 * Math.max(1, Math.abs(v))), 'outboard of a point inside a strip = strips beyond + independent partial integral');
}
// 4. PCHIP cumulative functions
{
  const cum = W.cumulativeWrench(rows);
  let e = 0; for (let k = 0; k <= rows.length; k++) { const y = k < rows.length ? rows[k][0] : rows.at(-1)[1], exact = rows.slice(k).reduce((t, w) => t.map((v, i) => v + w[2 + i]), [0, 0, 0, 0, 0, 0]); e = Math.max(e, ...cum.at(y).map((v, i) => Math.abs(v - exact[i]))); }
  ok(e < 1e-12, `cumulative function exact at every station (${e.toExponential(1)})`);
  let mono = true, prev = Infinity; for (let y = 0; y <= g.semiSpan; y += g.semiSpan / 997) { const v = cum.at(y)[2]; if (v > prev + 1e-15) mono = false; prev = v; }
  ok(mono, 'cumulative vertical force (monotone data) stays monotone between stations');
  const p = W.pchip([0, 1, 2, 3], [0, 1, 1, 2]); ok(Math.abs(p(1.5) - 1) < 1e-15 && p(0.5) > 0 && p(0.5) < 1, 'PCHIP keeps a flat segment flat and stays within the data');
}
// 5. delivery stations
{
  const L = 300, lv = [[0, 30, 0, 0, 0, 0, 0, 0], [30, 80, 0, 0, 0, 0, 0, 0], [80, 120, 0, 0, 0, 0, 0, 0], [120, 230, 0, 0, 0, 0, 0, 0], [230, 296, 0, 0, 0, 0, 0, 0], [296, 297, 0, 0, 0, 0, 0, 0], [297, 299, 0, 0, 0, 0, 0, 0], [299, 300, 0, 0, 0, 0, 0, 0]];
  const st = W.deliveryStations(lv, { start_mm: 296, length_mm: 4, strips: 3 }, L, [79.9, 150, 230.05]);
  log(`delivery stations from [0, 30, 80, 120, 230, 296, 297, 299, 300] with snap stations 79.9, 150, 230.05: [${st.map(v => +v.toFixed(3)).join(', ')}]`);
  ok(st[0] === 0 && st.at(-1) === L && st.includes(296) && !st.some(y => y > 296 && y < L), 'the rounded-tip zone is one strip that starts where the rounding starts');
  ok(st.includes(79.9) && st.includes(230.05) && !st.includes(80) && !st.includes(230), 'nodes within 0.25 mm of a structural station are moved onto it');
  ok(st.every((y, i) => !i || y - st[i - 1] >= 0.1) && st.every(y => [79.9, 150, 230.05].every(t => t === y || Math.abs(t - y) >= 0.1)), '0.1 mm rule for every node and station');
  ok(st.slice(1).every((y, i) => y - st[i] <= L / 32 + 1e-9 || false) || st.slice(1).some((y, i) => y - st[i] > L / 32), 'wide strips are halved once');
  ok(st.includes(175.025) && st.includes(263.025), 'the 110 mm and 66 mm strips are halved');
}
// 6. synthetic sequence: quadratic error in 1/c and 1/s is removed exactly at the root, interior cuts are close
{
  const L = g.semiSpan, q = y => [-.01 * (1 - (y / L) ** 2), .002, .03 * (1 - (y / L) ** 2) * (1 + .3 * y / L)], e = y => [.004, -.001, .01 * (1 - y / L)];
  const stripsFor = (c, s) => {
    const ys = W.spanStations(g, s, 'sine'), eps = 3 / c + 20 / (c * c) - 2 / s + 9 / (s * s);
    return ys.slice(1).map((y1, i) => { const y0 = ys[i], F = simpson(y => [...q(y), ...e(y)], y0, y1), Fv = F.slice(0, 3).map((v, d) => v + eps * F[3 + d]), M = simpson(y => cross(lineAt(g, y), q(y).map((v, d) => v + eps * e(y)[d])), y0, y1); return [y0, y1, ...Fv, ...M]; });
  };
  const seq = { sequence: 'standard', levels: W.sequenceMeshes('standard').map(m => ({ ...m, strips: stripsFor(m.chordPanels, m.spanPanels), coefficients: { CL: 0, CLTrefftz: 0, CDpressure: 0, CDiTrefftz: 0, Cm: 0 }, roundedTip: null })) };
  const comb = W.combineSequence(g, seq, {});
  const exactTotal = simpson(y => [...q(y), ...cross(lineAt(g, y), q(y))], 0, L, 4000);
  const eRoot = Math.max(...comb.deliveredRootWrench.map((v, i) => Math.abs(v - exactTotal[i]) / Math.max(1e-9, Math.abs(exactTotal[i]))));
  ok(eRoot < 1e-9, `synthetic levels: delivered root wrench equals the exact (error-free) load (${eRoot.toExponential(1)})`);
  let eCut = 0; for (const k of [5, 11, 17]) { const y = comb.stations[k], ex = simpson(t => q(t), y, L, 2000), del = comb.strips.slice(k).reduce((a, r) => a.map((v, d) => v + r[2 + d]), [0, 0, 0]); eCut = Math.max(eCut, ...del.map((v, d) => Math.abs(v - ex[d]) / Math.max(Math.abs(exactTotal[d]), 1e-9))); }
  log(`synthetic sequence (error = 3/c + 20/c^2 - 2/s + 9/s^2 times a second load shape): root wrench error ${eRoot.toExponential(1)}, interior cut forces within ${eCut.toExponential(1)} of the root force`);
  ok(eCut < 2e-3, 'synthetic levels: interior cut forces match the exact distribution (PCHIP between different strip grids)');
  ok(Math.abs(comb.weights.reduce((t, w) => t + w.weight, 0) - 1) < 1e-12, 'level weights sum to one');
}
// 6b. a real sequence with the diagnostic flat tip cap is refused for the structure (its cap pressure is not in the load)
{
  const small = { semiSpan: 300, rootChord: 120, tipChord: 80, naca: '0012' }, flat = W.runSequence(small, { speed: 15, alphaDeg: 4 }, 'standard', { tipClosure: 'flat' });
  let msg = null; try { W.combineSequence(small, flat, {}); } catch (e) { msg = e.message; }
  ok(flat.tipClosure === 'flat' && flat.levels.every(l => l.tipCap && !l.roundedTip) && /flat tip cap leaves its pressure out/.test(msg || ''), `flat-cap sequence refused for the structure: ${msg}`);
  msg = null; try { W.combineSequence(small, { ...flat, tipClosure: undefined }, {}); } catch (e) { msg = e.message; }
  ok(/flat tip cap/.test(msg || ''), 'refused also when only the levels report the flat cap');
  ok(W.combineSequence(small, W.runSequence(small, { speed: 15, alphaDeg: 4 }, 'standard'), {}).strips.length > 0, 'the same wing with the rounded tip (default) is accepted');
}
// 7. end to end through the structural engine fork
{
  const spar = { fraction: .3, length: 400, topWidth: 8, topThickness: .8, bottomWidth: 8, bottomThickness: .8, webThickness: .6, material: { ...Sp.MAT } };
  const sgeo = { ...raw, modules: 1, rodFractions: [], interiorRibs: 2, spars: [spar, { ...spar, fraction: .62 }], skin: 1.2, te: 1.2 };
  const gE = EF.makeGeometry(sgeo), t0 = Date.now(), seq = W.runSequence(gE, { speed: 18, alphaDeg: 5 }, 'standard');
  const snap = [...EF.ribStations(gE), ...EF.seams(gE), ...gE.stations.map(s => s.eta * gE.semiSpan), ...gE.spars.map(s => s.length)];
  const comb = W.combineSequence(gE, seq, { snapStations: snap });
  const input = { geometry: sgeo, assembly: { seamsBonded: true }, load: { kind: 'custom', items: [] }, aeroLoad: UI.engineLoad(comb, 'test'), nSections: 5 };
  const R = EF.solve(input), a = R.analysis3D, P0 = a.nodes[0];
  const extrap = seq.weights.reduce((t, w) => { const l = seq.levels.find(v => v.chordPanels === w.chordPanels && v.spanPanels === w.spanPanels), s = l.strips.reduce((u, r) => u.map((v, i) => v + r[2 + i]), [0, 0, 0, 0, 0, 0]); return t.map((v, i) => v + w.weight * s[i]); }, [0, 0, 0, 0, 0, 0]);
  const given = [...extrap.slice(0, 3), ...sub(extrap.slice(3), cross(P0, extrap.slice(0, 3)))];
  const eF = Math.max(...[0, 1, 2].map(i => Math.abs(a.appliedWrench.force[i] - given[i]))), eM = Math.max(...[0, 1, 2].map(i => Math.abs(a.appliedWrench.momentAboutRoot[i] - given[3 + i])));
  log(`end to end (sweep 20, dihedral 7, twist, ${comb.strips.length} delivered strips, Standard sequence ${((Date.now() - t0) / 1000).toFixed(1)} s): beam applied F = [${a.appliedWrench.force.map(v => v.toFixed(5)).join(', ')}] N, M about the root node = [${a.appliedWrench.momentAboutRoot.map(v => v.toFixed(3)).join(', ')}] N mm; difference from the weighted sum of the meshes ${eF.toExponential(1)} N, ${eM.toExponential(1)} N mm`);
  ok(eF < 1e-12 && eM < 1e-9, 'the beam receives exactly the extrapolated six-component resultant');
  ok(Math.abs(a.appliedWrench.momentAboutRoot[0]) > 100 && Math.abs(comb.deliveredRootWrench[1]) > 0.05, 'dihedral case: the spanwise force and every moment component are carried');
  const adm = UI.admit(W, gE, UI.recordFromSequence(seq, 'x'.repeat(64)), comb, R);
  for (const r of adm.rows.filter(x => x.kind === 'torque')) ok(Math.abs(r.transferResidual) < 1e-9 * Math.max(1, Math.abs(r.value)), `${r.label}: beam cut torque equals the delivered torque (${r.transferResidual.toExponential(1)} N mm)`);
  log(`admission on this structure: ${adm.admitted ? 'admitted' : 'not admitted'}; ${adm.rows.map(r => `${r.label} ${(100 * r.measure).toFixed(1)}%`).join('; ')}`);
}
console.log(`test_wing_aero_transfer: ${checks} checks passed`);
