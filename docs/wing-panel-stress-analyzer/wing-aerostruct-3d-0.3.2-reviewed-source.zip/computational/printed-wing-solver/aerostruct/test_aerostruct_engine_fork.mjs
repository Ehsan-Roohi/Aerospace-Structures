// Wing AeroStruct structural engine fork (aerostruct/engine.js):
//  A. without an aerodynamic load every result is identical to the unchanged Wing Lab 1.3 engine (web/engine.js);
//  B. six-component aerodynamic strip loads are carried exactly through the spatial beam: the applied wrench and the
//     normal-cut resultants equal INDEPENDENT references (own load-line geometry, own Simpson quadrature, own
//     plane crossing), reactions balance them, and two classical equivalences hold to round-off (z-only strips on the
//     load line = the 1.3 distributed line loads; a pure couple = a force pair);
//  C. refusals (closed tip, flight lift, malformed strips, near-coincident stations, structures outside the spatial
//     beam's admission);
//  D. aerostruct/engine_fork.diff is exactly the change set (so the review reads the real diff).
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const require = createRequire(import.meta.url), here = path.dirname(fileURLToPath(import.meta.url));
const EF = require('./engine.js'), E = require('../web/engine.js'), Sp = require('../web/wing_spars.js'), IO = require('../web/wing_study_io.js');
let checks = 0;
const ok = (c, m) => { assert.ok(c, m); checks++; };
const near = (a, b, rel, abs, label) => { ok(Number.isFinite(a) && Number.isFinite(b) && Math.abs(a - b) <= abs + rel * Math.max(Math.abs(a), Math.abs(b)), `${label}: ${a} vs ${b}`); };
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], sub = (a, b) => a.map((v, i) => v - b[i]), dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const t0 = Date.now();

// ---------------------------------------------------------------- A. identical without an aerodynamic load
function snapshot(value) {
  const seen = new WeakSet();
  return JSON.stringify(value, function (k, v) {
    if (k === 'version') return undefined;
    if (typeof v === 'function' || v instanceof Map || v instanceof Set) return undefined;
    if (ArrayBuffer.isView(v)) return Array.from(v);
    if (typeof v === 'number' && !Number.isFinite(v)) return String(v);
    if (v && typeof v === 'object') { if (seen.has(v)) return '[repeat]'; seen.add(v); }
    return v;
  });
}
const material = { ...Sp.MAT }, spar = { fraction: .3, length: 300, topWidth: 8, topThickness: .8, bottomWidth: 8, bottomThickness: .8, webThickness: .6, material };
const naca = code => ({ kind: 'naca4', code });
const spatialBase = { geometry: { naca: '2412', semiSpan: 300, rootChord: 160, tipChord: 120, modules: 1, rodFractions: [], interiorRibs: 2, spars: [spar, { ...spar, fraction: .65 }], sweepDeg: 20, dihedralDeg: 8, twistEnabled: true,
  stations: [{ eta: 0, airfoil: naca('2412'), incidenceDeg: 4 }, { eta: .5, airfoil: naca('2412'), incidenceDeg: 2 }, { eta: 1, airfoil: naca('0012'), incidenceDeg: -3 }] }, assembly: { seamsBonded: true }, nSections: 3, nElements: 8, nGrid: 31 };
const editable = IO.importPrintedStudy(readFileSync(path.join(here, '../../../tests/fixtures/wing_lab_editable_browser.json'), 'utf8'), E, {}).state;
const closedGeometry = { naca: '0020', semiSpan: 130, rootChord: 160, tipChord: 0, skin: .8, te: .8, cavityStart: .12, cavityEnd: .8, modules: 1, rodFractions: [], interiorRibs: 0, customInteriorRibs: [5, 53, 118], ribThickness: 4, interfaceOffset: 5, cap: 2, sweepDeg: 0, dihedralDeg: 0 };
const cases = [
  ['course default (straight beam, flight load)', { geometry: { ...E.DEFAULT_GEOMETRY } }],
  ['course with six custom load kinds', { geometry: { ...E.DEFAULT_GEOMETRY }, load: { kind: 'custom', items: [{ kind: 'point', position: 400, force: 1.5, fraction: .4 }, { kind: 'distributed', start: 0, end: 450, qStart: .01, qEnd: .004, fraction: .3 }, { kind: 'elliptic', start: 0, end: 450, shape: 'start', total: 3, fraction: .25 }, { kind: 'parabolic', start: 100, end: 300, shape: 'middle', peak: .005, fraction: .5 }, { kind: 'table', points: [[0, .002], [200, .004], [450, 0]], fraction: .35 }, { kind: 'schrenk', total: 2, fraction: .25 }] } }],
  ['editable course fixture (bonded seams, spars)', { geometry: { ...editable.geometry }, pla: { ...E.MATERIALS[editable.plaKey] }, rod: { ...E.MATERIALS[editable.rodKey] }, assembly: { ...editable.assembly }, load: { ...editable.load }, criteria: { ...editable.criteria } }],
  ['spatial: sweep 20, dihedral 8, twist, spars, three custom loads', { ...spatialBase, load: { kind: 'custom', items: [{ kind: 'point', position: 265, force: 1.2, fraction: .68 }, { kind: 'distributed', start: 0, end: 300, qStart: .002, qEnd: .004, fraction: .35 }, { kind: 'elliptic', start: 50, end: 250, shape: 'end', peak: .006, fraction: .55 }] } }],
  ['spatial: flight Schrenk lift, no inertia relief', { geometry: { airfoil: naca('2412'), semiSpan: 300, rootChord: 160, tipChord: 120, modules: 1, rodFractions: [], interiorRibs: 2, sweepDeg: 12, dihedralDeg: 5 }, load: { kind: 'flight', aircraftMass: .2, loadFactor: 1, distribution: 'schrenk', liftFraction: .25, inertiaRelief: false }, nElements: 8, nSections: 3, nGrid: 11 }],
  ['spatial: self-weight with a point load', { ...spatialBase, load: { kind: 'custom', selfWeight: true, items: [{ kind: 'point', position: 300, force: 2, fraction: .3 }] } }],
  ['closed elliptic tip (section stress)', { geometry: { ...closedGeometry, planform: 'elliptic' }, load: { kind: 'flight', aircraftMass: 1, loadFactor: 1, distribution: 'uniform', liftFraction: .25, inertiaRelief: false }, nGrid: 25, nElements: 8, nSections: 3 }],
];
for (const [name, input] of cases) {
  const a = E.solve(JSON.parse(JSON.stringify(input))), b = EF.solve(JSON.parse(JSON.stringify(input)));
  ok(snapshot(a) === snapshot(b), `A: ${name}: fork result differs from Wing Lab 1.3`);
  const g = E.makeGeometry(input.geometry);
  ok(snapshot(E.analysisCapability(g, input)) === snapshot(EF.analysisCapability(g, input)), `A: ${name}: capability differs`);
  const na = E.normalize(input), nb = EF.normalize(input); ok(nb.aero === null, 'no aerodynamic load normalizes to null'); delete nb.aero;
  ok(snapshot(na) === snapshot(nb), `A: ${name}: normalized input differs`);
}
ok(EF.VERSION === '1.3.0+aerostruct.1' && E.VERSION === '1.3.0', 'fork version marks the change');
console.log(`A: ${cases.length} inputs give results identical to Wing Lab 1.3 (deep comparison of every number) (${((Date.now() - t0) / 1000).toFixed(1)} s)`);

// ---------------------------------------------------------------- B. six-component transfer, independent references
// Independent geometry convention (as in web/test_wing_spatial_review.mjs): x aft, y projected span, z up; sections in
// aircraft x-z planes; positive incidence raises the leading edge about the twist reference.
function physicalPoint(g, y, x, z = 0) {
  const c = g.rootChord + (g.tipChord - g.rootChord) * y / g.semiSpan, eta = y / g.semiSpan, ss = g.stations || []; let incidence = 0;
  if (ss.length) { let j = 0; while (j < ss.length - 2 && eta > ss[j + 1].eta) j++; const t = (eta - ss[j].eta) / (ss[j + 1].eta - ss[j].eta); incidence = (1 - t) * ss[j].incidenceDeg + t * ss[j + 1].incidenceDeg; }
  const a = incidence * Math.PI / 180, p = (g.twistReferenceFraction ?? .25) * c, xle = y * Math.tan((g.sweepDeg || 0) * Math.PI / 180) + (g.sweepReferenceFraction || 0) * (g.rootChord - c), zle = y * Math.tan((g.dihedralDeg || 0) * Math.PI / 180);
  return [xle + p + (x - p) * Math.cos(a) + z * Math.sin(a), y, zle - (x - p) * Math.sin(a) + z * Math.cos(a)];
}
const chordOf = (g, y) => g.rootChord + (g.tipChord - g.rootChord) * y / g.semiSpan;
const simpson = (fn, a, b, n = 2000) => { let s = fn(a).map(v => v); const e = fn(b); for (let i = 0; i < s.length; i++) s[i] += e[i]; for (let k = 1; k < n; k++) { const v = fn(a + (b - a) * k / n), w = k % 2 ? 4 : 2; for (let i = 0; i < s.length; i++) s[i] += w * v[i]; } return s.map(v => v * (b - a) / (3 * n)); };
// piecewise Simpson split at the geometry's incidence-law stations (kinks of the load line)
function integrate(g, fn, a, b) { const br = [a, ...(g.stations || []).map(s => s.eta * g.semiSpan).filter(y => y > a && y < b), b]; let out = null; for (let i = 1; i < br.length; i++) { const v = simpson(fn, br[i - 1], br[i]); out = out ? out.map((x, k) => x + v[k]) : v; } return out; }
const line = (g, y, f = .25) => physicalPoint(g, y, f * chordOf(g, y));
function reference(g, strips, f, P, n) { // outboard wrench of the strip representation for the plane (P, n), about P
  const s = y => dot(sub(line(g, y, f), P), n), L = g.semiSpan;
  let ystar = 0; if (n) { if (s(0) < 0) { if (s(L) < 0) ystar = L; else { let lo = 0, hi = L; for (let k = 0; k < 80; k++) { const m = (lo + hi) / 2; if (s(m) < 0) lo = m; else hi = m; } ystar = (lo + hi) / 2; } } }
  const out = [0, 0, 0, 0, 0, 0];
  for (const r of strips) {
    const [y0, y1] = r, h = y1 - y0, F = r.slice(2, 5), M = r.slice(5, 8), fi = F.map(v => v / h), R = integrate(g, y => line(g, y, f), y0, y1), m = M.map((v, d) => (v - cross(R, fi)[d]) / h);
    const a = Math.max(y0, ystar); if (a >= y1) continue;
    const w = integrate(g, y => [...fi, ...cross(sub(line(g, y, f), P), fi).map((v, d) => v + m[d])], a, y1);
    for (let d = 0; d < 6; d++) out[d] += w[d];
  }
  return { force: out.slice(0, 3), moment: out.slice(3), ystar };
}
// synthetic strips with every component non-zero (boundaries on the rib stations 100, 200 or well away from them)
const ys = [0, 27, 61, 100, 133, 170, 200, 236, 271, 300];
const strips = ys.slice(1).map((y1, j) => { const y0 = ys[j], c = (y0 + y1) / 2; return [y0, y1, -.02 - .001 * j, .012 * (j % 2 ? -1 : 1) + .004, .5 - .03 * j, 8 + c * (.5 - .03 * j) + .2 * j, -40 + 3 * j, 6 - .5 * j]; });
const aero = { kind: 'aeroStrips', lineFraction: .25, strips, label: 'synthetic six-component strips' };
const sInput = { ...spatialBase, load: { kind: 'custom', items: [] }, aeroLoad: aero };
const sg = EF.makeGeometry(sInput.geometry), rs = EF.solve(sInput), a3 = rs.analysis3D;
ok(!!a3 && a3.aeroLoad && EF.analysisCapability(sg, sInput).mode === 'spatial-beam', 'B: aerodynamic strips use the spatial beam');
const P0 = a3.nodes[0], refAll = reference(sg, strips, .25, P0, null);
const given = strips.reduce((t, r) => t.map((v, i) => v + r[2 + i]), [0, 0, 0, 0, 0, 0]);
for (let d = 0; d < 3; d++) {
  near(a3.appliedWrench.force[d], refAll.force[d], 1e-12, 1e-13, `B: applied force ${'xyz'[d]}`);
  near(a3.appliedWrench.momentAboutRoot[d], refAll.moment[d], 1e-9, 1e-9, `B: applied moment ${'xyz'[d]} about the root node (independent)`);
  near(refAll.moment[d], given[3 + d] - cross(P0, given.slice(0, 3))[d], 1e-9, 1e-9, `B: reference moment equals the strip moments transported to the root node (${'xyz'[d]})`);
  near(-a3.reactions[d].value, refAll.force[d], 1e-5, 1e-6, `B: reaction force ${'xyz'[d]} balances (frame solver tolerance)`);
  near(-a3.reactions[3 + d].value, refAll.moment[d], 1e-5, 1e-4, `B: reaction moment ${'xyz'[d]} balances (frame solver tolerance)`);
}
ok(a3.aeroLoad.transferResidual.force < 1e-12 && a3.aeroLoad.transferResidual.moment < 1e-9, `B: engine-reported transfer residual ${JSON.stringify(a3.aeroLoad.transferResidual)}`);
let worstCut = 0;
for (const y of [0, 20, 61, 99.9, 150, 210, 270, 299]) {
  const c = a3.cutAt(y), n = c.R[0], ref = reference(sg, strips, .25, c.reference, n);
  for (let d = 0; d < 3; d++) { near(c.force[d], ref.force[d], 1e-9, 1e-12, `B: cut y=${y} force ${d}`); near(c.moment[d], ref.moment[d], 1e-9, 1e-9, `B: cut y=${y} moment ${d}`); }
  const ac = a3.aeroLoad.cutAt(y); near(ac.torque, dot(ref.moment, n), 1e-9, 1e-9, `B: aerodynamic cut torque y=${y}`);
  worstCut = Math.max(worstCut, ...[0, 1, 2].map(d => Math.abs(c.moment[d] - ref.moment[d])));
}
console.log(`B: 9 strips with all six components on a swept, dihedral, twisted wing: applied wrench and 8 normal-cut resultants equal the independent reference (largest moment difference ${worstCut.toExponential(2)} N mm); reactions balance`);
// dihedral: the spanwise force alone carries root bending through z Fy; sweep: Fx carries a root yawing moment
{
  const only = k => strips.map(r => { const o = [r[0], r[1], 0, 0, 0, 0, 0, 0]; o[2 + k] = r[2 + k]; const mid = line(sg, (r[0] + r[1]) / 2); const F = o.slice(2, 5), M = cross(mid, F); for (let d = 0; d < 3; d++) o[5 + d] = M[d]; return o; });
  const fy = EF.solve({ ...sInput, aeroLoad: { ...aero, strips: only(1) } }).analysis3D, refFy = reference(sg, only(1), .25, fy.nodes[0], null);
  ok(Math.abs(refFy.moment[0]) > 1e-3, 'B: with 8 deg dihedral the spanwise force alone has a root moment about x');
  for (let d = 0; d < 3; d++) near(fy.appliedWrench.momentAboutRoot[d], refFy.moment[d], 1e-9, 1e-10, `B: Fy-only strips root moment ${d}`);
  const fx = EF.solve({ ...sInput, aeroLoad: { ...aero, strips: only(0) } }).analysis3D, refFx = reference(sg, only(0), .25, fx.nodes[0], null);
  for (let d = 0; d < 3; d++) near(fx.appliedWrench.momentAboutRoot[d], refFx.moment[d], 1e-9, 1e-10, `B: Fx-only strips root moment ${d}`);
  ok(Math.abs(refFx.moment[2]) > 1e-3, 'B: the chordwise force alone has a root moment about z');
}
// equivalence 1: z-only strips on the load line (zero couple) = the 1.3 distributed line loads at x/c = 0.25
{
  const zs = strips.map(r => { const h = r[1] - r[0], q = r[4] / h, R = integrate(sg, y => line(sg, y), r[0], r[1]), M = cross(R, [0, 0, q]); return [r[0], r[1], 0, 0, r[4], ...M]; });
  const items = zs.map(r => ({ kind: 'distributed', start: r[0], end: r[1], qStart: r[4] / (r[1] - r[0]), qEnd: r[4] / (r[1] - r[0]), fraction: .25 }));
  const ra = EF.solve({ ...sInput, aeroLoad: { ...aero, strips: zs } }), rb = E.solve({ ...spatialBase, load: { kind: 'custom', items } });
  let worst = 0;
  for (const k of ['deflection', 'chordwiseDeflection', 'twist', 'V', 'M', 'T']) { const u = ra[k], v = rb[k]; const scale = Math.max(...Array.from(v, Math.abs)); for (let i = 0; i < v.length; i++) worst = Math.max(worst, Math.abs(u[i] - v[i]) / scale); }
  for (const k of ['sigTop', 'sigBot']) { const u = ra.stress[k], v = rb.stress[k], scale = Math.max(...Array.from(v, x => Number.isFinite(x) ? Math.abs(x) : 0)); for (let i = 0; i < v.length; i++) if (Number.isFinite(v[i])) worst = Math.max(worst, Math.abs(u[i] - v[i]) / scale); }
  ok(worst < 1e-9, `B: z-only aerodynamic strips reproduce the 1.3 distributed loads (largest relative difference ${worst.toExponential(2)})`);
  console.log(`B: z-only strips on the quarter-chord line = Wing Lab 1.3 distributed loads: deflection, twist, V, M, T and skin stress agree to ${worst.toExponential(2)} (relative)`);
}
// equivalence 2: a pure aerodynamic couple = an equal and opposite pair of 1.3 line loads (rectangular, untwisted
// wing whose normal planes are y = const, so the pair and the couple load the same beam stations)
{
  const rect = { naca: '2412', semiSpan: 300, rootChord: 140, tipChord: 140, modules: 1, rodFractions: [], interiorRibs: 2, spars: [spar], twistEnabled: true, stations: [{ eta: 0, airfoil: naca('2412'), incidenceDeg: 0 }, { eta: 1, airfoil: naca('2412'), incidenceDeg: 0 }] };
  const yb = [0, 60, 100, 160, 200, 300], items = [], cs = [];
  yb.slice(1).forEach((y1, j) => { const y0 = yb[j], q = .004 + .001 * j; items.push({ kind: 'distributed', start: y0, end: y1, qStart: q, qEnd: q, fraction: .1 }, { kind: 'distributed', start: y0, end: y1, qStart: -q, qEnd: -q, fraction: .9 }); cs.push([y0, y1, 0, 0, 0, 0, .8 * 140 * q * (y1 - y0), 0]); });
  const base = { geometry: rect, assembly: { seamsBonded: true }, nSections: 3, nElements: 8, nGrid: 31 };
  const ra = EF.solve({ ...base, load: { kind: 'custom', items: [] }, aeroLoad: { kind: 'aeroStrips', lineFraction: .25, strips: cs } }), rb = E.solve({ ...base, load: { kind: 'custom', items } });
  const normals = ra.analysis3D.sectionSamples.map(s => s.R[0]); ok(normals.every(n => Math.abs(n[1] - 1) < 1e-9), 'B: the rectangular wing has y-normal sections');
  let worst = 0; for (const k of ['twist', 'T', 'M']) { const u = ra[k], v = rb[k], scale = Math.max(...Array.from(v, Math.abs)) || 1; for (let i = 0; i < v.length; i++) worst = Math.max(worst, Math.abs(u[i] - v[i]) / scale); }
  ok(Math.max(...Array.from(rb.twist, Math.abs)) > 1e-6 && worst < 1e-8, `B: a pure couple equals the force pair (largest relative difference ${worst.toExponential(2)})`);
  ok([ra, rb].every(r => Math.max(...Array.from(r.deflection, Math.abs)) < 1e-12 && Math.max(...Array.from(r.V, Math.abs)) < 1e-12), 'B: neither the couple nor the pair deflects or shears the beam (round-off only)');
  console.log(`B: a pure aerodynamic pitching couple twists the beam exactly like the equivalent 1.3 force pair (relative difference ${worst.toExponential(2)}; tip twist ${(rb.twist.at(-1) * 180 / Math.PI).toExponential(3)} deg)`);
}

// ---------------------------------------------------------------- C. refusals
const throwsLike = (fn, re, label) => { let msg = null; try { fn(); } catch (e) { msg = e.message; } ok(msg !== null && re.test(msg), `${label}: ${msg}`); };
{
  const cg = EF.makeGeometry({ ...closedGeometry, planform: 'elliptic' }), ci = { geometry: { ...closedGeometry, planform: 'elliptic' }, load: { kind: 'custom', items: [] }, aeroLoad: { kind: 'aeroStrips', lineFraction: .25, strips: [[0, 130, 0, 0, 1, 50, 0, 0]] } };
  ok(EF.analysisCapability(cg, ci).supported === false && /zero-chord tip/.test(EF.analysisCapability(cg, ci).message), 'C: closed tip refuses aerodynamic strips');
  throwsLike(() => EF.solve(ci), /zero-chord tip/, 'C: closed-tip solve refused');
  throwsLike(() => EF.solve({ ...sInput, load: { kind: 'flight', aircraftMass: .2, loadFactor: 1, distribution: 'schrenk', liftFraction: .25, inertiaRelief: false } }), /replaces the prescribed flight lift/, 'C: flight lift plus aerodynamic load refused');
  throwsLike(() => EF.solve({ ...sInput, geometry: { ...E.DEFAULT_GEOMETRY } }), /rods/i, 'C: course wing with rods and dry seams is outside the spatial beam');
  const bad = (strips2, re, label, extra = {}) => throwsLike(() => EF.normalize({ ...sInput, aeroLoad: { ...aero, strips: strips2, ...extra } }), re, `C: ${label}`);
  bad([[0, 100, 0, 0, 1, 0, 0]], /\[y0, y1, Fx/, 'seven numbers');
  bad([[0, 100, 0, 0, NaN, 0, 0, 0]], /finite/, 'non-finite');
  bad([[0, 301, 0, 0, 1, 0, 0, 0]], /semi-span/, 'beyond the tip');
  bad([[0, 100, 0, 0, 1, 0, 0, 0], [90, 200, 0, 0, 1, 0, 0, 0]], /overlap/, 'overlap');
  bad([[0, .05, 0, 0, 1, 0, 0, 0]], /narrower/, 'sliver strip');
  bad([[0, 100.05, 0, 0, 1, 0, 0, 0]], /within 0\.1 mm of the structural station 100/, 'station 0.05 mm from a rib');
  bad(strips, /lineFraction|chord fraction/, 'line fraction', { lineFraction: 1.5 });
  throwsLike(() => EF.normalize({ ...sInput, aeroLoad: { ...aero, kind: 'table' } }), /aeroStrips/, 'C: wrong kind');
  throwsLike(() => EF.normalize({ ...sInput, aeroLoad: { ...aero, extra: 1 } }), /Unknown aerodynamic load field/, 'C: unknown field');
}

// ---------------------------------------------------------------- D. the documented diff is the change set
{
  let out = ''; try { out = execFileSync('diff', ['-u', '--label', 'web/engine.js', '--label', 'aerostruct/engine.js', path.join(here, '../web/engine.js'), path.join(here, 'engine.js')], { encoding: 'utf8' }); } catch (e) { out = e.stdout; }
  ok(out.length > 0 && out === readFileSync(path.join(here, 'engine_fork.diff'), 'utf8'), 'D: engine_fork.diff equals diff -u web/engine.js aerostruct/engine.js');
  const added = out.split('\n').filter(l => l.startsWith('+') && !l.startsWith('+++')).length, removed = out.split('\n').filter(l => l.startsWith('-') && !l.startsWith('---')).length;
  console.log(`D: engine_fork.diff is current (${added} lines added, ${removed} removed relative to Wing Lab 1.3)`);
}
console.log(`test_aerostruct_engine_fork: ${checks} checks passed (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
