#!/usr/bin/env bash
# Verify the review ZIP two ways, without the slow reference study:
#  A. overlay: clean clone of the base commit + only the two new folders from the ZIP; build, all suites, git status
#  B. standalone: the ZIP's folder extracted on its own (no git); build, all suites
set -uo pipefail
ZIP=/mnt/user-data/outputs/wing-aerostruct-0.3.0-dev-review.zip
NAME=wing-aerostruct-0.3.0-dev-review
WORK=/root/as-verify
rm -rf "$WORK" && mkdir -p "$WORK"
export MIE446_JSDOM_MODULE=/home/claude/testdeps/node_modules/jsdom PLAYWRIGHT_MODULE=/opt/npm-tools/node_modules/playwright/index.mjs WING_THREE_DIR=/home/claude/testdeps/node_modules/three-r128
unset WING_AEROSTRUCT_REFERENCE
(cd "$WORK" && unzip -q "$ZIP")
# A. overlay on a clean clone
git clone -q --no-hardlinks /home/claude/repo "$WORK/clone" && git -C "$WORK/clone" checkout -q 5ab2498
echo "A. clean clone at $(git -C "$WORK/clone" rev-parse --short HEAD); status before overlay: $(git -C "$WORK/clone" status --porcelain | wc -l) entries"
cp -r "$WORK/$NAME/computational/printed-wing-solver/aerostruct" "$WORK/clone/computational/printed-wing-solver/"
cp -r "$WORK/$NAME/site-aerostruct" "$WORK/clone/"
rm -rf "$WORK/clone/computational/printed-wing-solver/aerostruct/test-logs"
(cd "$WORK/clone" && computational/printed-wing-solver/aerostruct/run_tests.sh "$WORK/logs-overlay" > /dev/null 2>&1); echo "A. run_tests exit $?"
cat "$WORK/logs-overlay/SUMMARY.txt"
echo "A. git status after build and tests:"; git -C "$WORK/clone" status --porcelain
for f in index.html wing-lab.html wing-aero/aero_bundle.js wing-aero/wing_aero_worker.js wing-print/engine_bundle.js wing-print/wing_print_worker.js truss-lab.html; do
  a=$(sha256sum "$WORK/$NAME/site-aerostruct/$f" | cut -c1-16); b=$(sha256sum "$WORK/clone/site-aerostruct/$f" | cut -c1-16)
  echo "A. rebuilt site-aerostruct/$f $( [ "$a" = "$b" ] && echo identical to the ZIP || echo DIFFERS: $a vs $b)"
done
# B. standalone folder
rm -rf "$WORK/$NAME/computational/printed-wing-solver/aerostruct/test-logs"
(cd "$WORK/$NAME" && computational/printed-wing-solver/aerostruct/run_tests.sh "$WORK/logs-standalone" > /dev/null 2>&1); echo "B. run_tests exit $?"
cat "$WORK/logs-standalone/SUMMARY.txt"
