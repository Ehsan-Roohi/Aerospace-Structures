// Lifting and thickness benchmarks against exact conformal-map potential flow (independent of the
// panel equations). Sections are exact Karman-Trefftz airfoils (finite trailing-edge angle) and one
// Joukowski airfoil (cusped), sampled exactly at the x/c = (1 - cos)/2 stations the app uses for
// NACA and DAT sections. Checks:
//  1. thickness-only Cp at the mid-span of a rectangular AR-20 wing versus the exact 2-D Cp;
//  2. elliptic-planform wings, AR 8-64: 1/CL fitted in 1/AR. The intercept gives the 2-D lift slope
//     (exact: 8 pi a / c) and the 1/AR slope is Prandtl's induced-angle coefficient 1/(pi alpha);
//  3. the zero-lift angle of a cambered Karman-Trefftz wing versus the exact -(beta + chord angle).
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { karmanTrefftz, joukowski, conformalLoopCosine as conformalLoop } from './aero_test_support.mjs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js'), G = require('../web/wing_geometry.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const loopFor = (g, J) => (y, nHalf) => { const c = G.chordAt(g, y); if (!(c > 1e-9 * g.rootChord)) return null; return conformalLoop(J, nHalf).pts.map(p => [p[0] * c, p[1] * c]); };
const prepared = (geo, J, key, mesh) => { const g = W.aeroGeometry(geo); return W.prepare(geo, mesh, { sectionLoop: loopFor(g, J), sectionKey: key }); };

const KT = karmanTrefftz({ b: 1, ex: 0.075, ey: 0, teAngleDeg: 12 });
const JK = joukowski({ b: 1, ex: 0.093, ey: 0 });
log(`Karman-Trefftz section: t/c ${KT.thicknessRatio.toFixed(4)}, TE angle 12 deg, exact a0 = ${KT.liftSlope2D.toFixed(5)} /rad`);
log(`Joukowski section: t/c ${JK.thicknessRatio.toFixed(4)}, cusped TE, exact a0 = ${JK.liftSlope2D.toFixed(5)} /rad`);

// 1. Thickness-only flow at mid-span, rectangular wing, semi-span 10 chords (AR 20), alpha = 0.
{
  const geo = { semiSpan: 1000, rootChord: 100, tipChord: 100, naca: '0012' };
  for (const nChord of [16, 24, 32]) {
    const m = prepared(geo, KT, 'kt-thickness-' + nChord, { chordPanels: nChord, spanPanels: 16, spanSpacing: 'cosine' });
    const r = W.evaluate(m, { alphaDeg: 0, speed: 10 }), wm = m.wm, j = 0; // root strip of the mirrored pair = mid-span
    let err2 = 0, n = 0, worst = 0;
    const params = conformalLoop(KT, nChord).params;
    for (let i = 0; i < wm.ni; i++) {
      if (i < 2 || i > wm.ni - 3) continue; // trailing-edge stagnation panels: exact Cp -> 1 at a point
      const k = wm.index(i, j), P = [m.wm.S.PC[3 * k], m.wm.S.PC[3 * k + 1], m.wm.S.PC[3 * k + 2]], loc = G.inversePoint(m.geometry, P).map(v => v / 100);
      // exact Cp at the contour point closest to the panel centroid (golden-section search in circle angle)
      let lo = Math.min(params[i], params[i + 1]), hi = Math.max(params[i], params[i + 1]);
      const d = th => { const q = KT.toLocal(KT.map(th)); return (q[0] - loc[0]) ** 2 + (q[1] - loc[1]) ** 2; };
      for (let it = 0; it < 80; it++) { const m1 = lo + 0.382 * (hi - lo), m2 = lo + 0.618 * (hi - lo); if (d(m1) < d(m2)) hi = m2; else lo = m1; }
      const e = r.panels.cp[k] - KT.cpAt((lo + hi) / 2, 0); err2 += e * e; n++; worst = Math.max(worst, Math.abs(e));
    }
    log(`thickness flow, ${2 * nChord} chordwise panels: mid-span Cp RMS error ${Math.sqrt(err2 / n).toExponential(2)}, max ${worst.toExponential(2)}, CL ${r.coefficients.CL.toExponential(1)}`);
    ok(Math.abs(r.coefficients.CL) < 1e-10, 'symmetric section at zero incidence carries no lift');
    if (nChord === 32) { ok(Math.sqrt(err2 / n) < 0.01, 'mid-span thickness Cp RMS error < 0.01'); ok(worst < 0.03, 'mid-span thickness Cp max error < 0.03'); }
  }
}
// 2. Lift slope in the 2-D limit and Prandtl's induced angle, elliptic planform.
function liftStudy(J, key, nChord, ARs) {
  const alpha = 4 * Math.PI / 180, rows = [];
  for (const AR of ARs) {
    const cr = 100, L = AR * Math.PI * cr / 8, geo = { planform: 'elliptic', semiSpan: L, rootChord: cr, tipChord: 0, naca: '0012' };
    const r = W.evaluate(prepared(geo, J, `${key}-${nChord}-${AR}`, { chordPanels: nChord, spanPanels: 24 }), { alphaDeg: 4, speed: 10 });
    rows.push({ AR, CL: r.coefficients.CL, CLt: r.coefficients.CLTrefftz, e: r.coefficients.spanEfficiencyTrefftz });
  }
  // least squares 1/CL = p0 + p1 x + p2 x^2, x = 1/AR
  const fit = sel => { const A = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], b = [0, 0, 0]; for (const r of rows) { const v = [1, 1 / r.AR, 1 / r.AR ** 2], y = 1 / sel(r); for (let p = 0; p < 3; p++) { b[p] += v[p] * y; for (let q = 0; q < 3; q++) A[p][q] += v[p] * v[q]; } } const M = A.map((r, i) => [...r, b[i]]); for (let k = 0; k < 3; k++) for (let i = k + 1; i < 3; i++) { const f = M[i][k] / M[k][k]; for (let j = k; j < 4; j++) M[i][j] -= f * M[k][j]; } const x = [0, 0, 0]; for (let i = 2; i >= 0; i--) { let s = M[i][3]; for (let j = i + 1; j < 3; j++) s -= M[i][j] * x[j]; x[i] = s / M[i][i]; } return x; };
  const p = fit(r => r.CL), pt = fit(r => r.CLt);
  return { rows, a0: 1 / (p[0] * alpha), a0t: 1 / (pt[0] * alpha), induced: p[1] * Math.PI * alpha, inducedT: pt[1] * Math.PI * alpha };
}
const errsT = [];
for (const nChord of [16, 24, 32, 40]) {
  const s = liftStudy(KT, 'kt-lift', nChord, [8, 16, 32, 64]);
  const err = 100 * (s.a0 / KT.liftSlope2D - 1), errT = 100 * (s.a0t / KT.liftSlope2D - 1); errsT.push(errT);
  log(`Karman-Trefftz, ${2 * nChord} chordwise panels: CL at AR 8/16/32/64 = ${s.rows.map(r => r.CL.toFixed(5)).join(' / ')}; e = ${s.rows.map(r => r.e.toFixed(3)).join(' / ')}`);
  log(`   extrapolated 2-D slope ${s.a0.toFixed(4)} (pressure) / ${s.a0t.toFixed(4)} (Trefftz) vs exact ${KT.liftSlope2D.toFixed(4)}: ${err.toFixed(2)}% / ${errT.toFixed(2)}%; induced coefficient / (1/pi alpha) = ${s.induced.toFixed(4)} / ${s.inducedT.toFixed(4)}`);
  if (nChord >= 32) { ok(Math.abs(err) < 1.5, 'extrapolated 2-D lift slope within 1.5% of the exact conformal value'); ok(Math.abs(s.induced - 1) < 0.05, "Prandtl's induced-angle coefficient within 5%"); }
  for (const r of s.rows) ok(r.e > 0.97 && r.e < 1.02, 'elliptic planform gives near-elliptic loading (Trefftz e)');
}
ok(errsT.every((e, i) => i === 0 || Math.abs(e) < Math.abs(errsT[i - 1])), 'Trefftz-based 2-D lift-slope error decreases monotonically with chordwise refinement');
{ // Joukowski (cusped trailing edge): reported as a limitation case, finest chordwise level only
  const s = liftStudy(JK, 'jk-lift', 24, [8, 16, 32]);
  log(`Joukowski (cusped TE), 48 chordwise panels, AR 8/16/32 extrapolation: 2-D slope ${s.a0.toFixed(4)} vs exact ${JK.liftSlope2D.toFixed(4)} (${(100 * (s.a0 / JK.liftSlope2D - 1)).toFixed(2)}%)`);
  ok(Math.abs(s.a0 / JK.liftSlope2D - 1) < 0.05, 'cusped Joukowski 2-D slope within 5% (cusp limitation documented)');
}
// 3. Zero-lift angle of a cambered Karman-Trefftz section on a high-AR elliptic wing.
{
  const KC = karmanTrefftz({ b: 1, ex: 0.075, ey: 0.035, teAngleDeg: 12 });
  const cr = 100, geo = { planform: 'elliptic', semiSpan: 32 * Math.PI * cr / 8, rootChord: cr, tipChord: 0, naca: '0012' };
  const m = prepared(geo, KC, 'kt-camber', { chordPanels: 32, spanPanels: 24 });
  const c1 = W.evaluate(m, { alphaDeg: -1, speed: 10 }).coefficients.CL, c2 = W.evaluate(m, { alphaDeg: 2, speed: 10 }).coefficients.CL;
  const aL0 = -1 - c1 * 3 / (c2 - c1), exact = KC.zeroLiftAngle * 180 / Math.PI;
  log(`cambered Karman-Trefftz: zero-lift angle ${aL0.toFixed(3)} deg vs exact ${exact.toFixed(3)} deg (untwisted wing: same as 2-D)`);
  ok(Math.abs(aL0 - exact) < 0.1, 'zero-lift angle within 0.1 deg of the exact value');
}
console.log(`test_wing_aero_conformal: ${checks} checks passed`);
