# Third-party sources: file-to-source map (Wing AeroStruct 3-D panel solver, candidate 0.3.2-exp.3, branch exp5-cornersplit)

What is reused, what is adapted, what is only a reference, and what is new. "Reference only" means the program was run
(or its source read) to compare results or to check a formulation; none of its code is in the solver.

| Part | File | Status | Source |
|---|---|---|---|
| Panel split exception at the closed corners of the last strip (`tbSplitRule`; `tbPanel` takes `split[k]`) | `wing_aero_panel.js` | new | Written here. Diagnosis: the shorter-diagonal split gave the upper and lower corner panels the same triangle (a zero-thickness, double-covered triangle; the surface's solid-angle indicator was 0 on both sides of it). Compared against PANAIR at PANAIR's own control points on the same meshes (reference only, below). |
| Surface velocity from the jump relations of the solved sheet, `v = V - (V.n_T) n_T + grad_s mu_T` per triangle (`tensorTriangleVelocity`) | `wing_aero_panel.js` | own implementation, verified equal to MachLine | MachLine `panel_get_velocity_jump`, `panel_get_velocity` (Morino inner flow), src/panel.f90, commit d62befa. Equality checked to round-off by `test_wing_aero_machline_port.mjs`. No MachLine code in the solver. |
| Panel force = exact integral of the quadratic Cp over each triangle; pressure couple about the panel centroid (`panels.force_N`, `panels.momentAboutCentroid_Nmm`) | `wing_aero_panel.js` | own implementation, verified equal to MachLine | MachLine `panel_get_quadratic_pressure_params`, `panel_get_avg_pressure_coef`, `panel_get_moment_about_centroid`, `panel_calc_C_integrals`. Equal to round-off once the third area moments are assigned (see the next row). |
| Port of the MachLine routines above, incompressible case, plus the panel geometry they use | `validation/machline/machline_routines.mjs` | ported (MIT, notice in the file) | MachLine src/panel.f90 and src/flow.f90 at d62befa; the header maps every function to the Fortran routine and line. One documented difference: `cOrder`. MachLine's `panel_calc_C_integrals` runs its recursion with Ni = Nj = 3, which never assigns the third moments C(3,0), C(2,1), C(1,2), C(0,3) that `panel_get_moment_about_centroid` reads (unassigned memory in MachLine). `cOrder: 4` runs the same recursion one order further and assigns them. |
| Validation test using the port | `test_wing_aero_machline_port.mjs` | new | Written here. |
| Reference calculations: same-mesh runs, corner Cp at PANAIR's control points, pressure drag and moments; the reference NUMBERS used by `test_wing_aero_external_acceptance.mjs` | `validation/panair/panair_reference_rect0012.json` (numbers only, provenance in `validation/panair/README.md`); decks, outputs and tools in the evidence package | reference only (output data, no code) | PANAIR A502 (Boeing / NASA; "ht2 (12 feb 92) boeing ver i00"), panair.f90 from PDAS, built with gfortran and checked against the PDAS sample decks. PANAIR's subdivision (`generate subpanels`: four corner sub-panels and the planar parallelogram of the edge mid-points) has no diagonal. It was read for the split comparison and not adopted, because it is a different element. |

## MachLine licence (for `validation/machline/machline_routines.mjs`)

MIT License

Copyright (c) 2021 USU Aero Lab

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
