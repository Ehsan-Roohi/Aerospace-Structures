// Worked example of WING_AEROSTRUCT.md section 8.4: a wing with a mid-span station and its own two-spar structure
// (400 mm semi-span, 160 to 90 mm chord, sweep 20 deg, dihedral 7 deg, incidence 2, 0.5 and -2 deg at eta 0, 0.5
// and 1, NACA 2412 to 0012, bonded spars at 30% and 62% chord, 18 m/s, alpha 5 deg). Runs the Standard and Fine
// sequences, applies each to the spatial beam and prints every admission row (torque about the structure's
// shear-centre axis, force, bending, lift consistency, twist claim, one-way coupling).
// Run: node validation/midspan_example.mjs   (about 30 s; the output is stored in validation/midspan_example.log)
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const A = require('../wing_aero_panel.js'), E = require('../engine.js'), UI = require('../wing_aero_ui.js'), Sp = require('../../web/wing_spars.js');
const deg = 180 / Math.PI, t0 = Date.now();
const spar = { fraction: 0.3, length: 400, topWidth: 8, topThickness: 0.8, bottomWidth: 8, bottomThickness: 0.8, webThickness: 0.6, material: { ...Sp.MAT } };
const n4 = code => ({ kind: 'naca4', code });
const geometry = { semiSpan: 400, rootChord: 160, tipChord: 90, naca: '2412', sweepDeg: 20, dihedralDeg: 7, sweepReferenceFraction: 0.25, twistEnabled: true, twistReferenceFraction: 0.25, modules: 1, rodFractions: [], interiorRibs: 2, spars: [spar, { ...spar, fraction: 0.62 }], skin: 1.2, te: 1.2,
  stations: [{ eta: 0, airfoil: n4('2412'), incidenceDeg: 2 }, { eta: 0.5, airfoil: n4('2412'), incidenceDeg: 0.5 }, { eta: 1, airfoil: n4('0012'), incidenceDeg: -2 }] };
const g = E.makeGeometry(geometry), L = g.semiSpan, snap = [...E.ribStations(g), ...E.seams(g), ...g.stations.map(s => s.eta * L), ...g.spars.map(s => s.length)], cache = new Map();
console.log(`mid-span-station wing: spar and shell modulus ${Sp.MAT.E} MPa; flow 18 m/s, alpha 5 deg`);
for (const sn of ['standard', 'fine']) {
  const t1 = Date.now(), seq = A.runSequence(g, { speed: 18, alphaDeg: 5 }, sn, { cache }), rec = UI.recordFromSequence(seq, 'example'), comb = UI.delivered(A, g, rec, snap);
  const R = E.solve({ geometry, assembly: { seamsBonded: true }, load: { kind: 'custom', items: [] }, aeroLoad: UI.engineLoad(comb, 'example'), nSections: 5 }), adm = UI.admit(A, g, rec, comb, R);
  console.log(`${sn} sequence (${((Date.now() - t1) / 1000).toFixed(1)} s): ${adm.admitted ? 'admitted' : 'NOT admitted'}; claims torque ${adm.claims.torque}, twist ${adm.claims.twist}${adm.failed.length ? `; failed: ${adm.failed.join('; ')}` : ''}`);
  for (const r of adm.rows) console.log(`   ${r.label.padEnd(40)} ${r.kind === 'twist' ? `${r.status}: tip ${(r.value * deg).toFixed(4)} ± ${(r.uncertainty * deg).toFixed(4)} deg; bound on |twist| ${(r.bound * deg).toFixed(4)} deg; lift effect of the bound ${(100 * r.twist.liftEffect).toFixed(3)}%; largest dtheta / |theta| ${(100 * r.twist.worstRelative).toFixed(1)}%`
    : r.kind === 'aeroelastic' ? `${(100 * r.value).toFixed(3)}% of the lift (limit ${(100 * r.tolerance).toFixed(0)}%)`
    : r.kind === 'liftConsistency' ? `CL ${r.value.toFixed(4)} vs ${r.reference.toFixed(4)} (${(100 * r.measure).toFixed(2)}%)`
    : `${r.value.toFixed(4)} ± ${r.uncertainty.toFixed(4)} (${(100 * r.measure).toFixed(2)}%) ${r.status || (r.admitted ? 'resolved' : 'FAILS')}`}`);
}
console.log(`midspan_example: done in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
