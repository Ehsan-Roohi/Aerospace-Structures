// Exact current Wing Lab nominal field at supplied physical solid IP positions.
// No least-squares stress fitting or relocation onto a convenient section.
import {readFileSync,writeFileSync} from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),E=require('../../computational/printed-wing-solver/web/engine.js');
import {buildBeamReference} from './wing_solid_beam_reference.mjs';
const [studyPath,reportPath,pointsPath,outputPath,channel='uniform']=process.argv.slice(2);
if(!outputPath)throw Error('study report points output [uniform|torque] required');
const read=p=>JSON.parse(readFileSync(p,'utf8')),doc=read(studyPath),report=read(reportPath),points=read(pointsPath);
// Reuse the independently wrench-checked reference builder to obtain declared
// physical load points/material cards, then solve the same final 80-element case.
const uniform=channel==='uniform'?report:{...report,load_channel:'uniform_tip_2N',force_N:[0,0,2],applied_moment_Nmm:[2*report.tip_centroid_mm[1],-2*report.tip_centroid_mm[0],0]};
const reference=buildBeamReference(doc,uniform,channel==='torque'?report:null,{elements:[40,80],sections:15,cuts:[110,130,190]});
const run=reference.runs.at(-1),loadPoints=run[channel==='uniform'?'vertical':'torque'].physicalLoadPoints;
const G=require('../../computational/printed-wing-solver/web/wing_geometry.js'),g=reference.geometry;
const items=loadPoints.map(p=>{const local=G.inversePoint(g,p.point);return {kind:'point',position:g.semiSpan,force:p.force[2],fraction:local[0]/g.tipChord};});
const r=E.solve({geometry:g,pla:reference.shellMaterial,assembly:doc.study.assembly,criteria:doc.study.criteria,nSections:15,nElements:80,nGrid:11,load:{kind:'custom',items}}),a=r.analysis3D;
const rows=points.map((p,i)=>{
 if(i%500===0)console.log('Matched IP',i,'/',points.length);
 try{const foot=a.locatePhysicalPoint(p);if(foot.outside)return {resolved:false,reason:foot.outside};const c=a.cutAt(foot.station);if(c.endZone)return {resolved:false,reason:c.endZone};const d=p.map((v,k)=>v-c.reference[k]),q=c.R.map(row=>row.reduce((s,v,k)=>s+v*d[k],0));return {resolved:true,station:foot.station,normal:c.R[0],value:r.pla.E*(c.strain[0]+c.strain[1]*q[2]-c.strain[2]*q[1])};}catch(e){return {resolved:false,reason:e.message};}
});
writeFileSync(outputPath,JSON.stringify({method:'Current Wing Lab 80-element nominal stress at exact physical IP normal foot; no stress fit',reference,points:rows})+'\n');
console.log(JSON.stringify({outputPath,total:rows.length,resolved:rows.filter(x=>x.resolved).length}));
