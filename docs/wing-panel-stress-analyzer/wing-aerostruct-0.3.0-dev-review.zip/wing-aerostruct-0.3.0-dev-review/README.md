# Wing AeroStruct 0.3.0 development package (for review, not published)

Wing AeroStruct is a separate application: the Wing Lab page with a coupled aerodynamic panel method and the
spatial-beam structural engine. It does not change Wing Lab.

Base: `Ehsan-Roohi/Aerospace-Structures` at commit `5ab2498`. The archive holds one self-contained folder that
builds and tests on its own:

| Folder | Content |
|---|---|
| `computational/printed-wing-solver/aerostruct/` | new: sources, structural engine fork and its diff, tests, validation study, build script, documentation, proposed CI workflow, test logs and screenshots |
| `site-aerostruct/` | new: the built site (preview build; regenerate with the build script) |
| `computational/printed-wing-solver/web/`, `tests/fixtures/` | the unchanged Wing Lab 1.3 modules and course fixtures of commit `5ab2498`, which the build and the tests read |

`MANIFEST.txt` lists the size and SHA-256 of every file and marks the base-commit files; those are byte-identical
to commit `5ab2498` (checked against the committed blobs when the archive was made).

To add Wing AeroStruct to a checkout of the repository instead, copy only the two new folders,
`computational/printed-wing-solver/aerostruct/` and `site-aerostruct/`, to the repository root. Do not copy the
base-commit folders over a newer checkout. Nothing in `docs/` (the published Wing Lab) or in
`computational/printed-wing-solver/web/` is changed; in a git checkout the test runner reports the number of
changed files there (zero in the included logs).

## What the second review asked for and where it is

The 0.2.0 build admitted the editable fixture's Fine root torque 1.950 ± 0.955 N mm (49% of itself) and the 25%,
50% and 75% torques (69%, 129%, 181%) through a fixed 10.667 N mm floor. In 0.3.0:

* No floor and no q S c normalization: a torque is resolved only if U <= 10% of |T| and every mesh that carries
  weight in the load gives its sign; otherwise it is reported as "magnitude not resolved" or "sign not resolved".
  `WING_AEROSTRUCT.md` section 7.1, `wing_aero_panel.js` (`admission`).
* Twist claims gated on resolved torque: torque and twist are shown only if every reported torque is resolved and
  the twist uncertainty dtheta is within 10% of the twist. dtheta is the integral of the torque uncertainty times
  this structure's torsional compliance (the frame elements' GJ); the bound on the true twist is |theta| + dtheta.
  Section 7.2.
* Near-zero torque: the load is admitted only if that bound could change the lift by at most 1% (justified in
  section 7.2), and then torque and twist are withheld from every result view, including the root reactions, cut
  moments and reports; the unresolved torques appear only in the admission record, with their uncertainty and the
  status "magnitude not resolved" or "sign not resolved". Otherwise the coupled result is refused. A
  one-way-coupling check refuses a twist that would change the lift by more than 2%. Sections 7.2 to 7.5.
* Low-GJ structures and opposite-sign meshes: suite `test_aerostruct_twist` (five structures on both sequences,
  twist bound validated against a much finer reference load) and `test_wing_aero_admission` (synthetic
  opposite-sign cases, every resolved sign of the seven-wing reference study). Sections 8.1 and 8.3 to 8.5.
* Capped browser runtime: no larger sequence was added; on the Fine sequence an unresolved, non-negligible twist
  is refused. The six-component transfer is unchanged (section 5).

The first review's items (six-component transfer, executed mesh-convergence admission, flat-tip investigation,
global load consistency) are in sections 4 to 6 and 8.6.

## Look at it

Workers need http(s), so serve the folder rather than opening the file directly (from `file://` the page still
works but solves on the main thread):

```sh
python3 -m http.server --directory site-aerostruct 8000     # then open http://localhost:8000/
```

Wing workspace, input column, **Aerodynamics**: "Run mesh sequence", then "Apply to structure and solve". The
admission table appears under the buttons. On the editable course fixture both sequences admit the load with
torque and twist withheld; give the shell and spars a very low modulus and the coupled result is refused.

## Rebuild and test

```sh
python3 computational/printed-wing-solver/aerostruct/build_wing_aerostruct.py
MIE446_JSDOM_MODULE=/path/to/node_modules/jsdom \
PLAYWRIGHT_MODULE=/path/to/node_modules/playwright/index.mjs \
WING_THREE_DIR=/path/to/three@0.128.0 \
computational/printed-wing-solver/aerostruct/run_tests.sh /tmp/wing-aerostruct-logs
# optional, about 13 minutes: WING_AEROSTRUCT_REFERENCE=1 adds validation/reference_study.mjs to the run
```

## Read next

* `computational/printed-wing-solver/aerostruct/WING_AEROSTRUCT.md`: review history, the exact formulation, tip
  closure, transfer algebra, extrapolation, uncertainty and admission (including the twist claim), validation,
  study files, separate site, tests, limitations, provenance.
* `computational/printed-wing-solver/aerostruct/test-logs/SUMMARY.txt` and the per-suite logs: the actual run
  behind every number in the documentation (all 15 suites and the reference study pass);
  `test_aerostruct_twist.log` has the structure-by-structure results.
* `computational/printed-wing-solver/aerostruct/test-logs/PACKAGE_VERIFICATION.txt`: this archive checked on a
  clean clone of `5ab2498` (only the two new folders added; all suites pass, `git status` shows only those two
  folders, the rebuilt site is byte-identical to the one included) and as a standalone folder without git.

Nothing here has been published. To publish later, copy the contents of `site-aerostruct/` to the root of a new
website; do not copy it into `docs/`.
