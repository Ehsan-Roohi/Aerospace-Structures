# Homework 2B: Integrate, Mix, and Trace the Load

MIE 446 Aerospace Structures, Fall 2026. Parts 2, 4 and 5, 65 points.
Due Thursday, November 5, 2026; Canvas shows the time and submission link.

Start with the student guide, `MIE446_HW2B_Integration_Mixing_Load_Paths.pdf`.
It gives the numbered steps, MATLAB commands, Excel cell references, independent
checks and the submission list, including the one-slide brief, README, process
note and Engineering Judgment Record for the whole of Homework 2.

## Files

- `MIE446_HW2B_Integration_Mixing_Load_Paths.pdf`: student guide (HTML source included)
- `MIE446_HW2B_Starter.m`: MATLAB starter for Parts 2, 4 and 5
- `MIE446_HW2B_Excel_Starter.xlsx`: WingLoads sheet (Part 2) and Controls sheet (Parts 4 and 5)
- `assets/`: body axes, wing model and control-lever figures (PNG, with editable SVG for the two model figures)

Extract the ZIP before opening its files. In MATLAB, make the extracted folder
your Current Folder. In Excel, save a working copy. Gray cells and MATLAB TODOs
are intentionally unfinished; a blank answer is not a zero result.

## Reading

| Part | Points | Lecture 1 reference | What you produce |
|---|---:|---|---|
| 2. Integrate force and moment increments | 35 | 5, 7A-3b and 7A-5 | MATLAB integration, Excel trapezoids, plots, convergence and resolution tests, speed scaling |
| 4. Mix elevon commands | 20 | 7A-11 and its elevon-mixer cell | Five-case requested and limited deflections, forces, moments and a saturation explanation |
| 5. Trace local structural loads | 10 | 7A-1, 7A-5 and 7A-14 | Two load-path drawings, a string-tension table and an inclined-string case |

[Lecture 1 in Google Colab](https://colab.research.google.com/github/Ehsan-Roohi/Aerospace-Structures/blob/main/notebooks/MIE446_Lecture_01_Trust_Forces_Airfoils.ipynb).
The wing and elevon models are specified instructional models, not measurements
from the Lilienthal paper or performance claims for the printed course wing.
Parts 2 and 4 use body axes and moments about the CG; Part 5 uses a local vane
pivot. Whole-aircraft control moments and local pivot moments are different
quantities.

Keep your HW 2A Part 1 readings: the Engineering Judgment Record asks you to
compare them with your Part 2 results.
