// The cross term of the mesh-sequence estimator (0.3.2-exp.4). NEW FILE; the older suites are unchanged (those that
// count seven meshes per sequence now fail on that count and are listed as such in the candidate's failure table).
//
// The additive combination Q_chord + Q_span - Q_base is exact only for a separable discretization error
// E(c, s) = A(c) + B(s). With a cross term k / (c s) it misses -k / (cb sb). Each sequence now solves one mesh refined
// in both directions (the joint mesh J) and adds X = f D, D = Q(J) - Q(cJ, sb) - Q(cb, sJ) + Q(base),
// f = (1/cb)(1/sb) / ((1/cJ - 1/cb)(1/sJ - 1/sb)); U gains 1.25 x 0.5 |X| (wing_aero_panel.js, SEQUENCES).
//  1. Synthetic sequences with a known cross term: the estimate is exact; without the joint mesh it misses exactly
//     -k / (cb sb); for a separable error X = 0.
//  2. Weights: one consistent load set (the estimate is the weighted sum of the levels); the cross weights; U.
//  3. A sequence stored before the joint mesh existed (seven meshes) is combined additively, exactly as written.
//  4. Study files: an eight-mesh load and a seven-mesh (earlier) load are read; mixed or foreign sets are refused.
//  5. Evidence on the rectangular NACA 0012 AR 6 wing at alpha 4 (the PANAIR wing): a 4 x 5 grid of joint meshes
//     (validation/cross_term_grid_rect0012.json, this core): the grid belongs to this core (two meshes re-solved);
//     every coefficient has the bilinear cross term (k nearly constant over 12 joint meshes); the least-squares
//     continuum value of the whole grid; the live Standard and Fine estimates cover it within U (the additive estimate
//     did not: Cm, -1.8e-5 against U 1.7e-5), and Fine CDi covers the finer same-model meshes 96 x 64 and 128 x 64.
//  6. Study files written BY 0.3.1 and BY 6e30853 (seven meshes, validation/legacy_loads/): read without adding or
//     fabricating a joint mesh, combined under the earlier separable rule, marked (crossTerm.estimated false, an
//     admission note), and their delivered load, coefficients, U and torques equal bit for bit what the writer itself
//     delivered; the built Worker solves eight meshes and the page record keeps them.
// Runtime about 2 minutes. MIE446_JSDOM_MODULE is not needed.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js'), IO = require('./wing_study_io.js'), E = require('./engine.js'), UI = require('./wing_aero_ui.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; console.log('   ok', m); };
const t0 = Date.now(), e3 = x => x.toExponential(3);

console.log('1. Synthetic sequences with a known cross term');
for (const name of ['standard', 'fine']) {
  const d = W.SEQUENCES[name], cb = d.baseChord, sb = d.baseSpan;
  const Q = (c, s) => 7 + 3 / c - 20 / c ** 2 - 2 / s + 9 / s ** 2 + 40 / (c * s);
  const est = W.sequenceEstimate(name, Q), add = W.sequenceEstimate(name, Q, W.ADMISSION, false);
  ok(Math.abs(est.value - 7) < 1e-12, `${name}: quadratic-in-1/n errors in each direction plus 40 / (c s): estimate ${est.value.toPrecision(15)} = 7 (cross term ${e3(est.cross.value)} restored)`);
  ok(Math.abs(add.value - (7 - 40 / (cb * sb))) < 1e-12, `${name}: the additive combination alone misses exactly -k / (cb sb) = ${e3(-40 / (cb * sb))} (got ${e3(add.value - 7)})`);
  const S = (c, s) => 5 + 0.3 * (c / 16) ** -0.7 - 0.2 * (s / 8) ** -1.1, es = W.sequenceEstimate(name, S), as = W.sequenceEstimate(name, S, W.ADMISSION, false);
  ok(Math.abs(es.cross.value) < 1e-15 && es.value === as.value && es.uncertainty === as.uncertainty, `${name}: separable error: X = ${e3(es.cross.value)}, estimate and U identical to the additive combination`);
}

console.log('2. Weights and U');
for (const name of ['standard', 'fine']) {
  const d = W.SEQUENCES[name], [cJ, sJ] = d.joint, cb = d.baseChord, sb = d.baseSpan, f = W.crossFactor(d);
  ok(Math.abs(f - (1 / cb) * (1 / sb) / ((1 / cJ - 1 / cb) * (1 / sJ - 1 / sb))) < 1e-12 && Math.abs(Math.abs(f) - 9) < 1e-12, `${name}: joint mesh ${2 * cJ} x ${sJ} (around x spanwise), factor f = ${f}`);
  const w = W.sequenceWeights(name), w0 = W.sequenceWeights(name, false), wt = (L, c, s) => (L.find(x => x.chordPanels === c && x.spanPanels === s) || { weight: 0 }).weight;
  ok(Math.abs(w.reduce((t, x) => t + x.weight, 0) - 1) < 1e-12 && W.sequenceMeshes(name).length === 8 && W.sequenceMeshes(name, false).length === 7, `${name}: eight meshes (seven without the joint mesh); weights sum to 1`);
  ok(Math.abs(wt(w, cJ, sJ) - f) < 1e-12 && Math.abs(wt(w, cJ, sb) - wt(w0, cJ, sb) + f) < 1e-12 && Math.abs(wt(w, cb, sJ) - wt(w0, cb, sJ) + f) < 1e-12 && Math.abs(wt(w, cb, sb) - wt(w0, cb, sb) - f) < 1e-12,
    `${name}: the cross weights are f, -f, -f, f at J, (cJ, sb), (cb, sJ), base`);
  let seed = 17; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647), table = new Map(), Q = (c, s) => { const k = c + 'x' + s; if (!table.has(k)) table.set(k, rnd()); return table.get(k); };
  const est = W.sequenceEstimate(name, Q), via = w.reduce((t, x) => t + x.weight * Q(x.chordPanels, x.spanPanels), 0);
  ok(Math.abs(est.value - via) < 1e-12, `${name}: arbitrary level values: the estimate equals the weighted sum of the levels (one consistent, conservative load set)`);
  ok(Math.abs(est.uncertainty - 1.25 * (est.chord.term + est.span.term + 0.5 * Math.abs(est.cross.value))) < 1e-14, `${name}: U = 1.25 (chord term + span term + 0.5 |X|)`);
}

console.log('3. A sequence stored before the joint mesh existed');
{
  const g = E.makeGeometry(E.DEFAULT_GEOMETRY), seq = W.runSequence(g, { speed: 15, alphaDeg: 4 }, 'standard');
  const legacy = { ...seq, levels: seq.levels.filter(l => !(l.chordPanels === 24 && l.spanPanels === 24)) };
  const cNew = W.combineSequence(g, seq), cOld = W.combineSequence(g, legacy);
  ok(seq.levels.length === 8 && legacy.levels.length === 7 && cNew.crossTerm.estimated && !cOld.crossTerm.estimated, 'the solved sequence has eight meshes; without the joint mesh crossTerm.estimated is false');
  // independent additive weights: Lagrange polynomial through the three finest levels of each direction, minus the base
  const d = W.SEQUENCES.standard, lag = h => h.map((hi, i) => h.reduce((p, hj, j) => (j === i ? p : p * hj / (hj - hi)), 1)), three = a => a.slice(-3);
  const wc = lag(three(d.chord).map(c => 1 / c)), ws = lag(three(d.span).map(s => 1 / s)), lv = (c, s) => seq.levels.find(l => l.chordPanels === c && l.spanPanels === s);
  const additive = key => three(d.chord).reduce((t, c, i) => t + wc[i] * lv(c, d.baseSpan).coefficients[key], 0) + three(d.span).reduce((t, s, i) => t + ws[i] * lv(d.baseChord, s).coefficients[key], 0) - lv(d.baseChord, d.baseSpan).coefficients[key];
  ok(['CL', 'CLTrefftz', 'CDpressure', 'CDiTrefftz', 'Cm'].every(k => Math.abs(cOld.coefficients[k].value - additive(k)) <= 1e-12 * Math.max(1e-3, Math.abs(additive(k)))), 'seven meshes: every coefficient is the additive combination (independent Lagrange weights here)');
  const cuts = [{ y: 0, root: true, reference: [50, 0, 0], normal: [0, 1, 0] }, { y: 150, reference: [55, 150, 0], normal: [0, 1, 0] }];
  const aNew = W.admission(g, seq, cNew, cuts), aOld = W.admission(g, legacy, cOld, cuts);
  ok(aNew.crossTerm.estimated && !aOld.crossTerm.estimated && aOld.rows.filter(r => r.kind === 'torque').every(r => r.estimate.cross === null) && aNew.rows.filter(r => r.kind === 'torque').every(r => r.estimate.cross && Number.isFinite(r.estimate.cross.value)),
    'admission: torque estimates carry the cross term with the joint mesh and none without it');
  console.log(`   course wing, Standard: CL ${cNew.coefficients.CL.value.toFixed(6)} +- ${e3(cNew.coefficients.CL.uncertainty)} (additive ${cOld.coefficients.CL.value.toFixed(6)} +- ${e3(cOld.coefficients.CL.uncertainty)}); Cm ${e3(cNew.coefficients.Cm.value)} +- ${e3(cNew.coefficients.Cm.uncertainty)} (additive ${e3(cOld.coefficients.Cm.value)} +- ${e3(cOld.coefficients.Cm.uncertainty)}); ${(seq.timing.totalMs / 1000).toFixed(1)} s`);

  console.log('4. Study files');
  const fixture = readFileSync(new URL('../../../tests/fixtures/wing_lab_editable_browser.json', import.meta.url), 'utf8'), base = IO.importPrintedStudy(fixture, E).state, gs = E.makeGeometry(base.geometry);
  IO.setAeroGeometryKey(x => IO.sha256(W.geometryKey(x)));
  const sq = W.runSequence(gs, { speed: 15, alphaDeg: 4 }, 'standard'), record = UI.recordFromSequence(sq, IO.sha256(W.geometryKey(gs)));
  const state = rec => ({ ...base, load: { ...base.load, kind: 'custom', items: [] }, aerodynamics: { speed: 15, density: 1.225, alphaDeg: 4, sequence: 'standard' }, aeroLoad: rec });
  const text = IO.exportPrintedStudy(state(record), E, { savedAt: '2026-10-29T00:00:00.000Z' }), back = IO.importPrintedStudy(text, E);
  ok(JSON.parse(text).study.aeroLoad.levels.length === 8 && back.ok && JSON.stringify(back.state.aeroLoad) === JSON.stringify(record), 'an eight-mesh load is saved and read back exactly');
  const rec7 = { ...record, levels: record.levels.filter(l => !(l.chordPanels === 24 && l.spanPanels === 24)) }, back7 = IO.importPrintedStudy(IO.exportPrintedStudy(state(rec7), E), E);
  ok(back7.ok && back7.state.aeroLoad.levels.length === 7 && !UI.delivered(W, gs, back7.state.aeroLoad, []).crossTerm.estimated, 'a seven-mesh load (written before the joint mesh existed) is read and combined additively');
  const refuse = (mut, re, label) => { const d = JSON.parse(text); mut(d); const r = IO.importPrintedStudy(JSON.stringify(d), E); ok(!r.ok && r.errors.some(e => re.test(e)), `${label}: ${r.errors.find(e => re.test(e)) || r.errors[0]}`); };
  refuse(d => { const i = d.study.aeroLoad.levels.findIndex(l => l.chordPanels === 16 && l.spanPanels === 16); d.study.aeroLoad.levels.splice(i, 1); }, /not a mesh of the standard sequence/, 'seven meshes with the joint mesh but without a refinement level');
  refuse(d => { d.study.aeroLoad.levels.splice(0, 2); }, /must hold the 8 meshes .*or its first 7/, 'six meshes');
  refuse(d => { d.study.aeroLoad.levels.at(-1).chordPanels = 20; }, /not a mesh of the standard sequence/, 'foreign joint mesh');
}

console.log('5. Rectangular NACA 0012 AR 6, alpha 4 (the PANAIR wing): the joint grid');
{
  const G = JSON.parse(readFileSync(new URL('./validation/cross_term_grid_rect0012.json', import.meta.url), 'utf8')), geo = G.geometry, flow = G.flow, cb = 32, sb = 16;
  const keys = ['CL', 'CLTrefftz', 'CDpressure', 'CDiTrefftz', 'Cm'], Q = (c, s) => G.meshes[`${c}x${s}`];
  for (const [c, s] of [[32, 16], [48, 24]]) {
    const r = W.evaluate(W.prepare(geo, { chordPanels: c, spanPanels: s }, { referenceLimits: { maxPanels: 100000, chordPanels: [6, 512], spanPanels: [4, 256] } }), flow).coefficients;
    ok(keys.every(k => Math.abs(r[k] - Q(c, s)[k]) <= 1e-10 * Math.max(Math.abs(Q(c, s)[k]), 1e-4)), `the stored grid belongs to this core: ${2 * c} x ${s} re-solved, every coefficient within 1e-10`);
  }
  const C = G.chord, S = G.span, joint = [];
  for (const c of C) for (const s of S) if (c !== cb && s !== sb && c >= 48 && s >= 24) joint.push([c, s]);
  const live = { standard: W.combineSequence(geo, W.runSequence(geo, flow, 'standard')).coefficients, fine: W.combineSequence(geo, W.runSequence(geo, flow, 'fine')).coefficients };
  const solveLS = (A, y) => { const n = A[0].length, M = Array.from({ length: n }, (_, i) => [...Array.from({ length: n }, (_, j) => A.reduce((t, r) => t + r[i] * r[j], 0)), A.reduce((t, r, q) => t + r[i] * y[q], 0)]);
    for (let k = 0; k < n; k++) { let p = k; for (let i = k + 1; i < n; i++) if (Math.abs(M[i][k]) > Math.abs(M[p][k])) p = i; [M[k], M[p]] = [M[p], M[k]]; for (let i = k + 1; i < n; i++) { const f = M[i][k] / M[k][k]; for (let j = k; j <= n; j++) M[i][j] -= f * M[k][j]; } }
    const x = new Array(n).fill(0); for (let i = n - 1; i >= 0; i--) { let t = M[i][n]; for (let j = i + 1; j < n; j++) t -= M[i][j] * x[j]; x[i] = t / M[i][i]; } return x; };
  const models = [(hc, hs) => [1, hc, hc * hc, hs, hs * hs, hc * hs], (hc, hs) => [1, hc * hc, hc ** 3, hs, hs * hs, hc * hs], (hc, hs) => [1, hc, hc * hc, hs, hs ** 1.5, hc * hs]];
  for (const k of keys) {
    const ks = joint.map(([c, s]) => (Q(c, s)[k] - Q(c, sb)[k] - Q(cb, s)[k] + Q(cb, sb)[k]) / ((1 / c - 1 / cb) * (1 / s - 1 / sb))), mean = ks.reduce((a, b) => a + b, 0) / ks.length, spread = Math.max(...ks.map(v => Math.abs(v / mean - 1)));
    const pts = []; for (const c of C) for (const s of S) pts.push([c, s, Q(c, s)[k]]);
    const fits = models.map(m => solveLS(pts.map(([c, s]) => m(1 / c, 1 / s)), pts.map(p => p[2]))[0]), ref = fits.reduce((a, b) => a + b, 0) / fits.length, uRef = Math.max(...fits.map(v => Math.abs(v - ref)));
    // the cross term is bilinear: its coefficient varies by at most 35 % between joint meshes (CDi: 10 %)
    ok(spread < (k === 'CDiTrefftz' ? 0.10 : 0.35), `${k}: cross-term coefficient k = ${e3(mean)} over ${ks.length} joint meshes (largest deviation ${(100 * spread).toFixed(0)} %); X(32 x 16 base) = ${e3(mean / (cb * sb))}`);
    for (const sn of ['standard', 'fine']) {
      const e = live[sn][k], err = Math.abs(e.value - ref), noX = e.value - (e.cross ? e.cross.value : 0), errAdd = Math.abs(noX - ref);
      ok(err + uRef <= e.uncertainty, `${k} ${sn}: ${e.value.toPrecision(8)} +- ${e3(e.uncertainty)}; grid continuum ${ref.toPrecision(8)} (+- ${e3(uRef)} between fit models): |error| + u ${e3(err + uRef)} <= U (additive alone: error ${e3(errAdd)} against its U ${e3(e.uncertainty - 1.25 * 0.5 * Math.abs(e.cross ? e.cross.value : 0))})`);
    }
  }
  const fi = live.fine.CDiTrefftz;
  for (const m of ['96x64', '128x64']) ok(Math.abs(fi.value - G.meshes[m].CDiTrefftz) <= fi.uncertainty, `Fine CDi ${fi.value.toPrecision(8)} +- ${e3(fi.uncertainty)} covers the finer same-model mesh ${m} (${G.meshes[m].CDiTrefftz.toPrecision(8)}, itself ${e3(G.meshes[m].CDiTrefftz - live.fine.CDiTrefftz.value)} from the estimate)`);
}
console.log('6. Study files written by earlier versions (seven meshes) and the built Worker');
{
  // Files written BY THE EARLIER CODE (validation/legacy_loads/make_legacy_load.mjs, run with 0.3.1 and with 6e30853),
  // with that code's own delivered load: read, combined under the earlier separable rule, marked, nothing fabricated.
  IO.setAeroGeometryKey(x => IO.sha256(W.geometryKey(x)));
  for (const tag of ['0.3.1', '6e30853']) {
    const text = readFileSync(new URL(`./validation/legacy_loads/legacy_v4_${tag}_standard.json`, import.meta.url), 'utf8'), exp = JSON.parse(readFileSync(new URL(`./validation/legacy_loads/legacy_v4_${tag}_standard_expected.json`, import.meta.url), 'utf8'));
    const r = IO.importPrintedStudy(text, E);
    ok(r.ok && r.version === 4 && r.state.aeroLoad.levels.length === 7 && JSON.parse(text).study.aeroLoad.levels.length === 7, `${tag} file: version 4 with seven meshes is read, still seven meshes (no joint mesh added)`);
    const gx = E.makeGeometry(r.state.geometry), comb = UI.delivered(W, gx, r.state.aeroLoad, []);
    ok(comb.crossTerm.estimated === false && /cross term not estimated/.test(comb.crossTerm.note) && Object.values(comb.coefficients).every(e => e.cross === null), `${tag} file: combined additively and marked (crossTerm.estimated false: "${comb.crossTerm.note}")`);
    ok(JSON.stringify(comb.strips) === JSON.stringify(exp.strips) && JSON.stringify(comb.weights) === JSON.stringify(exp.weights), `${tag} file: delivered strips and weights equal, bit for bit, what ${exp.writer} delivered for it`);
    ok(Object.entries(exp.coefficients).every(([k, e]) => comb.coefficients[k].value === e.value && comb.coefficients[k].uncertainty === e.uncertainty), `${tag} file: every coefficient and its U equal the writer's`);
    const cuts = [{ y: 0, root: true, reference: [50, 0, 0], normal: [0, 1, 0] }, { y: 150, reference: [55, 150, 0], normal: [0, 1, 0] }], ld = r.state.aeroLoad;
    const adm = W.admission(gx, { sequence: ld.sequence, levels: ld.levels, flow: { ...ld.flow, dynamicPressure_Pa: 0.5 * ld.flow.density * ld.flow.speed ** 2 }, reference: W.references(W.aeroGeometry(gx)) }, comb, cuts);
    ok(adm.crossTerm.estimated === false && adm.notes.some(n => /seven meshes of an earlier version/.test(n)) && /cross term is not estimated/.test(adm.method), `${tag} file: the admission says so in its notes and method`);
    const tq = adm.rows.filter(x => x.kind === 'torque');
    ok(tq.length === exp.torques.length && tq.every((x, i) => x.value === exp.torques[i].value && x.uncertainty === exp.torques[i].uncertainty), `${tag} file: the admission torques and U equal the writer's`);
  }
  // the built Worker (site-aerostruct/wing-aero, as test_wing_aero_worker.mjs runs it): eight meshes, progress per mesh
  const vm = await import('node:vm'), dir = new URL('../../../site-aerostruct/wing-aero/', import.meta.url), rd = f => readFileSync(new URL(f, import.meta.url), 'utf8');
  const bundle = readFileSync(new URL('aero_bundle.js', dir), 'utf8'), workerText = readFileSync(new URL('wing_aero_worker.js', dir), 'utf8');
  ok(bundle === ['../web/wing_airfoils.js', '../web/wing_geometry.js', 'wing_aero_panel.js'].map(rd).join('\n;\n'), 'the built Worker bundle is exactly the current sources');
  const posted = [], ctx = { console, Date, Math, JSON, Map, Set, WeakSet, Float64Array, Int32Array, Uint8Array, Object, Array, Error, Number, String, isFinite, Symbol, performance };
  ctx.self = ctx; ctx.postMessage = m => posted.push(structuredClone(m)); ctx.importScripts = () => vm.runInContext(bundle, ctx, { filename: 'aero_bundle.js' });
  vm.createContext(ctx); vm.runInContext(workerText, ctx, { filename: 'wing_aero_worker.js' });
  const gw = JSON.parse(JSON.stringify(E.makeGeometry(E.DEFAULT_GEOMETRY)));
  ctx.onmessage({ data: { id: 7, kind: 'sequence', geometry: gw, flow: { speed: 15, density: 1.225, alphaDeg: 4 }, sequence: 'fine', options: {} } });
  const done = posted.find(m => m.kind === 'complete'), direct = W.runSequence(gw, { speed: 15, density: 1.225, alphaDeg: 4 }, 'fine');
  ok(posted.filter(m => m.kind === 'progress' && /^Mesh \d of 8/.test(m.text)).length === 8 && done && done.result.levels.length === 8 && JSON.stringify(done.result.definition.joint) === '[48,24]', 'Worker, Fine: one progress message per mesh (8) and the eight solved meshes, joint mesh 96 x 24');
  ok(JSON.stringify(done.result.levels.map(l => l.strips)) === JSON.stringify(direct.levels.map(l => l.strips)) && JSON.stringify(done.result.weights) === JSON.stringify(direct.weights), 'Worker levels and weights equal a direct call of the core');
  const rec = UI.recordFromSequence(done.result, IO.sha256(W.geometryKey(gw)));
  ok(rec.levels.length === 8 && UI.delivered(W, gw, rec, []).crossTerm.estimated === true, 'the page record of a Worker result keeps all eight meshes and is combined with the cross term');
}
console.log(`\ncross term: ${checks} checks passed (${((Date.now() - t0) / 1000).toFixed(0)} s)`);
