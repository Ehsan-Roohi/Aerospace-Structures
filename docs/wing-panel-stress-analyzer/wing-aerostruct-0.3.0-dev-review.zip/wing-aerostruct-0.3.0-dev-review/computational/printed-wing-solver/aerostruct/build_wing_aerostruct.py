"""Build Wing AeroStruct (development) as a SEPARATE application. Never writes to docs/ (the published Wing Lab).

Wing AeroStruct = the unchanged Wing Lab 1.3 modules in ../web/ plus the files in this directory:
  wing_aerostruct_template.html  Wing Lab 1.3 page + aerodynamics and coupling section, own branding and storage
  engine.js                      Wing Lab 1.3 structural engine + six-component aerodynamic strip loads
                                 (fork; the exact change set is engine_fork.diff)
  wing_study_io.js               1.3 study IO + optional study.aerodynamics (v3) and study.aeroLoad (v4) blocks
  wing_aero_panel.js             source/doublet surface-panel core, mesh sequence, extrapolation, admission (new)
  wing_aero_ui.js                aerodynamic UI and coupling helpers (new)
  wing_aero_worker.js            Web Worker for the panel solves (new)
A file present here overrides the 1.3 file of the same name; every other module is read from ../web/.

    python computational/printed-wing-solver/aerostruct/build_wing_aerostruct.py [output-directory]

Default output: <repo>/site-aerostruct/ with index.html and wing-lab.html (the same standalone page, so links from
the copied Truss Lab stay inside this site), truss-lab.html (copied unchanged), wing-print/ (STL/DXF/STEP Worker),
wing-aero/ (aerodynamic Worker) and BUILD.json (sources and SHA-256). Nothing is published and docs/ is only read.
"""

import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "web"
REPO = HERE.parents[2]
APP_VERSION = "0.3.0-dev"
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else REPO / "site-aerostruct"
if OUT == (REPO / "docs").resolve() or (REPO / "docs").resolve() in OUT.parents:
    raise SystemExit("Refusing to write Wing AeroStruct into docs/: that is the published Wing Lab site.")


def source(name):
    """AeroStruct override if present, otherwise the shared Wing Lab 1.3 module."""
    own = HERE / name
    return own if own.exists() else BASE / name


used = {}


def read(name):
    path = source(name)
    text = path.read_text(encoding="utf-8")
    used[name] = {"path": str(path.relative_to(REPO)), "sha256": hashlib.sha256(text.encode()).hexdigest()}
    return text


page = read("wing_aerostruct_template.html")
assert "/*__ENGINE__*/" in page
page = page.replace("/*__ENGINE__*/", read("engine.js"))
for token, filename in [("/*__WING_CHART_MATH__*/", "wing_chart_math.js"), ("/*__WING_GEOMETRY_HELP__*/", "wing_geometry_help.js"), ("/*__WING_SELECTION_UI__*/", "wing_selection_ui.js")]:
    assert token in page
    page = page.replace(token, read(filename))
TOKENS = [("/*__LOAD_PROFILES__*/", "load_profiles.js"), ("/*__WING_SPARS__*/", "wing_spars.js"), ("/*__WING_FINITE_SECTION_DEPS__*/", "vendor/finite-section-geometry/geometry.min.js"),
          ("/*__WING_FINITE_SECTION__*/", "wing_finite_section.js"), ("/*__WING_AIRFOILS__*/", "wing_airfoils.js"), ("/*__WING_GEOMETRY__*/", "wing_geometry.js"),
          ("/*__WING_AERO_PANEL__*/", "wing_aero_panel.js"), ("/*__WING_AERO_UI__*/", "wing_aero_ui.js"),
          ("/*__WING_FRAME3D__*/", "wing_frame3d.js"), ("/*__WING_CLOSED_TIP_STRESS__*/", "wing_closed_tip_stress.js"), ("/*__WING_GEOMETRY_UI__*/", "wing_geometry_ui.js"),
          ("/*__BEAM_STYLES__*/", "beam_lab.css"), ("/*__BEAM_SECTIONS__*/", "beam_sections.js"), ("/*__BEAM_ENGINE__*/", "beam_learning_engine.js"),
          ("/*__BEAM_STRENGTH__*/", "beam_strength.js"), ("/*__BEAM_STRENGTH_UI__*/", "beam_strength_ui.js"), ("/*__BEAM_STUDY__*/", "beam_study.js"), ("/*__BEAM_DIAGRAMS__*/", "beam_diagrams.js"),
          ("/*__BEAM_SOLUTION__*/", "beam_solution.js"), ("/*__COMPANION_TOOLS__*/", "companion_tools.js"), ("/*__FOUNDATIONS__*/", "foundations_ui.js"), ("/*__TEACHING_MODELS__*/", "teaching_models.js"),
          ("/*__WING_LOADS_UI__*/", "wing_loads_ui.js"), ("/*__WING_WORKSPACE_UI__*/", "wing_workspace_ui.js"), ("/*__WING_STUDY_IO__*/", "wing_study_io.js"), ("/*__WING_STL_IMPORT__*/", "wing_stl_import.js"),
          ("/*__WING_STL_REFERENCE_UI__*/", "wing_stl_reference_ui.js"), ("/*__WING_PRINT_UI__*/", "wing_print_ui.js"), ("/*__TEACHING_PANELS__*/", "teaching_panels.js"),
          ("/*__METAL_ENGINE__*/", "metal_wing_engine.js"), ("/*__METAL_REFERENCE__*/", "metal_wing_reference.json"), ("/*__METAL_UI__*/", "metal_wing_ui.js")]
for token, filename in TOKENS:
    assert page.count(token) == 1, token
    text = read(filename)
    if filename == "vendor/finite-section-geometry/geometry.min.js":
        text = "/*\n" + read("vendor/finite-section-geometry/LICENSES.txt") + "\n*/\n" + text
    if filename.endswith(".json"):
        json.loads(text)
        text = text.strip()
    if filename == "wing_print_ui.js":  # isolate the printer-fit record from the Wing Lab site's storage
        assert text.count("'winglab:print-fit-record'") == 2  # read and write
        text = text.replace("'winglab:print-fit-record'", "'wing-aerostruct:print-fit-record'")
    page = page.replace(token, text)
assert "/*__" not in page.replace("/*__proto__", ""), "an inline token was left unreplaced"
assert "localStorage.getItem(\"winglab:" not in page and "'winglab:printed-study" not in page and "winglab-1.4:" not in page

OUT.mkdir(parents=True, exist_ok=True)
title_end = page.index("</title>") + len("</title>")
standalone = ("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
              "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n"
              "<meta name=\"color-scheme\" content=\"light\">\n<meta name=\"robots\" content=\"noindex\">\n"
              + page[:title_end] + "\n" + page[title_end:page.index("</style>") + len("</style>")]
              + "\n</head>\n<body>\n" + page[page.index("</style>") + len("</style>"):] + "\n</body>\n</html>\n")
# Aerodynamic panel Worker, loaded only on "Run mesh sequence". Its URL carries a content hash so a
# browser never pairs a new page with a cached old Worker (or the Worker with an old bundle).
aero_files = ["wing_airfoils.js", "wing_geometry.js", "wing_aero_panel.js"]
aero_bundle = "\n;\n".join(read(name) for name in aero_files)
aero_hash = hashlib.sha256(aero_bundle.encode()).hexdigest()[:12]
aero_worker = read("wing_aero_worker.js").replace("'./aero_bundle.js'", f"'./aero_bundle.js?v={aero_hash}'")
assert f"aero_bundle.js?v={aero_hash}" in aero_worker
worker_hash = hashlib.sha256(aero_worker.encode()).hexdigest()[:12]
assert standalone.count("wing-aero/wing_aero_worker.js?v=aerostruct-dev") == 1
standalone = standalone.replace("wing-aero/wing_aero_worker.js?v=aerostruct-dev", f"wing-aero/wing_aero_worker.js?v={worker_hash}")
(OUT / "index.html").write_text(standalone, encoding="utf-8", newline="\n")
# Same page under the Wing Lab file name, so cross-links (e.g. from the Truss Lab) stay inside this site.
(OUT / "wing-lab.html").write_text(standalone, encoding="utf-8", newline="\n")
# The Truss Lab is not part of AeroStruct: copy the already-built stable page unchanged (read-only source).
truss = REPO / "docs" / "truss-lab.html"
if truss.exists():
    shutil.copyfile(truss, OUT / "truss-lab.html")
    used["truss-lab.html (copied unchanged)"] = {"path": "docs/truss-lab.html", "sha256": hashlib.sha256(truss.read_bytes()).hexdigest()}

# STL/DXF/STEP Worker (Wing Lab 1.3 modules; the engine fork is identical to 1.3 without an aerodynamic load).
print_files = ["load_profiles.js", "wing_spars.js", "vendor/finite-section-geometry/geometry.min.js", "wing_finite_section.js", "wing_airfoils.js", "wing_geometry.js", "wing_frame3d.js", "wing_closed_tip_stress.js", "engine.js", "wing_print_mesh.js", "wing_cad_export.js"]
print_bundle = "\n;\n".join(read(name) for name in print_files)
print_hash = hashlib.sha256(print_bundle.encode()).hexdigest()[:12]
target = OUT / "wing-print"
(target / "vendor").mkdir(parents=True, exist_ok=True)
(target / "engine_bundle.js").write_text(print_bundle, encoding="utf-8", newline="\n")
shutil.copyfile(source("vendor/finite-section-geometry/LICENSES.txt"), target / "section-geometry-LICENSES.txt")
(target / "wing_print_worker.js").write_text(read("wing_print_worker.js").replace("'./engine_bundle.js'", f"'./engine_bundle.js?v={print_hash}'"), encoding="utf-8", newline="\n")
for name in ["manifold.js", "manifold.wasm", "LICENSE", "PROVENANCE.json"]:
    shutil.copyfile(BASE / "vendor" / "manifold-3.5.4" / name, target / "vendor" / name)

target = OUT / "wing-aero"
target.mkdir(parents=True, exist_ok=True)
(target / "aero_bundle.js").write_text(aero_bundle, encoding="utf-8", newline="\n")
(target / "wing_aero_worker.js").write_text(aero_worker, encoding="utf-8", newline="\n")

build = {"product": "MIE 446 Wing AeroStruct", "version": APP_VERSION, "status": "development build, not published; a separate application from Wing Lab",
         "builtAt": datetime.now(timezone.utc).replace(microsecond=0).isoformat(), "page": "index.html", "pageSha256": hashlib.sha256(standalone.encode()).hexdigest(),
         "workers": {"wing-aero": {"worker": worker_hash, "bundle": aero_hash}, "wing-print": print_hash}, "sources": dict(sorted(used.items()))}
(OUT / "BUILD.json").write_text(json.dumps(build, indent=2) + "\n", encoding="utf-8", newline="\n")
print(f"{OUT.relative_to(REPO) if REPO in OUT.parents else OUT}/index.html {len(standalone) / 1024:.0f} KB; wing-aero/ {worker_hash} (bundle {aero_hash}); wing-print/ {print_hash}; docs/ untouched")
