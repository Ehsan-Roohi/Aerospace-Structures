// Wing AeroStruct BUILT page (site-aerostruct/index.html) in jsdom with the real engines, as the Wing Lab page tests
// do (inline scripts in page order; WebGL replaced by a THREE stand-in copied from ../web/test_wing_layout_controls.mjs).
// Drives the coupled workflow like a user: open the editable course study, run the Standard sequence and apply it (the
// near-zero torque about this structure's axis is not resolved; its twist bound is negligible, so the coupled result
// is shown with torque and twist withheld: views disabled, charts and report without them), the same load on a
// low-GJ version of the structure (refused: coupled result withheld), the Fine sequence (six-component load in the
// spatial beam, the reviewer's 1.950 +- 0.955 N mm reported as not resolved), autosave as version 4, undo and redo,
// stale shape refused, removal, share link, and the Wing Lab site and sources left untouched.
//   MIE446_JSDOM_MODULE=/path/to/node_modules/jsdom node computational/printed-wing-solver/aerostruct/test_aerostruct_page.mjs
import assert from 'node:assert/strict';
import { readFileSync, existsSync, realpathSync } from 'node:fs';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import vm from 'node:vm';
const require = createRequire(import.meta.url);
const { JSDOM, VirtualConsole } = require(process.env.MIE446_JSDOM_MODULE || 'jsdom');
const E = require('./engine.js');
const pageUrl = new URL('../../../site-aerostruct/index.html', import.meta.url);
if (!existsSync(pageUrl)) { console.log('test_aerostruct_page: build site-aerostruct first (build_wing_aerostruct.py)'); process.exit(1); }
const page = readFileSync(pageUrl, 'utf8');
let checks = 0;
const ok = (cond, msg) => { assert.ok(cond, msg); checks++; };
const log = (...a) => console.log('  ', ...a);
function makeThree() {
  const universal=(seed)=>{
    const store=Object.create(null), kids=new Map();
    if(seed&&typeof seed==='object'&&!Array.isArray(seed)) Object.assign(store,seed);
    return new Proxy(function(){},{
      get(t,k){
        if(k===Symbol.toPrimitive) return hint=>hint==='number'?0:'';
        if(k===Symbol.iterator) return function*(){};
        if(k==='then'||k==='toJSON'||typeof k==='symbol') return undefined;
        if(k in store) return store[k];
        if(!kids.has(k)) kids.set(k,universal());
        return kids.get(k);
      },
      set(t,k,v){if(typeof k==='string'&&/^\d+$/.test(k))return true;store[k]=v;return true;},
      has:()=>true, apply:()=>universal(), construct:(t,args)=>universal(args[0]),
    });
  };
  class Obj {
    constructor(){this.children=[];this.parent=null;this.visible=true;this.name='';this.userData={};for(const k of ['position','rotation','scale','quaternion','matrixWorld'])this[k]=universal();}
    add(...o){for(const c of o){if(c.parent)c.parent.remove(c);c.parent=this;this.children.push(c);}return this;}
    remove(o){const i=this.children.indexOf(o);if(i>=0){this.children.splice(i,1);o.parent=null;}return this;}
    traverse(f){f(this);for(const c of [...this.children])c.traverse(f);}
    getObjectByName(n){if(this.name===n)return this;for(const c of this.children){const r=c.getObjectByName(n);if(r)return r;}return undefined;}
    clone(){const o=new this.constructor(this.geometry,this.material);o.name=this.name;o.visible=this.visible;o.userData={...this.userData};for(const c of this.children)o.add(c.clone());return o;}
    updateMatrixWorld(){} updateWorldMatrix(){} lookAt(){}
  }
  class Mesh extends Obj {constructor(geometry,material){super();this.isMesh=true;this.geometry=geometry||universal();this.material=material||universal();}}
  class Group extends Obj {}
  class Scene extends Obj {}
  class ArrowHelper extends Obj {constructor(direction,origin,length,color){super();Object.assign(this,{direction,origin,length,color});}}
  const classes={Mesh,Group,Scene,Object3D:Obj,ArrowHelper};
  return new Proxy({},{get:(t,k)=>typeof k==='symbol'?undefined:k in classes?classes[k]:universal(),has:()=>true});
}

const virtualConsole = new VirtualConsole(), pageErrors = [];
virtualConsole.on('jsdomError', e => pageErrors.push(String(e && e.message)));
const dom = new JSDOM(page, { url: 'https://example.org/wing-aerostruct/index.html', runScripts: 'outside-only', virtualConsole });
const w = dom.window, ctx = dom.getInternalVMContext();
Object.defineProperty(w, 'innerWidth', { value: 1440, configurable: true });
w.matchMedia = () => ({ matches: false, addEventListener() {}, removeEventListener() {}, addListener() {}, removeListener() {} });
w.requestAnimationFrame = () => 0; w.cancelAnimationFrame = () => {}; w.setInterval = () => 0;
w.HTMLElement.prototype.scrollIntoView = function () {}; w.HTMLCanvasElement.prototype.getContext = () => null;
w.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
w.confirm = () => true;
w.console.error = () => {};
// jsdom has no modal dialogs: the page's error dialog (used when a coupled result is withheld) opens as a flag
if (w.HTMLDialogElement && !w.HTMLDialogElement.prototype.showModal) { w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); }; w.HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); }; }
for (const [, attrs, code] of page.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
  if (/\bsrc=/.test(attrs)) { if (/OrbitControls/.test(attrs)) w.THREE = makeThree(); continue; }
  vm.runInContext(code, ctx);
}
const $ = s => w.document.querySelector(s), tick = (ms = 0) => new Promise(r => setTimeout(r, ms));
async function until(test, what, ms = 180000) { const end = Date.now() + ms; while (!test()) { assert.ok(Date.now() < end, `timed out waiting for ${what}`); await tick(20); } }
const ui = () => w.WingLabUI;
const settled = async () => { await until(() => !ui().isRunning(), 'the solver to finish'); await tick(5); };
const solved = async () => { await until(() => ui().result() && !ui().isRunning() && !ui().isStale() && /Solved/.test($('#stateChip').textContent), 'a solved study'); await tick(5); };
w.dispatchEvent(new w.CustomEvent('wing-learning-stage', { detail: 'project' }));
await solved();
ok(/Wing AeroStruct/.test(w.document.title) && $('#wingProjectTitle').textContent === 'Wing AeroStruct' && /separate from Wing Lab/.test($('#wingProjectTitle').parentElement.textContent), 'the page identifies itself as Wing AeroStruct, separate from Wing Lab');
ok($('#wingSide #wlAero #wingAeroPanel .wae') && $('#aeroRun') && $('#aeroSequence'), 'the aerodynamics and coupling section is mounted in the input column');
// the course default (rods, dry seams) cannot take six-component loads: the sequence runs, Apply is refused with the reason
$('#aeroRun').click();
await until(() => /^Solved the standard sequence/.test($('#aeroStatus').textContent) || $('#aeroStatus .wae-err'), 'Standard sequence on the course wing');
ok($('#aeroApply').disabled && /cannot take the aerodynamic load/.test($('#aeroResults').textContent) && /rods/i.test($('#aeroResults').textContent), 'course wing with rods: Apply disabled, the spatial-beam restriction is named');
// open the editable course study (bonded seams, spars, no rods) through the page's own file path
const files = ui().studyFiles();
files.openText(readFileSync(new URL('../../../tests/fixtures/wing_lab_editable_browser.json', import.meta.url), 'utf8'), 'wing_lab_editable_browser.json');
await until(() => [...w.document.querySelectorAll('#wingStudyFiles button')].some(b => /^Apply/.test(b.textContent) && !b.disabled), 'the study preview');
[...w.document.querySelectorAll('#wingStudyFiles button')].find(b => /^Apply/.test(b.textContent)).click();
await tick(20); ui().solve(); await solved();
ok(!ui().result().analysis3D && ui().state().assembly.seamsBonded && !ui().state().geometry.rodFractions.length, 'editable study opened and solved by the straight beam (no aerodynamic load yet)');
// Standard sequence, apply: the torque about this structure's shear-centre axis is a near-zero difference that the
// Standard sequence does not resolve (no absolute floor); the twist bound from this structure's torsional compliance
// is aerodynamically negligible, so the coupled result is shown with torque and twist withheld
$('#aeroRun').click();
await until(() => /^Solved the standard sequence/.test($('#aeroStatus').textContent), 'Standard sequence on the editable wing');
ok(!$('#aeroApply').disabled, 'Apply offered for the bonded, rod-free structure');
$('#aeroApply').click(); await settled();
const adm1 = ui().aero().admission, R1 = ui().result();
log(`Standard sequence applied: ${adm1 ? (adm1.admitted ? 'admitted' : 'NOT admitted') : 'no admission'} (torque ${adm1?.claims.torque}, twist ${adm1?.claims.twist}); ${adm1 ? adm1.rows.map(r => `${r.label} ${r.kind === 'twist' ? r.status : `${(100 * r.measure).toFixed(1)}%${r.status && !r.resolved ? ` ${r.status}` : ''}`}`).join('; ') : ''}`);
ok(ui().state().aeroLoad && ui().state().aeroLoad.sequence === 'standard' && ui().state().load.kind === 'custom', 'the Standard load is stored in the study');
ok(adm1 && adm1.admitted && adm1.claims.torque === 'withheld' && adm1.claims.twist === 'withheld' && adm1.rows.filter(r => r.kind === 'torque').every(r => !r.resolved) && /admitted with torque and twist withheld/.test($('#aeroAdmission').textContent), 'Standard: torque not resolved at any cut; admitted with torque and twist withheld (twist bound negligible)');
ok(R1.aeroAdmission === adm1 && !ui().isStale() && /torque and twist withheld/.test($('#wingAeroLoadResult').textContent), 'the coupled result is shown; its record says torque and twist are withheld');
const sel = $('#wingMoreResults'), opt = v => [...sel.options].find(o => o.value === v);
ok(opt('twist').disabled && opt('torque').disabled && /withheld/.test(opt('twist').title) && !opt('bending').disabled, 'More results: twist and torque disabled with the reason, bending still available');
const plotBefore = ui().state().plot; sel.value = 'twist'; sel.dispatchEvent(new w.Event('change', { bubbles: true })); await tick(5);
ok(ui().state().plot === plotBefore && ui().state().plot !== 'twist', 'choosing the twist view anyway is refused');
ok($('#wingTwistWithheldNote') && !/Elastic axis twist/.test($('#wingSpatialCharts').textContent) && /twist component withheld/.test($('#wingSpatialCharts').textContent) && /torsion T withheld/.test($('#wingSpatialCharts').textContent), 'spatial results: no twist or torque curve; bending rotations without the twist component; the bound is stated');
ok(/Twist about the axis/.test($('#wingSpatialResults').textContent) && /withheld/.test($('#wingSpatialResults').textContent), 'tip response table: twist withheld, bending rotations shown');
ok(/Twist and torque about the shear-centre axis: WITHHELD/.test($('#report').value) && !/Tip elastic rotation \[rad\]/.test($('#report').value), 'the report states the withheld twist instead of a value');
// the root reactions and cut moments contain the unresolved torque about the beam axis: only their bending part is shown
{
  const a1 = R1.analysis3D, e0 = a1.cutAt(0).R[0], react = Array.from({ length: 6 }, (_, i) => a1.reactions.find(r => r.dof === i)?.value ?? 0), Mr = react.slice(3);
  const t = Mr[0] * e0[0] + Mr[1] * e0[1] + Mr[2] * e0[2], bend = Mr.map((v, i) => v - t * e0[i]);
  const cells = [...$('#wingSpatialResults').querySelectorAll('tr')].filter(tr => /^M[xyz] bending$/.test(tr.querySelector('th')?.textContent || '')).map(tr => Number(tr.querySelector('td').textContent));
  log(`root reaction moment [${Mr.map(v => v.toFixed(3)).join(', ')}] N mm; component about the beam axis ${t.toFixed(3)} N mm (withheld); bending part shown [${cells.map(v => v.toFixed(3)).join(', ')}]`);
  ok($('#wingRootTorqueWithheld') && cells.length === 3 && cells.every((v, i) => Math.abs(v - bend[i]) <= 1e-5 * Math.max(1, Math.abs(bend[i]))) && ![...$('#wingSpatialResults').querySelectorAll('th')].some(th => /^M[xyz]$/.test(th.textContent)), 'root reactions: forces and the bending part of the moment shown, the torque about the beam axis withheld');
  ok(/Cut bending moment Mx \/ My \/ Mz \(torque about the beam axis removed/.test($('#wingSpatialCharts').textContent) && !/Cut moment Mx \/ My \/ Mz/.test($('#wingSpatialCharts').textContent), 'cut-moment chart without the unresolved torque component');
  ok(/Root reaction torque about the beam axis: WITHHELD/.test($('#report').value) && !/Root reactions \[N,N,N,Nmm,Nmm,Nmm\]/.test($('#report').value) && /"torqueAboutBeamAxis":"WITHHELD/.test($('#report').value) && /twist WITHHELD/.test($('#report').value), 'report: reaction torque, applied-wrench torque and twist written as WITHHELD');
  ok(/bending moment about beam root \[[^\]]+\] N·mm \(torque about the beam axis withheld/.test($('#wingLoadStatus').textContent) && !/total M about beam root/.test($('#wingLoadStatus').textContent), 'load status line: bending moment about the root, torque withheld');
}
// the same load on a low-GJ version of the structure (shell and spar modulus 10 MPa): the unresolved torque now gives a
// twist bound that is not negligible, so the coupled result is withheld (refused rather than overclaimed)
{
  const st = ui().state(), sparsBefore = JSON.parse(JSON.stringify(st.geometry.spars)), eBefore = st.plaOver.E;
  ui().applyGeometry({ spars: sparsBefore.map(sp => ({ ...sp, material: { ...sp.material, E: 10 } })) }); st.plaOver.E = 10;
  const before = ui().result(); ui().solve(); await settled();
  const admSoft = ui().aero().admission;
  log(`low-GJ structure: ${admSoft.admitted ? 'admitted' : 'NOT admitted'}; twist bound lift effect ${(100 * admSoft.twist.liftEffect).toFixed(2)}%; ${ui().inputError()}`);
  ok(!admSoft.admitted && admSoft.twist.status === 'unresolved' && ui().isStale() && ui().result() === before && /Coupled result withheld/.test(ui().inputError() || '') && /NOT admitted/.test($('#aeroAdmission').textContent) && /would change the lift by/.test($('#aeroAdmission').textContent), 'low-GJ structure: coupled result withheld, the previous result kept and marked out of date, the reason named');
  ui().applyGeometry({ spars: sparsBefore }); if (eBefore === undefined) delete st.plaOver.E; else st.plaOver.E = eBefore;
  ui().solve(); await solved();
  ok(ui().result().aeroAdmission?.admitted && !ui().isStale(), 'the original structure is admitted again');
}
// Fine sequence: admitted; the spatial beam carries the six-component load
$('#aeroSequence').value = 'fine';
const tf = Date.now(); $('#aeroRun').click();
await until(() => /^Solved the fine sequence/.test($('#aeroStatus').textContent), 'Fine sequence', 300000);
log(`Fine sequence: ${$('#aeroStatus').textContent} (${((Date.now() - tf) / 1000).toFixed(1)} s on the page thread)`);
$('#aeroApply').click(); await settled();
const R = ui().result(), adm2 = ui().aero().admission;
ok(adm2 && adm2.admitted && R.aeroAdmission === adm2 && !ui().isStale() && adm2.claims.twist === 'withheld', 'Fine sequence admitted: the coupled result is shown, torque and twist still withheld');
{ const t = adm2.rows.filter(r => r.kind === 'torque');
  ok(t[0].status === 'magnitude not resolved' && Math.abs(t[0].value - 1.95) < 0.01 && t[2].status === 'sign not resolved' && t[3].status === 'sign not resolved' && !t[3].meshSignsAgree, `Fine: root ${t[0].value.toFixed(3)} ± ${t[0].uncertainty.toFixed(3)} N mm reported as not resolved (${(100 * t[0].relative).toFixed(0)}% of |T|); 50% and 75% signs not resolved; meshes of both signs at 75%`); }
const a = R.analysis3D, strips = a.aeroLoad.strips, sum = strips.reduce((t, r) => t.map((v, i) => v + r[2 + i]), [0, 0, 0, 0, 0, 0]);
const P0 = a.nodes[0], Mroot = [sum[3] - (P0[1] * sum[2] - P0[2] * sum[1]), sum[4] - (P0[2] * sum[0] - P0[0] * sum[2]), sum[5] - (P0[0] * sum[1] - P0[1] * sum[0])];
log(`coupled: ${strips.length} strips; applied F = [${a.appliedWrench.force.map(v => v.toFixed(5)).join(', ')}] N, M = [${a.appliedWrench.momentAboutRoot.map(v => v.toFixed(3)).join(', ')}] N mm; root torque ${adm2.rows[0].value.toFixed(3)} ± ${adm2.rows[0].uncertainty.toFixed(3)} N mm (${(100 * adm2.rows[0].relative).toFixed(1)}% of |T|: ${adm2.rows[0].status}); twist ${adm2.twist.status}, bound ${(adm2.twist.maxBound * 180 / Math.PI).toExponential(2)} deg, lift effect ${(100 * adm2.twist.liftEffect).toFixed(3)}%`);
ok([0, 1, 2].every(i => Math.abs(a.appliedWrench.force[i] - sum[i]) < 1e-12 && Math.abs(a.appliedWrench.momentAboutRoot[i] - Mroot[i]) < 1e-9), 'all six root-wrench components of the delivered strips reach the beam');
ok($('#wingAeroLoadResult') && /six components, admitted/.test($('#wingAeroLoadResult').textContent), 'results record names the six-component aerodynamic load and its admission');
ok(/Aerodynamic panel load/.test($('#tree').textContent), 'the study tree names the aerodynamic load');
// isolated autosave: version 4 with the applied load
await tick(30);
const saved = JSON.parse(w.localStorage.getItem('wing-aerostruct:printed-study:v1'));
ok(saved && saved.version === 4 && saved.study.aeroLoad.sequence === 'fine' && saved.study.aeroLoad.levels.length === 7 && saved.app.name === 'MIE 446 Wing AeroStruct', 'autosave is a version-4 AeroStruct study with the applied load');
ok(w.localStorage.getItem('winglab:printed-study:v1') === null && w.localStorage.getItem('winglab-1.4:printed-study:v1') === null, 'nothing is written under the Wing Lab storage keys');
// share links refuse the applied load
$('#wingShareBtn').click(); await tick(20);
ok(/Share links do not carry an applied aerodynamic load/.test($('#wingShareMsg').textContent), 'share link refused while the load is applied');
// undo: back to the Standard record; redo: Fine again
$('#wingUndo').click(); await tick(10);
ok(ui().state().aeroLoad && ui().state().aeroLoad.sequence === 'standard', 'undo restores the previous applied load');
$('#wingRedo').click(); await tick(10);
ok(ui().state().aeroLoad.sequence === 'fine', 'redo restores the Fine load');
ui().solve(); await solved(); ok(ui().result().aeroAdmission.admitted, 'solving again after redo: admitted');
// a shape change makes the applied load stale: the solve refuses it instead of reusing or dropping it
const ag = ui().applyGeometry({ dihedralDeg: 2 }); await tick(5); ui().solve(); await settled();
log(`shape change: applyGeometry ${JSON.stringify(ag).slice(0, 160)}; dihedral now ${ui().state().geometry.dihedralDeg}; input error: ${ui().inputError()}; panel: ${$('#aeroApplied').textContent.slice(0, 160)}`);
ok(ui().isStale() && /solved for a different wing shape/.test(ui().inputError() || '') && /wing shape changed after this load was solved/.test($('#aeroApplied').textContent), 'stale aerodynamic load refused at Solve and flagged in the panel');
$('#wingUndo').click(); await tick(10); ui().solve(); await solved(); ok(ui().result().aeroAdmission?.admitted, 'undoing the shape change restores the admitted coupled result');
// remove: the structure is solved again without the aerodynamic load
$('#aeroRemove').click(); await tick(10); ui().solve(); await solved();
ok(ui().state().aeroLoad === null && !ui().result().analysis3D?.aeroLoad && $('#aeroAdmission').innerHTML === '', 'removal: no aerodynamic load in the study or the result');
ok(!pageErrors.length, `no page errors: ${pageErrors.slice(0, 3).join(' | ')}`);
// the separate site is self-contained: every relative link of its pages resolves inside site-aerostruct/
const site = new URL('../../../site-aerostruct/', import.meta.url), docs = new URL('../../../docs/', import.meta.url);
const bytes = (base, f) => readFileSync(new URL(f, base));
ok(bytes(site, 'wing-lab.html').equals(bytes(site, 'index.html')), 'wing-lab.html is the same AeroStruct page as index.html');
ok(!existsSync(new URL('truss-lab.html', docs)) || bytes(site, 'truss-lab.html').equals(bytes(docs, 'truss-lab.html')), 'truss-lab.html is the stable Truss Lab copied unchanged');
const relLinks = f => [...readFileSync(new URL(f, site), 'utf8').matchAll(/href="([^"#$][^"]*)"/g)].map(m => m[1].split('#')[0]).filter(h => !/^[a-z]+:/i.test(h));
const missing = ['index.html', 'truss-lab.html'].flatMap(f => relLinks(f).filter(h => !existsSync(new URL(h, site))).map(h => `${f} -> ${h}`));
ok(!missing.length && relLinks('index.html').includes('truss-lab.html') && relLinks('truss-lab.html').includes('wing-lab.html'), `relative links resolve inside site-aerostruct: ${missing.join(', ') || 'all found'}`);
ok(!/ehsan-roohi\.github\.io\/Aerospace-Structures\/(wing-lab|truss-lab)\.html/.test(page), 'no link from the AeroStruct page back into the published Wing Lab pages');
for (const f of ['wing-aero/wing_aero_worker.js', 'wing-aero/aero_bundle.js', 'wing-print/wing_print_worker.js', 'wing-print/engine_bundle.js', 'BUILD.json']) ok(existsSync(new URL(f, site)), `${f} present`);
// Wing Lab is untouched in this working tree
const repo = new URL('../../../', import.meta.url).pathname;
let docsClean = null;
try { // only when this folder is the top level of a git checkout (not, e.g., a standalone copy inside another repository)
  const top = execFileSync('git', ['-C', repo, 'rev-parse', '--show-toplevel'], { encoding: 'utf8' }).trim();
  if (realpathSync(top) === realpathSync(repo)) docsClean = execFileSync('git', ['-C', repo, 'status', '--porcelain', '--', 'docs', 'computational/printed-wing-solver/web'], { encoding: 'utf8' }).trim() === '';
} catch { docsClean = null; }
if (docsClean !== null) ok(docsClean, 'docs/ (published Wing Lab) and the Wing Lab sources have no changes'); else log('not a git checkout of the repository: Wing Lab check skipped');
console.log(`test_aerostruct_page: ${checks} checks passed`);
