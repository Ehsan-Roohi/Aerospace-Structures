// Tensor-quadratic doublet candidate (0.3.2-exp.3): kernel, basis and consistency tests (focused; NOT a physics gate).
//   1. panel doublet (quadratic P2 on each triangle of the split, node values from the panel's biquadratic at the
//      bilinear pre-images) against an independent reference: the P2 polynomial fitted through the six node values
//      by a 6 x 6 solve, polar coordinates about the projection of the field point, radial integral in closed form,
//      angle by adaptive Gauss-Kronrod; regular panels, warped rounded-tip panels and collapsed closed-tip panels;
//      the source vector (each triangle with its own normal) and the self terms;
//   2. equal values reproduce the 0.3.1 constant-doublet panel; jump across the panel = local doublet value;
//      far-field expansion error falls as (d/r)^2;
//   3. basis: constants reproduced; the chordwise and spanwise spline equations hold; every edge shared by two panels
//      carries the same three values on both sides (continuity), across the rounded-tip seam and at the closed-tip
//      point; zero wake strength at the tip for any doublets;
//   4. the panel matrix and the field evaluation are the same function; the solution satisfies the interior condition;
//   5. trailing-edge matching: wake strength = upper minus lower surface trace POINTWISE along the edge;
//   6. mirror image equals an explicit full span (cyclic span chains through both tips) with the same doublet model;
//   7. symmetric section at zero incidence carries no lift; Trefftz lift = exact integral of the solved wake; strip loads
//      reproduce the resultant;
//   8. doubletModel 'constant' reproduces published 0.3.1 bit for bit (SOLVER031) and 'span-quadratic' the previous
//      candidate commit (SOLVER_SQ) bit for bit;
//   9. non-planar panels (tip-rounding strips; every panel of a twisted wing): far field per triangle (each triangle
//      planar) at orders 1, 2 and 4 against the exact kernels, falling like the planar expansions; the assembled
//      solution of a twisted wing against the all-exact assembly;
//  10. surface velocity: the kernel's tangential-gradient jump across the sheet (differences of tensorPanel on both
//      sides) equals grad mu_T of the independently fitted P2 polynomial at generic triangle-interior points and at the
//      control points, and the recovered velocity (tensorTriangleVelocity) is V_t + grad mu_T of the same polynomial;
//      panel forces and couples are the exact integrals of the recovered quadratic Cp; strip wrenches include the couples.
//  12. far field of the ASSEMBLED solution on a fine spanwise mesh (rectangular NACA 0012 AR 6, 16 x 48, alpha 4):
//      default zones against every panel exact (the error of the earlier zones grew with spanwise refinement);
//  11. split rule at the closed corners of the last strip: no two panels share a triangle (no zero-thickness, double-
//      covered triangle); the panels that take the other diagonal are exactly those an independent all-pairs search
//      finds, only at the last strip's trailing-edge and leading-edge corners; the surface's solid-angle indicator is -1
//      just inside and 0 just outside their triangles; the fan fallback on a synthetic surface.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const t0 = Date.now();
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, s) => a.map(v => v * s);
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => Math.hypot(...a), unit = a => mul(a, 1 / norm(a));
const SWEPT = { naca: '2412', semiSpan: 300, rootChord: 140, tipChord: 80, sweepDeg: 15, dihedralDeg: 6, sweepReferenceFraction: 0.25 };
const ELLIPTIC = { naca: '0012', planform: 'elliptic', semiSpan: 400, rootChord: 150, tipChord: 0 };
let seed = 24680; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const xk = [0.991455371120813, 0.949107912342759, 0.864864423359769, 0.741531185599394, 0.586087235467691, 0.405845151377397, 0.207784955007898, 0];
const wk = [0.022935322010529, 0.063092092629979, 0.104790010322250, 0.140653259715525, 0.169004726639267, 0.190350578064785, 0.204432940075298, 0.209482141084728];
const wg = [0, 0.129484966168870, 0, 0.279705391489277, 0, 0.381830050505119, 0, 0.417959183673469];
const gk = (f, a, b) => { const c = 0.5 * (a + b), h = 0.5 * (b - a); let K = 0, G = 0; for (let i = 0; i < 8; i++) { if (i < 7) { const f1 = f(c - h * xk[i]), f2 = f(c + h * xk[i]); K += wk[i] * (f1 + f2); G += wg[i] * (f1 + f2); } else { const f0 = f(c); K += wk[i] * f0; G += wg[i] * f0; } } return [K * h, G * h]; };
const integ = (f, a, b, tol, d = 0) => { const [K, G] = gk(f, a, b); if (Math.abs(K - G) <= tol || d > 48) return K; const c = 0.5 * (a + b); return integ(f, a, c, tol, d + 1) + integ(f, c, b, tol, d + 1); };
const solveN = (A, b) => { const n = b.length, M = A.map((r, i) => [...r, b[i]]); for (let i = 0; i < n; i++) { let p = i; for (let k = i + 1; k < n; k++) if (Math.abs(M[k][i]) > Math.abs(M[p][i])) p = k; [M[i], M[p]] = [M[p], M[i]]; for (let k = i + 1; k < n; k++) { const f = M[k][i] / M[i][i]; for (let q = i; q <= n; q++) M[k][q] -= f * M[i][q]; } } const x = new Array(n).fill(0); for (let i = n - 1; i >= 0; i--) { let s = M[i][n]; for (let q = i + 1; q < n; q++) s -= M[i][q] * x[q]; x[i] = s / M[i][i]; } return x; };

// ---------------------------------------------------------------- independent reference of the documented model
const lag = x => [(1 - x) * (1 - 2 * x), 4 * x * (1 - x), x * (2 * x - 1)];
const corners = (S, k) => [0, 1, 2, 3].map(q => [S.PV[12 * k + 3 * q], S.PV[12 * k + 3 * q + 1], S.PV[12 * k + 3 * q + 2]]);
// bilinear pre-image of X (least squares), written independently: Newton on the normal equations' gradient
function preimage(c, X, s, t) {
  const B = (s, t) => [0, 1, 2].map(i => (1 - s) * (1 - t) * c[0][i] + s * (1 - t) * c[1][i] + s * t * c[2][i] + (1 - s) * t * c[3][i]);
  for (let it = 0; it < 60; it++) {
    const R = sub(B(s, t), X), Bs = [0, 1, 2].map(i => (1 - t) * (c[1][i] - c[0][i]) + t * (c[2][i] - c[3][i])), Bt = [0, 1, 2].map(i => (1 - s) * (c[3][i] - c[0][i]) + s * (c[2][i] - c[1][i]));
    const [ds, dt] = solveN([[dot(Bs, Bs), dot(Bs, Bt)], [dot(Bs, Bt), dot(Bt, Bt)]], [dot(Bs, R), dot(Bt, R)]); s -= ds; t -= dt;
    if (Math.abs(ds) + Math.abs(dt) < 1e-16) break;
  }
  return [s, t];
}
// the documented exception to the shorter-diagonal split: two mode-0 panels whose triangles coincide (every vertex within
// 1e-6 of the smaller panel diameter of a vertex of the other: the closed corners of the last strip) take the other
// diagonal. Brute force over all pairs of triangles (independent of the core's sorted sweep); first pass only, so a
// core panel on the fan fallback (split 2) would not match this reference.
const flipCache = new WeakMap();
function cornerFlips(S) {
  if (flipCache.has(S)) return flipCache.get(S);
  const tris = [], flips = new Set();
  for (let k = 0; k < S.count; k++) {
    const c = corners(S, k); if (norm(sub(c[2], c[3])) <= 1e-9 * S.PD[k]) continue;
    const d02 = norm(sub(c[2], c[0])), d13 = norm(sub(c[3], c[1])); if (Math.abs(d02 - d13) <= 1e-9 * Math.max(d02, d13)) continue;
    const r = d13 < d02 ? 1 : 0, p = q => c[(q + r) % 4];
    for (const Q of [[p(0), p(1), p(2)], [p(0), p(2), p(3)]]) tris.push({ k, Q, g: mul(add(add(Q[0], Q[1]), Q[2]), 1 / 3) });
  }
  for (let a = 0; a < tris.length; a++) for (let b = a + 1; b < tris.length; b++) {
    const A = tris[a], B = tris[b], tol = 1e-6 * Math.min(S.PD[A.k], S.PD[B.k]);
    if (A.k === B.k || norm(sub(A.g, B.g)) > tol) continue;
    if (A.Q.every(P => B.Q.some(Q => norm(sub(P, Q)) <= tol))) { flips.add(A.k); flips.add(B.k); }
  }
  flipCache.set(S, flips); return flips;
}
// the documented split and node parameters: returns triangles [{ Q: 3 points, nodes: 6 [s, t] (vertices, mids 01 12 20) }]
function panelModel(S, k) {
  const c = corners(S, k), d = S.PD[k], M = [0, 1, 2].map(i => 0.25 * (c[0][i] + c[1][i] + c[2][i] + c[3][i])), mid = (A, B) => [0, 1, 2].map(i => 0.5 * (A[i] + B[i]));
  const P = [[0, 0], [1, 0], [1, 1], [0, 1]], pm = (a, b) => [0.5 * (a[0] + b[0]), 0.5 * (a[1] + b[1])];
  if (norm(sub(c[2], c[3])) <= 1e-9 * d) { // collapsed v2 v3 (closed tip): fan of three about M; the tip node is the tip value
    const tip = [0.5, 1], Mp = [0.5, 0.5], s0 = preimage(c, mid(M, c[0]), 0.25, 0.25), s1 = preimage(c, mid(M, c[1]), 0.75, 0.25), s2 = preimage(c, mid(M, c[2]), 0.5, 0.75);
    return [{ Q: [M, c[0], c[1]], nodes: [Mp, P[0], P[1], s0, [0.5, 0], s1] }, { Q: [M, c[1], c[2]], nodes: [Mp, P[1], tip, s1, [1, 0.5], s2] }, { Q: [M, c[2], c[0]], nodes: [Mp, tip, P[0], s2, [0, 0.5], s0] }];
  }
  const d02 = norm(sub(c[2], c[0])), d13 = norm(sub(c[3], c[1])), tie = Math.abs(d02 - d13) <= 1e-9 * Math.max(d02, d13);
  if (tie) { // fan of four about M (any tie, warped or planar: mirror-invariant)
    const sp = [0, 1, 2, 3].map(q => preimage(c, mid(M, c[q]), 0.5 * (0.5 + P[q][0]), 0.5 * (0.5 + P[q][1])));
    return [0, 1, 2, 3].map(q => { const r = (q + 1) % 4; return { Q: [M, c[q], c[r]], nodes: [[0.5, 0.5], P[q], P[r], sp[q], pm(P[q], P[r]), sp[r]] }; });
  }
  const rot = (d13 < d02) !== cornerFlips(S).has(k) ? 1 : 0, a = rot, b = (1 + rot) % 4, cc = (2 + rot) % 4, dd = (3 + rot) % 4, dg = preimage(c, mid(c[a], c[cc]), 0.5, 0.5);
  return [{ Q: [c[a], c[b], c[cc]], nodes: [P[a], P[b], P[cc], pm(P[a], P[b]), pm(P[b], P[cc]), dg] }, { Q: [c[a], c[cc], c[dd]], nodes: [P[a], P[cc], P[dd], dg, pm(P[cc], P[dd]), pm(P[dd], P[a])] }];
}
const biq = (slots, [s, t]) => { const A = lag(s), B = lag(t); let v = 0; for (let b = 0; b < 3; b++) for (let a = 0; a < 3; a++) v += slots[a + 3 * b] * A[a] * B[b]; return v; };
// potential (per unit doublet units, /4pi) of the P2 doublet through six node values on triangle Q at P; source: unit source
function triP2Ref(Q, vals6, P, source = false) {
  const N = cross(sub(Q[1], Q[0]), sub(Q[2], Q[0])), A2 = norm(N); if (!(A2 > 1e-12)) return 0;
  const n = N.map(v => v / A2), h = dot(sub(P, Q[0]), n), Ph = P.map((v, i) => v - h * n[i]), e1 = unit(sub(Q[1], Q[0])), e2 = cross(n, e1), ah = Math.abs(h);
  const loc = X => [dot(sub(X, Q[0]), e1), dot(sub(X, Q[0]), e2)], pts = [Q[0], Q[1], Q[2], mid(Q[0], Q[1]), mid(Q[1], Q[2]), mid(Q[2], Q[0])].map(loc);
  const c = solveN(pts.map(([x, y]) => [1, x, y, x * x, x * y, y * y]), vals6), [xh, yh] = loc(Ph);
  const m0 = c[0] + c[1] * xh + c[2] * yh + c[3] * xh * xh + c[4] * xh * yh + c[5] * yh * yh, gx = c[1] + 2 * c[3] * xh + c[4] * yh, gy = c[2] + c[4] * xh + 2 * c[5] * yh;
  let total = 0;
  for (let i = 0; i < 3; i++) {
    const Av = sub(Q[i], Ph), Bv = sub(Q[(i + 1) % 3], Ph), a2 = [dot(Av, e1), dot(Av, e2)], b2 = [dot(Bv, e1), dot(Bv, e2)], cr = a2[0] * b2[1] - a2[1] * b2[0];
    if (Math.abs(cr) < 1e-14 * (norm(Av) + norm(Bv)) ** 2) continue;
    const thA = Math.atan2(a2[1], a2[0]); let dth = Math.atan2(b2[1], b2[0]) - thA; while (dth > Math.PI) dth -= 2 * Math.PI; while (dth < -Math.PI) dth += 2 * Math.PI;
    const ex = b2[0] - a2[0], ey = b2[1] - a2[1];
    const f = th => {
      const ct = Math.cos(th), st = Math.sin(th), R = cr / (ct * ey - st * ex), w = Math.sqrt(R * R + h * h);
      if (source) return w - ah;
      const a = m0, b = gx * ct + gy * st, cq = c[3] * ct * ct + c[4] * ct * st + c[5] * st * st;
      return a * (Math.sign(h) - h / w) + b * h * (-R / w + Math.log((R + w) / ah)) + cq * h * (w + h * h / w - 2 * ah);
    };
    total += integ(f, thA, thA + dth, 1e-15 * Math.abs(dth) * 10);
  }
  return total / (4 * Math.PI);
}
function mid(A, B) { return [0, 1, 2].map(i => 0.5 * (A[i] + B[i])); }
const slotValues = (B, k, V) => Array.from({ length: 9 }, (_, q) => V[B.refs[9 * k + q]]);
function panelRef(S, B, k, V, P) { const sl = slotValues(B, k, V); return panelModel(S, k).reduce((r, T) => r + triP2Ref(T.Q, T.nodes.map(st => biq(sl, st)), P), 0); }
function panelRefSource(S, k, P) { return panelModel(S, k).reduce((r, T) => { const N = cross(sub(T.Q[1], T.Q[0]), sub(T.Q[2], T.Q[0])), A2 = norm(N); return A2 > 1e-12 ? add(r, mul(N, triP2Ref(T.Q, [0, 0, 0, 0, 0, 0], P, true) / A2)) : r; }, [0, 0, 0]); }
// the surface doublet at a surface point X of panel k (the documented P2 of the triangle that contains X)
function doubletAt(S, B, k, V, X) {
  const sl = slotValues(B, k, V); let best = null;
  for (const T of panelModel(S, k)) {
    const N = cross(sub(T.Q[1], T.Q[0]), sub(T.Q[2], T.Q[0])), A2 = norm(N); if (!(A2 > 1e-12 * S.PD[k] ** 2)) continue;
    const n = N.map(v => v / A2), l = [0, 1, 2].map(i => dot(cross(sub(T.Q[(i + 2) % 3], T.Q[(i + 1) % 3]), sub(X, T.Q[(i + 1) % 3])), n) / A2), inside = Math.min(...l);
    if (!best || inside > best.inside) { const v6 = T.nodes.map(st => biq(sl, st)), [l0, l1, l2] = l; best = { inside, v: v6[0] * l0 * (2 * l0 - 1) + v6[1] * l1 * (2 * l1 - 1) + v6[2] * l2 * (2 * l2 - 1) + 4 * (v6[3] * l0 * l1 + v6[4] * l1 * l2 + v6[5] * l2 * l0) }; }
  }
  return best.v;
}
const meshOf = (geo, mesh) => W.wingMesh(W.aeroGeometry(geo), { ...mesh, doubletModel: 'tensor-quadratic' });

// ---------------------------------------------------------------- 1. kernel vs independent reference
{
  let worst = 0, worstS = 0, worstSelf = 0; const byH = {}, modes = {};
  for (const [geo, mesh] of [[SWEPT, { chordPanels: 8, spanPanels: 5 }], [ELLIPTIC, { chordPanels: 8, spanPanels: 6 }]]) {
    const wm = meshOf(geo, mesh), S = wm.S, B = wm.body, V = Float64Array.from({ length: B.nValues }, () => rnd() * 2 - 1);
    for (let c = 0; c < 60; c++) {
      const k = c % 3 === 0 ? wm.index(Math.floor(rnd() * wm.ni), wm.ns - 1) : Math.floor(rnd() * wm.wingPanels); // a third on the tip strip
      const mode = W.tensorSlots(B, k).mode; modes[mode] = (modes[mode] || 0) + 1;
      const C = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]], d = S.PD[k], nrm = [S.PN[3 * k], S.PN[3 * k + 1], S.PN[3 * k + 2]];
      const hr = [1, 0.3, 0.05, 0.01, 1e-3, 1e-5][c % 6], P = [0, 1, 2].map(i => C[i] + (rnd() - 0.5) * 1.5 * d + nrm[i] * hr * d * (rnd() < 0.5 ? -1 : 1));
      const a = W.tensorPanel(B, S, k, P); let core = 0, sc = 0; for (let q = 0; q < 9; q++) { const id = B.refs[9 * k + q]; sc += Math.abs(V[id]); }
      const ids = new Set(Array.from(B.refs.subarray(9 * k, 9 * k + 9))); for (const id of ids) core += a.coefficients[id] * V[id];
      const err = Math.abs(core - panelRef(S, B, k, V, P)) / sc; worst = Math.max(worst, err); byH[hr] = Math.max(byH[hr] || 0, err);
      const sref = panelRefSource(S, k, P); worstS = Math.max(worstS, norm(sub(a.sourceVector, sref)) / Math.max(1e-300, Math.abs(a.source)));
    }
    for (let c = 0; c < 30; c++) { const k = c % 2 ? wm.index(Math.floor(rnd() * wm.ni), wm.ns - 1) : Math.floor(rnd() * wm.wingPanels), C = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]], sref = panelRefSource(S, k, C); worstSelf = Math.max(worstSelf, norm(sub([B.selfSourceVec[3 * k], B.selfSourceVec[3 * k + 1], B.selfSourceVec[3 * k + 2]], sref)) / norm(sref)); }
  }
  { // warped panels with equal diagonals (the four-triangle fan, mode 1): a 2 x 2 patch of saddle-warped squares
    const nodes = [], quads = [];
    for (let j = 0; j <= 2; j++) for (let i = 0; i <= 2; i++) nodes.push(i * 10, j * 10, ((i + j) % 2) * 1.3);
    for (let j = 0; j < 2; j++) for (let i = 0; i < 2; i++) quads.push(j * 3 + i, j * 3 + i + 1, (j + 1) * 3 + i + 1, (j + 1) * 3 + i);
    const S = W.buildSurface(Float64Array.from(nodes), Int32Array.from(quads)), refs = new Int32Array(36);
    for (let k = 0; k < 4; k++) for (let q = 0; q < 9; q++) refs[9 * k + q] = q === 4 ? k : 4 + 8 * k + (q < 4 ? q : q - 1);
    const B = W.tensorQuadBasis(S, { n: 4, nValues: 36, refs, spanChains: [], stationChains: [], stripChains: [], tipMean: null }), V = Float64Array.from({ length: 36 }, () => rnd() * 2 - 1);
    for (let c = 0; c < 24; c++) {
      const k = c % 4; modes[W.tensorSlots(B, k).mode] = (modes[W.tensorSlots(B, k).mode] || 0) + 1;
      const C = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]], d = S.PD[k], P = [0, 1, 2].map(i => C[i] + (rnd() - 0.5) * 1.5 * d + (i === 2 ? [1, 0.3, 0.05, 0.01, 1e-3, 1e-5][c % 6] * d * (rnd() < 0.5 ? -1 : 1) : 0));
      const a = W.tensorPanel(B, S, k, P); let core = 0, sc = 0; for (let q = 0; q < 9; q++) { const id = refs[9 * k + q]; core += a.coefficients[id] * V[id]; sc += Math.abs(V[id]); }
      worst = Math.max(worst, Math.abs(core - panelRef(S, B, k, V, P)) / sc);
      worstS = Math.max(worstS, norm(sub(a.sourceVector, panelRefSource(S, k, P))) / Math.max(1e-300, Math.abs(a.source)));
    }
  }
  log(`tensor panel vs independent P2 / polar reference (144 panel-point pairs; split modes ${JSON.stringify(modes)}): doublet max |error|/sum|values| ${worst.toExponential(2)}; by height/d ${Object.entries(byH).map(([h, e]) => h + ': ' + e.toExponential(1)).join(', ')}`);
  ok(modes[0] && modes[1] && modes[2], 'all three split modes exercised (shorter diagonal, fan of four on a warped tie, fan of three on a collapsed tip panel)');
  log(`source vector (per-triangle normals) vs the reference: max relative error ${worstS.toExponential(2)}; self term ${worstSelf.toExponential(2)}`);
  ok(worst < 1e-12, 'tensor panel doublet potential matches the defining integral (all three split modes)');
  ok(worstS < 1e-12 && worstSelf < 1e-12, 'tensor panel source vector and its self term match the defining integrals');
  // the self (control-point) doublet weights: the P2 value at the control point
  const wm = meshOf(SWEPT, { chordPanels: 8, spanPanels: 5 }), S = wm.S, B = wm.body, V = Float64Array.from({ length: B.nValues }, () => rnd() * 2 - 1);
  let wcp = 0; for (let k = 0; k < S.count; k += 3) { const cpw = W.tensorSlots(B, k).cpWeights, sl = slotValues(B, k, V); let v = 0; for (let q = 0; q < 9; q++) v += cpw[q] * sl[q]; wcp = Math.max(wcp, Math.abs(v - doubletAt(S, B, k, V, [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]]))); }
  ok(wcp < 1e-12, `control-point (self-term) weights give the doublet at the control point (${wcp.toExponential(1)})`);
}
// ---------------------------------------------------------------- 2. constant limit, jump, far field
{
  const wm = meshOf(SWEPT, { chordPanels: 8, spanPanels: 5 }), S = wm.S, B = wm.body, ones = new Float64Array(B.nValues).fill(1);
  let worstD = 0;
  for (let c = 0; c < 2000; c++) {
    const k = Math.floor(rnd() * wm.wingPanels), C = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]], d = S.PD[k], P = C.map(x => x + (rnd() - 0.5) * 4 * d);
    const a = W.tensorPanel(B, S, k, P), b = W.influence(S, k, P); let s = 0; for (const id of new Set(Array.from(B.refs.subarray(9 * k, 9 * k + 9)))) s += a.coefficients[id];
    worstD = Math.max(worstD, Math.abs(s - b.doublet));
  }
  log(`equal values vs the 0.3.1 constant-doublet solid angle: max difference ${worstD.toExponential(2)}`);
  ok(worstD < 1e-13, 'equal values reproduce the constant-strength doublet panel');
  const k = wm.index(3, 1), V = Float64Array.from({ length: B.nValues }, () => rnd() * 2 - 1), T = W.tensorSlots(B, k).tris.find(t => t.valid);
  const X = [0, 1, 2].map(i => 0.4 * T.points[0][i] + 0.35 * T.points[1][i] + 0.25 * T.points[2][i]), nn = unit(cross(sub(T.points[1], T.points[0]), sub(T.points[2], T.points[0])));
  const phi = P => { const a = W.tensorPanel(B, S, k, P); let v = 0; for (const id of new Set(Array.from(B.refs.subarray(9 * k, 9 * k + 9)))) v += a.coefficients[id] * V[id]; return v; };
  const local = doubletAt(S, B, k, V, X), jumps = [1e-4, 1e-7].map(e => phi(X.map((x, i) => x + e * nn[i])) - phi(X.map((x, i) => x - e * nn[i])));
  log(`jump across the panel at an interior point: ${jumps.map(j => j.toFixed(9)).join(', ')} vs the local doublet ${local.toFixed(9)}`);
  ok(Math.abs(jumps[1] - local) < 1e-6, 'potential jump across the panel equals the local doublet value');
  const errAt = R => { let w = 0; for (let c = 0; c < 300; c++) { const k2 = Math.floor(rnd() * wm.wingPanels), C = [S.PC[3 * k2], S.PC[3 * k2 + 1], S.PC[3 * k2 + 2]], d = S.PD[k2], dir = unit([rnd() - 0.5, rnd() - 0.5, rnd() - 0.5]), P = C.map((x, i) => x + dir[i] * R * d); const a = W.tensorPanel(B, S, k2, P), f = W.tensorPanel(B, S, k2, P, 1); for (let q = 0; q < 9; q++) w = Math.max(w, Math.abs(a.slots[q] - f.slots[q]) / (S.PA[k2] / (4 * Math.PI * (R * d) ** 2))); } return w; };
  const e6 = errAt(6), e12 = errAt(12), e24 = errAt(24);
  log(`far-field expansion (zeroth + first moments, nine values) vs exact, max error / (A / 4 pi r^2): r = 6 d: ${e6.toExponential(2)}, 12 d: ${e12.toExponential(2)}, 24 d: ${e24.toExponential(2)}`);
  ok(e6 < 1e-2 && e12 < e6 / 3 && e24 < e12 / 3, 'far-field error small at the 0.3.1 threshold and falling as (d/r)^2');
}
// ---------------------------------------------------------------- 3. basis: splines, continuity, tip
{
  for (const [geo, mesh, label] of [[SWEPT, { chordPanels: 8, spanPanels: 5 }, 'rounded'], [ELLIPTIC, { chordPanels: 10, spanPanels: 7 }, 'closed']]) {
    const wm = meshOf(geo, mesh), S = wm.S, B = wm.body, n = S.count, mu = Float64Array.from({ length: n }, () => rnd() * 2 - 1), V = W.tensorValues(B, mu);
    const C1 = W.tensorValues(B, new Float64Array(n).fill(1.7)); let cst = 0; for (const q of new Set(B.refs)) cst = Math.max(cst, Math.abs(C1[q] - 1.7)); // every value a panel uses
    let res = 0;
    for (const ch of [...B.spanChains, ...B.stationChains, ...B.stripChains]) { // the C1 spline equations and the end conditions on every chain
      const N = ch.cells.length, h = ch.h, E = k => V[ch.knots[k]], m = k => V[ch.cells[k]];
      const sl0 = k => (-3 * E(k) + 4 * m(k) - E(k + 1)) / h[k], sl1 = k => (E(k) - 4 * m(k) + 3 * E(k + 1)) / h[k], scale = Math.max(1e-12, ...Array.from(ch.cells, c => Math.abs(V[c]))) / Math.min(...h);
      for (let k = 1; k < N; k++) res = Math.max(res, Math.abs(sl1(k - 1) - sl0(k)) / scale);
      res = Math.max(res, (ch.start === 'natural' ? Math.abs(E(0) - 2 * m(0) + E(1)) / h[0] : Math.abs(sl0(0))) / scale, (ch.end === 'natural' ? Math.abs(E(N - 1) - 2 * m(N - 1) + E(N)) / h[N - 1] : Math.abs(sl1(N - 1))) / scale);
    }
    ok(res < 1e-12 && cst < 1e-14, `${label}: chordwise (station and strip) and spanwise spline equations and end conditions hold (residual ${res.toExponential(1)}); constants reproduced`);
    // continuity: the documented surface doublet evaluated from both panels at points of every shared edge
    let jump = 0;
    const edgePts = (A, Bp) => [0.1, 0.37, 0.5, 0.82].map(t => A.map((x, i) => x + t * (Bp[i] - x)));
    for (let j = 0; j < wm.ns; j++) for (let i = 0; i < wm.ni; i++) {
      const k = wm.index(i, j), c = corners(S, k);
      if (i < wm.ni - 1) for (const X of edgePts(c[1], c[2])) jump = Math.max(jump, Math.abs(doubletAt(S, B, k, V, X) - doubletAt(S, B, wm.index(i + 1, j), V, X)));
      if (j < wm.ns - 1) for (const X of edgePts(c[3], c[2])) jump = Math.max(jump, Math.abs(doubletAt(S, B, k, V, X) - doubletAt(S, B, wm.index(i, j + 1), V, X)));
      if (j === wm.ns - 1 && label === 'rounded') { // the seam panel's top edge runs the other way (the two edges coincide to the geometry's ~1e-7 mm)
        const cm = corners(S, wm.index(wm.ni - 1 - i, j)), A = edgePts(c[3], c[2]), Bm = edgePts(cm[2], cm[3]);
        for (let q = 0; q < A.length; q++) jump = Math.max(jump, Math.abs(doubletAt(S, B, k, V, A[q]) - doubletAt(S, B, wm.index(wm.ni - 1 - i, j), V, Bm[q])));
      }
      if (j === wm.ns - 1 && label === 'closed') jump = Math.max(jump, Math.abs(doubletAt(S, B, k, V, c[2]) - V[B.topo.T]));
    }
    log(`${label}: largest doublet difference between the two sides of a shared edge (chordwise, spanwise${label === 'rounded' ? ', tip seam' : ', at the tip point'}): ${jump.toExponential(2)}`);
    ok(jump < 1e-12, `${label}: the body doublet is continuous across every shared edge${label === 'rounded' ? ' and across the tip seam' : ' and single-valued at the closed-tip point'}`);
    const ws = W.wakeStrengths(wm.wake, mu, B);
    ok(Math.abs(ws.atB[wm.ns - 1]) < 1e-14, `${label} tip: wake strength zero at the tip for ANY doublets (${ws.atB[wm.ns - 1].toExponential(1)})`);
  }
}
// ---------------------------------------------------------------- 4. matrix row = field evaluation; interior condition
{
  const wm = meshOf(SWEPT, { chordPanels: 8, spanPanels: 5 }), S = wm.S, n = S.count;
  const sys = W.assemble(S, { image: true, wake: wm.wake, body: wm.body, farField: 6 }), mu = Float64Array.from({ length: n }, (_, k) => Math.sin(0.37 * k) + 0.2 * Math.cos(1.3 * k));
  let worst = 0, scale = 0;
  for (const i of [0, 7, Math.floor(n / 2), n - 3, n - 1]) {
    let row = 0; for (let k = 0; k < n; k++) row += sys.A[i * n + k] * mu[k];
    const f = W.fieldPotential(S, wm.body, wm.wake, [S.PC[3 * i], S.PC[3 * i + 1], S.PC[3 * i + 2]], mu, [0, 0, 1], { self: i, farField: 6 });
    worst = Math.max(worst, Math.abs(row + sys.bz[i] - f)); scale = Math.max(scale, Math.abs(row));
  }
  log(`matrix row x mu + source term vs fieldPotential at control points: max difference ${worst.toExponential(2)} (scale ${scale.toExponential(2)})`);
  ok(worst <= 1e-13 * Math.max(1, scale), 'panel matrix and field evaluation are the same function');
  // a row assembled by the transposed spline maps equals the direct evaluation through the forward map
  // the row assembled by the transposed spline maps against the plain evaluation of every value (exact kernels), and
  // the default row (far field graded: exact inside 4 diameters, fourth order to 6, second to 24, first beyond; on a
  // non-planar panel per triangle in the triangles' diameters, and first order about the centroid beyond 24 diameters)
  // against the exact row: its error must not exceed that of the plain first-order expansion at 6 diameters
  const P = [S.PC[0] + 3, S.PC[1] + 2, S.PC[2] + 5], V = W.tensorValues(wm.body, mu), ws = W.wakeStrengths(wm.wake, mu, wm.body);
  const wakePart = () => { let w = 0; for (let j = 0; j < wm.wake.count; j++) { const wk = wm.wake, o = 3 * j, q = W.quadStrip(P, [wk.a[o], wk.a[o + 1], wk.a[o + 2]], wk.dir, [wk.b[o], wk.b[o + 1], wk.b[o + 2]]), qm = W.quadStrip([P[0], -P[1], P[2]], [wk.a[o], wk.a[o + 1], wk.a[o + 2]], wk.dir, [wk.b[o], wk.b[o + 1], wk.b[o + 2]]); w += (q[0] + qm[0]) * ws.atA[j] + (q[1] + qm[1]) * ws.gamma[j] + (q[2] + qm[2]) * ws.atB[j]; } return w; };
  const plain = far => { let d = wakePart(); for (let k = 0; k < n; k++) { const a = W.tensorPanel(wm.body, S, k, P, far), b = W.tensorPanel(wm.body, S, k, [P[0], -P[1], P[2]], far); for (let id = 0; id < wm.body.nValues; id++) if (a.coefficients[id] || b.coefficients[id]) d += (a.coefficients[id] + b.coefficients[id]) * V[id]; } return d; };
  const viaRow = far => { const r = W.addRow(wm.body, wm.wake, S, P, -1, true, far); let v = 0; for (let k = 0; k < n; k++) v += r.row[k] * mu[k]; return v; };
  const exact = plain(Infinity), rowExact = viaRow(Infinity), rowDefault = viaRow(6), first6 = plain(6);
  ok(Math.abs(rowExact - exact) < 1e-13 * Math.max(1, Math.abs(exact)), `row by the transposed spline maps = direct sum over values, exact kernels (${Math.abs(rowExact - exact).toExponential(1)})`);
  log(`row at a field point: default far field error ${Math.abs(rowDefault - exact).toExponential(2)}, plain first-order expansion at 6 diameters ${Math.abs(first6 - exact).toExponential(2)} (value ${exact.toExponential(3)}; planar panels ${Array.from(wm.body.planar).reduce((x, y) => x + y, 0)} of ${n})`);
  ok(Math.abs(rowDefault - exact) <= Math.abs(first6 - exact), 'default (graded) far field no less accurate than the first-order expansion at 6 diameters');
  {
    // planar panels, expansion orders 1, 2 and 4 against the exact kernels: (a) every slot, random directions (error /
    // (A / 4 pi r^2)); (b) the combined potential of a SMOOTH doublet (values of a smooth mu), the target along the
    // panel's long (spanwise) axis slightly off its plane, the worst direction for a sliver panel (relative error).
    const B = wm.body, dirs = Array.from({ length: 300 }, () => unit([rnd() - 0.5, rnd() - 0.5, rnd() - 0.5])), ks = [];
    for (let c = 0; c < 5000 && ks.length < 300; c++) { const k2 = Math.floor(rnd() * n); if (B.planar[k2]) ks.push(k2); }
    const errAt = (R, order) => { let w = 0; ks.forEach((k2, c) => { const C = [S.PC[3 * k2], S.PC[3 * k2 + 1], S.PC[3 * k2 + 2]], d = S.PD[k2], Q = C.map((x, i) => x + dirs[c][i] * R * d); const a = W.tensorPanel(B, S, k2, Q), f = W.tensorFar(B, S, k2, Q, order); for (let q = 0; q < 9; q++) w = Math.max(w, Math.abs(a.slots[q] - f.slots[q]) / (S.PA[k2] / (4 * Math.PI * (R * d) ** 2))); }); return w; };
    const E = {}; for (const o of [1, 2, 4]) for (const R of [2.4, 4, 8, 12, 16, 24]) E[o + '@' + R] = errAt(R, o);
    log(`planar panels, far field vs exact, max slot error / (A / 4 pi r^2): ${[1, 2, 4].map(o => `order ${o}: ` + [2.4, 4, 8, 12, 16, 24].map(R => `${R} d ${E[o + '@' + R].toExponential(1)}`).join(', ')).join('; ')}`);
    ok(E['2@4'] < 2e-3 && E['2@8'] < E['2@4'] / 5 && E['2@16'] < E['2@8'] / 5, 'second order: small at 4 diameters, falling at least as (d/r)^3');
    // (beyond about 10 diameters the closed-form reference itself loses digits by cancellation: about 1e-6 here)
    ok(E['4@4'] < E['4@2.4'] / 8 && E['4@8'] < E['4@4'] / 16 && E['4@2.4'] <= E['2@4'], 'fourth order: falling at least as (d/r)^5 (2.4 to 8 diameters); at 2.4 diameters no larger than second order at 4');
    ok(E['1@24'] < E['1@12'] / 3 && E['1@12'] < 4 * E['2@4'], 'first order: falling as (d/r)^2; at 12 diameters within a small factor of second order at 4');
    // smooth doublet, along-span targets
    const muS = Float64Array.from({ length: n }, (_, k) => Math.sin(S.PC[3 * k] / 70) + Math.cos(S.PC[3 * k + 1] / 160) + 0.3 * S.PC[3 * k + 2] / 20), VS = W.tensorValues(B, muS);
    const smooth = (R, order) => { let w = 0; for (const k2 of ks.slice(0, 120)) { const C = [S.PC[3 * k2], S.PC[3 * k2 + 1], S.PC[3 * k2 + 2]], d = S.PD[k2], N = [S.PN[3 * k2], S.PN[3 * k2 + 1], S.PN[3 * k2 + 2]], u = unit([0.2 * N[0], 1 + 0.2 * N[1], 0.2 * N[2]]), Q = C.map((x, i) => x + u[i] * R * d), refs = B.refs.subarray(9 * k2, 9 * k2 + 9); const a = W.tensorPanel(B, S, k2, Q), f = W.tensorFar(B, S, k2, Q, order); let pa = 0, pf = 0; for (let q = 0; q < 9; q++) { pa += a.slots[q] * VS[refs[q]]; pf += f.slots[q] * VS[refs[q]]; } if (Math.abs(pa) > 1e-12) w = Math.max(w, Math.abs(pf - pa) / Math.abs(pa)); } return w; };
    const s24 = smooth(2.4, 4), s4 = smooth(4, 2), s24b = smooth(2.4, 2);
    log(`smooth doublet, targets along the panel's long axis 0.2 d off its plane, relative potential error: order 4 at 2.4 d ${s24.toExponential(2)}, order 2 at 4 d ${s4.toExponential(2)} (order 2 at 2.4 d ${s24b.toExponential(2)})`);
    ok(s24 <= s4, 'smooth doublet, worst direction: the fourth-order zone from 2.4 diameters is no less accurate than the second-order zone from 4');
  }
  const sol = W.unitSolutions(S, { image: true, wake: wm.wake, body: wm.body, farField: 6, solver: 'lu' });
  let res = 0, mx = 0;
  for (let i = 0; i < n; i += 5) { res = Math.max(res, Math.abs(W.fieldPotential(S, wm.body, wm.wake, [S.PC[3 * i], S.PC[3 * i + 1], S.PC[3 * i + 2]], sol.muz, [0, 0, 1], { self: i, farField: 6 }))); mx = Math.max(mx, Math.abs(sol.muz[i])); }
  log(`solved doublets: interior potential at control points re-evaluated by fieldPotential: max ${res.toExponential(2)} (doublet scale ${mx.toExponential(2)})`);
  ok(res < 1e-10 * mx, 'the solution satisfies the interior Dirichlet condition with the field evaluation');
}
// ---------------------------------------------------------------- 5. pointwise trailing-edge matching
{
  for (const [geo, label] of [[SWEPT, 'rounded'], [ELLIPTIC, 'closed']]) {
    const wm = meshOf(geo, { chordPanels: 8, spanPanels: 6 }), S = wm.S, B = wm.body, n = S.count, mu = Float64Array.from({ length: n }, () => rnd() * 2 - 1), V = W.tensorValues(B, mu), ws = W.wakeStrengths(wm.wake, mu, B);
    const Qt = (a, m, b, t) => a * (1 - t) * (1 - 2 * t) + 4 * m * t * (1 - t) + b * t * (2 * t - 1);
    let worst = 0;
    for (let j = 0; j < wm.ns; j++) {
      const up = wm.index(wm.ni - 1, j), lo = wm.index(0, j), cu = corners(S, up), cl = corners(S, lo);
      for (const t of [0, 0.13, 0.5, 0.71, 1]) {
        const Xu = cu[1].map((x, i) => x + t * (cu[2][i] - x)), Xl = cl[0].map((x, i) => x + t * (cl[3][i] - x));
        worst = Math.max(worst, Math.abs(doubletAt(S, B, up, V, Xu) - doubletAt(S, B, lo, V, Xl) - Qt(ws.atA[j], ws.gamma[j], ws.atB[j], t)));
      }
    }
    log(`${label}: trailing-edge matching, max |mu_upper - mu_lower - mu_wake| at 5 points per strip (random doublets): ${worst.toExponential(2)}`);
    ok(worst < 1e-12, `${label}: wake strength = jump of the two surface traces pointwise along the trailing edge (no TE line vortex)`);
  }
}
// ---------------------------------------------------------------- 6. mirror image vs explicit full span
{
  const wm = meshOf(SWEPT, { chordPanels: 8, spanPanels: 5 }), S = wm.S, n = S.count, w = wm.wake, m = w.count, ni = wm.ni, ns = wm.ns, ys = wm.ys, B = wm.body, tp = B.topo;
  const half = W.unitSolutions(S, { image: true, wake: w, body: B, farField: Infinity, solver: 'lu' });
  const nodes = S.nodes, nn = nodes.length / 3, full = new Float64Array(2 * nodes.length);
  full.set(nodes); for (let i = 0; i < nn; i++) { full[3 * (nn + i)] = nodes[3 * i]; full[3 * (nn + i) + 1] = -nodes[3 * i + 1]; full[3 * (nn + i) + 2] = nodes[3 * i + 2]; }
  const quads = new Int32Array(8 * n); quads.set(S.quads); for (let k = 0; k < n; k++) for (let q = 0; q < 4; q++) quads[4 * (n + k) + q] = nn + S.quads[4 * k + 3 - q];
  const SF = W.buildSurface(full, quads);
  // unified ids of the full span: panels [0, 2n); MK: one cyclic chain per row pair (4 ns knots); KM per side; KK per
  // side with the root station shared
  const nh = ni / 2, oMK = 2 * n, oKM = oMK + nh * 4 * ns, oKK = oKM + 2 * (ni + 1) * ns, nValues = oKK + (ni + 1) * (2 * ns + 1);
  const mk = (i, j, left) => { const c = i >= nh ? ni - 1 - i : i, base = oMK + c * 4 * ns; if (!left) return i >= nh ? base + j : base + 2 * ns - j; return i >= nh ? base + (4 * ns - j) % (4 * ns) : base + 2 * ns + j; };
  const km = (mI, j, left) => oKM + mI + (ni + 1) * (j + (left ? ns : 0)), kk = (mI, j, left) => oKK + mI + (ni + 1) * (left && j > 0 ? ns + j : j);
  const refs = new Int32Array(18 * n), idx = (i, j, left) => (left ? n : 0) + wm.index(i, j);
  for (const left of [false, true]) for (let j = 0; j < ns; j++) for (let i = 0; i < ni; i++) {
    const k = idx(i, j, left), r = [kk(i, j, left), mk(i, j, left), kk(i + 1, j, left), km(i, j, left), k, km(i + 1, j, left), kk(i, j + 1, left), mk(i, j + 1, left), kk(i + 1, j + 1, left)];
    const rr = left ? [r[6], r[7], r[8], r[3], r[4], r[5], r[0], r[1], r[2]] : r; // the left panels run tip -> root in t
    for (let q = 0; q < 9; q++) refs[9 * k + q] = rr[q];
  }
  const spanChains = [], stationChains = [], stripChains = [];
  for (let c = 0; c < nh; c++) {
    const up = ni - 1 - c, cells = [], h = [];
    for (let j = 0; j < ns; j++) { cells.push(idx(up, j, false)); h.push(ys[j + 1] - ys[j]); }
    for (let j = ns - 1; j >= 0; j--) { cells.push(idx(c, j, false)); h.push(ys[j + 1] - ys[j]); }
    for (let j = 0; j < ns; j++) { cells.push(idx(c, j, true)); h.push(ys[j + 1] - ys[j]); }
    for (let j = ns - 1; j >= 0; j--) { cells.push(idx(up, j, true)); h.push(ys[j + 1] - ys[j]); }
    spanChains.push({ cells: Int32Array.from(cells), h: Float64Array.from(h), knots: Int32Array.from({ length: 4 * ns }, (_, q) => oMK + c * 4 * ns + q), cyclic: true });
  }
  for (const left of [false, true]) {
    for (const ch of tp.stationChains) { const j = Math.round((ch.knots[0] - tp.oKK) / (ni + 1)); if (left && j === 0) continue; stationChains.push({ ...ch, cells: Int32Array.from({ length: ni }, (_, i) => mk(i, j, left)), knots: Int32Array.from({ length: ni + 1 }, (_, q) => kk(q, j, left)) }); }
    for (const ch of tp.stripChains) { const j = Math.round((ch.knots[0] - tp.oKM) / (ni + 1)); stripChains.push({ ...ch, cells: Int32Array.from({ length: ni }, (_, i) => idx(i, j, left)), knots: Int32Array.from({ length: ni + 1 }, (_, q) => km(q, j, left)) }); }
  }
  const BF = W.tensorQuadBasis(SF, { n: 2 * n, nValues, refs, spanChains, stationChains, stripChains, tipMean: null });
  const fw = { count: 2 * m, a: new Float64Array(6 * m), b: new Float64Array(6 * m), dir: w.dir, kuttaWidth: w.kuttaWidth, kuttaPanels: new Int32Array(2 * m * w.kuttaWidth), kuttaWeights: new Float64Array(2 * m * w.kuttaWidth) };
  fw.a.set(w.a); fw.b.set(w.b);
  for (let j = 0; j < m; j++) for (const [dst, src] of [[fw.a, w.b], [fw.b, w.a]]) { dst[3 * (m + j)] = src[3 * j]; dst[3 * (m + j) + 1] = -src[3 * j + 1]; dst[3 * (m + j) + 2] = src[3 * j + 2]; }
  const strips = [];
  for (let j = 0; j < 2 * m; j++) { const left = j >= m, jj = left ? j - m : j, up = idx(ni - 1, jj, left), lo = idx(0, jj, left); strips.push({ up: refs[9 * up + 5], lo: refs[9 * lo + 3], aUp: refs[9 * up + 2], aLo: refs[9 * lo + 0], bUp: refs[9 * up + 8], bLo: refs[9 * lo + 6] }); }
  fw.basis = { kind: 'tensor-quadratic', strips }; fw.body = BF;
  const fs = W.unitSolutions(SF, { image: false, wake: fw, body: BF, farField: Infinity, solver: 'lu' });
  let d = 0, s = 0; for (let k = 0; k < n; k++) { d = Math.max(d, Math.abs(fs.muz[k] - half.muz[k]), Math.abs(fs.mux[k] - half.mux[k]), Math.abs(fs.muz[n + k] - half.muz[k])); s = Math.max(s, Math.abs(half.muz[k])); }
  log(`tensor-quadratic: image half-wing (clamped root) vs explicit full span (cyclic span chains through both tips; sweep 15, dihedral 6, taper): max doublet difference ${(d / s).toExponential(2)} (relative)`);
  ok(d / s < 1e-10, 'mirror image with zero root slope equals the explicit full span with the same doublet model');
}
// ---------------------------------------------------------------- 7. symmetry, Trefftz, load transfer
{
  const sym = W.solve({ naca: '0012', semiSpan: 500, rootChord: 120, tipChord: 70, sweepDeg: 20, dihedralDeg: 0 }, { alphaDeg: 0, speed: 10 }, { chordPanels: 12, spanPanels: 8 });
  ok(sym.mesh.doubletModel === 'tensor-quadratic' && Math.abs(sym.coefficients.CL) < 1e-10, `default model is tensor-quadratic; symmetric section at zero incidence carries no lift (CL ${sym.coefficients.CL.toExponential(1)})`);
  const m = W.prepare({ naca: '2412', semiSpan: 450, rootChord: 160, tipChord: 100, sweepDeg: 10, dihedralDeg: 5 }, { chordPanels: 12, spanPanels: 10 }), r = W.evaluate(m, { alphaDeg: 4, speed: 15 });
  const ws = r.diagnostics.wake, w = m.wm.wake; let L = 0;
  for (let j = 0; j < w.count; j++) L += (w.b[3 * j + 1] - w.a[3 * j + 1]) * (ws.strengthAtInnerEdge[j] + 4 * ws.stripStrength[j] + ws.strengthAtOuterEdge[j]) / 6;
  const CLt = 2 * (2 * L / 15) / r.reference.area_mm2;
  ok(Math.abs(CLt - r.coefficients.CLTrefftz) < 1e-12 * Math.abs(CLt), `Trefftz lift = exact integral of the solved quadratic wake (${CLt.toFixed(8)})`);
  ok(Math.abs(ws.strengthAtOuterEdge[w.count - 1]) < 1e-12 * Math.max(...ws.stripStrength.map(Math.abs)), 'solved wake strength zero at the rounded tip');
  ok(r.strips.every((st, j) => st.gamma === ws.stripStrength[j]), 'strip circulation = the wake strength at the strip mid-point (trailing-edge trace jump)');
  const sw = r.semiWing, F = [0, 0, 0], M = [0, 0, 0];
  for (const st of r.strips) { const f = st.force_N, mq = st.momentAboutQuarterChord_Nmm, p = st.quarterChordPoint_mm; for (let c = 0; c < 3; c++) F[c] += f[c]; M[0] += mq[0] + p[1] * f[2] - p[2] * f[1]; M[1] += mq[1] + p[2] * f[0] - p[0] * f[2]; M[2] += mq[2] + p[0] * f[1] - p[1] * f[0]; }
  const eF = Math.max(...F.map((v, c) => Math.abs(v - sw.force_N[c]))) / Math.hypot(...sw.force_N), eM = Math.max(...M.map((v, c) => Math.abs(v - sw.momentAboutRootOrigin_Nmm[c]))) / Math.hypot(...sw.momentAboutRootOrigin_Nmm);
  ok(eF < 1e-12 && eM < 1e-12, `strip loads reproduce the semi-wing force and root moment (relative ${eF.toExponential(1)}, ${eM.toExponential(1)})`);
}
// ---------------------------------------------------------------- 8. the other models unchanged
{
  const geo = { naca: '2412', semiSpan: 400, rootChord: 150, tipChord: 90, sweepDeg: 10, dihedralDeg: 4 };
  for (const [env, model] of [['SOLVER031', 'constant'], ['SOLVER_SQ', 'span-quadratic']]) {
    if (!process.env[env]) { log(`(${model} comparison skipped: set ${env})`); continue; }
    const P = require(process.env[env]), a = W.solve(geo, { alphaDeg: 5, speed: 15 }, { chordPanels: 12, spanPanels: 8 }, { doubletModel: model }), b = P.solve(geo, { alphaDeg: 5, speed: 15 }, { chordPanels: 12, spanPanels: 8 }, { doubletModel: model });
    let d = 0; for (let k = 0; k < a.panels.count; k++) d = Math.max(d, Math.abs(a.panels.cp[k] - b.panels.cp[k]), Math.abs(a.panels.mu[k] - b.panels.mu[k]));
    log(`doubletModel '${model}' vs ${P.VERSION} (${env}): max |dCp|, |dmu| = ${d}; CL ${a.coefficients.CL} vs ${b.coefficients.CL}`);
    ok(d === 0 && a.coefficients.CL === b.coefficients.CL && a.coefficients.CDiTrefftz === b.coefficients.CDiTrefftz && a.coefficients.Cm === b.coefficients.Cm, `doubletModel '${model}' is bit-identical to ${P.VERSION}`);
  }
}
// ---------------------------------------------------------------- 9. non-planar panels: far field per triangle
{
  const TWIST = { naca: '2412', semiSpan: 450, rootChord: 160, tipChord: 100, twistEnabled: true, twistReferenceFraction: 0.25, stations: [{ eta: 0, airfoil: '2412', incidenceDeg: 2 }, { eta: 1, airfoil: '2412', incidenceDeg: -2 }] };
  const wm = W.wingMesh(W.aeroGeometry(TWIST), W.normalizeMesh({ chordPanels: 12, spanPanels: 8 })), S = wm.S, B = wm.body, n = S.count;
  let planar = 0; for (let k = 0; k < n; k++) planar += B.planar[k];
  ok(planar === 0, `a twisted wing: every panel is non-planar (${planar} planar of ${n})`);
  // (a) every slot, random directions, error / (A / 4 pi r^2) at R panel diameters
  const ks = []; for (let c = 0; c < 5000 && ks.length < 200; c++) { const k2 = Math.floor(rnd() * n); if (!B.planar[k2]) ks.push(k2); }
  const dirs = ks.map(() => unit([rnd() - 0.5, rnd() - 0.5, rnd() - 0.5]));
  const errAt = (R, order) => { let w = 0; ks.forEach((k2, c) => { const d = S.PD[k2], Q = [0, 1, 2].map(i => S.PC[3 * k2 + i] + dirs[c][i] * R * d); const a = W.tensorPanel(B, S, k2, Q), f = W.tensorFarTriangles(B, S, k2, Q, order); for (let q = 0; q < 9; q++) w = Math.max(w, Math.abs(a.slots[q] - f.slots[q]) / (S.PA[k2] / (4 * Math.PI * (R * d) ** 2))); }); return w; };
  const E = {}; for (const o of [1, 2, 4]) for (const R of [2.4, 4, 8, 12]) E[o + '@' + R] = errAt(R, o);
  log(`non-planar panels, far field per triangle vs exact, max slot error / (A / 4 pi r^2): ${[1, 2, 4].map(o => `order ${o}: ` + [2.4, 4, 8, 12].map(R => `${R} d ${E[o + '@' + R].toExponential(1)}`).join(', ')).join('; ')}`);
  ok(E['1@8'] < E['1@4'] / 3 && E['1@12'] < E['1@8'] / 2, 'per triangle, first order: falling as (d/r)^2');
  ok(E['2@8'] < E['2@4'] / 5 && E['2@4'] < E['1@4'] / 3, 'per triangle, second order: falling at least as (d/r)^3, below first order');
  ok(E['4@4'] < E['4@2.4'] / 8 && E['4@2.4'] <= E['2@4'], 'per triangle, fourth order: falling at least as (d/r)^5; at 2.4 diameters no larger than second order at 4');
  // (b) the assembled solution of the twisted wing: default far field against every panel exact
  const g = W.aeroGeometry(TWIST), flow = { alphaDeg: 4, speed: 15 }, mesh = { chordPanels: 12, spanPanels: 8 };
  const a = W.solve(g, flow, { ...mesh, farField: 6 }), b = W.solve(g, flow, { ...mesh, farField: Infinity });
  let dcp = 0; for (let k = 0; k < a.panels.count; k++) dcp = Math.max(dcp, Math.abs(a.panels.cp[k] - b.panels.cp[k]));
  const dCL = Math.abs(a.coefficients.CL - b.coefficients.CL) / Math.abs(b.coefficients.CL);
  log(`twisted wing 12 x 8: default far field vs every panel exact: CL ${dCL.toExponential(2)} (relative), max |dCp| ${dcp.toExponential(2)}`);
  ok(dCL < 1e-4 && dcp < 1e-2, 'twisted wing: the default far field changes CL by less than 1e-4 and Cp by less than 0.01');
}
// ---------------------------------------------------------------- 10. surface velocity = the jump of the solved distribution
// The independent reference (panelModel, biq: the documented split, node pre-images and P2 fit) gives grad_s mu_T; the
// core's kernel (tensorPanel, exact) gives the potential on both sides of the sheet, whose tangential-gradient jump is
// taken by fourth-order differences in the triangle's plane; the core's recovery (tensorTriangleVelocity, linear on each
// triangle) minus the tangential freestream must equal both, at generic triangle-interior points and at the control point.
{
  const p2Grad = (T, vals6, X) => { // independent: P2 fitted through the six node values in the triangle's own frame
    const Q = T.Q, N = cross(sub(Q[1], Q[0]), sub(Q[2], Q[0])), n = unit(N), e1 = unit(sub(Q[1], Q[0])), e2 = cross(n, e1), loc = P => [dot(sub(P, Q[0]), e1), dot(sub(P, Q[0]), e2)];
    const c = solveN([Q[0], Q[1], Q[2], mid(Q[0], Q[1]), mid(Q[1], Q[2]), mid(Q[2], Q[0])].map(loc).map(([x, y]) => [1, x, y, x * x, x * y, y * y]), vals6), [x, y] = loc(X);
    return { n, g: add(mul(e1, c[1] + 2 * c[3] * x + c[4] * y), mul(e2, c[2] + c[4] * x + 2 * c[5] * y)), e1, e2 };
  };
  let eJump = 0, eRec = 0, eJumpCP = 0, eRecCP = 0, scale = 0, pts = 0, cpPts = 0; const modesSeen = {};
  for (const [geo, mesh] of [[SWEPT, { chordPanels: 8, spanPanels: 5 }], [ELLIPTIC, { chordPanels: 8, spanPanels: 6 }]]) {
    const wm = meshOf(geo, mesh), S = wm.S, B = wm.body, mu = Float64Array.from({ length: S.count }, () => rnd() * 2 - 1), V = W.tensorValues(B, mu);
    const R = W.tensorTriangles(B, S), U = W.tensorTriangleVelocity(B, S, R, mu, [0, 0, 0]);
    const phiK = (k, P) => { const a = W.tensorPanel(B, S, k, P); let s = 0; for (const id of new Set(Array.from(B.refs.subarray(9 * k, 9 * k + 9)))) if (id >= 0) s += a.coefficients[id] * V[id]; return s; };
    const ks = []; for (let c = 0; c < 24; c++) ks.push(c % 2 ? wm.index(Math.floor(rnd() * wm.ni), wm.ns - 1) : Math.floor(rnd() * wm.wingPanels));
    for (const k of ks) {
      const sl = slotValues(B, k, V), model = panelModel(S, k); modesSeen[W.tensorSlots(B, k).mode] = true;
      const C = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]];
      model.forEach((T, t) => {
        const j = R.first[k] + t, vals6 = T.nodes.map(st => biq(sl, st)), area2 = norm(cross(sub(T.Q[1], T.Q[0]), sub(T.Q[2], T.Q[0])));
        if (!(area2 > 1e-12 * S.PD[k] ** 2)) return;
        // the core's triangle j must be this triangle (same vertices)
        for (let i = 0; i < 3; i++) if (norm(sub([R.X[9 * j + 3 * i], R.X[9 * j + 3 * i + 1], R.X[9 * j + 3 * i + 2]], T.Q[i])) > 1e-9 * S.PD[k]) throw new Error('triangle order differs');
        const targets = [];
        for (let rep = 0; rep < 2; rep++) { let l; do { const a = rnd(), b = rnd(); l = [a, b, 1 - a - b]; } while (Math.min(...l) < 0.15); targets.push({ l, cp: false }); }
        if (R.cpTri[k] === j) targets.push({ l: [R.cpL[3 * k], R.cpL[3 * k + 1], R.cpL[3 * k + 2]], cp: true });
        for (const { l, cp } of targets) {
          const X = add(add(mul(T.Q[0], l[0]), mul(T.Q[1], l[1])), mul(T.Q[2], l[2])), ref = p2Grad(T, vals6, X), h = Math.sqrt(area2 / 2), eps = 1e-7 * h, del = 1e-3 * h;
          const side = s => { const P0 = add(X, mul(ref.n, s * eps)), fd = e => { const f = d => phiK(k, add(P0, mul(e, d))); return (-f(2 * del) + 8 * f(del) - 8 * f(-del) + f(-2 * del)) / (12 * del); }; return add(mul(ref.e1, fd(ref.e1)), mul(ref.e2, fd(ref.e2))); };
          const jump = sub(side(1), side(-1)), rec = [0, 1, 2].map(c => l[0] * U[9 * j + c] + l[1] * U[9 * j + 3 + c] + l[2] * U[9 * j + 6 + c]);
          const ej = norm(sub(jump, ref.g)), er = norm(sub(rec, ref.g)); scale = Math.max(scale, norm(ref.g));
          if (cp) { eJumpCP = Math.max(eJumpCP, ej); eRecCP = Math.max(eRecCP, er); cpPts++; } else { eJump = Math.max(eJump, ej); eRec = Math.max(eRec, er); pts++; }
        }
      });
    }
  }
  log(`recovery vs the sheet (random doublets, split modes ${Object.keys(modesSeen).join(', ')}): ${pts} generic triangle-interior points and ${cpPts} control points; max |[grad_t phi] (kernel, differences) - grad mu_T (reference)| ${eJump.toExponential(2)} / ${eJumpCP.toExponential(2)}; max |recovered - grad mu_T| ${eRec.toExponential(2)} / ${eRecCP.toExponential(2)} (max |grad mu_T| ${scale.toExponential(2)})`);
  ok(eJump < 1e-5 * scale && eJumpCP < 1e-5 * scale, 'the kernel\'s tangential-gradient jump across the sheet is grad mu_T of the documented P2 polynomial (generic points and control points)');
  ok(eRec < 1e-11 * scale && eRecCP < 1e-11 * scale, 'the recovered surface velocity is V_t + grad mu_T of the same polynomial, to round-off');
  // a solved solution: panel Cp = the recovered velocity at the control point; forces and couples = the exact integrals
  const m = W.prepare(SWEPT, { chordPanels: 10, spanPanels: 6 }), r = W.evaluate(m, { alphaDeg: 4, speed: 15 }), R = m.surface.R, al = 4 * Math.PI / 180, q = 0.5 * 1.225 * 15 * 15 * 1e-6;
  const GP = []; for (const [a, b, w] of [[0.501426509658179, 0.249286745170910, 0.116786275726379], [0.873821971016996, 0.063089014491502, 0.050844906370207]]) GP.push([a, b, b, w], [b, a, b, w], [b, b, a, w]);
  { const [a, b, c, w] = [0.053145049844817, 0.310352451033784, 0.636502499121399, 0.082851075618374]; GP.push([a, b, c, w], [a, c, b, w], [b, a, c, w], [b, c, a, w], [c, a, b, w], [c, b, a, w]); }
  let eF = 0, eM = 0, eCp = 0, sF = 0;
  for (let k = 0; k < m.wm.S.count; k++) {
    const C = [m.wm.S.PC[3 * k], m.wm.S.PC[3 * k + 1], m.wm.S.PC[3 * k + 2]]; let F = [0, 0, 0], M = [0, 0, 0];
    for (let j = R.first[k]; j < R.first[k + 1]; j++) {
      const v = l => [0, 1, 2].map(c => Math.cos(al) * (l[0] * m.surface.Ux[9 * j + c] + l[1] * m.surface.Ux[9 * j + 3 + c] + l[2] * m.surface.Ux[9 * j + 6 + c]) + Math.sin(al) * (l[0] * m.surface.Uz[9 * j + c] + l[1] * m.surface.Uz[9 * j + 3 + c] + l[2] * m.surface.Uz[9 * j + 6 + c]));
      const n = [R.N[3 * j], R.N[3 * j + 1], R.N[3 * j + 2]], Xv = i => [R.X[9 * j + 3 * i], R.X[9 * j + 3 * i + 1], R.X[9 * j + 3 * i + 2]];
      for (const [a, b, c, w] of GP) { const vv = v([a, b, c]), cp = 1 - dot(vv, vv), X = add(add(mul(Xv(0), a), mul(Xv(1), b)), mul(Xv(2), c)), dF = mul(n, -q * cp * w * R.area[j]); F = add(F, dF); M = add(M, cross(sub(X, C), dF)); }
      if (R.cpTri[k] === j) { const vv = v([R.cpL[3 * k], R.cpL[3 * k + 1], R.cpL[3 * k + 2]]); eCp = Math.max(eCp, Math.abs(1 - dot(vv, vv) - r.panels.cp[k])); }
    }
    eF = Math.max(eF, norm(sub(F, [0, 1, 2].map(c => r.panels.force_N[3 * k + c])))); sF = Math.max(sF, norm(F));
    eM = Math.max(eM, norm(sub(M, [0, 1, 2].map(c => r.panels.momentAboutCentroid_Nmm[3 * k + c]))));
  }
  log(`solved swept wing 10 x 6: panel force vs a degree-6 quadrature of the recovered Cp, max error ${eF.toExponential(2)} N (max |F| ${sF.toExponential(2)}); couple about the centroid ${eM.toExponential(2)} N mm; panel Cp = Cp at the control point within ${eCp.toExponential(1)}`);
  ok(eF < 1e-12 * sF && eM < 1e-12 * sF * m.wm.S.PD[0] && eCp < 1e-12, 'panel forces and couples are the exact integrals of the recovered quadratic Cp; panel Cp is its value at the control point');
  const sw = W.stripWrenches(r), res = W.resultantOfPanels(r); let eS = 0;
  for (let c = 0; c < 3; c++) eS = Math.max(eS, Math.abs(sw.reduce((s, w) => s + w[5 + c], 0) - r.semiWing.momentAboutRootOrigin_Nmm[c]), Math.abs(res.moment[c] - r.semiWing.momentAboutRootOrigin_Nmm[c]));
  ok(eS < 1e-11 * Math.hypot(...r.semiWing.momentAboutRootOrigin_Nmm), `strip wrenches and resultantOfPanels include the panel couples (root moment within ${eS.toExponential(1)} N mm)`);
}
// ---------------------------------------------------------------- 11. split rule at the closed corners of the last strip
{
  // (a) the rule itself on a synthetic surface: panels 0 and 1 share A, B, C and their shorter diagonals (AC) give both
  // the triangle ABC -> both take the other diagonal (BD, BD'); panel 2 (D, B, X, C) splits along BC into BXC and BCD,
  // which panel 0's flipped triangle BCD would then duplicate -> panels 0 and 2 take the fan of four, panel 1 keeps BD'
  // (panel 3: an unrelated panel far away, as buildSurface needs four)
  const A = [0, 0, 0], Bq = [10, 0, 0], C = [10, 10, 0], D = [0, 10, 1], D1 = [0, 10, -1], X = [20, 5, 0];
  const S3 = W.buildSurface(Float64Array.from([A, Bq, C, D, D1, X, [100, 0, 0], [103, 0, 0], [102, 2, 0], [100, 2, 0]].flat()), Int32Array.from([0, 1, 2, 3, 0, 1, 2, 4, 3, 1, 5, 2, 6, 7, 8, 9]));
  const B3 = W.tensorQuadBasis(S3, { n: 4, nValues: 36, refs: Int32Array.from({ length: 36 }, (_, i) => i), spanChains: [], stationChains: [], stripChains: [], tipMean: null });
  const s3 = [0, 1, 2, 3].map(k => W.tensorSlots(B3, k)), same = (P, Q) => norm(sub(P, Q)) <= 1e-12;
  const t1 = s3[1].tris.map(t => t.points), want1 = [[Bq, C, D1], [Bq, D1, A]];
  log(`synthetic surface: split ${s3.map(s => s.split).join(', ')}, modes ${s3.map(s => s.mode).join(', ')}`);
  ok(s3[0].split === 2 && s3[1].split === 1 && s3[2].split === 2 && s3[3].split === 0 && s3[0].mode === 1 && s3[1].mode === 0 && s3[2].mode === 1 && s3[3].mode === 0 && t1.every((Q, t) => Q.every((P, i) => same(P, want1[t][i]))),
    'split rule: a shared shorter-diagonal triangle -> both panels take the other diagonal; a coincidence that would remain -> the fan of four');
  // (b) wing meshes
  const GATE2412 = { naca: '2412', semiSpan: 900, rootChord: 160, tipChord: 100, planform: 'linear', sweepDeg: 10, dihedralDeg: 10, sweepReferenceFraction: 0.25, twistReferenceFraction: 0.25, twistEnabled: false };
  const RECT0012 = { naca: '0012', semiSpan: 600, rootChord: 200, tipChord: 200 };
  let flagged = 0, wrongPlace = 0, mismatch = 0, fan = 0, dup = 0, modelErr = 0, chiIn = 0, chiOut = 0, chiPts = 0; const lines = [];
  for (const [name, geo, mesh] of [['2412 gate', GATE2412, { chordPanels: 32, spanPanels: 16 }], ['rect0012 AR6', RECT0012, { chordPanels: 32, spanPanels: 24 }], ['swept', SWEPT, { chordPanels: 8, spanPanels: 5 }], ['elliptic', ELLIPTIC, { chordPanels: 8, spanPanels: 6 }]]) {
    const wm = meshOf(geo, mesh), S = wm.S, B = wm.body, ni = wm.ni, ns = wm.ns, ref = cornerFlips(S), core = new Set(), here = [];
    for (let k = 0; k < S.count; k++) if (B.split[k]) { core.add(k); if (B.split[k] === 2) fan++; }
    for (const k of new Set([...ref, ...core])) if (!(ref.has(k) && core.has(k))) mismatch++;
    for (const k of core) { const i = k % ni, j = Math.floor(k / ni); here.push(`(i ${i}, j ${j})`); if (!(j === ns - 1 && [0, ni - 1, ni / 2 - 1, ni / 2].includes(i))) wrongPlace++; }
    flagged += core.size; lines.push(`${name} ${mesh.chordPanels}x${mesh.spanPanels}: ${here.join(' ') || 'none'}`);
    // the core's triangles: the documented split (panelModel, with the exception) and no triangle shared by two panels
    const tris = [];
    for (let k = 0; k < S.count; k++) {
      const T = W.tensorSlots(B, k), model = panelModel(S, k);
      T.tris.forEach((t, ti) => { if (!t.valid) return; tris.push({ k, Q: t.points, g: mul(add(add(t.points[0], t.points[1]), t.points[2]), 1 / 3) }); for (let i = 0; i < 3; i++) modelErr = Math.max(modelErr, norm(sub(t.points[i], model[ti].Q[i])) / S.PD[k]); });
    }
    for (let a = 0; a < tris.length; a++) for (let b = a + 1; b < tris.length; b++) {
      const P = tris[a], Q = tris[b], tol = 1e-6 * Math.min(S.PD[P.k], S.PD[Q.k]);
      if (P.k !== Q.k && norm(sub(P.g, Q.g)) <= tol && P.Q.every(p => Q.Q.some(q => norm(sub(p, q)) <= tol))) dup++;
    }
    // solid-angle indicator of the closed surface (unit doublet everywhere, no source): -1 inside, 0 outside
    const ones = new Float64Array(S.count).fill(1), chi = P => W.fieldPotential(S, B, wm.wake, P, ones, [0, 0, 0], { farField: Infinity });
    for (const k of core) for (const t of W.tensorSlots(B, k).tris) {
      if (!t.valid) continue; const Q = t.points, N = cross(sub(Q[1], Q[0]), sub(Q[2], Q[0])), A2 = norm(N), nT = mul(N, 1 / A2), G = mul(add(add(Q[0], Q[1]), Q[2]), 1 / 3);
      for (const d of [1e-6, 1e-3]) { const h = d * Math.sqrt(A2 / 2); chiIn = Math.max(chiIn, Math.abs(chi(add(G, mul(nT, -h))) + 1)); chiOut = Math.max(chiOut, Math.abs(chi(add(G, mul(nT, h))))); chiPts++; }
    }
  }
  log(`panels on the other diagonal: ${lines.join('; ')}`);
  log(`against the all-pairs reference: ${mismatch} mismatches; fan fallback ${fan}; triangles shared by two panels ${dup}; core triangles vs the documented split max offset ${modelErr.toExponential(1)} (panel diameters); solid-angle indicator at ${chiPts} points: max |chi + 1| inside ${chiIn.toExponential(1)}, max |chi| outside ${chiOut.toExponential(1)}`);
  ok(flagged > 0 && mismatch === 0 && fan === 0 && wrongPlace === 0, 'the panels that take the other diagonal are exactly the coincident pairs (last strip, trailing-edge and leading-edge corners only)');
  ok(dup === 0 && modelErr < 1e-12, 'no triangle is shared by two panels; every panel follows the documented split');
  ok(chiPts > 0 && chiIn < 1e-6 && chiOut < 1e-6, 'the surface bounds a volume at the corners: solid-angle indicator -1 just inside and 0 just outside the corner triangles');
}
// ---------------------------------------------------------------- 12. far field of the assembled solution, fine span
{
  // earlier zones (exact inside 2.4 diameters, fourth order to 4, second to 12) measured on this wing: dCL / CL 1.0e-4,
  // dCm 2.7e-6; the error grew with spanwise refinement (64 x 24 ... 64 x 96: a spurious Cm drift of 1.6e-5)
  const RECT = { naca: '0012', semiSpan: 600, rootChord: 200, tipChord: 200 }, flow = { alphaDeg: 4, speed: 10 };
  const rd = W.evaluate(W.prepare(RECT, { chordPanels: 16, spanPanels: 48 }), flow), rx = W.evaluate(W.prepare(RECT, { chordPanels: 16, spanPanels: 48, farField: Infinity }), flow);
  let dcp = 0; for (let k = 0; k < rx.panels.cp.length; k++) dcp = Math.max(dcp, Math.abs(rd.panels.cp[k] - rx.panels.cp[k]));
  const dCL = Math.abs(rd.coefficients.CL / rx.coefficients.CL - 1), dCLt = Math.abs(rd.coefficients.CLTrefftz / rx.coefficients.CLTrefftz - 1), dCm = Math.abs(rd.coefficients.Cm - rx.coefficients.Cm);
  log(`rectangular NACA 0012 AR 6, 16 x 48: default far field vs every panel exact: CL ${dCL.toExponential(2)} (relative), CL Trefftz ${dCLt.toExponential(2)}, Cm ${dCm.toExponential(2)} (absolute; Cm ${rx.coefficients.Cm.toExponential(3)}), max |dCp| ${dcp.toExponential(2)}`);
  ok(dCL < 2e-5 && dCLt < 2e-5 && dCm < 4e-7 && dcp < 1e-3, 'fine spanwise mesh: the default far field changes CL and CL Trefftz by less than 2e-5 (relative), Cm by less than 4e-7 and Cp by less than 1e-3');
}
console.log(`test_wing_aero_tensor_doublet: ${checks} checks passed (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
