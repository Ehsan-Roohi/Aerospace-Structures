# Wing AeroStruct numerical revision 0.3.2-exp.4

Reviewed core: 17bdcbe, numerically identical to 7e6b7eb. The independent 2D
solver remains 1.1.0 in the deployed application and is separate from this
numerical-source archive. The historical UI archive is not replaced here.

Run from the extracted directory with Node.js:

    node computational/printed-wing-solver/aerostruct/test_wing_aero_external_acceptance.mjs
    node computational/printed-wing-solver/aerostruct/test_wing_aero_transfer.mjs
    node computational/printed-wing-solver/aerostruct/test_wing_aero_tensor_doublet.mjs

The original test predicates and references are included unchanged. They do
not all pass against this different discretization. Review the published
validation page and raw receipts; do not replace the old references to force
a pass. One cross-term fixture U differs by 2.17e-18 on Windows/Node24;
same-machine legacy recombination was independently identical.

Sources and moments are integrated from the same physical quadratic pressure
field. Eight meshes include a mixed chord/span error estimate; old seven-mesh
study loads retain their original combination. U is empirical. Deepest local
tip/wake-corner pressure and collapsed last-strip Cp remain unvalidated.
No viscous, stall, separation, aeroelastic or local structural-strength
validation is claimed. Retain THIRD_PARTY_NOTICES.md, including test-port notices.
