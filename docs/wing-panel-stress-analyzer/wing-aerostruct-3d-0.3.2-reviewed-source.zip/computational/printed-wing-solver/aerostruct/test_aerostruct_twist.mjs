// Wing AeroStruct twist claim on real structures (admission with the structure's torsional compliance):
//  1. the compliance integral behind the twist bound, theta(y) = integral of T k dy with k = (element length /
//     projected length) / GJ of the frame elements, reproduces the spatial beam's own twist (editable fixture and a
//     swept, dihedral, twisted two-spar wing under six-component strip loads);
//  2. structures with the course wing's outer shape (alpha 4 deg, 15 m/s), Standard and Fine sequences:
//       editable fixture, near-zero torque about its shear-centre axis: torque NOT resolved at any cut (the reviewer's
//         case 1.950 +- 0.955 N mm on Fine), the 75% cut has meshes of opposite sign; the twist bound is aerodynamically
//         negligible, so the load is admitted with torque and twist WITHHELD (no floor, no qSc normalization);
//       the same structure with a low-GJ shell and spars (modulus 10 MPa): the same unresolved torque now gives a twist
//         bound that is not negligible, so the coupled result is REFUSED on both sequences;
//       forward spars (large torque): every torque and the twist resolved on Fine (shown), Standard withheld;
//       forward spars, GJ / 4: twist resolved and its one-way-coupling lift effect below 2% (shown);
//       forward spars, GJ / 40: twist resolved but it would change the lift by more than 2%: REFUSED (rigid-wing load
//         not consistent with the structure);
//  3. the twist bound holds against a much finer reference load (validation/admission_reference.json, written by
//     validation/reference_study.mjs): on every structure and sequence, at 16 stations and the tip,
//     |theta(delivered) - theta(reference)| <= dtheta(delivered) + dtheta(reference), and also the stricter
//     |theta(delivered) - theta(reference)| + dtheta(reference) <= dtheta(delivered);
//  4. the twist bound is consistent between sequences: |theta(Standard) - theta(Fine)| <= dtheta(Standard) + dtheta(Fine).
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const A = require('./wing_aero_panel.js'), E = require('./engine.js'), IO = require('./wing_study_io.js'), UI = require('./wing_aero_ui.js'), Sp = require('../web/wing_spars.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const t0 = Date.now(), deg = 180 / Math.PI;
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const fixture = IO.importPrintedStudy(readFileSync(new URL('../../../tests/fixtures/wing_lab_editable_browser.json', import.meta.url), 'utf8'), E).state;
const base = fixture.geometry, flow = { speed: 15, density: 1.225, alphaDeg: 4 };
const twistAt = (R, y) => E.interp(y, R.y, R.twist);

// 1. compliance integral against the frame's own twist
function complianceCheck(input, label) {
  const R = E.solve(input), a = R.analysis3D, tor = UI.structuralTorsion(A, R), L = R.geometry.semiSpan;
  let theta = 0; const pts = [[0, 0]];
  for (const e of tor.elements) { const n = 6; for (let j = 0; j < n; j++) { const ya = e.y0 + (e.y1 - e.y0) * j / n, yb = e.y0 + (e.y1 - e.y0) * (j + 1) / n; theta += a.cutAt((ya + yb) / 2).localMoment[0] * e.k * (yb - ya); } pts.push([e.y1, theta]); }
  const worst = Math.max(...[0.25, 0.5, 0.75, 1].map(f => { const y = f * L, est = E.interp(y, pts.map(p => p[0]), pts.map(p => p[1])), tw = twistAt(R, y); return Math.abs(est - tw) / Math.abs(tw); }));
  log(`${label}: compliance integral of the internal torque vs the frame twist, largest relative difference ${worst.toExponential(2)} (tip twist ${(twistAt(R, L) * deg).toExponential(3)} deg)`);
  ok(worst < 0.01, `${label}: the twist bound uses the beam's actual torsional compliance (within 1%)`);
}
{
  const g = E.makeGeometry(base), L = g.semiSpan, snap = [...E.ribStations(g), ...E.seams(g), ...g.spars.map(s => s.length)];
  let ys = Array.from({ length: 33 }, (_, k) => k * L / 32); ys = ys.filter((y, i) => i === 0 || i === ys.length - 1 || snap.every(t => Math.abs(t - y) >= 0.1));
  const strips = ys.slice(0, -1).map((y0, i) => { const y1 = ys[i + 1], h = y1 - y0, f = 1 - (y0 / L) ** 2; return [y0, y1, -0.002 * h * f, 0.001 * h, 0.02 * h * f, 0.05 * h, -0.8 * h * f, 0.02 * h]; });
  complianceCheck({ geometry: base, assembly: fixture.assembly, load: { kind: 'custom', items: [] }, aeroLoad: { kind: 'aeroStrips', lineFraction: 0.25, strips } }, 'editable fixture');
  const spar = { fraction: .3, length: 400, topWidth: 8, topThickness: .8, bottomWidth: 8, bottomThickness: .8, webThickness: .6, material: { ...Sp.MAT } };
  const sgeo = { semiSpan: 400, rootChord: 160, tipChord: 90, naca: '2412', sweepDeg: 20, dihedralDeg: 7, sweepReferenceFraction: 0.25, twistEnabled: true, twistReferenceFraction: 0.25, modules: 1, rodFractions: [], interiorRibs: 2, spars: [spar, { ...spar, fraction: .62 }], skin: 1.2, te: 1.2,
    stations: [{ eta: 0, airfoil: { kind: 'naca4', code: '2412' }, incidenceDeg: 2 }, { eta: 0.5, airfoil: { kind: 'naca4', code: '2412' }, incidenceDeg: 0.5 }, { eta: 1, airfoil: { kind: 'naca4', code: '0012' }, incidenceDeg: -2 }] };
  const g2 = E.makeGeometry(sgeo), L2 = g2.semiSpan, snap2 = [...E.ribStations(g2), ...E.seams(g2), ...g2.stations.map(s => s.eta * L2), ...g2.spars.map(s => s.length)];
  let y2 = Array.from({ length: 33 }, (_, k) => k * L2 / 32); y2 = y2.filter((y, i) => i === 0 || i === y2.length - 1 || snap2.every(t => Math.abs(t - y) >= 0.1));
  const strips2 = y2.slice(0, -1).map((y0, i) => { const y1 = y2[i + 1], h = y1 - y0, f = 1 - (y0 / L2) ** 2; return [y0, y1, -0.002 * h * f, 0.001 * h, 0.02 * h * f, 0.05 * h, -0.8 * h * f, 0.02 * h]; });
  complianceCheck({ geometry: sgeo, assembly: { seamsBonded: true }, load: { kind: 'custom', items: [] }, aeroLoad: { kind: 'aeroStrips', lineFraction: 0.25, strips: strips2 }, nSections: 5 }, 'swept 20 deg, dihedral 7 deg, twisted two-spar wing');
}

// 2. structures and the twist claim
const soft = (E_) => ({ geometry: { ...base, spars: base.spars.map(s => ({ ...s, material: { ...s.material, E: E_ } })) }, pla: { E: E_ } });
const forward = (E_) => ({ geometry: { ...base, spars: [{ ...base.spars[0], fraction: 0.12, material: { ...base.spars[0].material, E: E_ } }, { ...base.spars[1], fraction: 0.35, material: { ...base.spars[1].material, E: E_ } }] }, pla: { E: E_ } });
const STRUCTURES = {
  'editable fixture': { ...soft(2000), expect: { standard: 'withheld', fine: 'withheld' } },
  'low-GJ fixture (modulus 10 MPa)': { ...soft(10), expect: { standard: 'refused', fine: 'refused' } },
  'forward spars': { ...forward(2000), expect: { standard: 'withheld', fine: 'shown' } },
  'forward spars, GJ / 4': { ...forward(500), expect: { standard: 'withheld', fine: 'shown' } },
  'forward spars, GJ / 40': { ...forward(50), expect: { standard: 'refused', fine: 'refused' } },
};
const outer = E.makeGeometry(base), cache = new Map(), seqs = {};
for (const sn of ['standard', 'fine']) seqs[sn] = A.runSequence(outer, flow, sn, { cache });
const ref = JSON.parse(readFileSync(new URL('./validation/admission_reference.json', import.meta.url), 'utf8')).twistReference;
ok(ref && ref.config === 'course4' && Array.isArray(ref.stations) && ref.stations.length === ref.wrench.length && ref.cutStations.length === A.ADMISSION.torsionStations, 'stored reference load of the course wing (twist reference) present');
ok(JSON.stringify(ref.flow) === JSON.stringify({ speed: 15, alphaDeg: 4 }) && Math.abs(ref.stations.at(-1) - outer.semiSpan) < 1e-9, 'the reference load belongs to this wing and flow');
const refStrips = ref.stations.slice(0, -1).map((y0, k) => [y0, ref.stations[k + 1], ...ref.wrench[k].map((v, d) => v - ref.wrench[k + 1][d])]);
const results = {};
for (const [name, st] of Object.entries(STRUCTURES)) {
  const sg = E.makeGeometry(st.geometry), L = sg.semiSpan, snap = [...E.ribStations(sg), ...E.seams(sg), ...sg.spars.map(s => s.length)];
  const inputOf = aeroLoad => ({ geometry: st.geometry, assembly: fixture.assembly, load: { kind: 'custom', items: [], fos: 1.5, tipMass: 0 }, aeroLoad, pla: st.pla });
  const Rref = E.solve(inputOf({ kind: 'aeroStrips', lineFraction: 0.25, strips: refStrips, label: 'reference' })), torRef = UI.structuralTorsion(A, Rref);
  // the reference load's own twist bound: torque uncertainty at each cut plane from the stored uncertainties of the force
  // and of the moment about the load-line point r: T = n . (M_r - (P - r) x F), so |dT| <= sum |n_d| u(M_r,d) + sum |(n x (P - r))_d| u(F_d)
  const uT = torRef.cuts.map((c, k) => { const n = c.normal, P = c.reference, r = ref.cutLinePoint[k], u = ref.cutUncertainty[k], arm = cross(n, P.map((v, d) => v - r[d])); return [0, 1, 2].reduce((t, d) => t + Math.abs(n[d]) * u[3 + d] + Math.abs(arm[d]) * u[d], 0); });
  const Yr = [...torRef.cuts.map(c => c.y), L], Ur = [...uT, 0];
  const dthetaRef = y => { let s = 0; for (let i = 0; i < Yr.length - 1 && Yr[i] < y; i++) { const a = Yr[i], b = Math.min(Yr[i + 1], y), Ub = Math.max(Ur[i], Ur[i + 1]); for (const e of torRef.elements) { const lo = Math.max(a, e.y0), hi = Math.min(b, e.y1); if (hi > lo) s += Ub * e.k * (hi - lo); } } return s; };
  results[name] = {};
  for (const sn of ['standard', 'fine']) {
    const rec = UI.recordFromSequence(seqs[sn], IO.sha256(A.geometryKey(sg))), comb = UI.delivered(A, sg, rec, snap);
    const R = E.solve(inputOf(UI.engineLoad(comb, 'test'))), adm = UI.admit(A, sg, rec, comb, R), tw = adm.twist;
    const outcome = !adm.admitted ? 'refused' : adm.claims.twist === 'shown' ? 'shown' : 'withheld';
    const torques = adm.rows.filter(r => r.kind === 'torque');
    const fb = adm.rows.filter(r => r.kind === 'force' || r.kind === 'bending');
    log(`${name}, ${sn}: ${fb.map(r => `${r.label} ${r.value.toFixed(3)} ± ${r.uncertainty.toFixed(3)} (${(100 * r.relative).toFixed(1)}%)`).join('; ')}`);
    log(`${name}, ${sn}: ${outcome}; torque ${torques.map(r => `${r.value.toFixed(3)} ± ${r.uncertainty.toFixed(3)} (${(100 * r.relative).toFixed(0)}%, ${r.status}${r.meshSignsAgree ? '' : ', meshes of opposite sign'})`).join('; ')}; tip twist ${(tw.tipTheta * deg).toExponential(3)} ± ${(tw.tipDtheta * deg).toExponential(2)} deg; bound on |twist| ${(tw.maxBound * deg).toExponential(2)} deg, its lift effect ${(100 * tw.liftEffect).toFixed(3)}%, one-way coupling ${(100 * tw.rigidWingEffect).toFixed(3)}%`);
    ok(outcome === st.expect[sn], `${name}, ${sn}: ${st.expect[sn]} (got ${outcome})`);
    ok(adm.rows.every(r => r.floorActive === undefined) && !('torqueFloor_Nmm' in adm), `${name}, ${sn}: no absolute torque floor in the admission`);
    ok(torques.every(r => r.resolved === (r.uncertainty <= 0.10 * Math.abs(r.value) && r.meshSignsAgree)), `${name}, ${sn}: a torque is resolved only if U <= 10% of |T| and the meshes agree in sign`);
    ok(torques.every(r => r.signResolved === (r.uncertainty < Math.abs(r.value) && r.meshSignsAgree)) && torques.every(r => r.status === (r.resolved ? 'resolved' : r.signResolved ? 'magnitude not resolved' : 'sign not resolved')), `${name}, ${sn}: sign resolved only if the interval excludes zero and the meshes agree`);
    ok((adm.claims.torque === 'shown') === torques.every(r => r.resolved) && (adm.claims.twist === 'shown') === (tw.status === 'resolved'), `${name}, ${sn}: torque and twist are shown only when resolved`);
    if (tw.status === 'resolved') ok(tw.stations.every(s => s.dtheta <= 0.10 * Math.abs(s.theta)), `${name}, ${sn}: a shown twist is within 10% of itself at 25, 50, 75% span and the tip`);
    if (tw.status === 'negligible') ok(tw.liftEffect <= 0.01 && !torques.every(r => r.resolved) && adm.admitted, `${name}, ${sn}: withheld twist admitted only because its bound changes the lift by at most 1%`);
    if (outcome === 'refused') ok(adm.failed.length > 0 && (tw.status === 'unresolved' || tw.rigidWingEffect > 0.02), `${name}, ${sn}: refused for an unresolved, non-negligible twist or a rigid-wing load inconsistent with the structure (${adm.failed.join('; ')})`);
    // 3. twist bound against the reference load on the same structure
    let worst = 0, worstStrict = 0;
    for (const c of [...tw.cuts.slice(1), { y: L, dtheta: tw.tipDtheta }]) {
      const diff = Math.abs(twistAt(R, c.y) - twistAt(Rref, c.y)), bound = c.dtheta + dthetaRef(c.y);
      worst = Math.max(worst, diff / bound); worstStrict = Math.max(worstStrict, (diff + dthetaRef(c.y)) / c.dtheta);
    }
    log(`    twist error against the reference load: largest |theta - theta_ref| / (dtheta + dtheta_ref) = ${worst.toFixed(3)}; with the reference bound moved to the error side: ${worstStrict.toFixed(3)}`);
    ok(worst <= 1, `${name}, ${sn}: |theta - theta_ref| <= dtheta + dtheta_ref at 16 stations and the tip`);
    ok(worstStrict <= 1, `${name}, ${sn}: the delivered bound alone covers the error even with the reference's own bound counted as error, |theta - theta_ref| + dtheta_ref <= dtheta (largest ratio ${worstStrict.toFixed(3)})`);
    results[name][sn] = { R, adm, worst, worstStrict, comb, sg };
  }
  // 4. consistency between the sequences
  const a = results[name].standard, b = results[name].fine;
  const worstPair = Math.max(...[...b.adm.twist.cuts.slice(1).map(c => c.y), L].map(y => { const da = a.adm.twist.cuts.find(c => Math.abs(c.y - y) < 1e-9)?.dtheta ?? a.adm.twist.tipDtheta, db = b.adm.twist.cuts.find(c => Math.abs(c.y - y) < 1e-9)?.dtheta ?? b.adm.twist.tipDtheta; return Math.abs(twistAt(a.R, y) - twistAt(b.R, y)) / (da + db); }));
  ok(worstPair <= 1, `${name}: Standard and Fine twists agree within the sum of their bounds (largest ratio ${worstPair.toFixed(3)})`);
}
// the reviewer's case, stated explicitly
{
  const fine = results['editable fixture'].fine.adm, rows = fine.rows.filter(r => r.kind === 'torque');
  ok(Math.abs(rows[0].value - 1.950) < 0.01 && Math.abs(rows[0].uncertainty - 0.955) < 0.01 && rows[0].status === 'magnitude not resolved', `editable fixture, Fine, root: ${rows[0].value.toFixed(3)} ± ${rows[0].uncertainty.toFixed(3)} N mm is reported as not resolved (49% of |T|), not admitted as a resolved torque`);
  ok(rows[2].status === 'sign not resolved' && rows[3].status === 'sign not resolved' && !rows[3].meshSignsAgree && rows[3].meshTorques.some(m => m.torque > 0) && rows[3].meshTorques.some(m => m.torque < 0), 'editable fixture, Fine: 50% and 75% torques have unresolved signs; at 75% the weighted meshes give torques of both signs');
  ok(fine.claims.torque === 'withheld' && fine.claims.twist === 'withheld' && fine.admitted, 'editable fixture, Fine: admitted with torque and twist withheld');
  log(`editable fixture, Fine, 75% cut: torques of the weighted meshes ${rows[3].meshTorques.map(m => `${2 * m.chordPanels} x ${m.spanPanels}: ${m.torque.toFixed(3)}`).join(', ')} N mm`);
  // the root torque of every solved mesh about this structure's root axis (why the torque is not resolved)
  const Rf = results['editable fixture'].fine.R, a = Rf.analysis3D, P0 = a.nodes[0], n0 = a.cutAt(0).R[0];
  const rootTorque = l => { const w = l.strips.reduce((t, r) => t.map((v, i) => v + r[2 + i]), [0, 0, 0, 0, 0, 0]), F = w.slice(0, 3), M = w.slice(3), m = M.map((v, i) => v - cross(P0, F)[i]); return m[0] * n0[0] + m[1] * n0[1] + m[2] * n0[2]; };
  const levels = [...seqs.standard.levels, ...seqs.fine.levels], seen = new Map(); for (const l of levels) seen.set(`${l.chordPanels}x${l.spanPanels}`, l);
  const chordwise = [...seen.values()].filter(l => l.spanPanels === 16).sort((p, q) => p.chordPanels - q.chordPanels), spanwise = [...seen.values()].filter(l => l.chordPanels === 32).sort((p, q) => p.spanPanels - q.spanPanels);
  log(`editable fixture, root torque of each solved mesh about the structure's root axis: chordwise (panels per surface, 16 strips) ${chordwise.map(l => `${l.chordPanels}: ${rootTorque(l).toFixed(2)}`).join(', ')} N mm; spanwise (strips, 32 per surface) ${spanwise.map(l => `${l.spanPanels}: ${rootTorque(l).toFixed(2)}`).join(', ')} N mm`);
  ok(chordwise.length === 6 && spanwise.length === 6 && rootTorque(chordwise[0]) > rootTorque(chordwise.at(-1)) + 5, 'the root torque falls by several N mm under chordwise refinement: a slowly converging small difference');
  // sensitivity of the withheld twist claim to the separability cross term, which U does not contain: add the largest
  // cross-term torque estimate of the reference study to U_T along the whole span and recompute the bound's lift effect
  const stored = JSON.parse(readFileSync(new URL('./validation/admission_reference.json', import.meta.url), 'utf8'));
  const X = Math.max(...Object.values(stored.configs).flatMap(c => Object.values(c.separability.axes).flatMap(ax => ax.flatMap(cut => cut.crossTorque.map(Math.abs)))));
  for (const sn of ['standard', 'fine']) {
    const { R: Rs, adm, comb, sg } = results['editable fixture'][sn], tw = adm.twist, tor = UI.structuralTorsion(A, Rs), L = sg.semiSpan;
    const Kint = y => tor.elements.reduce((t, e) => t + e.k * Math.max(0, Math.min(y, e.y1) - e.y0), 0);
    const q = 0.5 * flow.density * flow.speed ** 2 * 1e-6, Lsemi = Math.abs(comb.coefficients.CL.value) * q * A.references(A.aeroGeometry(sg)).semiArea_mm2, N = 240;
    let I = 0; for (let i = 0; i <= N; i++) { const y = i * L / N; I += (i === 0 || i === N ? 0.5 : 1) * E.chordAt(sg, y) * X * Kint(y); }
    const extra = q * A.ADMISSION.sectionLiftSlope * I * (L / N) / Lsemi;
    log(`editable fixture, ${sn}: with ${X.toFixed(3)} N mm (largest cross-term estimate) added to U_T on the whole span, the tip dtheta grows from ${(tw.tipDtheta * deg).toExponential(2)} to ${((tw.tipDtheta + X * Kint(L)) * deg).toExponential(2)} deg and the lift effect of the bound from ${(100 * tw.liftEffect).toFixed(4)}% to ${(100 * (tw.liftEffect + extra)).toFixed(4)}%`);
    ok(X < 0.25 && tw.liftEffect + extra <= 0.01, `editable fixture, ${sn}: the withheld twist stays negligible when the separability cross term is added to U_T`);
  }
}
console.log(`test_aerostruct_twist: ${checks} checks passed (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
