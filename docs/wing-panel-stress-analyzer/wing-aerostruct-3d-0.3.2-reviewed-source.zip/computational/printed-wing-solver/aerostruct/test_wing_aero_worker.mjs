// The BUILT aerodynamic Worker (site-aerostruct/wing-aero/wing_aero_worker.js + aero_bundle.js, written by
// build_wing_aerostruct.py) run in an isolated VM context with a Worker-like global (self, importScripts,
// postMessage). Checks: the bundle is exactly the three source files; a mesh-sequence request equals a direct call of
// the core, reports progress per mesh and reuses the cached influence systems at a new angle; a target lift is met
// on the EXTRAPOLATED lift; single-mesh requests still work; invalid input returns an error message instead of
// throwing; the hashed bundle URL matches the bundle content.
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import vm from 'node:vm';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js'), E = require('./engine.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const dir = new URL('../../../site-aerostruct/wing-aero/', import.meta.url), read = f => readFileSync(new URL(f, import.meta.url), 'utf8');
if (!existsSync(new URL('wing_aero_worker.js', dir))) { console.log('test_wing_aero_worker: site-aerostruct/wing-aero not built; run build_wing_aerostruct.py first'); process.exit(1); }
const bundle = readFileSync(new URL('aero_bundle.js', dir), 'utf8'), workerText = readFileSync(new URL('wing_aero_worker.js', dir), 'utf8');
ok(bundle === ['../web/wing_airfoils.js', '../web/wing_geometry.js', 'wing_aero_panel.js'].map(read).join('\n;\n'), 'bundle is exactly the current source files (shared geometry + AeroStruct panel core)');
const hash = createHash('sha256').update(bundle).digest('hex').slice(0, 12);
ok(workerText.includes(`'./aero_bundle.js?v=${hash}'`), 'worker loads the bundle by its content hash');
ok(workerText.replace(`?v=${hash}`, '') === read('wing_aero_worker.js'), 'built worker equals the source worker apart from the hash');

const posted = [];
const ctx = { console, Date, Math, JSON, Map, Set, WeakSet, Float64Array, Int32Array, Object, Array, Error, Number, String, isFinite, Symbol, performance };
ctx.self = ctx; ctx.postMessage = m => posted.push(structuredClone(m));
ctx.importScripts = url => { assert.ok(url.startsWith('./aero_bundle.js'), 'only the bundle is imported'); vm.runInContext(bundle, ctx, { filename: 'aero_bundle.js' }); };
vm.createContext(ctx);
vm.runInContext(workerText, ctx, { filename: 'wing_aero_worker.js' });
ok(typeof ctx.onmessage === 'function', 'worker installs onmessage');
const send = data => { posted.length = 0; ctx.onmessage({ data: structuredClone(data) }); return posted.slice(); };
const g = E.makeGeometry(E.DEFAULT_GEOMETRY), geometry = JSON.parse(JSON.stringify(g));
const t0 = Date.now(), first = send({ id: 1, kind: 'sequence', geometry, flow: { speed: 15, density: 1.225, alphaDeg: 4 }, sequence: 'standard', options: {} }), t1 = Date.now();
const done1 = first.find(m => m.kind === 'complete');
ok(first.filter(m => m.kind === 'progress' && m.id === 1 && /^Mesh \d of 7/.test(m.text)).length === 7, 'one progress message per mesh of the sequence');
ok(done1 && done1.id === 1 && done1.result.kind === 'meshSequence' && done1.result.levels.length === 7, 'completion message with the seven solved meshes');
const direct = W.runSequence(g, { speed: 15, density: 1.225, alphaDeg: 4 }, 'standard');
ok(JSON.stringify(done1.result.levels.map(l => l.strips)) === JSON.stringify(direct.levels.map(l => l.strips)) && JSON.stringify(done1.result.weights) === JSON.stringify(direct.weights), 'worker levels and weights equal a direct call');
ok(done1.result.levels.every(l => !l.modelCacheHit) && done1.result.base.chordwise.length === done1.result.base.strips.length, 'first request: new solves; base-mesh chordwise Cp present');
const t2 = Date.now(), second = send({ id: 2, kind: 'sequence', geometry, flow: { speed: 20, density: 1.1, alphaDeg: 6 }, sequence: 'standard', options: {} }), t3 = Date.now();
const done2 = second.find(m => m.kind === 'complete');
ok(done2.result.levels.every(l => l.modelCacheHit), 'second request at a new angle and speed reuses all seven cached influence systems');
ok(JSON.stringify(done2.result.levels.map(l => l.strips)) === JSON.stringify(W.runSequence(g, { speed: 20, density: 1.1, alphaDeg: 6 }, 'standard').levels.map(l => l.strips)), 'cached result equals a fresh solve');
log(`Standard sequence: first request ${t1 - t0} ms (7 new influence systems), second ${t3 - t2} ms (cached)`);
ok(t3 - t2 < t1 - t0, 'cached request is faster');
const trim = send({ id: 3, kind: 'sequence', geometry, flow: { speed: 15 }, sequence: 'standard', options: { targetLift_N: 3.924 } }).find(m => m.kind === 'complete');
const liftExt = trim.result.weights.reduce((t, w) => t + w.weight * trim.result.levels.find(l => l.chordPanels === w.chordPanels && l.spanPanels === w.spanPanels).liftN, 0);
ok(Math.abs(liftExt - 3.924) < 1e-8 && trim.result.trim.alphaDeg > 0, `target-lift request: alpha ${trim.result.trim.alphaDeg.toFixed(4)} deg gives the extrapolated lift ${liftExt.toFixed(9)} N`);
const single = send({ id: 4, kind: 'solve', geometry, mesh: { chordPanels: 20, spanPanels: 12 }, flow: { speed: 15, alphaDeg: 4 }, options: {} }).find(m => m.kind === 'complete');
ok(Math.abs(single.result.coefficients.CL - W.solve(g, { speed: 15, alphaDeg: 4 }, { chordPanels: 20, spanPanels: 12 }).coefficients.CL) < 1e-14 && single.result.stripLoads.length === single.result.strips.length, 'single-mesh request equals a direct call and carries its six-component strip loads');
for (const [id, data, re] of [[5, { kind: 'sequence', geometry, flow: { speed: 150 }, sequence: 'standard' }, /Mach/], [6, { kind: 'sequence', geometry, flow: { betaDeg: 3 }, sequence: 'standard' }, /Sideslip/], [7, { kind: 'ping' }, /Unknown aerodynamic request/],
  [8, { kind: 'sequence', geometry: { ...geometry, planform: 'linear', tipChord: 0 }, flow: {}, sequence: 'standard' }, /zero tip chord/], [9, { kind: 'sequence', geometry, flow: {}, sequence: 'ultra' }, /Unknown mesh sequence/]]) {
  const reply = send({ id, ...data }).find(m => m.kind === 'error');
  ok(reply && reply.id === id && re.test(reply.text), `error reply ${re}`);
}
console.log(`test_wing_aero_worker: ${checks} checks passed`);
