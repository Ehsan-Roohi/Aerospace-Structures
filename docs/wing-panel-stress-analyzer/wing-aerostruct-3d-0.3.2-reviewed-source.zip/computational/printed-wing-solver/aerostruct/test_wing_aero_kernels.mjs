// Panel influence kernels of wing_aero_panel.js against independent references: brute-force
// recursive Gauss quadrature of the defining integrals, polar in-plane integration, the Gauss
// solid-angle closure of a watertight body, the R -> infinity limit of a long wake strip, the
// mirror-image identity used for the symmetric half-wing, and the far-field approximation error.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { bruteQuad, inPlaneSource, ellipsoidMesh } from './aero_test_support.mjs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js');
let checks = 0;
const near = (a, b, tol, label) => { assert.ok(Number.isFinite(a) && Math.abs(a - b) <= tol, `${label}: ${a} vs ${b} (tol ${tol})`); checks++; };
const log = (...a) => console.log('  ', ...a);

// 1. Planar trapezoid and a non-planar (twisted) quad versus brute-force quadrature.
const flat = [[0, 0, 0], [2, 0, 0], [2, 1, 0], [0, 1.5, 0]];
const warped = [[0, 0, 0], [2, 0, 0.12], [2.1, 1.2, 0], [0, 1.4, -0.1]];
for (const [name, v] of [['planar trapezoid', flat], ['warped quad', warped]]) {
  const S = W.buildSurface(Float64Array.from(v.flat().concat([9, 9, 9, 10, 9, 9, 10, 10, 9, 9, 10, 9])), Int32Array.from([0, 1, 2, 3, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7]));
  let worstS = 0, worstD = 0;
  for (const P of [[1, .6, .8], [1, .6, -.3], [3, 2, .5], [-1, -1, .1], [10, 4, 3], [.5, .4, .05], [1.9, 0.1, 0.02], [1, 0.7, -0.02]]) {
    const r = W.influence(S, 0, P), b = bruteQuad(v, P, 2);
    // the doublet uses the true edges (exact for any surface spanning them); the source of a warped
    // panel is integrated over its flattened mean-plane projection, so compare the source only when planar
    worstD = Math.max(worstD, Math.abs(r.doublet - b.doublet));
    if (name === 'planar trapezoid') worstS = Math.max(worstS, Math.abs(r.source - b.source));
  }
  log(`${name}: max |source - quadrature| = ${worstS.toExponential(2)}, max |doublet - quadrature| = ${worstD.toExponential(2)}`);
  near(worstD, 0, 1e-9, `${name} doublet vs quadrature`);
  if (name === 'planar trapezoid') near(worstS, 0, 1e-9, 'source vs quadrature');
}
// Warped quad doublet: the bilinear surface and the two-triangle surface share the same boundary,
// so their potentials must agree away from the surface (Stokes); check one far-off-surface point tightly.
{
  const S = W.buildSurface(Float64Array.from(warped.flat().concat([9, 9, 9, 10, 9, 9, 10, 10, 9, 9, 10, 9])), Int32Array.from([0, 1, 2, 3, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7]));
  const P = [0.7, 0.5, 1.3], r = W.influence(S, 0, P), b = bruteQuad(warped, P, 3);
  log(`warped quad doublet off-surface: ${r.doublet.toFixed(10)} vs quadrature ${b.doublet.toFixed(10)}`);
  near(r.doublet, b.doublet, 2e-8, 'warped doublet depends only on the edges');
}
// 2. Self-induced source at the centroid (the matrix diagonal) versus polar integration.
{
  const S = W.buildSurface(Float64Array.from(flat.flat().concat([9, 9, 9, 10, 9, 9, 10, 10, 9, 9, 10, 9])), Int32Array.from([0, 1, 2, 3, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7]));
  const ref = inPlaneSource(flat.map(p => [p[0], p[1]]), [S.PC[0], S.PC[1]]);
  log(`self source: kernel ${S.SELF[0].toFixed(12)}, polar quadrature ${ref.toFixed(12)}`);
  near(S.SELF[0], ref, 1e-12, 'self source');
  near(W.influence(S, 0, [S.PC[0], S.PC[1], 1e-9]).doublet, 0.5, 1e-7, 'doublet just outside -> +1/2');
  near(W.influence(S, 0, [S.PC[0], S.PC[1], -1e-9]).doublet, -0.5, 1e-7, 'doublet just inside -> -1/2');
}
// 3. Gauss closure on a watertight body (UV sphere, planar quads and pole triangles): the doublet
// solid angles of all panels sum to -1 inside, 0 outside, and -1/2 + others at a centroid.
{
  const m = ellipsoidMesh(1, 1, 1, 24, 12), S = W.buildSurface(m.nodes, m.quads);
  const total = (P, skip = -1) => { let s = 0; for (let k = 0; k < S.count; k++) if (k !== skip) s += W.influence(S, k, P).doublet; return s; };
  near(total([0.1, -0.2, 0.3]), -1, 1e-12, 'closure inside'); near(total([1.7, 0.4, -0.9]), 0, 1e-12, 'closure outside');
  let worst = 0; for (const i of [0, 50, 137, 200, 287]) worst = Math.max(worst, Math.abs(total([S.PC[3 * i], S.PC[3 * i + 1], S.PC[3 * i + 2]], i) - 0.5 + 1));
  log(`closure at panel centroids (sum of others + self -1/2 = -1): worst error ${worst.toExponential(2)}`);
  near(worst, 0, 1e-12, 'closure at centroids');
}
// 4. Semi-infinite wake triangle equals the limit of a long finite one.
{
  const a = [0.3, 0.2, 0.05], b = [0.35, 0.9, 0.07], u = [1, 0, 0];
  for (const P of [[0.5, 0.5, 0.2], [-1, 0.4, -0.3], [3, 0.6, 0.01], [0.2, -0.5, 0.4]]) {
    const R = 1e7, far = [a[0] + R * u[0], a[1] + R * u[1], a[2] + R * u[2]];
    const finite = W.triAngle(...P, ...a, ...far, ...b), limit = W.semiInfiniteAngle(...P, ...a, ...u, ...b);
    near(limit, finite, 1e-6, 'semi-infinite limit');
  }
}
// 5. Mirror identity used for the half-wing image: panel reflected in y with reversed order at P
// equals the original panel at the reflected point (doublet and source).
{
  const v = [[0.2, 0.3, 0.05], [0.9, 0.35, 0.02], [0.95, 0.8, -0.03], [0.25, 0.75, 0.01]];
  const mir = [v[3], v[2], v[1], v[0]].map(p => [p[0], -p[1], p[2]]);
  const S = W.buildSurface(Float64Array.from(v.flat().concat(mir.flat())), Int32Array.from([0, 1, 2, 3, 4, 5, 6, 7, 0, 1, 2, 3, 4, 5, 6, 7]));
  for (const P of [[0.5, 0.2, 0.3], [0.1, -0.4, -0.2], [2, 1, 1]]) {
    const img = W.influence(S, 1, P), ref = W.influence(S, 0, [P[0], -P[1], P[2]]);
    near(img.doublet, ref.doublet, 1e-14, 'mirror doublet'); near(img.source, ref.source, 1e-14, 'mirror source');
  }
}
// 6. Far-field (point source/doublet) approximation used beyond 6 panel diameters.
{
  const S = W.buildSurface(Float64Array.from(flat.flat().concat([9, 9, 9, 10, 9, 9, 10, 10, 9, 9, 10, 9])), Int32Array.from([0, 1, 2, 3, 4, 5, 6, 7, 4, 5, 6, 7, 4, 5, 6, 7]));
  let worst = 0;
  for (const dir of [[1, 0, 0], [0.3, 0.4, 0.866], [0, 0, 1], [-0.7, 0.7, 0.1]]) {
    const r = 6.01 * S.PD[0], P = [S.PC[0] + r * dir[0], S.PC[1] + r * dir[1], S.PC[2] + r * dir[2]];
    const exact = W.influence(S, 0, P), approx = W.influence(S, 0, P, 6);
    worst = Math.max(worst, Math.abs(approx.source - exact.source) / exact.source);
  }
  log(`far-field source approximation at 6 diameters: worst relative error ${worst.toExponential(2)}`);
  near(worst, 0, 2e-3, 'far-field source error');
}
console.log(`test_wing_aero_kernels: ${checks} checks passed`);
