// Span-quadratic doublet (0.3.2-exp.2 model, kept as doubletModel 'span-quadratic'): kernel, basis and consistency tests
// (focused; NOT a physics gate). The default model is now 'tensor-quadratic' (test_wing_aero_tensor_doublet.mjs).
//   1. panel doublet (C1-spline quadratic in y) and source potentials on the panel's triangles (shorter-diagonal split,
//      four-triangle fan on a warped tie) against an independent reference: polar coordinates about the projection of
//      the field point, radial integral in closed form, angle by adaptive Gauss-Kronrod (no solid angle, no edge
//      logarithm); warped rounded-tip panels and closed-tip triangles included; the source self term at the centroid;
//   2. semi-infinite strip with quadratic spanwise strength against an independent reference (streamwise integral in
//      closed form, spanwise adaptive Gauss-Kronrod);
//   3. equal values reproduce the 0.3.1 constant-doublet panel and strip; jump across the panel = local doublet value;
//   4. far-field expansion error falls as (d/r)^2;
//   5. spline basis: C1 and end conditions hold, constants reproduced, the two surfaces share the tip knot (trailing-
//      edge jump exactly 0 at a rounded or closed tip, for any doublets);
//   6. the panel matrix and the field evaluation are the same function; the solution satisfies the interior condition;
//   7. trailing-edge matching: wake strength = upper minus lower surface doublet trace POINTWISE along the edge;
//   8. mirror image equals an explicit full span (cyclic chains through both tips) with the same doublet model;
//   9. up/down symmetry: a symmetric section at zero incidence carries no lift; strip loads reproduce the resultant;
//  10. Trefftz lift is the exact integral of the solved quadratic wake; drag converged in its sub-division;
//  11. doubletModel 'constant' reproduces published 0.3.1 bit for bit (when SOLVER031 points to it).
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const t0 = Date.now();
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, s) => a.map(v => v * s);
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => Math.hypot(...a), unit = a => mul(a, 1 / norm(a));
const SWEPT = { naca: '2412', semiSpan: 300, rootChord: 140, tipChord: 80, sweepDeg: 15, dihedralDeg: 6, sweepReferenceFraction: 0.25 };
const ELLIPTIC = { naca: '0012', planform: 'elliptic', semiSpan: 400, rootChord: 150, tipChord: 0 };
let seed = 12345; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const xk = [0.991455371120813, 0.949107912342759, 0.864864423359769, 0.741531185599394, 0.586087235467691, 0.405845151377397, 0.207784955007898, 0];
const wk = [0.022935322010529, 0.063092092629979, 0.104790010322250, 0.140653259715525, 0.169004726639267, 0.190350578064785, 0.204432940075298, 0.209482141084728];
const wg = [0, 0.129484966168870, 0, 0.279705391489277, 0, 0.381830050505119, 0, 0.417959183673469];
const gk = (f, a, b) => { const c = 0.5 * (a + b), h = 0.5 * (b - a); let K = 0, G = 0; for (let i = 0; i < 8; i++) { if (i < 7) { const f1 = f(c - h * xk[i]), f2 = f(c + h * xk[i]); K += wk[i] * (f1 + f2); G += wg[i] * (f1 + f2); } else { const f0 = f(c); K += wk[i] * f0; G += wg[i] * f0; } } return [K * h, G * h]; };
const integ = (f, a, b, tol, d = 0) => { const [K, G] = gk(f, a, b); if (Math.abs(K - G) <= tol || d > 48) return K; const c = 0.5 * (a + b); return integ(f, a, c, tol, d + 1) + integ(f, c, b, tol, d + 1); };

// ---------------------------------------------------------------- 1. panel kernel vs independent reference
// phi = (1/4 pi) int Q(y(X)) (P - X).n / |P - X|^3 dA over each fan triangle; Q = q0 + q1 (y - y0) + q2 (y - y0)^2.
function triRef(Q3, q, y0, P, source = false) {
  const N = cross(sub(Q3[1], Q3[0]), sub(Q3[2], Q3[0])), A2 = norm(N); if (!(A2 > 1e-12)) return 0;
  const n = N.map(v => v / A2), h = dot(sub(P, Q3[0]), n), Ph = P.map((v, i) => v - h * n[i]), e1 = unit(sub(Q3[1], Q3[0])), e2 = cross(n, e1);
  const yh = Ph[1] - y0, gy = [e1[1], e2[1]], ah = Math.abs(h); let total = 0;
  for (let i = 0; i < 3; i++) { // signed sub-triangles (P^, Q_i, Q_i+1), polar about P^
    const A = sub(Q3[i], Ph), B = sub(Q3[(i + 1) % 3], Ph), a2 = [dot(A, e1), dot(A, e2)], b2 = [dot(B, e1), dot(B, e2)], cr = a2[0] * b2[1] - a2[1] * b2[0];
    if (Math.abs(cr) < 1e-14 * (norm(A) + norm(B)) ** 2) continue;
    const thA = Math.atan2(a2[1], a2[0]); let dth = Math.atan2(b2[1], b2[0]) - thA; while (dth > Math.PI) dth -= 2 * Math.PI; while (dth < -Math.PI) dth += 2 * Math.PI;
    const ex = b2[0] - a2[0], ey = b2[1] - a2[1];
    const f = th => { // radial integrals int_0^R (a + b rho + c rho^2) h rho / (rho^2 + h^2)^(3/2) d rho in closed form
      const ct = Math.cos(th), st = Math.sin(th), R = cr / (ct * ey - st * ex), g = ct * gy[0] + st * gy[1];
      const w = Math.sqrt(R * R + h * h);
      if (source) return w - ah; // int_0^R rho / sqrt(rho^2 + h^2) d rho
      const a = q[0] + q[1] * yh + q[2] * yh * yh, b = (q[1] + 2 * q[2] * yh) * g, c = q[2] * g * g;
      return a * (Math.sign(h) - h / w) + b * h * (-R / w + Math.log((R + w) / ah)) + c * h * (w + h * h / w - 2 * ah);
    };
    total += integ(f, thA, thA + dth, 1e-15 * Math.abs(dth) * 10);
  }
  return total / (4 * Math.PI);
}
const corners = (S, k) => [0, 1, 2, 3].map(q => [S.PV[12 * k + 3 * q], S.PV[12 * k + 3 * q + 1], S.PV[12 * k + 3 * q + 2]]);
// the documented triangulation: two triangles along the shorter diagonal, the fan about the vertex mean on a warped tie
function panelTriangles(S, k) {
  const v = corners(S, k), M = [0, 1, 2].map(c => 0.25 * (v[0][c] + v[1][c] + v[2][c] + v[3][c])), d02 = norm(sub(v[2], v[0])), d13 = norm(sub(v[3], v[1]));
  const tie = Math.abs(d02 - d13) <= 1e-9 * Math.max(d02, d13);
  if (tie && S.PW[k] > 1e-12 * S.PD[k]) return [[M, v[0], v[1]], [M, v[1], v[2]], [M, v[2], v[3]], [M, v[3], v[0]]];
  return !tie && d13 < d02 ? [[v[1], v[2], v[3]], [v[1], v[3], v[0]]] : [[v[0], v[1], v[2]], [v[0], v[2], v[3]]];
}
// the source with each triangle's own normal (the right-hand side of the triangulated surface): sum_T S_T n_T
function panelRefVec(S, k, P) {
  const v = corners(S, k), ym = 0.5 * (v[0][1] + v[3][1]);
  return panelTriangles(S, k).reduce((r, T) => { const N = cross(sub(T[1], T[0]), sub(T[2], T[0])), A2 = norm(N); return A2 > 1e-12 ? add(r, mul(N, triRef(T, [0, 0, 0], ym, P, true) / A2)) : r; }, [0, 0, 0]);
}
function panelRef(S, k, vals, P, source = false) {
  const v = corners(S, k), yL = v[0][1], yR = v[3][1], dY = yR - yL, ym = 0.5 * (yL + yR);
  const q = [vals[1], (vals[2] - vals[0]) / dY, 2 * (vals[0] - 2 * vals[1] + vals[2]) / (dY * dY)];
  return panelTriangles(S, k).reduce((r, T) => r + triRef(T, q, ym, P, source), 0);
}
{
  let worst = 0, worstS = 0, worstSelf = 0, maxFlat = 0, worstV = 0, worstSelfV = 0; const byH = {};
  for (const [geo, label] of [[SWEPT, 'swept/dihedral rounded tip'], [ELLIPTIC, 'elliptic closed tip']]) {
    const wm = W.wingMesh(W.aeroGeometry(geo), { chordPanels: 10, spanPanels: 6, doubletModel: 'span-quadratic' }), S = wm.S, B = wm.body;
    for (let c = 0; c < 72; c++) {
      const k = c % 3 === 0 ? wm.index(Math.floor(rnd() * wm.ni), wm.ns - 1) : Math.floor(rnd() * wm.wingPanels); // a third on the tip strip
      const C = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]], d = S.PD[k], nrm = [S.PN[3 * k], S.PN[3 * k + 1], S.PN[3 * k + 2]];
      const hr = [1, 0.3, 0.05, 0.01, 1e-3, 1e-5][c % 6], P = [0, 1, 2].map(i => C[i] + (rnd() - 0.5) * 1.5 * d + nrm[i] * hr * d * (rnd() < 0.5 ? -1 : 1));
      const vals = [rnd() * 2 - 1, rnd() * 2 - 1, rnd() * 2 - 1], ref = panelRef(S, k, vals, P), a = W.spanQuadPanel(B, S, k, P);
      const err = Math.abs(a.left * vals[0] + a.mid * vals[1] + a.right * vals[2] - ref) / (Math.abs(vals[0]) + Math.abs(vals[1]) + Math.abs(vals[2]));
      worst = Math.max(worst, err); byH[hr] = Math.max(byH[hr] || 0, err);
      const sref = panelRef(S, k, [0, 0, 0], P, true); worstS = Math.max(worstS, Math.abs(a.source - sref) / Math.abs(sref));
      maxFlat = Math.max(maxFlat, Math.abs(a.source - W.influence(S, k, P).source) / Math.abs(sref));
      const vref = panelRefVec(S, k, P); worstV = Math.max(worstV, norm(sub(a.sourceVector, vref)) / Math.abs(sref));
    }
    for (let c = 0; c < 40; c++) { const k = Math.floor(rnd() * wm.wingPanels), C = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]], sref = panelRef(S, k, [0, 0, 0], C, true); worstSelf = Math.max(worstSelf, Math.abs(B.selfSource[k] - sref) / sref); const vref = panelRefVec(S, k, C); worstSelfV = Math.max(worstSelfV, norm(sub([B.selfSourceVec[3 * k], B.selfSourceVec[3 * k + 1], B.selfSourceVec[3 * k + 2]], vref)) / sref); }
  }
  log(`span-quadratic panel vs independent polar reference (144 panel/point pairs, swept/dihedral rounded tip and elliptic closed tip, a third on the tip strip): doublet max |error|/sum|values| ${worst.toExponential(2)}; by height/d ${Object.entries(byH).map(([h, e]) => h + ': ' + e.toExponential(1)).join(', ')}`);
  log(`source over the same triangles vs the reference: max relative error ${worstS.toExponential(2)}; self term at the centroid ${worstSelf.toExponential(2)}; (difference from the 0.3.1 flattened-quadrilateral source at the same points: up to ${(100 * maxFlat).toFixed(2)} %, largest on warped tip panels)`);
  ok(worst < 1e-12, 'span-quadratic panel doublet potential matches the defining integral');
  ok(worstS < 1e-12 && worstSelf < 1e-12, 'panel source potential (and its self term) matches the defining integral over the same triangles');
  log(`source with each triangle's own normal (sum_T S_T n_T, the right-hand side) vs the reference: max |error|/|S| ${worstV.toExponential(2)}; self term ${worstSelfV.toExponential(2)}`);
  ok(worstV < 1e-12 && worstSelfV < 1e-12, 'per-triangle-normal source vector (and its self term) matches the defining integrals');
}
// ---------------------------------------------------------------- 2. quadratic strip vs independent reference
function stripRef(P, A, u, B, mA, mM, mB) { // Q = A + s e + t u; the t-integral is h (1 + D.u/|D|)/|D x u|^2
  const l = norm(sub(B, A)), e = unit(sub(B, A)), uxe = cross(u, e), n = unit(uxe), sn = norm(uxe), h = dot(sub(P, A), n);
  const mu = s => { const t = s / l; return mA * (1 - t) * (1 - 2 * t) + 4 * mM * t * (1 - t) + mB * t * (2 * t - 1); };
  const f = s => { const D = sub(sub(P, A), mul(e, s)), c = cross(D, u); return mu(s) * h * (1 + dot(D, u) / norm(D)) / dot(c, c); };
  const sp = Math.min(l, Math.max(0, dot(sub(P, A), mul(sub(e, mul(u, dot(e, u))), 1 / (1 - dot(e, u) ** 2)))));
  let peak = 0; for (let q = 0; q <= 64; q++) peak = Math.max(peak, Math.abs(f(q / 64 * l))); peak = Math.max(peak, Math.abs(f(sp)));
  const tol = 1e-16 * peak * l;
  return sn * ((sp > 0 ? integ(f, 0, sp, tol) : 0) + (sp < l ? integ(f, sp, l, tol) : 0)) / (4 * Math.PI);
}
{
  let worst = 0, worstC = 0;
  for (let c = 0; c < 300; c++) {
    const A = [rnd() * 2 - 1, rnd() * 2 - 1, rnd() * 2 - 1], B = add(A, [rnd() - 0.5, 0.5 + rnd(), rnd() - 0.5]), u = unit([1, 0, (rnd() - 0.5) * 0.6]);
    const l = norm(sub(B, A)), n = unit(cross(u, unit(sub(B, A)))), hgt = [2, 0.3, 1e-2, 1e-3, 1e-4][c % 5] * l * (rnd() < 0.5 ? -1 : 1);
    const P = add(add(add(A, mul(sub(B, A), rnd() * 1.4 - 0.2)), mul(u, (rnd() * 3 - 0.5) * l)), mul(n, hgt)), m3 = [rnd() * 4 - 2, rnd() * 4 - 2, rnd() * 4 - 2];
    const k = W.quadStrip(P, A, u, B);
    worst = Math.max(worst, Math.abs(k[0] * m3[0] + k[1] * m3[1] + k[2] * m3[2] - stripRef(P, A, u, B, ...m3)) / (Math.abs(m3[0]) + Math.abs(m3[1]) + Math.abs(m3[2])));
    worstC = Math.max(worstC, Math.abs(k[0] + k[1] + k[2] - W.semiInfiniteAngle(...P, ...A, ...u, ...B) / (4 * Math.PI)));
  }
  log(`quadratic wake strip vs independent reference (300 oblique strips, heights 2 l .. 1e-4 l): max error ${worst.toExponential(2)}; equal values vs the 0.3.1 strip ${worstC.toExponential(2)}`);
  ok(worst < 1e-11, 'quadratic-strength semi-infinite strip matches the defining integral');
  ok(worstC < 1e-15, 'equal values reproduce the 0.3.1 constant-strength wake strip');
}
// ---------------------------------------------------------------- 3. constant limit, jump; 4. far field
{
  const wm = W.wingMesh(W.aeroGeometry(SWEPT), { chordPanels: 10, spanPanels: 6, doubletModel: 'span-quadratic' }), S = wm.S, B = wm.body;
  let worstD = 0, worstS = 0;
  for (let c = 0; c < 3000; c++) {
    const k = Math.floor(rnd() * wm.wingPanels), C = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]], d = S.PD[k], P = C.map(x => x + (rnd() - 0.5) * 4 * d);
    const a = W.spanQuadPanel(B, S, k, P), b = W.influence(S, k, P);
    worstD = Math.max(worstD, Math.abs(a.left + a.mid + a.right - b.doublet)); worstS = Math.max(worstS, Math.abs(a.source - b.source));
  }
  log(`equal values vs the 0.3.1 constant-doublet solid angle: max difference ${worstD.toExponential(2)}`);
  ok(worstD < 1e-13, 'equal values reproduce the constant-strength doublet panel');
  const k = wm.index(3, 0), v = corners(S, k), T = panelTriangles(S, k)[0];
  const Ph = [0, 1, 2].map(i => 0.4 * T[0][i] + 0.35 * T[1][i] + 0.25 * T[2][i]), nn = unit(cross(sub(T[1], T[0]), sub(T[2], T[0]))), vals = [2, 5, -1];
  const yL = v[0][1], yR = v[3][1], t = (Ph[1] - yL) / (yR - yL), local = vals[0] * (1 - t) * (1 - 2 * t) + 4 * vals[1] * t * (1 - t) + vals[2] * t * (2 * t - 1);
  const phi = P => { const a = W.spanQuadPanel(B, S, k, P); return a.left * vals[0] + a.mid * vals[1] + a.right * vals[2]; };
  const jumps = [1e-4, 1e-7].map(e => phi(Ph.map((x, i) => x + e * nn[i])) - phi(Ph.map((x, i) => x - e * nn[i])));
  log(`jump across the panel at an interior point: ${jumps.map(j => j.toFixed(9)).join(', ')} vs the local quadratic value ${local.toFixed(9)}`);
  ok(Math.abs(jumps[1] - local) < 1e-6, 'potential jump across the panel equals the local doublet value');
  const errAt = R => { let w = 0; for (let c = 0; c < 400; c++) { const k2 = Math.floor(rnd() * wm.wingPanels), C = [S.PC[3 * k2], S.PC[3 * k2 + 1], S.PC[3 * k2 + 2]], d = S.PD[k2], dir = unit([rnd() - 0.5, rnd() - 0.5, rnd() - 0.5]), P = C.map((x, i) => x + dir[i] * R * d); const a = W.spanQuadPanel(B, S, k2, P), f = W.spanQuadPanel(B, S, k2, P, 1); for (const q of ['left', 'mid', 'right']) w = Math.max(w, Math.abs(a[q] - f[q]) / (S.PA[k2] / (4 * Math.PI * (R * d) ** 2))); } return w; };
  const e6 = errAt(6), e12 = errAt(12), e24 = errAt(24);
  log(`far-field expansion (zeroth + first moments) vs exact, max error / (A / 4 pi r^2): r = 6 d: ${e6.toExponential(2)}, 12 d: ${e12.toExponential(2)}, 24 d: ${e24.toExponential(2)}`);
  ok(e6 < 5e-3 && e12 < e6 / 3 && e24 < e12 / 3, 'far-field error small at the 0.3.1 threshold and falling as (d/r)^2');
}
// ---------------------------------------------------------------- 5. spline basis
{
  for (const [geo, mesh, label] of [[SWEPT, { chordPanels: 10, spanPanels: 6 }, 'rounded'], [SWEPT, { chordPanels: 10, spanPanels: 6, tipClosure: 'flat' }, 'flat cap'], [ELLIPTIC, { chordPanels: 12, spanPanels: 8 }, 'closed']]) {
    const wm = W.wingMesh(W.aeroGeometry(geo), { ...mesh, doubletModel: 'span-quadratic' }), B = wm.body, n = wm.S.count, mu = Float64Array.from({ length: n }, () => rnd() * 2 - 1), e = W.knotValues(B, mu);
    let res = 0, cst = 0;
    const ones = W.knotValues(B, new Float64Array(n).fill(1.7)); for (let q = 0; q < B.knotCount; q++) cst = Math.max(cst, Math.abs(ones[q] - 1.7));
    for (const ch of B.chains) { // C1 at interior knots, slope / curvature conditions at the ends, residual of each equation
      const N = ch.cells.length, h = ch.h, E = k => e[ch.knots[k]], m = k => mu[ch.cells[k]];
      const sl0 = k => (-3 * E(k) + 4 * m(k) - E(k + 1)) / h[k], sl1 = k => (E(k) - 4 * m(k) + 3 * E(k + 1)) / h[k], scale = Math.max(...Array.from(ch.cells, c => Math.abs(mu[c]))) / Math.min(...h);
      for (let k = 1; k < N; k++) res = Math.max(res, Math.abs(sl1(k - 1) - sl0(k)) / scale);
      res = Math.max(res, Math.abs(sl0(0)) / scale);
      res = Math.max(res, (ch.end === 'natural' ? Math.abs(E(N - 1) - 2 * m(N - 1) + E(N)) / h[N - 1] : Math.abs(sl1(N - 1))) / scale);
    }
    ok(res < 1e-13 && cst < 1e-14, `${label}: knot values satisfy C1, zero root slope and the tip condition (residual ${res.toExponential(1)}); constants reproduced`);
    const ws = W.wakeStrengths(wm.wake, mu, B);
    if (label !== 'flat cap') ok(ws.atB[wm.ns - 1] === 0, `${label} tip: wake strength exactly zero at the tip for ANY doublets (the two trailing-edge rows share the tip knot)`);
    else log(`flat cap (diagnostic option, rows end at the cap): wake strength at the tip for random doublets ${ws.atB[wm.ns - 1].toFixed(4)}`);
  }
}
// ---------------------------------------------------------------- 6. matrix row = field evaluation
{
  const wm = W.wingMesh(W.aeroGeometry(SWEPT), { chordPanels: 10, spanPanels: 6, doubletModel: 'span-quadratic' }), S = wm.S, n = S.count;
  const sys = W.assemble(S, { image: true, wake: wm.wake, body: wm.body, farField: 6 }), mu = Float64Array.from({ length: n }, (_, k) => Math.sin(0.37 * k) + 0.2 * Math.cos(1.3 * k));
  let worst = 0, scale = 0;
  for (const i of [0, 7, Math.floor(n / 2), n - 3, n - 1]) {
    let row = 0; for (let k = 0; k < n; k++) row += sys.A[i * n + k] * mu[k];
    const f = W.fieldPotential(S, wm.body, wm.wake, [S.PC[3 * i], S.PC[3 * i + 1], S.PC[3 * i + 2]], mu, [0, 0, 1], { self: i, farField: 6 });
    worst = Math.max(worst, Math.abs(row + sys.bz[i] - f)); scale = Math.max(scale, Math.abs(row));
  }
  log(`matrix row x mu + source term vs fieldPotential at control points: max difference ${worst.toExponential(2)} (scale ${scale.toExponential(2)})`);
  ok(worst <= 1e-13 * Math.max(1, scale), 'panel matrix and field evaluation are the same function');
  const sol = W.unitSolutions(S, { image: true, wake: wm.wake, body: wm.body, farField: 6, solver: 'lu' });
  let res = 0, mx = 0;
  for (let i = 0; i < n; i += 7) { res = Math.max(res, Math.abs(W.fieldPotential(S, wm.body, wm.wake, [S.PC[3 * i], S.PC[3 * i + 1], S.PC[3 * i + 2]], sol.muz, [0, 0, 1], { self: i, farField: 6 }))); mx = Math.max(mx, Math.abs(sol.muz[i])); }
  log(`solved doublets: interior potential at control points re-evaluated by fieldPotential: max ${res.toExponential(2)} (doublet scale ${mx.toExponential(2)})`);
  ok(res < 1e-10 * mx, 'the solution satisfies the interior Dirichlet condition with the field evaluation');
}
// ---------------------------------------------------------------- 7. pointwise trailing-edge matching
{
  const wm = W.wingMesh(W.aeroGeometry(SWEPT), { chordPanels: 10, spanPanels: 6, doubletModel: 'span-quadratic' }), S = wm.S, B = wm.body, n = S.count;
  const mu = Float64Array.from({ length: n }, () => rnd() * 2 - 1), ws = W.wakeStrengths(wm.wake, mu, B), e = W.knotValues(B, mu);
  const Qt = (a, m, b, t) => a * (1 - t) * (1 - 2 * t) + 4 * m * t * (1 - t) + b * t * (2 * t - 1);
  let worst = 0;
  for (let j = 0; j < wm.ns; j++) {
    const up = wm.index(wm.ni - 1, j), lo = wm.index(0, j);
    for (const t of [0, 0.13, 0.5, 0.71, 1]) {
      const trace = k => Qt(e[B.kL[k]], mu[k], e[B.kR[k]], t);
      worst = Math.max(worst, Math.abs(trace(up) - trace(lo) - Qt(ws.atA[j], ws.gamma[j], ws.atB[j], t)));
    }
  }
  log(`trailing-edge matching: max |mu_upper - mu_lower - mu_wake| at 5 points per strip (random doublets): ${worst.toExponential(2)}`);
  ok(worst < 1e-13, 'the wake strength equals the jump of the two surface traces pointwise along the trailing edge (no TE line vortex)');
}
// ---------------------------------------------------------------- 8. mirror image vs explicit full span
{
  const wm = W.wingMesh(W.aeroGeometry(SWEPT), { chordPanels: 10, spanPanels: 6, doubletModel: 'span-quadratic' }), S = wm.S, n = S.count, w = wm.wake, m = w.count, ni = wm.ni, ns = wm.ns, ys = wm.ys;
  const half = W.unitSolutions(S, { image: true, wake: w, body: wm.body, farField: Infinity, solver: 'lu' });
  const nodes = S.nodes, nn = nodes.length / 3, full = new Float64Array(2 * nodes.length);
  full.set(nodes); for (let i = 0; i < nn; i++) { full[3 * (nn + i)] = nodes[3 * i]; full[3 * (nn + i) + 1] = -nodes[3 * i + 1]; full[3 * (nn + i) + 2] = nodes[3 * i + 2]; }
  const quads = new Int32Array(8 * n); quads.set(S.quads); for (let k = 0; k < n; k++) for (let q = 0; q < 4; q++) quads[4 * (n + k) + q] = nn + S.quads[4 * k + 3 - q];
  const SF = W.buildSurface(full, quads), kL = new Int32Array(2 * n), kR = new Int32Array(2 * n), chains = [];
  let knots = 0;
  for (let i = 0; i < ni / 2; i++) { // cyclic chain: right upper (root->tip), right lower (tip->root), left lower (root->tip), left upper (tip->root)
    const up = ni - 1 - i, cells = [], h = [];
    for (let j = 0; j < ns; j++) { const k = wm.index(up, j); cells.push(k); h.push(ys[j + 1] - ys[j]); kL[k] = knots + j; kR[k] = knots + j + 1; }
    for (let j = ns - 1; j >= 0; j--) { const k = wm.index(i, j); cells.push(k); h.push(ys[j + 1] - ys[j]); kR[k] = knots + 2 * ns - j - 1; kL[k] = knots + 2 * ns - j; }
    for (let j = 0; j < ns; j++) { const k = n + wm.index(i, j); cells.push(k); h.push(ys[j + 1] - ys[j]); kR[k] = knots + 2 * ns + j; kL[k] = knots + 2 * ns + j + 1; }
    for (let j = ns - 1; j >= 0; j--) { const k = n + wm.index(up, j); cells.push(k); h.push(ys[j + 1] - ys[j]); kL[k] = knots + 4 * ns - 1 - j; kR[k] = knots + (4 * ns - j) % (4 * ns); }
    chains.push({ cells: Int32Array.from(cells), h: Float64Array.from(h), knots: Int32Array.from({ length: 4 * ns }, (_, q) => knots + q), cyclic: true });
    knots += 4 * ns;
  }
  const BF = W.spanQuadBasis(SF, kL, kR, chains, knots);
  const fw = { count: 2 * m, a: new Float64Array(6 * m), b: new Float64Array(6 * m), dir: w.dir, kuttaWidth: w.kuttaWidth, kuttaPanels: new Int32Array(2 * m * w.kuttaWidth), kuttaWeights: new Float64Array(2 * m * w.kuttaWidth) };
  fw.a.set(w.a); fw.b.set(w.b); fw.kuttaPanels.set(w.kuttaPanels); fw.kuttaWeights.set(w.kuttaWeights);
  for (let j = 0; j < m; j++) {
    for (const [dst, src] of [[fw.a, w.b], [fw.b, w.a]]) { dst[3 * (m + j)] = src[3 * j]; dst[3 * (m + j) + 1] = -src[3 * j + 1]; dst[3 * (m + j) + 2] = src[3 * j + 2]; }
    for (let q = 0; q < w.kuttaWidth; q++) { fw.kuttaPanels[(m + j) * w.kuttaWidth + q] = n + w.kuttaPanels[j * w.kuttaWidth + q]; fw.kuttaWeights[(m + j) * w.kuttaWidth + q] = w.kuttaWeights[j * w.kuttaWidth + q]; }
  }
  fw.basis = W.spanQuadWake(fw, BF, SF);
  const fs = W.unitSolutions(SF, { image: false, wake: fw, body: BF, farField: Infinity, solver: 'lu' });
  let d = 0, s = 0; for (let k = 0; k < n; k++) { d = Math.max(d, Math.abs(fs.muz[k] - half.muz[k]), Math.abs(fs.mux[k] - half.mux[k]), Math.abs(fs.muz[n + k] - half.muz[k])); s = Math.max(s, Math.abs(half.muz[k])); }
  log(`span-quadratic: image half-wing (clamped root) vs explicit full span (cyclic chains through both tips; sweep 15, dihedral 6, taper): max doublet difference ${(d / s).toExponential(2)} (relative)`);
  ok(d / s < 1e-10, 'mirror image with zero root slope equals the explicit full span with the same doublet model');
}
// ---------------------------------------------------------------- 9. symmetry, load transfer; 10. Trefftz
{
  const sym = W.solve({ naca: '0012', semiSpan: 500, rootChord: 120, tipChord: 70, sweepDeg: 20, dihedralDeg: 0 }, { alphaDeg: 0, speed: 10 }, { chordPanels: 16, spanPanels: 10 }, { doubletModel: 'span-quadratic' });
  ok(Math.abs(sym.coefficients.CL) < 1e-10, `symmetric section at zero incidence carries no lift (CL ${sym.coefficients.CL.toExponential(1)})`);
  const m = W.prepare({ naca: '2412', semiSpan: 450, rootChord: 160, tipChord: 100, sweepDeg: 10, dihedralDeg: 5 }, { chordPanels: 16, spanPanels: 12 }, { doubletModel: 'span-quadratic' }), r = W.evaluate(m, { alphaDeg: 4, speed: 15 });
  const ws = r.diagnostics.wake, w = m.wm.wake; let L = 0;
  for (let j = 0; j < w.count; j++) L += (w.b[3 * j + 1] - w.a[3 * j + 1]) * (ws.strengthAtInnerEdge[j] + 4 * ws.stripStrength[j] + ws.strengthAtOuterEdge[j]) / 6;
  const CLt = 2 * (2 * L / 15) / r.reference.area_mm2;
  ok(Math.abs(CLt - r.coefficients.CLTrefftz) < 1e-12 * Math.abs(CLt), `Trefftz lift = exact integral of the solved quadratic wake (${CLt.toFixed(8)})`);
  const sv = { gamma: ws.stripStrength.map(v => v / 15), atA: ws.strengthAtInnerEdge.map(v => v / 15), atB: ws.strengthAtOuterEdge.map(v => v / 15) };
  // sub-division (midpoint-rule) error of the Trefftz drag at the default 16 sub-segments per strip, against 256; the
  // same quantity for the 0.3.1 reconstruction of 0.3.1's own wake on the same wing (SOLVER031) is the yardstick
  const subErr = (fn) => { const d16 = fn(16), d256 = fn(256); return (d16 - d256) / d256; };
  const eq = subErr(f => W.trefftzQuadratic(w, sv, f).dragOverHalfRho);
  if (process.env.SOLVER031) {
    const P = require(process.env.SOLVER031), mc = P.prepare({ naca: '2412', semiSpan: 450, rootChord: 160, tipChord: 100, sweepDeg: 10, dihedralDeg: 5 }, { chordPanels: 16, spanPanels: 12 }), rc = P.evaluate(mc, { alphaDeg: 4, speed: 15 }), wc = mc.wm.wake;
    const trace = []; for (let j = 0; j < wc.count; j++) trace.push([wc.a[3 * j + 1], wc.a[3 * j + 2]]); trace.push([wc.b[3 * (wc.count - 1) + 1], wc.b[3 * (wc.count - 1) + 2]]);
    const ec = subErr(f => P.trefftz(trace, rc.strips.map(st => st.gamma / 15), f).dragOverHalfRho);
    log(`Trefftz drag sub-division error at 16 sub-segments per strip (vs 256): quadratic wake ${eq.toExponential(2)}, 0.3.1 reconstruction of the 0.3.1 wake ${ec.toExponential(2)}`);
    ok(Math.abs(eq) <= 1.1 * Math.abs(ec), 'Trefftz drag quadrature error no larger than the 0.3.1 reconstruction error (same midpoint rule)');
  } else log(`Trefftz drag sub-division error at 16 sub-segments per strip (vs 256): ${eq.toExponential(2)} (set SOLVER031 for the 0.3.1 yardstick)`);
  ok(ws.strengthAtOuterEdge[w.count - 1] === 0, 'solved wake strength exactly zero at the rounded tip');
  const sw = r.semiWing, F = [0, 0, 0], M = [0, 0, 0];
  for (const st of r.strips) { const f = st.force_N, mq = st.momentAboutQuarterChord_Nmm, p = st.quarterChordPoint_mm; for (let c = 0; c < 3; c++) F[c] += f[c]; M[0] += mq[0] + p[1] * f[2] - p[2] * f[1]; M[1] += mq[1] + p[2] * f[0] - p[0] * f[2]; M[2] += mq[2] + p[0] * f[1] - p[1] * f[0]; }
  const eF = Math.max(...F.map((v, c) => Math.abs(v - sw.force_N[c]))) / Math.hypot(...sw.force_N), eM = Math.max(...M.map((v, c) => Math.abs(v - sw.momentAboutRootOrigin_Nmm[c]))) / Math.hypot(...sw.momentAboutRootOrigin_Nmm);
  ok(eF < 1e-12 && eM < 1e-12, `strip loads reproduce the semi-wing force and root moment (relative ${eF.toExponential(1)}, ${eM.toExponential(1)})`);
}
// ---------------------------------------------------------------- 11. constant model = published 0.3.1
if (process.env.SOLVER031) {
  const P = require(process.env.SOLVER031), geo = { naca: '2412', semiSpan: 400, rootChord: 150, tipChord: 90, sweepDeg: 10, dihedralDeg: 4 };
  const a = W.solve(geo, { alphaDeg: 5, speed: 15 }, { chordPanels: 12, spanPanels: 8 }, { doubletModel: 'constant' }), b = P.solve(geo, { alphaDeg: 5, speed: 15 }, { chordPanels: 12, spanPanels: 8 });
  let d = 0; for (let k = 0; k < a.panels.count; k++) d = Math.max(d, Math.abs(a.panels.cp[k] - b.panels.cp[k]), Math.abs(a.panels.mu[k] - b.panels.mu[k]));
  log(`doubletModel 'constant' vs published ${P.VERSION}: max |dCp|, |dmu| = ${d}; CL ${a.coefficients.CL} vs ${b.coefficients.CL}`);
  ok(d === 0 && a.coefficients.CL === b.coefficients.CL && a.coefficients.CDiTrefftz === b.coefficients.CDiTrefftz && a.coefficients.Cm === b.coefficients.Cm, "doubletModel 'constant' is bit-identical to 0.3.1");
} else log('(11 skipped: set SOLVER031 to the published 0.3.1 core to compare the constant model bit for bit)');
console.log(`test_wing_aero_span_doublet: ${checks} checks passed (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
