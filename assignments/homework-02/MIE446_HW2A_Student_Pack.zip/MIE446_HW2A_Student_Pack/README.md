# Homework 2A: Read the Evidence, then Locate the Force

MIE 446 Aerospace Structures, Fall 2026. Parts 1 and 3, 35 points.
Due Tuesday, October 20, 2026; Canvas shows the time and submission link.

Start with the student guide, `MIE446_HW2A_Evidence_and_Moment_Geometry.pdf`.
It gives the required reading, numbered steps, MATLAB commands, Excel cell
references, independent checks and the submission list.

## Files

- `MIE446_HW2A_Evidence_and_Moment_Geometry.pdf`: student guide (HTML source included)
- `MIE446_HW2A_Starter.m`: MATLAB starter for Part 3
- `MIE446_HW2A_Excel_Starter.xlsx`: Paper sheet (Part 1 readings) and Controls sheet (Part 3)
- `assets/HW2_Body_Axes.png`: body-axis figure used by the guide

Extract the ZIP before opening its files. In MATLAB, make the extracted folder
your Current Folder. In Excel, save a working copy. Gray cells and MATLAB TODOs
are intentionally unfinished; a blank answer is not a zero result.

## Reading

- [Lecture 1 in Google Colab](https://colab.research.google.com/github/Ehsan-Roohi/Aerospace-Structures/blob/main/notebooks/MIE446_Lecture_01_Trust_Forces_Airfoils.ipynb): sections 7A-3, 7A-3a, 7A-3b and 7A-7 to 7A-13
- Raffel et al., [Flight Controls of Otto Lilienthal's Experimental Monoplane from 1895](https://elib.dlr.de/191143/1/JoA_Paper_Lilienthal_Flight_Controls.pdf): device descriptions, the opening of Section II and Section II.C, Figures 11 and 12. Read the plotted markers (filled circles for the spoileron, crosses for wing warping), not the dashed lines, and compare signs and trends rather than coefficient sizes.

HW 2B (Parts 2, 4 and 5, 65 points, due November 5) is released separately and
builds on both parts of this assignment. Discuss and cross-check within your
three-person team; each student submits independently authored work through Canvas.
