#!/usr/bin/env bash
# Wing AeroStruct (development): build the separate site, then run every AeroStruct test suite.
#   computational/printed-wing-solver/aerostruct/run_tests.sh [log-directory]
# Needs Node 18+ and Python 3. The jsdom suites (UI, page, study IO) need jsdom 26: either installed where
# Node can resolve it, or MIE446_JSDOM_MODULE=/path/to/node_modules/jsdom. The real-browser suite runs when
# Playwright with Chromium is available (see below). Each suite writes its full output to
# <log-directory>/<suite>.log; SUMMARY.txt lists exit code, wall time and the last line of every suite.
# The slow reference study (validation/reference_study.mjs, about 13 minutes) runs only with
# WING_AEROSTRUCT_REFERENCE=1; its stored results are checked by test_wing_aero_admission in every run.
# Never writes to docs/ (the published Wing Lab).
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(cd "$HERE/../../.." && pwd)"
LOGS="${1:-$HERE/test-logs}"
mkdir -p "$LOGS"
SUMMARY="$LOGS/SUMMARY.txt"
{
  echo "Wing AeroStruct test run"
  echo "date (UTC): $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "node: $(node --version)   python: $(python3 --version 2>&1)   cpu: $(nproc) cores"
  echo "jsdom: ${MIE446_JSDOM_MODULE:-resolved by Node}"
  echo
} > "$SUMMARY"
if python3 "$HERE/build_wing_aerostruct.py" > "$LOGS/build.log" 2>&1; then
  echo "build    ok    $(tail -1 "$LOGS/build.log")" >> "$SUMMARY"
else
  echo "build    FAILED (see build.log)" >> "$SUMMARY"; cat "$SUMMARY"; exit 1
fi
failed=0
# Numerical suites first (pure Node), then the structural fork, the twist claim on real structures, the Worker,
# study IO, UI and page suites.
suites="test_wing_aero_kernels test_wing_aero_closed_bodies test_wing_aero_trefftz test_wing_aero_conformal \
        test_wing_aero_wing test_wing_aero_vlm test_wing_aero_admission test_wing_aero_transfer test_aerostruct_engine_fork \
        test_aerostruct_twist test_wing_aero_worker test_aerostruct_study_io test_aerostruct_aero_ui test_aerostruct_page"
# Real-browser suite: needs Playwright with Chromium (PLAYWRIGHT_MODULE=/path/to/playwright/index.mjs, or a
# resolvable 'playwright'), and three.js r128 from the CDN or WING_THREE_DIR=/path/to/three@0.128.0.
if [ -n "${PLAYWRIGHT_MODULE:-}" ] || node -e "require.resolve('playwright')" > /dev/null 2>&1; then
  suites="$suites test_aerostruct_browser"
else
  echo "test_aerostruct_browser        skipped: Playwright with Chromium not available" >> "$SUMMARY"
fi
for suite in $suites; do
  start=$(date +%s.%N)
  if [ "$suite" = test_aerostruct_browser ]; then
    (cd "$HERE" && node "$suite.mjs" "$LOGS/screenshots") > "$LOGS/$suite.log" 2>&1
  else
    (cd "$HERE" && node "$suite.mjs") > "$LOGS/$suite.log" 2>&1
  fi
  code=$?
  end=$(date +%s.%N)
  [ $code -eq 0 ] || failed=$((failed + 1))
  printf "%-30s exit %d  %6.1f s  %s\n" "$suite" "$code" "$(echo "$end - $start" | bc)" "$(tail -1 "$LOGS/$suite.log" | cut -c1-120)" >> "$SUMMARY"
done
if [ "${WING_AEROSTRUCT_REFERENCE:-0}" = 1 ]; then
  start=$(date +%s.%N)
  (cd "$HERE" && node validation/reference_study.mjs) > "$LOGS/reference_study.log" 2>&1
  code=$?; end=$(date +%s.%N)
  [ $code -eq 0 ] || failed=$((failed + 1))
  printf "%-30s exit %d  %6.1f s  %s\n" "reference_study" "$code" "$(echo "$end - $start" | bc)" "$(tail -1 "$LOGS/reference_study.log" | cut -c1-120)" >> "$SUMMARY"
fi
echo >> "$SUMMARY"
echo "suites failed: $failed" >> "$SUMMARY"
if command -v git > /dev/null && [ "$(git -C "$REPO" rev-parse --show-toplevel 2> /dev/null)" = "$(cd "$REPO" && pwd -P)" ]; then
  echo "Wing Lab files changed (docs/, web/): $(git -C "$REPO" status --porcelain -- docs computational/printed-wing-solver/web | wc -l)" >> "$SUMMARY"
else
  echo "Wing Lab files changed (docs/, web/): not checked (this folder is not a git checkout of the repository)" >> "$SUMMARY"
fi
cat "$SUMMARY"
exit $failed
