// Tensor-quadratic candidate (0.3.2-exp.3): the 3-D surface recovery and load integration against MachLine's own routines
// (focused; NOT a physics gate). MachLine (MIT, github.com/usuaero/MachLine, commit d62befa) is ported in
// validation/machline/machline_routines.mjs (panel_get_velocity_jump, panel_get_velocity, flow_get_C_P_inc,
// panel_get_quadratic_pressure_params, panel_get_avg_pressure_coef, panel_get_moment_about_centroid and the geometry
// they use; see that file's header for the line-by-line map and the licence).
//   1. the ported C(i, j) area moments of a triangle against a degree-5 quadrature (exact for i + j <= 3): MachLine's
//      own recursion (Ni = Nj = 3) leaves the third moments unassigned; one order further (cOrder 4) it gives them;
//   2. on three wings (rectangular NACA 0012 and NACA 0002 AR 6 at 32 x 24, the 2412 gate wing at 32 x 16; alpha 4):
//      for every triangle of every panel, MachLine's routines applied to the core's solved distribution (its P2 doublet
//      at the six nodes of the triangle and its source sigma_T = -c . n_T, Morino inner flow) give the core's panel
//      force, its pressure couple about the panel centroid and its control-point Cp, to round-off, including the
//      trailing-edge, leading-edge and last-strip corner panels;
//   3. MachLine's moment routine as written (third moments 0 here, unassigned memory in MachLine): the per-panel couples
//      it would give and their effect on Cm (logged).
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import * as ML from './validation/machline/machline_routines.mjs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const t0 = Date.now();
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], norm = a => Math.hypot(...a);

// ---------------------------------------------------------------- 1. area moments
{
  const P = [[0.3, -0.2, 0.1], [2.1, 0.4, -0.3], [0.7, 1.9, 0.5]];
  const GP = [[1 / 3, 1 / 3, 1 / 3, 0.225]];
  for (const [a, b, w] of [[0.059715871789770, 0.470142064105115, 0.132394152788506], [0.797426985353087, 0.101286507323456, 0.125939180544827]]) GP.push([a, b, b, w], [b, a, b, w], [b, b, a, w]);
  const exact = (pan, i, j) => GP.reduce((s, [l0, l1, l2, w]) => { const x = l0 * pan.vls[0][0] + l1 * pan.vls[1][0] + l2 * pan.vls[2][0], y = l0 * pan.vls[0][1] + l1 * pan.vls[1][1] + l2 * pan.vls[2][1]; return s + w * pan.A * x ** i * y ** j; }, 0);
  let e3 = 0, e4 = 0, third = 0;
  const p3 = ML.machlinePanel(P, [1, 0, 0], { cOrder: 3 }), p4 = ML.machlinePanel(P, [1, 0, 0], { cOrder: 4 });
  for (let i = 0; i <= 3; i++) for (let j = 0; j <= 3 - i; j++) {
    const ex = exact(p4, i, j), sc = p4.A * 2 ** (i + j);
    e4 = Math.max(e4, Math.abs(p4.C[i][j] - ex) / sc);
    if (i + j <= 2) e3 = Math.max(e3, Math.abs(p3.C[i][j] - ex) / sc); else third = Math.max(third, Math.abs(p3.C[i][j]));
  }
  log(`C(i, j) vs degree-5 quadrature: MachLine's recursion (Ni = Nj = 3) i + j <= 2 max relative error ${e3.toExponential(1)}, i + j = 3 never assigned (here ${third}); one order further (cOrder 4) all i + j <= 3: ${e4.toExponential(1)}`);
  ok(e3 < 1e-13 && e4 < 1e-13 && third === 0, 'ported area moments: MachLine\'s recursion exact through second order; carried one order further it gives the third moments its moment routine reads');
}
// ---------------------------------------------------------------- 2./3. the core's loads against MachLine's routines
{
  const CASES = [
    ['rectangular NACA 0012 AR 6', { naca: '0012', semiSpan: 600, rootChord: 200, tipChord: 200 }, 32, 24],
    ['rectangular NACA 0002 AR 6', { naca: '0002', semiSpan: 600, rootChord: 200, tipChord: 200 }, 32, 24],
    ['2412 gate wing', { naca: '2412', semiSpan: 900, rootChord: 160, tipChord: 100, planform: 'linear', sweepDeg: 10, dihedralDeg: 10, sweepReferenceFraction: 0.25, twistReferenceFraction: 0.25, twistEnabled: false }, 32, 16],
  ];
  const flow = { speed: 10, density: 1.225, alphaDeg: 4 }, al = flow.alphaDeg * Math.PI / 180, cHat = [Math.cos(al), 0, Math.sin(al)], U = flow.speed, q = 0.5 * flow.density * U * U * 1e-6;
  let eF = 0, eM = 0, eCp = 0, nCp = 0, nTri = 0, corner = 0; const asWritten = [];
  for (const [name, geo, nc, ns] of CASES) {
    const m = W.prepare(geo, { chordPanels: nc, spanPanels: ns }, { referenceLimits: { maxPanels: 100000, chordPanels: [6, 512], spanPanels: [4, 256] } }), r = W.evaluate(m, flow);
    const wm = m.wm, S = wm.S, B = wm.body, ni = wm.ni, n = wm.wingPanels, R = m.surface.R, V = W.tensorValues(B, Float64Array.from(r.panels.mu.slice(0, S.count), x => x / U));
    let mW = 0, dMy = 0;
    for (let k = 0; k < n; k++) {
      const T = W.tensorSlots(B, k), sl = Array.from({ length: 9 }, (_, s) => V[B.refs[9 * k + s]]), PC = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]];
      const nodeVal = id => { const nd = T.nodes[id]; return nd.slot >= 0 ? sl[nd.slot] : nd.weights.reduce((s, w, i) => s + w * sl[i], 0); };
      let F = [0, 0, 0], M = [0, 0, 0], M3 = [0, 0, 0];
      T.tris.forEach((t, ti) => {
        if (!t.valid) return; nTri++;
        const pan = ML.machlinePanel(t.points, cHat, { cOrder: 4 }), pan3 = ML.machlinePanel(t.points, cHat, { cOrder: 3 });
        const muP = ML.doubletParams(pan, t.nodes.map(nodeVal)), sigma = -(cHat[0] * pan.n_g[0] + cHat[1] * pan.n_g[1] + cHat[2] * pan.n_g[2]);
        const Cpp = ML.quadraticPressureParams(pan, muP, sigma, U, cHat), f = mul(ML.forceOfPanel(pan, ML.avgPressureCoef(pan, Cpp)), q), arm = cross(sub(pan.centr, PC), f);
        F = add(F, f); M = add(M, add(mul(ML.momentAboutCentroid(pan, Cpp), q), arm)); M3 = add(M3, add(mul(ML.momentAboutCentroid(pan3, Cpp), q), arm));
        if (R.cpTri[k] === R.first[k] + ti) {
          const l = [R.cpL[3 * k], R.cpL[3 * k + 1], R.cpL[3 * k + 2]], X = add(add(mul(t.points[0], l[0]), mul(t.points[1], l[1])), mul(t.points[2], l[2]));
          eCp = Math.max(eCp, Math.abs(ML.cpInc(ML.velocity(pan, muP, sigma, U, cHat, X), U) - r.panels.cp[k])); nCp++;
        }
      });
      const Fc = [0, 1, 2].map(c => r.panels.force_N[3 * k + c]), Mc = [0, 1, 2].map(c => r.panels.momentAboutCentroid_Nmm[3 * k + c]), sc = Math.max(norm(Fc), 1e-30);
      eF = Math.max(eF, norm(sub(F, Fc)) / sc); eM = Math.max(eM, norm(sub(M, Mc)) / (sc * S.PD[k])); mW = Math.max(mW, norm(sub(M3, Mc)) / (sc * S.PD[k])); dMy += M3[1] - Mc[1];
      const i = k % ni, j = Math.floor(k / ni); if (j === wm.ns - 1 && [0, ni - 1, ni / 2 - 1, ni / 2].includes(i)) corner++;
    }
    asWritten.push(`${name}: per-panel couple error up to ${(100 * mW).toFixed(2)} % of |F| d, Cm ${(2 * dMy / (q * r.reference.area_mm2 * r.reference.mac_mm)).toExponential(1)} (of ${r.coefficients.Cm.toExponential(3)})`);
  }
  log(`${CASES.length} wings, ${nTri} triangles, ${nCp} control points (${corner} last-strip corner panels): MachLine's routines on the core's distribution vs the core: force max relative error ${eF.toExponential(1)}, couple about the panel centroid ${eM.toExponential(1)} (of |F| x panel diameter), control-point Cp ${eCp.toExponential(1)}`);
  ok(eF < 1e-9 && eM < 1e-9 && eCp < 1e-9, 'the core\'s panel forces, pressure couples and control-point Cp are MachLine\'s velocity, quadratic-pressure, average-pressure and moment routines applied to the same distribution (to round-off), on every panel including the trailing-edge and corner panels');
  log(`MachLine's moment routine as written (third moments unassigned, 0 here): ${asWritten.join('; ')}`);
}
console.log(`test_wing_aero_machline_port: ${checks} checks passed (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
