import assert from 'node:assert/strict';
import {JSDOM,loadBeamLab} from './beam_test_dom.mjs';
const dom=new JSDOM('<div id="foundations"></div>',{url:'https://example.org',runScripts:'outside-only'});
const w=dom.window;
const rect=w.Element.prototype.getBoundingClientRect;
w.Element.prototype.getBoundingClientRect=function(){if(this.tagName.toLowerCase()==='svg'){const width=+this.getAttribute('width')||760;return {left:0,top:0,width,height:250};}return rect.call(this);};
const { $ }=loadBeamLab(dom), state=()=>w.BeamLab.state();
assert.equal(state().model.supports.length,0); // User must place restraints before analysis.
$('#beamleftSupport').value='fixed';$('#beamSolve').click();
const x=station=>{const s=$('#beamPicture svg');return +s.dataset.x0+(+s.dataset.x1-s.dataset.x0)*station/450;};
const event=(type,target,station)=>target.dispatchEvent(new w.MouseEvent(type,{bubbles:true,cancelable:true,button:0,clientX:x(station),clientY:30}));
const pick=kind=>$(`[data-place="load:${kind}"]`).click();
const pic=$('#beamPicture');
assert.equal(state().model.loads.length,0);
pick('point');assert.equal(state().model.loads.length,0);
event('click',pic,225);
assert.equal($('#beamLoadA').value,'225');assert.equal($('#beamP').value,'');
assert.equal(state().model.loads.length,0,'click selects a location, not an applied default');
$('#beamP').value='-2';$('#beamLoadForm').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
assert.equal(state().model.loads[0].force,-2);
assert.equal(state().solved.result.resultant,-2);
assert.ok($('[data-load-handle="0"]'));
event('pointerdown',$('[data-load-handle="0"]'),225);event('pointermove',pic,300);event('pointerup',pic,300);event('click',pic,300); // browser-synthesized post-release click is deliberately suppressed
assert.equal(state().model.loads[0].position,300);assert.equal(state().solved.model.loads[0].position,225,'manual solve preserves old results');
$('#beamSolve').click();assert.equal(state().solved.model.loads[0].position,300);
pick('moment');event('click',pic,0);assert.equal($('#beamLoadA').value,'0');assert.equal($('#beamC').value,'');
$('#beamC').value='-10';$('#beamLoadForm').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));assert.equal(state().model.loads[1].moment,-10);
for(const kind of ['rectangle','triangle','triangle-root','trapezoid','elliptic','parabolic']){
  pick(kind);event('pointerdown',pic,350);event('pointermove',pic,100);event('pointerup',pic,100);event('click',pic,100);
  assert.equal($('#beamLoadA').value,'100');assert.equal($('#beamLoadB').value,'350');assert.equal($('#beamLoadKind').value,kind);
  assert.equal(state().model.loads.length,2,'range selection does not insert an unconfirmed load');
  assert.equal($('#beamCurveValue').value,'');
}
$('#beamStopPlacing').click();assert.ok(!$('#beamPicture .bl-selection'));
pick('rectangle');event('pointerdown',pic,100);event('pointercancel',pic,200);assert.equal(state().model.loads.length,2);
$('#beamStopPlacing').click();
event('pointerdown',$('[data-load-handle="0"]'),300);event('pointermove',pic,400);event('pointercancel',pic,400);assert.equal(state().model.loads[0].position,300,'cancel restores load');
$('[data-load-handle="1"]').dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));assert.equal($('#beamC').value,'-10');
pick('rectangle');event('pointerdown',pic,100);event('pointermove',pic,200);event('pointerup',pic,200);event('click',pic,200);
$('#beamQ0').value='.01';$('#beamLoadForm').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
assert.equal(state().model.loads.length,3);assert.equal(state().solved.result.resultant,-1,'signed forces superpose: -2 + 1 N');
event('pointerdown',$('[data-load-handle="2"]'),150);event('pointermove',pic,450);event('pointerup',pic,450);event('click',pic,450);
assert.equal(state().model.loads[2].start,350);assert.equal(state().model.loads[2].end,450,'moving interval is bounded, not silently shortened');
assert.equal(state().model.loads[2].qStart,.01);assert.equal(state().model.loads[2].qEnd,.01);
$('#beamSolve').click();assert.equal(state().solved.result.resultant,-1,'moving a load preserves magnitude and length');
console.log('Graphical loads: empty start, all eight tools, signed force/couple, range selection, drag/move, cancel, keyboard edit and stale-result checks passed.');
dom.window.close();
