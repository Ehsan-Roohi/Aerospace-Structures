"""Collect case-specific CCX/beam agreement without promoting IP bands to cuts."""
import argparse
import json
from pathlib import Path

def summarize(out):
    read=lambda name:json.loads((out/name).read_text(encoding='utf-8'))
    result={'scope':'One specific swept, dihedral, twisted, tapered homogeneous wing and two global-wrench load channels. Raw signed matched-IP comparison, not complete section stress recovery or general validation.','channels':{}}
    lines=['# Independent CalculiX solid / nominal beam comparison','',result['scope'],'','The C3D10 curved geometry is mapped isoparametrically. The stress source is actual CalculiX integration-point S, not a nodal extrapolation or fitted affine stress field. Each matched comparison uses the actual physical IP and its beam normal foot. Four-IP volume weights describe sampled bands, not complete cut resultants.','']
    for ch in ['uniform','torque']:
        reports=[read(f'ccx-h{h}-{ch}-stress-comparison.json') for h in [8,5]]
        solid=[read(f'ccx-h{h}-{ch}-report.json') for h in [8,5]]
        beam=read(f'ccx-h5-{ch}-ip-beam-reference.json')['reference'];last=beam['runs'][-1]
        key='generalized_displacement_mm' if ch=='uniform' else 'theta_work_rad';bk='generalizedDisplacementMm' if ch=='uniform' else 'thetaWorkRad';beamvalue=last['vertical' if ch=='uniform' else 'torque'][bk]
        value=solid[-1][key];change=abs(solid[0][key]-value)/abs(value);error=abs(beamvalue-value)/abs(value)
        bands=[]
        for a,b in zip(reports[0]['bands'],reports[1]['bands']):
            bands.append({'station_mm':b['centre_mm'],'h8_count':a['count'],'h5_count':b['count'],'solid_band_rms_change_relative':abs(a['solid_rms_MPa']-b['solid_rms_MPa'])/b['solid_rms_MPa'],'h5_raw_beam_difference_relative_rms':b['raw_difference_relative_rms'],'h5_max_absolute_raw_difference_MPa':b['max_absolute_raw_difference_MPa']})
        result['channels'][ch]={'h5_solid_generalized_response':value,'beam_generalized_response':beamvalue,'generalized_response_relative_difference':error,'solid_response_h8_h5_relative_change':change,'band_changes':bands,'h5_regions':reports[1]['regions'],'independent_energy_max_relative_difference':max(r['energy_relative_difference'] for r in reports),'beam_refinement':beam['convergence'],'coverage_h8_h5':[{'all_ips':r['total_ip_count'],'matched_samples':r['matched_sample_count'],'resolved_samples':r['resolved_ip_count'],'unresolved_samples':r['unresolved_ip_count']} for r in reports]}
        lines.extend([f'## {ch}',f'Solid h5 generalized response: {value:.10g}; beam: {beamvalue:.10g}. Beam/solid difference {error:.3%}; h8-to-h5 solid response change {change:.3%}. For uniform this is work-conjugate translation in mm; for torque it is work/My in radians, not a fitted physical tip/ring orientation.','', '| Normal-foot band centre (mm) | h8 / h5 IP count | Solid band RMS change | h5 raw beam-minus-solid RMS / solid RMS | Largest sampled absolute difference (MPa) |','|---:|---:|---:|---:|---:|'])
        for b in bands:lines.append(f"| {b['station_mm']:g} | {b['h8_count']} / {b['h5_count']} | {b['solid_band_rms_change_relative']:.3%} | {b['h5_raw_beam_difference_relative_rms']:.3%} | {b['h5_max_absolute_raw_difference_MPa']:.6g} |")
        lines.extend(['','| h5 sampled region | IP count | Raw difference RMS / solid RMS |','|---|---:|---:|'])
        for region,metric in reports[1]['regions'].items():lines.append(f"| {region} | {metric['count']} | {metric.get('raw_difference_relative_rms',0):.3%} |")
        lines.extend(['','Root, rib and tip residuals were not fitted away or used to adjust the interior comparison. The quiet bands are not representative of every interior point; in particular the torque broad-interior raw residual exceeds 15%. IP sets differ across meshes. Their band RMS change is a sampled distribution comparison, not same-point stress convergence or proof of convergence of local peaks.','',f'Independent sum(sigma:epsilon detJ/24)/2 versus external work/2 differs by at most {result["channels"][ch]["independent_energy_max_relative_difference"]:.3g} relative, using printed displacement and stress precision.',''])
    lines.extend(['## Interpretation','The force-driven case has close nominal interior normal-stress agreement in the sampled bands. The pure global-My case retains larger local normal-stress residuals; those include effects the nominal affine beam field does not resolve. Matching section-scale RMS must not be read as matching every local stress.','', 'The original numerical gates are unchanged: 2% compliance refinement, 5% nominal-stress refinement, 10% beam/solid compliance and 15% nominal normal-stress agreement. The present IP-band diagnostics do not by themselves establish the complete-cut nominal-stress refinement gate, so this report does not declare overall validation or certification. Root clamping, traction application, ribs, section distortion, warping and local peak stresses remain separate questions.',''])
    result['overall_validation_claimed']=False
    (out/'ccx-beam-comparison-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');(out/'ccx-beam-comparison-summary.md').write_text('\n'.join(lines),encoding='utf-8')
    print('\n'.join(lines))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);summarize(p.parse_args().out)
