// Validation of the mesh-sequence extrapolation and its uncertainty U against references from far finer meshes.
// Run: node validation/reference_study.mjs [--write]   (about 13 minutes; --write refreshes admission_reference.json)
//
// For seven wings (course default at 4 and 8 deg, dihedral 6, sweep 25, rectangular NACA 0012, washout, and a
// combined swept/dihedral/twisted/tapered wing with two airfoils) the script
//  1. solves reference meshes: 48, 64, 96, 128, 192 panels per surface (chordwise) at 16 strips, and 24, 32, 48, 64,
//     96 strips at 32 panels per surface (up to about 7,300 panels; the app's Fine sequence stops at 96 and 48);
//  2. forms the reference value of each quantity by observed-order Richardson extrapolation (Celik et al. 2008) of
//     each force/moment COMPONENT on the three finest levels of each direction, combined additively, with the
//     reference uncertainty = change when the next-coarser triple is used; torques are e . M of the extrapolated
//     components (component extrapolation, not of the torque sequence itself, whose mixed orders mislead);
//  3. runs the app's Standard and Fine sequences (WingAeroPanel.runSequence, combineSequence, admission) for three
//     straight axes (25, 35 and 45% chord lines) with cut planes normal to the axis at the root and 25, 50, 75% span;
//  4. tests the additive (separable) error model that both the app and step 2 assume: three meshes refined in BOTH
//     directions (48 x 24, 64 x 32 and 96 x 48 panels per surface x strips, up to about 11,000 panels) give the mixed
//     second differences D = Q(c, s) - Q(32, s) - Q(c, 16) + Q(32, 16), which vanish for a separable error; the
//     cross-term error X(32, 16) of the additive combination (shared by the app and by step 2) is estimated as 9 D,
//     4 D and 2.25 D respectively (exact for a k / (c s) cross term), and the largest magnitude is used;
//  5. reports, for every torque, force and bending quantity: |estimate - reference| / U (coverage, must be <= 1),
//     the strict ratio (|estimate - reference| + reference uncertainty) / U, the strict+ ratio that also adds the
//     estimated cross-term error |X(32, 16)|, whether every RESOLVED quantity's error (strict+) is within its
//     tolerance (torque: 10% of |T| itself, no floor), and whether every torque whose sign the app reports as
//     resolved has the sign of the reference. The run fails if any estimate is outside U, any resolved quantity's
//     error exceeds its tolerance, or any resolved sign is wrong;
//  6. stores, for the course wing, a reference six-component load on the strip stations of the editable course
//     fixture (Fine delivery grid) with its uncertainty, so test_aerostruct_twist.mjs can measure the twist error of
//     the delivered loads on real structures against the twist bound.
// Everything below the "independent" marker is written separately from wing_aero_panel.js's extrapolation code.
import { createRequire } from 'node:module';
import { writeFileSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const require = createRequire(import.meta.url), here = path.dirname(fileURLToPath(import.meta.url));
const A = require('../wing_aero_panel.js'), E = require('../engine.js');
const t0 = Date.now(), write = process.argv.includes('--write');
const base = E.DEFAULT_GEOMETRY;
const CONFIGS = {
  course4: { g: { ...base }, flow: { speed: 15, alphaDeg: 4 } },
  course8: { g: { ...base }, flow: { speed: 15, alphaDeg: 8 } },
  dihedral6: { g: { ...base, dihedralDeg: 6 }, flow: { speed: 15, alphaDeg: 4 } },
  swept25: { g: { ...base, sweepDeg: 25, sweepReferenceFraction: 0.25 }, flow: { speed: 15, alphaDeg: 4 } },
  rect0012: { g: { ...base, naca: '0012', rootChord: 120, tipChord: 120, semiSpan: 360 }, flow: { speed: 15, alphaDeg: 5 } },
  washout: { g: { ...base, twistEnabled: true, twistReferenceFraction: 0.25, stations: [{ eta: 0, airfoil: '2412', incidenceDeg: 2 }, { eta: 1, airfoil: '2412', incidenceDeg: -2 }] }, flow: { speed: 15, alphaDeg: 4 } },
  combo: { g: { ...base, sweepDeg: 15, dihedralDeg: 5, sweepReferenceFraction: 0.25, tipChord: 70, twistEnabled: true, twistReferenceFraction: 0.25, stations: [{ eta: 0, airfoil: '4412', incidenceDeg: 1 }, { eta: 1, airfoil: '0012', incidenceDeg: -1 }] }, flow: { speed: 18, alphaDeg: 6 } },
};
const REF_CHORD = [48, 64, 96, 128, 192], REF_SPAN = [24, 32, 48, 64, 96], BASE_C = 32, BASE_S = 16;
const lim = { chordPanels: [6, 256], spanPanels: [4, 128], maxPanels: 14000 };
const MIXED = [[48, 24, 9], [64, 32, 4], [96, 48, 2.25]]; // [c, s, factor]: X(32, 16) = factor x D for a k / (c s) cross term

// ------------------------------------------------------------------ independent
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], sub = (a, b) => a.map((v, i) => v - b[i]);
// load line r(y) = quarter-chord point, independent geometry convention (see test_aerostruct_engine_fork.mjs)
function physicalPoint(g, y, x) {
  const L = g.semiSpan, c = g.rootChord + (g.tipChord - g.rootChord) * y / L, eta = y / L, ss = g.stations || []; let inc = 0;
  if (ss.length) { let j = 0; while (j < ss.length - 2 && eta > ss[j + 1].eta) j++; const t = (eta - ss[j].eta) / (ss[j + 1].eta - ss[j].eta); inc = (1 - t) * ss[j].incidenceDeg + t * ss[j + 1].incidenceDeg; }
  const a = inc * Math.PI / 180, p = (g.twistReferenceFraction ?? .25) * c, xle = y * Math.tan((g.sweepDeg || 0) * Math.PI / 180) + (g.sweepReferenceFraction || 0) * (g.rootChord - c), zle = y * Math.tan((g.dihedralDeg || 0) * Math.PI / 180);
  return [xle + p + (x - p) * Math.cos(a), y, zle - (x - p) * Math.sin(a)];
}
const lineAt = (g, y) => physicalPoint(g, y, .25 * (g.rootChord + (g.tipChord - g.rootChord) * y / g.semiSpan));
const simpsonVec = (fn, a, b, n = 64) => { const out = [0, 0, 0]; for (let k = 0; k <= n; k++) { const w = k === 0 || k === n ? 1 : k % 2 ? 4 : 2, v = fn(a + (b - a) * k / n); for (let i = 0; i < 3; i++) out[i] += w * v[i]; } return out.map(v => v * (b - a) / (3 * n)); };
// outboard wrench (about the origin) of a level's strips beyond y*, uniform intensity in the strip that contains y*
function cutOfLevel(g, strips, ystar) {
  const W = [0, 0, 0, 0, 0, 0];
  for (const r of strips) {
    if (r[1] <= ystar) continue;
    if (r[0] >= ystar) { for (let d = 0; d < 6; d++) W[d] += r[2 + d]; continue; }
    const h = r[1] - r[0], f = r.slice(2, 5).map(v => v / h), Rall = simpsonVec(y => lineAt(g, y), r[0], r[1]), m = r.slice(5, 8).map((v, d) => (v - cross(Rall, f)[d]) / h);
    const part = simpsonVec(y => lineAt(g, y), ystar, r[1]), hp = r[1] - ystar, c = cross(part, f);
    for (let d = 0; d < 3; d++) { W[d] += f[d] * hp; W[3 + d] += c[d] + m[d] * hp; }
  }
  return W;
}
function observed(ns, Q, lo = .5, hi = 3) { // ns ascending (coarse to fine), three values
  const [n3, n2, n1] = ns, [f3, f2, f1] = Q, r21 = n1 / n2, r32 = n2 / n3, e21 = f2 - f1, e32 = f3 - f2;
  if (e21 === 0 || e32 === 0) return { ext: f1, p: null };
  const s = Math.sign(e32 / e21); let p = 1;
  if (s > 0) for (let it = 0; it < 500; it++) { const pn = Math.abs(Math.log(Math.abs(e32 / e21)) + Math.log((r21 ** p - 1) / (r32 ** p - 1))) / Math.log(r21); if (!Number.isFinite(pn) || Math.abs(pn - p) < 1e-13) { p = Number.isFinite(pn) ? pn : 1; break; } p = pn; }
  const pu = s > 0 ? Math.min(hi, Math.max(lo, p)) : 1;
  return { ext: f1 + (f1 - f2) / (r21 ** pu - 1), p: s > 0 ? p : null };
}
// ------------------------------------------------------------------ end of independent part

const results = [], stored = { aeroVersion: A.VERSION, note: 'Reference values from reference_study.mjs (component-wise observed-order Richardson on chordwise 96/128/192 and spanwise 48/64/96 levels), cross-term (separability) estimates from three meshes refined in both directions, and the coverage summary of both sequences.', configs: {} };
const only = process.env.REF_ONLY ? process.env.REF_ONLY.split(',') : null; // e.g. REF_ONLY=course4 for a quick partial run
if (only && write) throw new Error('--write needs the full set of configurations (unset REF_ONLY).');
for (const [name, cfg] of Object.entries(CONFIGS).filter(([n]) => !only || only.includes(n))) {
  const g = A.aeroGeometry(E.makeGeometry(cfg.g)), L = g.semiSpan, cache = new Map(), tc = Date.now();
  const level = (c, s) => { const r = A.solve(g, cfg.flow, { chordPanels: c, spanPanels: s }, { cache, referenceLimits: lim }); return { strips: A.stripWrenches(r), base: r }; };
  const memo = new Map(), lv = (c, s) => { const k = c + 'x' + s; if (!memo.has(k)) memo.set(k, level(c, s)); return memo.get(k); };
  const chordRef = REF_CHORD.map(c => lv(c, BASE_S)), spanRef = REF_SPAN.map(s => lv(BASE_C, s)), baseLv = lv(BASE_C, BASE_S);
  const mixed = MIXED.map(([c, s, factor]) => ({ c, s, factor, both: lv(c, s), chordOnly: lv(c, BASE_S), spanOnly: lv(BASE_C, s), panels: lv(c, s).base.mesh.panels }));
  const q = baseLv.base.flow.dynamicPressure_Pa * 1e-6, refs = baseLv.base.reference, Tscale = q * refs.semiArea_mm2 * refs.mac_mm;
  // axes: straight chord-fraction lines from root to tip (stand-ins for structural shear-centre axes)
  const axes = [0.25, 0.35, 0.45].map(f => { const a = physicalPoint(g, 0, f * g.rootChord), b = physicalPoint(g, L, f * g.tipChord), d = sub(b, a), l = Math.hypot(...d), e = d.map(v => v / l); return { f, a, b, e }; });
  const seqs = {}; for (const sn of ['standard', 'fine']) seqs[sn] = A.runSequence(g, cfg.flow, sn, { cache });
  const combs = {}; for (const sn of ['standard', 'fine']) combs[sn] = A.combineSequence(g, seqs[sn], {});
  stored.configs[name] = { baseRootWrench: baseLv.strips.reduce((t, r) => t.map((v, i) => v + r[2 + i]), [0, 0, 0, 0, 0, 0]), axes: {}, separability: { meshes: mixed.map(m => ({ chordPanels: m.c, spanPanels: m.s, panels: m.panels, factor: m.factor })), axes: {} } };
  for (const ax of axes) {
    const cuts = [{ y: 0, root: true, reference: ax.a, normal: ax.e }, ...[0.25, 0.5, 0.75].map(t => ({ y: t * L, reference: ax.a.map((v, d) => v + t * (ax.b[d] - v)), normal: ax.e }))];
    const truthRows = cuts.map(cut => {
      // y* of the plane on the independent load line
      let ystar = 0; if (!cut.root) { const sgn = y => dot(sub(lineAt(g, y), cut.reference), cut.normal); let lo = 0, hi = L; for (let k = 0; k < 80; k++) { const m = (lo + hi) / 2; if (sgn(m) < 0) lo = m; else hi = m; } ystar = (lo + hi) / 2; }
      const about = W => { const M = sub(W.slice(3), cross(cut.reference, W.slice(0, 3))); return [...W.slice(0, 3), ...M]; };
      const comp = l => about(cutOfLevel(g, l.strips, ystar));
      const ch = chordRef.map(comp), sp = spanRef.map(comp), b = comp(baseLv);
      const val = [], unc = [];
      for (let d = 0; d < 6; d++) {
        const c1 = observed(REF_CHORD.slice(2), ch.slice(2).map(v => v[d])), c2 = observed(REF_CHORD.slice(1, 4), ch.slice(1, 4).map(v => v[d]));
        const s1 = observed(REF_SPAN.slice(2), sp.slice(2).map(v => v[d])), s2 = observed(REF_SPAN.slice(1, 4), sp.slice(1, 4).map(v => v[d]));
        val.push(c1.ext + s1.ext - b[d]); unc.push(Math.abs(c1.ext - c2.ext) + Math.abs(s1.ext - s2.ext));
      }
      const n = cut.normal, T = dot(val.slice(3), n), uT = unc.slice(3).reduce((t, u, d) => t + Math.abs(n[d]) * u, 0);
      const bend = val.slice(3).map((v, d) => v - T * n[d]);
      // separability: mixed second differences of the six components, cross-term estimates X = factor x D
      const X = mixed.map(m => { const q = comp(m.both), qc = comp(m.chordOnly), qs = comp(m.spanOnly); return q.map((v, d) => m.factor * (v - qc[d] - qs[d] + b[d])); });
      const xT = X.map(x => dot(x.slice(3), n)), xF = X.map(x => Math.hypot(...x.slice(0, 3))), xB = X.map(x => { const t = dot(x.slice(3), n); return Math.hypot(...x.slice(3).map((v, d) => v - t * n[d])); });
      return { y: cut.y, root: !!cut.root, ystar, T, uT, F: val.slice(0, 3), uF: Math.hypot(...unc.slice(0, 3)), Fmag: Math.hypot(...val.slice(0, 3)), bend, Bmag: Math.hypot(...bend), uB: Math.hypot(...unc.slice(3)),
        xT, xF, xB, XT: Math.max(...xT.map(Math.abs)), XF: Math.max(...xF), XB: Math.max(...xB) };
    });
    stored.configs[name].axes[ax.f] = truthRows.map(r => ({ y: r.y, T: r.T, uT: r.uT, Fmag: r.Fmag, Bmag: r.Bmag }));
    stored.configs[name].separability.axes[ax.f] = truthRows.map(r => ({ y: r.y, crossTorque: r.xT, crossForce: r.xF, crossBending: r.xB }));
    for (const sn of ['standard', 'fine']) {
      const adm = A.admission(g, seqs[sn], combs[sn], cuts);
      const torques = adm.rows.filter(r => r.kind === 'torque');
      torques.forEach((r, i) => {
        const t = truthRows[i], err = Math.abs(r.value - t.T), denom = Math.abs(r.value);
        results.push({ config: name, axis: ax.f, seq: sn, kind: 'torque', y: t.y, est: r.value, U: r.uncertainty, truth: t.T, uTruth: t.uT, X: t.XT, ratio: err / r.uncertainty, strict: (err + t.uT) / r.uncertainty, strictX: (err + t.uT + t.XT) / r.uncertainty, resolved: r.resolved, signResolved: r.signResolved, meshSignsAgree: r.meshSignsAgree, signWrong: Math.sign(r.value) !== Math.sign(t.T), measure: r.relative, trueMeasure: err / denom, strictMeasure: (err + t.uT + t.XT) / denom, tol: r.tolerance, Tscale });
      });
      for (const kind of ['force', 'bending']) {
        const r = adm.rows.find(x => x.kind === kind), t = truthRows[0], ref = kind === 'force' ? t.F : t.bend, uref = kind === 'force' ? t.uF : t.uB, X = kind === 'force' ? t.XF : t.XB, err = Math.hypot(...r.vector.map((v, d) => v - ref[d]));
        results.push({ config: name, axis: ax.f, seq: sn, kind, y: 0, est: r.value, U: r.uncertainty, truth: Math.hypot(...ref), uTruth: uref, X, ratio: err / r.uncertainty, strict: (err + uref) / r.uncertainty, strictX: (err + uref + X) / r.uncertainty, resolved: r.resolved, measure: r.measure, trueMeasure: err / Math.hypot(...ref), strictMeasure: (err + uref + X) / Math.hypot(...ref), tol: r.tolerance });
      }
    }
  }
  if (name === 'course4') {
    // reference six-component load of the course wing on the editable fixture's Fine delivery grid (same outer shape),
    // per component observed-order Richardson of the reference levels' outboard wrench about the origin
    const IO = require('../wing_study_io.js'), fixture = IO.importPrintedStudy(readFileSync(path.join(here, '../../../../tests/fixtures/wing_lab_editable_browser.json'), 'utf8'), E).state;
    const sg = E.makeGeometry(fixture.geometry);
    if (IO.sha256(A.geometryKey(sg)) !== IO.sha256(A.geometryKey(g))) throw new Error('The editable fixture no longer has the course wing outer shape.');
    const snap = [...E.ribStations(sg), ...E.seams(sg), ...(sg.stations || []).map(s => s.eta * L), ...sg.spars.map(s => s.length)];
    const grid = A.combineSequence(sg, seqs.fine, { snapStations: snap }).stations, cutYs = Array.from({ length: A.ADMISSION.torsionStations }, (_, k) => k * L / A.ADMISSION.torsionStations);
    // C: outboard wrench about the origin (builds the load); u: its uncertainty with the moment taken about the load-line
    // point r(y) of the station (small lever arms to the structural axis, so the reference torque bound stays tight)
    const refAt = y => { const r = lineAt(g, y), shift = W => [...W.slice(0, 3), ...sub(W.slice(3), cross(r, W.slice(0, 3)))];
      const ch = chordRef.map(l => cutOfLevel(g, l.strips, y)), sp = spanRef.map(l => cutOfLevel(g, l.strips, y)), b = cutOfLevel(g, baseLv.strips, y), C = [], u = [];
      const ext = (CH, SP, B, d) => { const c1 = observed(REF_CHORD.slice(2), CH.slice(2).map(v => v[d])), c2 = observed(REF_CHORD.slice(1, 4), CH.slice(1, 4).map(v => v[d])), s1 = observed(REF_SPAN.slice(2), SP.slice(2).map(v => v[d])), s2 = observed(REF_SPAN.slice(1, 4), SP.slice(1, 4).map(v => v[d])); return { value: c1.ext + s1.ext - B[d], u: Math.abs(c1.ext - c2.ext) + Math.abs(s1.ext - s2.ext) }; };
      const chR = ch.map(shift), spR = sp.map(shift), bR = shift(b);
      for (let d = 0; d < 6; d++) { C.push(ext(ch, sp, b, d).value); u.push(ext(chR, spR, bR, d).u); }
      return { C, u, r }; };
    const atGrid = grid.map(refAt), atCuts = cutYs.map(refAt); atGrid[atGrid.length - 1] = { C: [0, 0, 0, 0, 0, 0], u: [0, 0, 0, 0, 0, 0] };
    stored.twistReference = { config: name, flow: cfg.flow, fixture: 'tests/fixtures/wing_lab_editable_browser.json', note: 'Outboard six-component wrench (N, N mm about the aircraft origin) of the reference load at the strip stations of the Fine delivery grid of the editable fixture (strips = differences) and at the torsion cut stations k L / 16; uncertainties of the force and of the moment about the quarter-chord load-line point of each station (cutLinePoint).',
      stations: grid, wrench: atGrid.map(r => r.C), uncertainty: atGrid.map(r => r.u), cutStations: cutYs, cutWrench: atCuts.map(r => r.C), cutUncertainty: atCuts.map(r => r.u), cutLinePoint: atCuts.map(r => r.r) };
    console.log(`  twist reference: course wing load on ${grid.length - 1} strips of the editable fixture's Fine grid; root wrench ${atGrid[0].C.map(v => v.toFixed(4)).join(', ')} (uncertainty ${atGrid[0].u.map(v => v.toExponential(1)).join(', ')})`);
  }
  const lc = combs.standard.consistency, lcf = combs.fine.consistency;
  console.log(`${name}: references and both sequences in ${((Date.now() - tc) / 1000).toFixed(0)} s; extrapolated CL pressure/Trefftz ${lc.lift.pressure.toFixed(4)}/${lc.lift.trefftz.toFixed(4)} (Standard), ${lcf.lift.pressure.toFixed(4)}/${lcf.lift.trefftz.toFixed(4)} (Fine); CDp/CDi ${lc.drag.pressure.toFixed(5)}/${lc.drag.trefftz.toFixed(5)} (Standard), ${lcf.drag.pressure.toFixed(5)}/${lcf.drag.trefftz.toFixed(5)} (Fine)`);
  { const sep = stored.configs[name].separability, root = f => sep.axes[f][0];
    console.log(`  separability (mixed meshes ${mixed.map(m => `${2 * m.c} x ${m.s} (${m.panels} panels)`).join(', ')}): cross-term estimates X(32,16) of the root loads from 9 D, 4 D, 2.25 D:`);
    console.log(`    torque about the 25/35/45% chord axes (N mm): ${[0.25, 0.35, 0.45].map(f => root(f).crossTorque.map(v => v.toFixed(3)).join(' / ')).join(';  ')}`);
    console.log(`    |force| (N): ${root(0.25).crossForce.map(v => v.toFixed(4)).join(' / ')};  |bending| about the 25% axis (N mm): ${root(0.25).crossBending.map(v => v.toFixed(3)).join(' / ')}`); }
}
// report
const pad = (s, n) => String(s).padEnd(n);
console.log('\nconfig    axis seq      quantity            estimate      U          reference (+-u)       |X|     |err|/U  strict strict+  e(est)  e(true) resolved');
for (const r of results) console.log(`${pad(r.config, 9)} ${pad(r.axis, 4)} ${pad(r.seq, 8)} ${pad(r.kind === 'torque' ? `torque y=${r.y.toFixed(0)}` : r.kind, 18)} ${r.est.toFixed(4).padStart(10)} ${r.U.toFixed(4).padStart(9)}  ${r.truth.toFixed(4).padStart(10)} (+-${r.uTruth.toFixed(4)}) ${r.X.toFixed(4).padStart(7)}  ${r.ratio.toFixed(2).padStart(6)} ${r.strict.toFixed(2).padStart(6)} ${r.strictX.toFixed(2).padStart(6)} ${(100 * r.measure).toFixed(1).padStart(6)}% ${(100 * r.trueMeasure).toFixed(1).padStart(6)}% ${r.resolved ? 'yes' : r.kind === 'torque' && !r.signResolved ? 'no (sign)' : 'no'}`);
const summary = {};
for (const sn of ['standard', 'fine']) for (const kind of ['torque', 'force', 'bending']) {
  const rs = results.filter(r => r.seq === sn && r.kind === kind), worst = rs.reduce((a, b) => (b.ratio > a.ratio ? b : a));
  const resolvedBad = rs.filter(r => r.resolved && r.trueMeasure > r.tol), resolvedStrictBad = rs.filter(r => r.resolved && r.strictMeasure > r.tol);
  const sign = kind === 'torque' ? { signResolved: rs.filter(r => r.signResolved).length, signResolvedButWrong: rs.filter(r => r.signResolved && r.signWrong).length, wrongSignCases: rs.filter(r => r.signWrong).length, wrongSignFlagged: rs.filter(r => r.signWrong && !r.signResolved).length, meshSignsDisagree: rs.filter(r => !r.meshSignsAgree).length } : {};
  summary[`${sn}/${kind}`] = { cases: rs.length, maxRatio: worst.ratio, worst: `${worst.config} axis ${worst.axis} y ${worst.y}`, covered: rs.filter(r => r.ratio <= 1).length, strictCovered: rs.filter(r => r.strict <= 1).length, strictXCovered: rs.filter(r => r.strictX <= 1).length, maxStrictX: Math.max(...rs.map(r => r.strictX)), resolved: rs.filter(r => r.resolved).length, resolvedWithTrueErrorAboveTolerance: resolvedBad.length, resolvedWithStrictErrorAboveTolerance: resolvedStrictBad.length, ...sign };
}
console.log('\nsummary (coverage: |estimate - reference| <= U; strict adds the reference uncertainty; strict+ also adds the estimated cross-term error |X(32,16)|; torque tolerance is 10% of |T| itself):');
for (const [k, v] of Object.entries(summary)) console.log(`  ${pad(k, 17)} ${v.covered}/${v.cases} covered (strict ${v.strictCovered}/${v.cases}, strict+ ${v.strictXCovered}/${v.cases}, largest strict+ ratio ${v.maxStrictX.toFixed(2)}), largest |err|/U ${v.maxRatio.toFixed(2)} (${v.worst}); resolved ${v.resolved}; resolved with error above tolerance: ${v.resolvedWithTrueErrorAboveTolerance} (strict+ ${v.resolvedWithStrictErrorAboveTolerance})${k.endsWith('torque') ? `; sign resolved ${v.signResolved}, of which wrong ${v.signResolvedButWrong}; estimates with the wrong sign ${v.wrongSignCases}, all flagged sign-unresolved: ${v.wrongSignFlagged === v.wrongSignCases}; meshes disagree in sign at ${v.meshSignsDisagree}` : ''}`);
{ // torques whose Standard and Fine estimates have opposite signs: both must be flagged sign-unresolved
  const key = r => `${r.config}|${r.axis}|${r.y}`, std = new Map(results.filter(r => r.seq === 'standard' && r.kind === 'torque').map(r => [key(r), r]));
  const pairs = results.filter(r => r.seq === 'fine' && r.kind === 'torque').map(f => [std.get(key(f)), f]).filter(([a, b]) => a && Math.sign(a.est) !== Math.sign(b.est));
  summary.sequenceSignDisagreement = { cases: pairs.length, bothFlagged: pairs.filter(([a, b]) => !a.signResolved && !b.signResolved).length, list: pairs.map(([a, b]) => `${a.config} axis ${a.axis} y ${a.y.toFixed(0)}: Standard ${a.est.toFixed(3)}, Fine ${b.est.toFixed(3)}, reference ${a.truth.toFixed(3)}`) };
  console.log(`  Standard and Fine torques of opposite sign: ${pairs.length} cases, flagged sign-unresolved in both sequences: ${summary.sequenceSignDisagreement.bothFlagged}${pairs.length ? ` (${summary.sequenceSignDisagreement.list.join('; ')})` : ''}`);
}
stored.summary = summary;
console.log(`\nreference_study: ${results.length} quantity checks in ${((Date.now() - t0) / 60000).toFixed(1)} min`);
if (write) { writeFileSync(path.join(here, 'admission_reference.json'), JSON.stringify(stored, null, 1) + '\n'); console.log('wrote validation/admission_reference.json'); }
const failed = Object.entries(summary).filter(([k]) => k.includes('/')).some(([, v]) => v.resolvedWithTrueErrorAboveTolerance > 0 || v.resolvedWithStrictErrorAboveTolerance > 0 || v.covered < v.cases || v.signResolvedButWrong > 0) || summary.sequenceSignDisagreement.bothFlagged !== summary.sequenceSignDisagreement.cases;
if (failed) { console.log('VALIDATION FAILED'); process.exitCode = 1; }
