/* Lecture 03 links deliberately replace loads rather than adding to an old study. */
const Lecture03BeamCases = Object.freeze({
  'l03-centre': {support:'cantilever',loads:[{kind:'point',position:225,force:2}]},
  'l03-tip': {support:'cantilever',loads:[{kind:'point',position:450,force:2}]},
  'l03-uniform': {support:'cantilever',loads:[{kind:'distributed',start:0,end:450,qStart:2/450,qEnd:2/450}]},
  'l03-simple': {support:'simply-supported',loads:[{kind:'point',position:225,force:2}]},
  'l03-fixed': {support:'fixed-fixed',loads:[{kind:'point',position:225,force:2}]},
  'l03-lift': {support:'cantilever',loads:[{kind:'distributed',start:0,end:450,qStart:-2/450,qEnd:-2/450}]}
});
/*
 * MIE 446 Beam Lab — controller for the beam workspace (#foundations).
 * Uses BeamSections, BeamLearningEngine, BeamStudy, BeamDiagrams, BeamSolution and CompanionTools.
 * The inputs form a DRAFT. Every result shown comes from the last SOLVED model. When the draft differs
 * from that model, or the last solve was rejected, results are marked stale, the status says so and
 * exports are disabled: an invalid or pending change is never presented as the current solution.
 */
(() => {
  'use strict';
  const B=BeamLearningEngine, D=BeamDiagrams, Study=BeamStudy, Sol=BeamSolution, SEC=BeamSections;
  const host=document.querySelector('#foundations');
  const $=s=>document.querySelector(s), $$=(s,root=document)=>[...root.querySelectorAll(s)];
  const esc=Study.escapeHtml, fmt=D.fmt, f=(x,n=3)=>Number(x).toFixed(n);
  const clone=v=>JSON.parse(JSON.stringify(v));
  const plain=v=>String(Number(Number(v).toPrecision(6)));
  const raf=fn=>(window.requestAnimationFrame?window.requestAnimationFrame(fn):setTimeout(fn,16));
  const reducedMotion=()=>!!(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const MAX_LOADS=Study.LIMITS.loads;   // the load form and imported/shared studies use the same limit
  const LD=B.loads, LP=LD.profiles;      // distributed-load helpers (linear, elliptic, parabolic, table)
  const CURVE_LAW={
    elliptic:{start:'w(x) = w₀√(1 − s²), s = (x − a)/ℓ: maximum w₀ at a, zero at b',end:'w(x) = w₀√(1 − (1 − s)²): zero at a, maximum w₀ at b',middle:'w(x) = w₀√(1 − (2s − 1)²): zero at a and b, maximum w₀ at the middle'},
    parabolic:{start:'w(x) = w₀(1 − s²), s = (x − a)/ℓ: maximum w₀ at a with zero slope, zero at b',end:'w(x) = w₀(1 − (1 − s)²): zero at a, maximum w₀ at b with zero slope',middle:'w(x) = 4w₀ s(1 − s): zero at a and b, maximum w₀ at the middle'}};
  const CURVE_F={elliptic:'F = πw₀ℓ/4, so w₀ = 4F/(πℓ)',parabolic:'F = 2w₀ℓ/3, so w₀ = 3F/(2ℓ)'};
  const CENTROID_TEXT={elliptic:{start:'x̄ = a + 4ℓ/(3π)',end:'x̄ = b − 4ℓ/(3π)',middle:'x̄ = (a + b)/2'},parabolic:{start:'x̄ = a + 3ℓ/8',end:'x̄ = a + 5ℓ/8',middle:'x̄ = (a + b)/2'}};
  // Normal opening: an unrestrained beam with NO applied load and self-weight off. Supports and loads come from the user, a study
  // file or share link, or an explicitly chosen Lecture 03 example (buttons or ?beamCase= deep links).
  const BASE=Object.freeze({length:450,E:2000,density:1.24,elements:30,section:{shape:'rectangle',width:20,height:10},
    supports:[],hinges:[],loads:[],selfWeight:false});
  const DESCRIBE={fixed:'v = 0 and θ = 0; vertical reaction and reaction couple',
    pin:'v = 0; rotation free; vertical reaction, no couple (horizontal translation restrained)',
    roller:'v = 0; rotation and horizontal translation free; vertical reaction, no couple',
    free:'no restraint; no support reaction; end can move and rotate'};

  /* ------------------------------------------------------------ model setup */

  function presetModel(name) {
    const p=Lecture03BeamCases[name];
    return Study.modelFromInput(B.normalize({length:p.length??450,width:p.width??20,height:p.height??10,E:p.E??2000,
      density:BASE.density,elements:BASE.elements,support:p.support,simpleArrangement:p.simpleArrangement,loads:clone(p.loads)}));
  }
  const params=new URLSearchParams(window.location.search);
  const caseName=params.get('beamCase');
  const lectureCase=caseName!==null&&Object.prototype.hasOwnProperty.call(Lecture03BeamCases,caseName)?caseName:null;
  let startMessage='', initial=clone(BASE), hasInitialStudy=!!lectureCase;
  if(lectureCase) initial=presetModel(lectureCase);
  else if(params.has('beam')) {
    try {const shared=Study.decodeShare(params.get('beam'));B.solve({...shared,modes:false});initial=shared;hasInitialStudy=true;startMessage='Shared study opened from the link and solved.';}
    catch(e) {startMessage=`The shared beam link could not be opened: ${e.message} Start by entering a new beam model.`;}
  }

  // One cut station for the whole page: the Diagrams readout, the plot markers, the beam picture and Cut & section.
  const st={model:initial,solved:null,error:'',mechanism:null,draftError:'',tab:'diagrams',cut:{x:initial.length/2,side:'both',limit:'left',note:''},
    mode:0,animated:false,phase:0,placing:null,drag:null,editLoad:null,editorLoad:null,blankSetup:false,compare:{A:null,B:null},showDeflection:true,autoSolve:false,
    cache:{},message:''};
  const cutTab=()=>st.tab==='cut'||st.tab==='diagrams';   // tabs that show (and let you drag) the cut station

  /* ------------------------------------------------------------------ layout */

  const icon={
    pin:'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 4l-6 9h12z" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M3 16h14" stroke="currentColor" stroke-width="1.8"/></svg>',
    roller:'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M10 3l-5 8h10z" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="7" cy="14" r="2" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="13" cy="14" r="2" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M3 17.5h14" stroke="currentColor" stroke-width="1.5"/></svg>',
    fixed:'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M7 3v14" stroke="currentColor" stroke-width="2.2"/><path d="M7 5l-4 3M7 9l-4 3M7 13l-4 3M7 10h10" stroke="currentColor" stroke-width="1.5"/></svg>',
    hinge:'<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M2 10h5M13 10h5" stroke="currentColor" stroke-width="2.2"/><circle cx="10" cy="10" r="3" fill="none" stroke="currentColor" stroke-width="1.8"/></svg>'};
  const field=(id,label,unit,attrs='')=>`<label class="bl-field" id="${id}Field"><span id="${id}Label">${label}</span><span class="bl-input"><input id="${id}" type="number" step="any" inputmode="decimal" ${attrs}><span class="bl-unit">${unit}</span></span></label>`;
  const named=(name,label,unit,attrs='')=>`<label class="bl-field"><span>${label}</span><span class="bl-input"><input name="${name}" type="number" step="any" inputmode="decimal" required ${attrs}>${unit?`<span class="bl-unit">${unit}</span>`:''}</span></label>`;

  host.classList.add('bl');
  host.innerHTML=`
  <header class="bl-header">
    <div class="bl-brand"><svg viewBox="0 0 40 28" aria-hidden="true"><path d="M3 12h34" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="M6 15l-4 7h8z M34 15l-4 7h8z" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M20 2v8" stroke="currentColor" stroke-width="2"/><path d="M17 7l3 3 3-3" fill="none" stroke="currentColor" stroke-width="2"/></svg>
      <div><b>Beam Virtual Lab</b><small>MIE 446 · Aerospace Structures</small></div></div>
    <button type="button" class="bl-navtoggle" id="beamNavToggle" aria-expanded="false" aria-controls="beamNav">Workspaces</button>
    <nav class="bl-nav workspace-nav" id="beamNav" aria-label="Workspaces">
      <button class="workspace-link" type="button" data-stage="beam" aria-pressed="true">Beam</button>
      <a class="workspace-link" href="truss-lab.html">Truss</a>
      <button class="workspace-link" type="button" data-stage="wing" aria-pressed="false">Wing</button>
      <button class="workspace-link" type="button" data-stage="metal" aria-pressed="false">Full-scale wing</button>
      <details class="bl-companion"><summary class="workspace-link">Wing geometry tool</summary><div class="bl-companion-pop" data-companion="vinco"></div></details>
    </nav>
    <div class="bl-start-guide"><button type="button" class="bl-btn bl-btn-primary" id="beamGuideOpen">User manual · Start here</button><span>1 · Length, material &amp; mesh → 2 · Section shape &amp; dimensions → 3 · Supports → 4 · Loads &amp; values → 5 · Solve</span></div>
    <p class="bl-intro">Results belong to the last <b>solved</b> model. Changes remain pending until you press <b>Solve</b>.</p>
  </header>
  <div class="bl-app">
    <aside class="bl-side" aria-label="Beam inputs">
      <div class="bl-run">
        <div class="bl-status" id="beamRunStatus" role="status" aria-live="polite"><span class="bl-chip" id="beamChip">Starting</span><span id="beamRunText">Solving the default study…</span></div>
        <div class="bl-run-actions"><button type="button" class="bl-btn bl-btn-primary bl-btn-solve" id="beamSolve">Solve</button></div>
        <label class="bl-auto"><input type="checkbox" id="beamAutoSolve"> Solve automatically after each valid change</label>
        <button type="button" class="bl-btn bl-btn-sm" id="beamRevert" hidden>Revert inputs to the last solved model</button>
      </div>
      <details class="bl-acc" open><summary><span class="bl-step">1</span>Span, material &amp; mesh</summary><div class="bl-acc-body">
        <form id="beamGeometry" novalidate><div class="bl-grid2">
          ${named('length','Length L','mm')}${named('E','Elastic modulus E','MPa')}${named('density','Density ρ','g/cm³')}${named('elements','Requested elements','',"step='1' min='4' max='100'")}
        </div><button type="submit" class="sr-only">Solve</button></form>
        <p class="bl-help">Elements are numerical subdivisions, not physical parts. Their number controls the mesh resolution, not the physical beam. Support, point-load, load-boundary and hinge stations are always mesh nodes.</p>
        <details class="bl-box" id="beamMeshHelp"><summary>Why choose 10, 30 or 40 elements?</summary>
          <p class="bl-help">Each Euler–Bernoulli element joins two nodes. The solver finds nodal displacement and rotation, then interpolates the shape between nodes. For a 450 mm beam, nominal lengths are 45 mm with 10 elements, 15 mm with 30, and 11.25 mm with 40. Extra required stations can change the actual count and spacing.</p>
          <svg role="img" aria-label="The same beam divided into 10, 30 and 40 numerical elements" viewBox="0 0 430 120" style="width:100%">${[10,30,40].map((n,j)=>`<text x="4" y="${24+j*36}" fill="currentColor" font-size="13">${n}</text><path d="M42 ${20+j*36}H420" stroke="#166bbb" stroke-width="3"/>${Array.from({length:n+1},(_,k)=>`<path d="M${42+378*k/n} ${15+j*36}v10" stroke="currentColor"/>`).join('')}`).join('')}</svg>
          <p class="bl-help">More elements usually improve interpolation and vibration estimates but cost more calculation; they do not strengthen the beam or repair wrong inputs. In these constant-EI teaching beams, exact load integration and equilibrium recovery can already give almost unchanged reactions and V/M, even on a coarse mesh. Between-node displacement/rotation and frequencies can still change. Similar numbers do not make a mesh study pointless or prove the physical model correct.</p>
          <p class="bl-help">To check mesh sensitivity, solve the same model with, for example, 10, 30 and 40 elements, keeping loads, supports, section and material fixed. Compare the same displacement/rotation station and, when relevant, the same mode. Check absolute differences as well as relative differences; do not divide by a near-zero value. There is no universal guaranteed element count: choose a resolution appropriate to the quantities of interest and the accuracy required.</p>
        </details>
      </div></details>
      <details class="bl-acc" open><summary><span class="bl-step">2</span>Cross-section <span class="bl-badge" id="beamSectionBadge"></span></summary><div class="bl-acc-body">
        <label class="bl-field"><span>Shape</span><select class="bl-select" id="beamShape"><option value="">Choose a cross-section…</option>${Object.entries(SEC.SHAPES).map(([k,v])=>`<option value="${k}">${v.label}</option>`).join('')}</select></label>
        <div class="bl-grid2" id="beamSectionFields"></div>
        <div id="beamSectionView"></div>
      </div></details>
      <details class="bl-acc" open><summary><span class="bl-step">3</span>Supports &amp; hinges</summary><div class="bl-acc-body">
        <div class="bl-grid2" id="beamSupportOptions">
          <label class="bl-field"><span>Left end · x = 0</span><select class="bl-select" id="beamleftSupport">${['fixed','pin','roller','free'].map(k=>`<option value="${k}">${k}</option>`).join('')}</select></label>
          <label class="bl-field"><span>Right end · x = L</span><select class="bl-select" id="beamrightSupport">${['fixed','pin','roller','free'].map(k=>`<option value="${k}">${k}</option>`).join('')}</select></label>
        </div>
        <div><h4 class="bl-mini">Interior supports</h4><ol class="bl-list" id="beamInteriorList"></ol>
          <div class="bl-row"><button type="button" class="bl-btn bl-btn-sm" id="beamAddSupport">+ Interior support</button><button type="button" class="bl-btn bl-btn-sm" id="beamAddHinge">+ Internal hinge</button></div></div>
        <div><h4 class="bl-mini">Internal hinges (moment releases)</h4><ol class="bl-list" id="beamHingeList"></ol></div>
        <div class="bl-stability" id="beamSupportStatus" role="status" aria-live="polite"></div>
        <p class="bl-help">Or use <b>Place</b> above the beam picture and click the beam; drag interior supports and hinges to move them. This model solves transverse bending (v, θ) only; at least one pin or clamp must also stop the beam sliding horizontally.</p>
      </div></details>
      <details class="bl-acc" open><summary><span class="bl-step">4</span>Loads <span class="bl-badge" id="beamLoadBadge"></span></summary><div class="bl-acc-body">
        <p class="bl-help" style="margin-top:0">Positive force, line load and displacement point <b>down</b>; negative values point up. Positive couples are <b>clockwise</b>. q is force per length (N/mm), not pressure.</p>
        <div id="beamLoads"></div>
        <div class="bl-row"><button type="button" class="bl-btn bl-btn-sm bl-clear" id="beamClear">Clear All Loads</button></div>
        <label class="bl-check"><input type="checkbox" id="beamSelfWeight"><span>Include self-weight ρgA <span class="bl-help" id="beamSelfWeightValue"></span></span></label>
        <form id="beamLoadForm" novalidate class="bl-box"><div class="bl-grid2">
          <label class="bl-field" style="grid-column:1/-1"><span>Load type</span><select class="bl-select" id="beamLoadKind">
            <option value="point">Point force P</option><option value="moment">Point couple C</option><option value="rectangle">Uniform q</option>
            <option value="triangle">Triangular (zero at start)</option><option value="triangle-root">Triangular (zero at end)</option><option value="trapezoid">Trapezoidal</option>
            <option value="elliptic">Elliptic (curved)</option><option value="parabolic">Parabolic (curved)</option></select></label>
          ${field('beamLoadA','Position x','mm','required')}${field('beamLoadB','End','mm')}
          ${field('beamP','Force P (+ down)','N')}${field('beamC','Couple C (+ clockwise)','N·mm')}
          ${field('beamQ0','q at start','N/mm')}${field('beamQ1','q at end','N/mm')}
          <label class="bl-field" id="beamCurveShapeField" style="grid-column:1/-1"><span>Where is the maximum?</span><select class="bl-select" id="beamCurveShape">
            <option value="start">At the start a, zero at the end b (root-heavy)</option><option value="end">At the end b, zero at the start a (reversed)</option>
            <option value="middle">Symmetric: zero at both ends, maximum in the middle</option></select></label>
          <label class="bl-field" id="beamCurveBasisField"><span>Enter</span><select class="bl-select" id="beamCurveBasis">
            <option value="total">Total force F</option><option value="peak">Peak intensity w₀</option></select></label>
          ${field('beamCurveValue','Total force F (+ down)','N')}
        </div><p class="bl-help"><b>F (N) is total force; q (N/mm) is force per length.</b> A uniform 1000 N total over 450 mm means q = 2.222 N/mm, not 1000 N/mm. Curves: enter either total F or peak w₀; the other is derived. Change start/end and maximum location to inspect the law. Other nonlinear laws can be entered as a CSV table (piecewise-linear approximation).</p><p class="bl-help bl-curve-law" id="beamCurveLaw" hidden></p><div id="beamLoadPreview" aria-live="polite"></div><p class="bl-err" id="beamLoadError" role="alert" hidden></p>
        <div class="bl-row" style="margin-top:10px"><button type="submit" class="bl-btn bl-btn-primary" id="beamLoadSubmit">Add load &amp; solve</button><button type="button" class="bl-btn" id="beamLoadCancel" hidden>Cancel edit</button></div></form>
        <details class="bl-box bl-csv" id="beamCsvBox"><summary>Import a line-load table (CSV)</summary>
          ${LP.powerControls('beam',{length:'mm',force:'N'})}
          <p class="bl-help">Two columns with units in the header: <code>x_mm,w_N_per_mm</code> (w + down). 2–${LP.LIMITS.tableRows} rows, x strictly increasing on 0–L. The load is <b>linear between rows</b> and zero outside the first and last row; nothing is resampled or truncated. Lines starting with # are ignored. <button type="button" class="bl-btn bl-btn-sm" id="beamCsvTemplate">Download template</button></p>
          <label class="bl-field"><span>CSV file</span><input type="file" id="beamCsvFile" accept=".csv,text/csv,text/plain"></label>
          <label class="bl-field"><span>…or paste the table here</span><textarea id="beamCsvText" rows="5" spellcheck="false" class="bl-notes" placeholder="x_mm,w_N_per_mm&#10;0,0.002&#10;450,0"></textarea></label>
          <div class="bl-row"><button type="button" class="bl-btn" id="beamCsvPreview">Preview table</button></div>
          <div id="beamCsvResult" role="status" aria-live="polite"></div>
          <fieldset class="bl-csv-mode" id="beamCsvMode" hidden><legend>Apply the table</legend>
            <label class="bl-check"><input type="radio" name="beamCsvMode" value="add" checked><span>Add it to the current loads</span></label>
            <label class="bl-check"><input type="radio" name="beamCsvMode" value="replace"><span>Replace all current loads with it</span></label></fieldset>
          <div class="bl-row"><button type="button" class="bl-btn bl-btn-primary" id="beamCsvApply" disabled>Apply table &amp; solve</button><button type="button" class="bl-btn" id="beamCsvCancel">Cancel</button></div>
        </details>
      </div></details>
      <details class="bl-acc"><summary><span class="bl-step">5</span>Examples &amp; presets</summary><div class="bl-acc-body">
        <div><h4 class="bl-mini">Lecture 03 examples · 450 × 20 × 10 mm, E = 2000 MPa</h4><div class="bl-row">
          <button type="button" class="bl-btn bl-btn-sm" data-beam-preset="l03-tip">A · tip force</button><button type="button" class="bl-btn bl-btn-sm" data-beam-preset="l03-centre">Cantilever · centre force</button>
          <button type="button" class="bl-btn bl-btn-sm" data-beam-preset="l03-uniform">B · uniform 2 N</button><button type="button" class="bl-btn bl-btn-sm" data-beam-preset="l03-lift">B · uniform lift</button>
          <button type="button" class="bl-btn bl-btn-sm" data-beam-preset="l03-simple">C1 · pin–roller</button><button type="button" class="bl-btn bl-btn-sm" data-beam-preset="l03-fixed">C2 · fixed–fixed</button></div></div>
      </div></details>
    </aside>

    <section class="bl-card bl-model" aria-labelledby="beamModelTitle">
      <div class="bl-toolbar bl-file-tools" role="group" aria-label="Beam study files"><button type="button" class="bl-btn" id="beamOpenJson">Open JSON</button><button type="button" class="bl-btn" id="beamSaveJson">Save JSON</button><span class="bl-help" id="beamFileStatus" role="status" aria-live="polite">Save current inputs, including unfinished restraints. Open restores an editable study; results are never trusted from a file.</span></div>
      <div class="bl-card-head"><div><h2 id="beamModelTitle">Beam</h2><p class="bl-sub" id="beamModelSub"></p></div>
        <div class="bl-toolbar" role="toolbar" aria-label="Place on the beam"><span>Place</span>
          ${['pin','roller','fixed','hinge'].map(k=>`<button type="button" class="bl-tool" data-place="${k}" aria-pressed="false" title="Click the beam to place a ${k}">${icon[k]}${k[0].toUpperCase()+k.slice(1)}</button>`).join('')}
          <button type="button" class="bl-tool bl-clear" id="beamClearSupports">Clear All Supports</button>
          <button type="button" class="bl-tool" id="beamShowDefl" aria-pressed="true" title="Show the exaggerated deflected shape">Deflected shape</button></div></div>
      <div class="bl-toolbar bl-load-tools" role="toolbar" aria-label="Place loads on the beam"><span>Loads</span>
        <label>Drawing scale <select id="beamLoadScale" class="bl-select"><option value="common">Shared intensity scale</option><option value="independent">Independent heights · shape only</option></select></label>
        ${[['point','↓ Point force'],['moment','↻ Couple'],['rectangle','↓↓ Uniform'],['triangle','◿ Triangle →'],['triangle-root','◺ Triangle ←'],['trapezoid','▱ Trapezoid'],['elliptic','◠ Elliptic'],['parabolic','⌒ Parabolic']].map(([k,label])=>`<button type="button" class="bl-tool" data-place="load:${k}" aria-pressed="false">${label}</button>`).join('')}
        <button type="button" class="bl-tool" id="beamStopPlacing">Cancel / select</button>
        <button type="button" class="bl-tool bl-clear" id="beamClearPicture">Clear All Loads</button>
        <button type="button" class="bl-tool" id="beamUndo" title="Undo model edit (Ctrl/Cmd+Z)" disabled>↶ Undo</button>
        <button type="button" class="bl-tool" id="beamRedo" title="Redo model edit (Ctrl/Cmd+Shift+Z or Ctrl+Y)" disabled>↷ Redo</button>
      </div>
      <p class="bl-help" id="beamGraphicHelp" role="status">Choose a force/couple and click its station; for a line load, drag over its interval. Enter values in the compact box beside your selection and confirm with Enter or Apply. Purple numbered handles: click to edit, drag to move. Select an item and press Delete outside a text field to remove it. No load is added by selecting a tool.</p>
      <div class="bl-row"><button type="button" class="bl-btn bl-btn-sm" id="beamDeleteSelected" disabled>Delete selected item</button><span id="beamSelection" class="bl-help" role="status">Select a load, support or hinge; press Delete to remove it.</span></div>
      <div id="beamPicture" class="bl-picture"></div>
      <p class="bl-picture-note" id="beamPictureNote"></p>
      <section class="bl-load-editor" id="beamLoadEditor" aria-labelledby="beamLoadEditorTitle" hidden><button type="button" class="bl-btn bl-editor-close" id="beamLoadEditorClose" aria-label="Close graphical load editor and return parameters to the left">×</button><h3 id="beamLoadEditorTitle">Load parameters</h3><p class="bl-help">Edit position, interval and magnitude, then confirm. Close × only hides this editor; it does not delete a load. Use the removal controls below or select a purple handle and press Delete.</p><div class="bl-row"><button type="button" class="bl-btn bl-btn-sm" id="beamEditorDelete" disabled>Delete this load</button><button type="button" class="bl-btn bl-btn-sm bl-clear" id="beamEditorClear">Clear All Loads</button></div></section>
      <div id="beamKpis" class="bl-kpis" aria-label="Key results"></div>
      <div id="beamNotice"></div>
      <p id="beamStatus" class="bl-message" role="status" aria-live="polite"></p>
    </section>

    <section class="bl-card bl-results" aria-label="Results">
      <div class="bl-tabs" role="tablist" aria-label="Result views">
        ${[['diagrams','Diagrams'],['cut','Cut &amp; section'],['solution','Solution'],['modes','Modes'],['compare','Compare A/B'],['report','Report &amp; export'],['learn','Learn']]
          .map(([k,t],i)=>`<button type="button" role="tab" id="beamTabBtn-${k}" data-tab="${k}" aria-controls="beamTab-${k}" aria-selected="${i===0}" tabindex="${i===0?0:-1}">${t}</button>`).join('')}
      </div>
      <div class="bl-stale" id="beamStale" role="status" hidden></div>
      <div class="bl-tabpanel" role="tabpanel" id="beamTab-diagrams" aria-labelledby="beamTabBtn-diagrams">
        <div class="bl-exportbar" role="group" aria-label="Download results">
          <span class="bl-help">Download:</span>
          <button type="button" class="bl-btn bl-btn-sm" data-export="stations">Station table (CSV)</button>
          <button type="button" class="bl-btn bl-btn-sm" data-export="samples">Download Chart Data (CSV)</button>
          <button type="button" class="bl-btn bl-btn-sm" data-export="reactions">Reactions (CSV)</button>
          <button type="button" class="bl-btn bl-btn-sm" data-export="print">Report (print or PDF)</button>
          <button type="button" class="bl-btn bl-btn-sm bl-btn-ghost" data-open-tab="report">Study file and share link</button>
          <span class="bl-help">Images: use Download Chart Image (PNG) below each chart. CSV downloads contain numbers, not pictures.</span>
        </div>
        <p class="bl-help" id="beamDiagExportStatus" role="status" aria-live="polite"></p>
        <div id="beamReactions"></div>
        <div id="beamReactionShear"></div>
        <section class="bl-box bl-station" id="beamStation" aria-labelledby="beamStationTitle">
          <h3 id="beamStationTitle">Exact values at a station x</h3>
          <p class="bl-help bl-station-how">Type x, use a button, click or tap a plot, or drag the orange cut line on the beam picture. It is the same cut as in <b>Cut &amp; section</b>, and the plots below mark it.</p>
          <form class="bl-station-bar" id="beamStationForm" novalidate>
            <label class="bl-field bl-station-x"><span>Station x</span><span class="bl-input"><input id="beamStationX" type="number" step="any" inputmode="decimal" aria-describedby="beamStationRead"><span class="bl-unit">mm</span></span></label>
            <div class="bl-field"><span>Go to</span><div class="bl-row" id="beamStationQuick"></div></div>
            <div class="bl-field" id="beamStationLimitField" hidden><span>At the jump</span><div class="bl-seg" role="group" aria-label="Limit at the jump"><button type="button" data-cut-limit="left" aria-pressed="true">x⁻ just left</button><button type="button" data-cut-limit="right" aria-pressed="false">x⁺ just right</button></div></div>
            <button type="submit" class="sr-only" tabindex="-1">Show the values at x</button>
          </form>
          <div class="bl-row" id="beamStationSnaps"></div>
          <p class="bl-station-read" id="beamStationRead" role="status" aria-live="polite"></p>
          <div class="bl-station-cards" id="beamStationCards"></div>
          <p class="bl-help" id="beamStationMore"></p>
          <div class="bl-cols bl-station-explain"><figure class="bl-figure" id="beamStationFaces"></figure><div class="bl-signkey" id="beamSignKey"></div></div>
          <div class="bl-stationtable">
            <h4>Station table: exact values at the x you list</h4>
            <form class="bl-row bl-station-listform" id="beamStationListForm" novalidate>
              <label class="bl-field bl-station-list"><span>Stations x (mm), separated by commas or spaces</span><span class="bl-input"><input id="beamStationList" type="text" inputmode="decimal" autocomplete="off" spellcheck="false" aria-describedby="beamStationListError"></span></label>
              <button type="submit" class="bl-btn bl-btn-sm">Show</button>
              <button type="button" class="bl-btn bl-btn-sm" id="beamStationAdd">Add the current x</button>
              <button type="button" class="bl-btn bl-btn-sm" id="beamStationReset">Default list</button>
              <button type="button" class="bl-btn bl-btn-sm" data-export="stations">Download CSV</button>
            </form>
            <p class="bl-err" id="beamStationListError" role="alert" hidden></p>
            <div class="bl-tablewrap"><table class="bl-table" id="beamStationTable"></table></div>
            <p class="bl-help">V and M are exact (equilibrium); v and θ come from the Euler–Bernoulli finite element (node value or interpolation, as listed). Where V, M or θ jumps, the table has two rows: x⁻ (left) and x⁺ (right). The plots and the plot-samples CSV use sample points instead (mesh nodes and quarter points), so use this table for values at a chosen x.</p>
          </div>
        </section>
        <div id="beamCharts" class="bl-charts"></div><div id="beamStressMap"></div>
      </div>
      <div class="bl-tabpanel" role="tabpanel" id="beamTab-cut" aria-labelledby="beamTabBtn-cut" hidden>
        <p class="bl-sub" style="margin:0">Drag the orange cut line on the beam picture, use the slider, or type x. The free bodies show the parts on either side of the cut, with the internal shear V and moment M on their cut faces: the same V and M act on both faces, in opposite directions.</p>
        <div class="bl-cutbar">
          <label class="bl-field bl-cutrange"><span>Cut position x</span><input type="range" id="beamCut" min="0" max="450" step="0.5" value="225" aria-describedby="beamCutRead"></label>
          ${field('beamCutX','x','mm',"value='225'")}
          <div class="bl-field"><span>Parts shown</span><div class="bl-seg" role="group" aria-label="Parts shown"><button type="button" data-cut-side="both" aria-pressed="true">Both</button><button type="button" data-cut-side="left" aria-pressed="false">Left</button><button type="button" data-cut-side="right" aria-pressed="false">Right</button></div></div>
          <div class="bl-field" id="beamCutLimitField" hidden><span>At the jump</span><div class="bl-seg" role="group" aria-label="Limit at the discontinuity"><button type="button" data-cut-limit="left" aria-pressed="true">x⁻ just left</button><button type="button" data-cut-limit="right" aria-pressed="false">x⁺ just right</button></div></div>
        </div>
        <div class="bl-row" id="beamCutSnaps" aria-label="Jump to a station"></div>
        <p class="bl-help" id="beamCutRead"></p>
        <figure class="bl-figure" id="beamCutFbd"></figure>
        <div class="bl-cols"><div class="bl-box" id="beamCutValues"></div><div class="bl-box" id="beamCutCheck"></div></div>
        <div class="bl-charts" id="beamCutCharts"></div>
        <div id="beamCutSection"></div>
        <p class="bl-help" id="beamCutSectionNote"></p>
      </div>
      <div class="bl-tabpanel" role="tabpanel" id="beamTab-solution" aria-labelledby="beamTabBtn-solution" hidden>
        <div id="beamSolution"></div>
        <section class="bl-box" id="beamVerify"><h3>Verify before trusting</h3><p>Refine the mesh and compare. A tiny change is evidence of numerical convergence only; it does not prove that the real clamp, printed material or section is modelled correctly.</p>
          <button type="button" class="bl-btn" id="beamRefine">Compare 10 / 20 / 40 elements</button><div id="beamConvergence"></div></section>
      </div>
      <div class="bl-tabpanel" role="tabpanel" id="beamTab-modes" aria-labelledby="beamTabBtn-modes" hidden>
        <p>A natural mode is an undamped vibration <b>pattern</b>. Its amplitude is normalized, so the animation is <b>not</b> the displacement caused by your static load. Frequencies use the bending stiffness EI and the mass ρA of the chosen section (self-weight loading does not change them).</p>
        <div id="beamModeButtons" class="bl-row"></div><div class="bl-row"><button type="button" class="bl-btn" id="beamAnimate">Animate mode</button><span class="bl-help" id="beamAnimateNote"></span></div>
        <div id="beamModePicture"></div><div id="beamModeTable"></div>
        <p class="bl-help">Bending modes only. Higher modes change direction more often. A natural frequency alone does not predict resonance amplitude, damping, flutter or failure. A mechanism has no modes here because no stable static solution exists.</p>
      </div>
      <div class="bl-tabpanel" role="tabpanel" id="beamTab-compare" aria-labelledby="beamTabBtn-compare" hidden>
        <div class="bl-row"><button type="button" class="bl-btn bl-btn-primary" id="beamSaveA">Save current as A</button><button type="button" class="bl-btn bl-btn-primary" id="beamSaveB">Save current as B</button><button type="button" class="bl-btn" id="beamClearAB">Clear A and B</button></div>
        <div id="beamCompare"></div>
        <section class="bl-box"><h3>Equal-mass cross-sections</h3><p>Same material, same area A (so the same mass and self-weight), same span, supports and loads; only the shape changes. Fixed proportions are stated for each shape.</p>
          <button type="button" class="bl-btn" id="beamEqualMassBtn">Compare equal-mass shapes</button><div id="beamEqualMass"></div></section>
      </div>
      <div class="bl-tabpanel" role="tabpanel" id="beamTab-report" aria-labelledby="beamTabBtn-report" hidden>
        <label class="bl-field"><span>My explanation and notes (saved with the study; plain text)</span><textarea id="beamExplain" class="bl-notes" maxlength="4000" placeholder="The largest stress is at … because …; the largest displacement is at …"></textarea></label>
        <div class="bl-row">
          <button type="button" class="bl-btn bl-btn-primary" id="beamDownload">Save study (.json)</button>
          <button type="button" class="bl-btn" id="beamImport">Import study (.json)</button><input type="file" id="beamImportFile" accept=".json,application/json" class="sr-only" tabindex="-1" aria-hidden="true">
          <button type="button" class="bl-btn" id="beamShare">Copy share link</button>
          <button type="button" class="bl-btn" data-export="stations">Station table CSV</button>
          <button type="button" class="bl-btn" id="beamCsv">Download Chart Data (CSV)</button>
          <button type="button" class="bl-btn" id="beamCsvReactions">Reactions CSV</button>
          <button type="button" class="bl-btn" id="beamPrintBtn">Print / save as PDF</button>
        </div>
        <p class="bl-help" id="beamExportStatus" role="status" aria-live="polite"></p>
        <input class="bl-linkbox" id="beamShareBox" readonly hidden aria-label="Share link">
        <p class="bl-help">Study files are versioned JSON. Imports and links are validated and solved again on this page; a file from a newer version is refused without changing your study. <b>Print / save as PDF</b> opens your browser's print dialog with a report (inputs, free-body diagram, assumptions, supports, plots and results); choose “Save as PDF” there.</p>
        <p class="bl-help">CSV files have one header row with the units in the column names (x_mm, V_N, M_Nmm, v_mm, theta_rad, stresses in MPa) and open in Excel or any spreadsheet; they are CSV, not native Excel workbooks. <b>Station table</b>: exact values at the x you list on the Diagrams tab, with left and right rows at a jump. <b>Plot samples</b>: the points used to draw the plots (mesh nodes and quarter points; duplicate x rows are the left and right limits at a jump). Each plot on the Diagrams tab also downloads as a PNG image with its title, model, axes, units and sign convention.</p>
      </div>
      <div class="bl-tabpanel bl-learn" role="tabpanel" id="beamTab-learn" aria-labelledby="beamTabBtn-learn" hidden>
        <section class="bl-box bl-guide" id="beamGuide" aria-labelledby="beamGuideTitle">
          <h3 id="beamGuideTitle" tabindex="-1">User manual · Quick guide</h3>
          <p><b>First visit?</b> An editable initial beam is shown: L = 450 mm, rectangular section 20 × 10 mm, E = 2000 MPa, density 1.24 g/cm³ and 30 requested elements. These are starting values, not prescribed design data. Change length, material, mesh and section in panels 1–2; valid changes update the drawing. No supports or loads are applied, self-weight is off, and no structural solution is shown until you define stable restraints and press Solve. Examples, shared links and imported studies explicitly load their own models.</p>
          <ol class="bl-guide-steps">
            <li><b>Set dimensions and material.</b> In panels 1–2 enter length L, elastic modulus E, density and cross-section dimensions in the displayed units. Elements are numerical subdivisions, not physical parts; open the mesh help for accuracy guidance.</li>
            <li><b>Place supports.</b> Select <b>Fixed</b>, <b>Pin</b> or <b>Roller</b> above the picture, then click the beam at the intended station. A click near an end sets its restraint; an interior click adds an interior support. Drag an interior support to move it, or type its exact x in panel 3. End restraints can also be selected in the Left/Right end menus. A hinge is a moment release, <b>not a support to ground</b>.</li>
            <li><b>Check stability.</b> For a first simple model, place one Fixed support at x = 0 (a cantilever). Alternatively use a pin and a roller at different stations. With no supports, one pin alone, or rollers only, the beam cannot be solved as a stable planar structure. Read the stability message; the software never adds a missing support for you.</li>
            <li><b>Place a point force or couple.</b> Select <b>Point force</b> or <b>Couple</b> in the Loads toolbar, then click the required station on the beam. A compact Load parameters box opens beside that station: enter signed P in N or C in N·mm and press Enter or Apply. Selecting an icon alone does not apply a load. Positive P points down; positive C is clockwise. Confirmation or Close × hides the editor and returns the form to the left. Delete load N removes the associated applied load; Clear All Loads removes all applied loads after confirmation.</li>
            <li><b>Place a distributed load.</b> Select Uniform, Triangle, Trapezoid, Elliptic or Parabolic; drag its start-to-end interval on the beam. In the compact Load parameters box beside that interval, verify start/end x, enter intensity q in N/mm or explicitly labelled total force F in N for a curved profile, choose its shape and confirm with Enter or Apply. Inspect the live profile before adding. You can also enter positions numerically in the form on the left; CSV loads are validated and previewed before application. Drawing scale changes the picture only, never the force.</li>
            <li><b>Select, edit, move or remove.</b> Click a purple numbered load handle to open its compact editor; drag the handle to move the load. Enter or double-click also opens the editor. Select a support, hinge or load and press <b>Delete</b> outside a text field, or use <b>Delete selected item</b> or the editor’s Delete load button. Delete while typing only edits the input, not the model. Removing an end support makes that end free.</li>
            <li><b>Clear independently.</b> <b>Clear All Loads</b> beside the Loads tools removes applied loads and self-weight after confirmation, retaining supports and geometry. <b>Clear All Supports</b> beside the support tools removes end and interior restraints after confirmation, retaining loads, geometry and internal hinges. The beam is then unrestrained until you add supports again.</li>
            <li><b>Undo and redo.</b> Use Undo/Redo beside the Loads tools to restore model edits (geometry, material stiffness, section, supports, hinges and loads), up to 100 saved states. Outside text fields, Ctrl/Cmd+Z undoes; Ctrl/Cmd+Shift+Z or Ctrl+Y redoes. A new edit discards the redo branch. Inside an input, the keyboard shortcut retains normal text editing. Restoring inputs does not replace the last solved evidence: solve again, or enable automatic solving, when results are out of date.</li>
            <li><b>Solve and verify.</b> Press <b>Solve</b> after the model is stable. Load confirmation may solve the model immediately; subsequent support or geometry edits stay pending unless auto-solve is enabled. Results always belong to the last successful solve. A pending or unstable model cannot export current results; add/fix supports and solve again, or revert to the previous solved model.</li>
            <li><b>Diagrams.</b> Read the support reactions first, then V, M, v, θ and the stresses. Reactions are external forces on the beam; V and M are internal forces on a cut. The table and thin slices under the reactions show how they are linked.</li>
            <li><b>Station values.</b> Type x or press <b>L/2</b> to read exact V and M (equilibrium) and v, θ (Euler–Bernoulli finite element) at that x. At a point force, couple, support or hinge choose x⁻ or x⁺. <b>Cut &amp; section</b> shows the same cut with both parts and V and M on their faces.</li>
            <li><b>Report and downloads.</b> Station table CSV (any x you list), plot-samples CSV, reactions CSV, each plot as PNG, a printable report (print or save as PDF), the study file (.json) and a share link.</li>
          </ol>
          <h4>Signs and units</h4>
          <p>Units: mm, N, N/mm, N·mm and MPa. Forces, line loads and the deflection v are + down; couples, reaction couples C and the rotation θ are + clockwise. Inside the beam, V &gt; 0 acts ↓ on the left part's cut face and ↑ on the right part's, and M &gt; 0 is sagging (top in compression). A thin slice at a support then gives V(0⁺) = −R and M(0⁺) = +C at a left end, and V(L⁻) = +R and M(L⁻) = −C at a right end. Hand equations use the same signs: write ΣF = 0 with forces ↓ + (loads and reactions R<sub>y</sub>) and ΣM = 0 with couples and moments ↻ +. A negative reaction acts upward (or counter-clockwise).</p>
          <h4>Fixed–fixed and other indeterminate beams</h4>
          <p>Equilibrium gives two equations (plus one per hinge), but a fixed–fixed beam has four reaction unknowns. The other two come from compatibility: v = 0 and θ = 0 at both clamps. The Solution tab lists these conditions, and the solved beam satisfies them. Under downward loads the end moments are usually hogging (M &lt; 0).</p>
          <h4>Midpoint and jumps</h4>
          <p>Press <b>L/2</b> for the midpoint. Where a point force or a support acts, V has two values (x⁻ and x⁺) and its plot has a vertical step; a couple makes M jump and a hinge makes θ jump.</p>
          <h4>Plots versus exact values</h4>
          <p>Plots and the plot-samples CSV use sample points (mesh nodes and quarter points). The station readout and the station table compute V and M exactly at the x you choose, so you never have to guess from a sample.</p>
          <h4>Curved loads and CSV tables</h4>
          <p>An elliptic or parabolic load runs from a to b with its maximum where you choose: at the start (zero at the end), at the end, or in the middle (zero at both ends). Enter either the total force F or the peak w₀; the other is shown, with the resultant location x̄. Root-heavy on a cantilever 0..L: elliptic w₀ = 4F/(πL), x̄ = 4L/(3π), root couple 4FL/(3π); parabolic x̄ = 3L/8. These loads are integrated exactly, not split into straight pieces. A CSV table (<code>x_mm,w_N_per_mm</code>, w + down, 2–31 rows) is linear between its rows and zero outside them; the preview shows the rows, F, x̄ and the moment about x = 0 before you choose Add or Replace and press Apply. A table with an error is not imported and your loads stay as they were.</p>
          <h4>Model limits</h4>
          <p>Straight, prismatic, linear-elastic Euler–Bernoulli beam with small displacements and ideal supports. No shear deformation, axial force, buckling, plasticity, contact or stress concentrations. Stresses are nominal beam stresses, not a strength or airworthiness check.</p>
        </section>
        <article id="beamTheory"></article>
        <div id="beamSigns"></div>
        <h3>Supports, hinges and what they restrain</h3>
        <div class="bl-tablewrap"><table class="bl-table"><tr><th>Item</th><th>Restrained motion</th><th>Planar reactions</th></tr>
          <tr><td>Pin</td><td>Horizontal and vertical translation; rotation free</td><td>Rₓ, R<sub>y</sub>; no couple</td></tr>
          <tr><td>Roller on horizontal ground</td><td>Vertical translation only</td><td>R<sub>y</sub> only</td></tr>
          <tr><td>Fixed (clamp)</td><td>Both translations and rotation</td><td>Rₓ, R<sub>y</sub>, couple C</td></tr>
          <tr><td>Internal hinge</td><td>Keeps v continuous; lets the two sides rotate differently</td><td>Passes shear (and axial) force; M = 0</td></tr></table></div>
        <p><b>Transverse-only versus complete planar restraint.</b> This app solves the transverse displacement v and rotation θ. A planar beam also has an axial displacement u<sub>x</sub>, which is <b>not</b> solved here. For stability in the plane at least one pin or clamp must stop the beam from sliding horizontally, so a beam on rollers only is rejected. Two or more pins or clamps make the axial problem redundant, but with no axial load and no temperature change the horizontal reactions are still zero; axial force, thermal stress and inclined rollers are outside this model.</p>
        <p><b>Mechanisms are rejected, not solved.</b> Before solving, the app checks whether the supports and hinges leave any rigid-body motion (sliding, rotating about a single support, or folding at a hinge). A mechanism has no unique static solution and no meaningful vibration modes.</p>
        <h3>What equations are actually solved?</h3>
        <div class="bl-eq">EI v⁗ = q &nbsp; · &nbsp; M = −EI v″ &nbsp; · &nbsp; V = dM/dx &nbsp; · &nbsp; dV/dx = −q<br>σ<sub>x</sub> = −Mz/I &nbsp; · &nbsp; τ = VQ/(Ib) &nbsp; · &nbsp; K u = f &nbsp; · &nbsp; K φ = ω² M φ &nbsp; · &nbsp; f<sub>n</sub> = ω/(2π)</div>
        <p>x is distance along the beam, z is measured upward from the neutral axis, v is downward displacement, E is modulus, I is the second moment of area and κ = v″ is the curvature in this sign convention. Positive M is sagging: top compression, bottom tension. K and M in the eigenvalue equation are matrices, not the bending moment.</p>
        <p><b>Shear stress depends on the section.</b> τ = VQ/(Ib) is the average vertical shear stress across the total material width b(z) cut at height z. For a solid rectangle its maximum is 1.5|V|/A, for a solid circle 4|V|/(3A). For a tube or a box the cut through the neutral axis crosses two separate walls, so b is the sum of both wall thicknesses and each wall carries the same τ by symmetry. In the wide flanges of an I or box section the formula gives only a small average; the real flange shear flow runs mainly along the flange and is not shown. Surface shear is zero.</p>
        <p><b>Outside this beam model:</b> local or shell buckling of thin walls, web crippling under point loads, clamp and contact stress concentrations, holes, plasticity, transverse-shear deformation, torsion, and any CAD or print verification. The plots show nominal beam stress only.</p>
        <p><a href="https://teachbooks.tudelft.nl/computational-modelling/structural_linear/euler_bernouilli.html" target="_blank" rel="noopener noreferrer">TU Delft: Euler–Bernoulli finite elements</a> · <a href="https://help.solidworks.com/2026/english/simtutorialonline/Creating_Beam_Diagrams.htm" target="_blank" rel="noopener noreferrer">SOLIDWORKS: beam diagrams</a> · <a href="https://help.solidworks.com/2025/english/SolidWorks/cworks/HIDD_Mode_Shape_Amplitude.htm" target="_blank" rel="noopener noreferrer">Mode amplitude interpretation</a></p>
        <p class="bl-help">This app follows an educational simulation workflow. It is not SOLIDWORKS or ANSYS and does not replace solid/shell, contact, nonlinear or fracture analysis. The wing workspace uses upward-positive loading and states that convention explicitly.</p>
      </div>
    </section>
  </div>
  <div id="beamPrint" class="bl-print" aria-hidden="true"></div>`;
  // Keep one form and its listeners: graphical placement never sends the user away from the model.
  const loadFormHome=document.createElement('div');loadFormHome.id='beamLoadFormHome';
  $('#beamLoadForm').before(loadFormHome);loadFormHome.append($('#beamLoadForm'));
  function showGraphicEditor(open) {
    $('#beamLoadEditor').hidden=!open;
    (open?$('#beamLoadEditor'):loadFormHome).append($('#beamLoadForm'));
    if(open)positionBeamEditor();
  }
  $('#beamLoadEditor').setAttribute('role','dialog');
  $('#beamLoadEditor h3').id='beamLoadEditorTitle';$('#beamLoadEditor').setAttribute('aria-labelledby','beamLoadEditorTitle');
  $('#beamLoadEditor > .bl-help').textContent='Enter values, then press Enter or Apply. + force is down; + couple is clockwise. × closes without deleting.';
  function positionBeamEditor(){
    const editor=$('#beamLoadEditor');if(editor.hidden||host.hidden)return;
    const svg=$('#beamPicture svg');if(!svg)return;
    const bounds=svg.getBoundingClientRect();if(!bounds.width)return;
    const k=$('#beamLoadKind').value,a=Number($('#beamLoadA').value),b=Number($('#beamLoadB').value),station=k==='point'||k==='moment'?a:(a+b)/2;
    const vb=svg.getAttribute('viewBox').split(/\s+/).map(Number),L=+svg.dataset.length;
    const beam=svg.querySelector('.bl-beam'),beamY=Number(beam?.getAttribute('y')||0)+6;
    let anchor={left:bounds.left+(+svg.dataset.x0+(+svg.dataset.x1-+svg.dataset.x0)*Math.max(0,Math.min(L,station||0))/L)/vb[2]*bounds.width,
      top:bounds.top+beamY/vb[3]*bounds.height};anchor.right=anchor.left;anchor.bottom=anchor.top;
    const circle=st.editorLoad!==null&&svg.querySelector(`[data-load-handle="${st.editorLoad}"] circle`);if(circle)anchor=circle.getBoundingClientRect();
    const box=editor.getBoundingClientRect(),pad=8,gap=12,vw=document.documentElement.clientWidth||window.innerWidth,vh=window.innerHeight,w=box.width||340,h=box.height||280;
    let left=anchor.right+gap,top=anchor.top-30;
    if(left+w>vw-pad)left=anchor.left-w-gap;
    if(left<pad){left=Math.max(pad,Math.min(anchor.left-w/2,vw-w-pad));top=anchor.bottom+gap;if(top+h>vh-pad)top=anchor.top-h-gap;}
    editor.style.left=Math.max(pad,Math.min(left,vw-w-pad))+'px';editor.style.top=Math.max(pad,Math.min(top,vh-h-pad))+'px';
  }
  window.addEventListener('resize',positionBeamEditor);window.addEventListener('scroll',positionBeamEditor,true);
  $('#beamLoadEditorClose').onclick=()=>{
    showGraphicEditor(false);st.graphicPreview=null;st.editLoad=null;st.editorLoad=null;syncLoadForm();renderPicture();
    message('Graphical load editor closed. Parameters are available on the left; applied loads are unchanged.');
    $('#beamStopPlacing').focus({preventScroll:true});
  };
  if(typeof CompanionTools!=='undefined') CompanionTools.fill(host);

  /* ------------------------------------------------------------- inputs */

  const geometryInput=k=>$(`#beamGeometry [name="${k}"]`);
  function readNumber(el,label) {
    const text=String(el.value).trim(), wrap=el.closest('.bl-input');
    const value=text===''?NaN:Number(text);
    if(wrap) wrap.dataset.invalid=String(!Number.isFinite(value));
    if(!Number.isFinite(value)) throw new Error(`${label} must be a number.`);
    return value;
  }
  function interiorRows(){return $$('#beamInteriorList [data-row="support"]');}
  function hingeRows(){return $$('#beamHingeList [data-row="hinge"]');}

  /** The draft model from the form (no physics validation; the engine does that). */
  function readDraft() {
    const m={};
    m.length=readNumber(geometryInput('length'),'Length L');m.E=readNumber(geometryInput('E'),'Elastic modulus E');
    m.density=readNumber(geometryInput('density'),'Density ρ');m.elements=readNumber(geometryInput('elements'),'Requested elements');
    const shape=$('#beamShape').value;if(!SEC.SHAPES[shape])throw new Error('Choose a cross-section and enter its dimensions.');m.section={shape};
    for(const [key,symbol,label] of SEC.SHAPES[shape].fields) m.section[key]=readNumber($(`#beamSectionFields [data-sec="${key}"]`),`${label} ${symbol}`);
    m.supports=[];
    const left=$('#beamleftSupport').value, right=$('#beamrightSupport').value;
    if(left!=='free') m.supports.push({x:0,kind:left,row:-1});
    interiorRows().forEach((row,i)=>m.supports.push({x:readNumber(row.querySelector('[data-field="x"]'),`Interior support ${i+1} position`),kind:row.querySelector('[data-field="kind"]').value,row:i}));
    if(right!=='free') m.supports.push({x:m.length,kind:right,row:-2});
    m.hinges=hingeRows().map((row,i)=>readNumber(row.querySelector('[data-field="x"]'),`Hinge ${i+1} position`));
    m.loads=clone(st.model.loads);
    m.selfWeight=$('#beamSelfWeight').checked;
    return m;
  }
  const canonical=m=>JSON.stringify({length:m.length,E:m.E,density:m.density,elements:m.elements,section:m.section,
    supports:[...m.supports].map(s=>({x:s.x,kind:s.kind})).sort((a,b)=>a.x-b.x),hinges:[...m.hinges].sort((a,b)=>a-b),loads:m.loads,selfWeight:!!m.selfWeight});
  let modelHistory=[clone(st.model)],historyIndex=0,restoringHistory=false;
  function recordHistory(){
    if(!restoringHistory&&!st.drag&&!st.draftError&&canonical(st.model)!==canonical(modelHistory[historyIndex])){
      modelHistory=modelHistory.slice(0,historyIndex+1);modelHistory.push(clone(st.model));
      if(modelHistory.length>100)modelHistory.shift();historyIndex=modelHistory.length-1;
    }
    $('#beamUndo').disabled=historyIndex===0;$('#beamRedo').disabled=historyIndex===modelHistory.length-1;
  }
  function travelHistory(delta){
    const next=historyIndex+delta;if(next<0||next>=modelHistory.length)return;
    clearTimeout(autoTimer);restoringHistory=true;historyIndex=next;st.model=clone(modelHistory[next]);
    st.error='';st.draftError='';st.mechanism=null;st.placing=null;st.drag=null;st.graphicPreview=null;st.editLoad=null;st.editorLoad=null;selection=null;
    showGraphicEditor(false);renderInputs(st.model);renderPicture();renderStatus();renderNotice();restoringHistory=false;
    $$('[data-place]').forEach(b=>b.setAttribute('aria-pressed','false'));
    message((delta<0?'Undo':'Redo')+' restored model inputs. Solve to update results, or enable automatic solving.');
    if(st.autoSolve)autoTimer=setTimeout(()=>{if(!isCurrent())solve();},250);
  }
  $('#beamUndo').onclick=()=>travelHistory(-1);$('#beamRedo').onclick=()=>travelHistory(1);
  $('#beamGuide').append($('#beamMeshHelp'));
  function isCurrent() {
    if(!st.solved) return false;
    try {return canonical(readDraft())===canonical(st.solved.model);} catch(e) {return false;}
  }

  function renderScalars(m) {
    for(const k of ['length','E','density','elements']) geometryInput(k).value=m[k];
    $('#beamShape').value=m.section.shape;
    renderSectionFields(m.section);
    $('#beamleftSupport').value=(m.supports.find(s=>s.x===0)||{kind:'free'}).kind;
    $('#beamrightSupport').value=(m.supports.find(s=>s.x===m.length)||{kind:'free'}).kind;
    $('#beamSelfWeight').checked=!!m.selfWeight;
    $$('.bl-input[data-invalid]',host).forEach(w=>w.dataset.invalid='false');
  }
  function renderSectionFields(section) {
    if(!SEC.SHAPES[section.shape]){$('#beamSectionFields').innerHTML='';return;}
    $('#beamSectionFields').innerHTML=SEC.SHAPES[section.shape].fields.map(([key,symbol,label])=>
      `<label class="bl-field"><span>${label} ${symbol.replace(/_(\w+)/,'<sub>$1</sub>')}</span><span class="bl-input"><input data-sec="${key}" type="number" step="any" inputmode="decimal" value="${section[key]}"><span class="bl-unit">${key.endsWith('Ratio')?'ratio':'mm'}</span></span></label>`).join('');
  }
  const EMPTY={support:'<li class="bl-empty">None — use “+ Interior support” or Place on the picture.</li>',hinge:'<li class="bl-empty">None.</li>'};
  const supportRow=(s,i)=>`<li data-row="support" class="bl-rowedit"><span class="bl-tag sup">S${i+1}</span>
      <select class="bl-select" data-field="kind" aria-label="Interior support ${i+1} type">${['pin','roller','fixed'].map(k=>`<option value="${k}"${k===s.kind?' selected':''}>${k}</option>`).join('')}</select>
      <span class="bl-input"><input data-field="x" type="number" step="any" inputmode="decimal" value="${s.x}" aria-label="Interior support ${i+1} position x"><span class="bl-unit">mm</span></span>
      <button type="button" class="bl-btn bl-btn-sm bl-btn-ghost" data-remove-row aria-label="Remove interior support ${i+1}">✕</button></li>`;
  const hingeRow=(h,i)=>`<li data-row="hinge" class="bl-rowedit bl-rowedit-h"><span class="bl-tag">H${i+1}</span>
      <span class="bl-input"><input data-field="x" type="number" step="any" inputmode="decimal" value="${h}" aria-label="Hinge ${i+1} position x"><span class="bl-unit">mm</span></span>
      <button type="button" class="bl-btn bl-btn-sm bl-btn-ghost" data-remove-row aria-label="Remove hinge ${i+1}">✕</button></li>`;
  function renderLists(m) {
    const L=m.length, interior=m.supports.filter(s=>s.x>0&&s.x<L);
    $('#beamInteriorList').innerHTML=interior.map(supportRow).join('')||EMPTY.support;
    $('#beamHingeList').innerHTML=m.hinges.map(hingeRow).join('')||EMPTY.hinge;
    renderLoadList();
  }
  // Rows are added and removed in place so that values being typed elsewhere are never lost.
  function relabelRows(list,type) {
    const rows=[...list.querySelectorAll(`[data-row="${type}"]`)];
    rows.forEach((row,i)=>{
      row.querySelector('.bl-tag').textContent=`${type==='support'?'S':'H'}${i+1}`;
      const sel=row.querySelector('[data-field="kind"]');if(sel)sel.setAttribute('aria-label',`Interior support ${i+1} type`);
      row.querySelector('[data-field="x"]').setAttribute('aria-label',`${type==='support'?'Interior support':'Hinge'} ${i+1} position x`);
      row.querySelector('[data-remove-row]').setAttribute('aria-label',`Remove ${type==='support'?'interior support':'hinge'} ${i+1}`);
    });
    if(!rows.length) list.innerHTML=EMPTY[type];
  }
  function addRow(type,value) {
    const list=type==='support'?$('#beamInteriorList'):$('#beamHingeList'), empty=list.querySelector('.bl-empty');
    if(empty) empty.remove();
    const n=list.querySelectorAll(`[data-row="${type}"]`).length;
    list.insertAdjacentHTML('beforeend',type==='support'?supportRow(value,n):hingeRow(value,n));
    relabelRows(list,type);
  }
  const SHAPE_WORD={start:'max at start',end:'max at end',middle:'symmetric'};
  function loadText(p) {
    if(p.kind==='point') return `${plain(p.force)} N at x=${plain(p.position)} mm`;
    if(p.kind==='moment') return `${plain(p.moment)} N·mm couple at x=${plain(p.position)} mm`;
    if(p.kind==='elliptic'||p.kind==='parabolic') {
      const n=Number.isFinite(p.total)&&Number.isFinite(p.peak)?p:LP.normalizeCurve(p,{min:-Infinity,max:Infinity,lengthUnit:'mm'});
      return `${p.kind} (${SHAPE_WORD[p.shape]}) over ${plain(p.start)}–${plain(p.end)} mm: ${n.basis==='total'?`F = ${plain(n.total)} N (w₀ = ${plain(n.peak)} N/mm)`:`w₀ = ${plain(n.peak)} N/mm (F = ${plain(n.total)} N)`}`;
    }
    if(p.kind==='table') {const t=LP.stats(p);return `table of ${p.points.length} rows over ${plain(t.start)}–${plain(t.end)} mm, linear between rows: F = ${plain(t.total)} N${p.source&&p.source.filename?` · ${p.source.filename}`:''}`;}
    return `${plain(p.qStart)} → ${plain(p.qEnd)} N/mm over ${plain(p.start)}–${plain(p.end)} mm`;
  }
  const loadTag=p=>p.kind==='point'?'P':p.kind==='moment'?'C':p.kind==='elliptic'?'ell':p.kind==='parabolic'?'par':p.kind==='table'?'CSV':'q';
  function renderLoadList() {
    const loads=st.model.loads;
    $('#beamLoads').innerHTML=`<ol class="bl-list">${loads.map((p,i)=>`<li data-editing="${st.editLoad===i}"><span class="bl-tag load">${loadTag(p)}</span><span class="bl-li-text">${esc(loadText(p))}</span>
      <span class="bl-li-actions"><button type="button" class="bl-btn bl-btn-sm bl-btn-ghost" data-edit-load="${i}" aria-label="Edit load ${i+1}">Edit</button><button type="button" class="bl-btn bl-btn-sm bl-btn-ghost" data-delete-load="${i}" aria-label="Remove load ${i+1}">✕</button></span></li>`).join('')}</ol>${loads.map((p,i)=>`<details class="bl-box"><summary>Load ${i+1}: profile, total force & resultant</summary>${previewLoad(p,loads)}</details>`).join('')}${loads.length?'':'<p class="bl-help bl-empty-loads">No load defined. Add your own load.</p>'}`;
    $('#beamLoadBadge').textContent=`${loads.length}/${MAX_LOADS}`;
    renderEditorActions();
  }
  function renderInputs(m) {selection=null;renderScalars(m);renderLists(m);syncLoadForm();renderSectionView();renderStability();}

  function sectionFromDraft() {
    const shape=$('#beamShape').value, s={shape};
    if(!SEC.SHAPES[shape])throw new Error('Choose a cross-section, then enter its dimensions.');
    for(const [key,symbol,label] of SEC.SHAPES[shape].fields) s[key]=readNumber($(`#beamSectionFields [data-sec="${key}"]`),`${label} ${symbol}`);
    return s;
  }
  function renderSectionView() {
    let html;
    try {
      const scalar=k=>geometryInput(k).value.trim()===''?NaN:Number(geometryInput(k).value);
      const s=sectionFromDraft(), p=SEC.properties(s), rho=scalar('density'), L=scalar('length');
      const mass=Number.isFinite(rho)&&Number.isFinite(L)?SEC.massPerLength(p,rho)*L:NaN, q=Number.isFinite(rho)?SEC.selfWeightLine(p,rho,B.GRAVITY):NaN;
      html=`<div class="bl-secview">${D.sectionDrawing(s,p,{width:300})}<dl class="bl-props">
        <dt>Area A</dt><dd>${fmt(p.A)} mm²</dd><dt>${s.shape==='layered'?'Transformed I (reference E₁)':'Second moment I'}</dt><dd>${fmt(p.I)} mm⁴</dd><dt>${s.shape==='layered'?'Geometric half-depth h/2':'Extreme fibre c'}</dt><dd>${fmt(p.c)} mm</dd>
        <dt>${s.shape==='layered'?'Reference Itrans/cmax (not a universal stress modulus)':'Section modulus S = I/c'}</dt><dd>${fmt(p.S)} mm³</dd><dt>Shear factor k (τ<sub>max</sub> = k|V|/A)</dt><dd>${fmt(p.shearFactor,4)}</dd>
        <dt>Beam mass</dt><dd>${Number.isFinite(mass)?fmt(mass)+' g':'—'}</dd><dt>Self-weight ρgA</dt><dd>${Number.isFinite(q)?fmt(q)+' N/mm':'—'}</dd></dl></div>
        ${p.slender.map(t=>`<p class="bl-help bl-warnline">${esc(t)}</p>`).join('')}`;
      $('#beamSectionBadge').textContent=p.label;
      if(s.shape==='layered'){
        const E1=scalar('E');
        html+=`<p class="bl-help"><b>Material 1 = lower layer:</b> E₁=${fmt(E1)} MPa, ρ₁=${fmt(rho)} g/cm³. <b>Material 2 = upper layer:</b> E₂=${fmt(E1*s.modulusRatio)} MPa, ρ₂=${fmt(rho*s.densityRatio)} g/cm³. Edit E₁ and ρ₁ in Span/material and the ratios here. The displayed I is transformed to material 1, not the geometric I. zNA is measured upward from geometric mid-depth. Shared strain does not mean shared stress: σᵢ=−(Eᵢ/E₁)M(z−zNA)/Itrans. Perfect bond only; no slip or adhesive strength check. Changes affect the full beam solve, self-weight, stress, modal mass and all exports.</p>`;
      }
      $('#beamSelfWeightValue').textContent=Number.isFinite(q)?`(${fmt(q)} N/mm, ${Number.isFinite(L)?fmt(q*L):'—'} N in total)`:'';
    } catch(e) {html=`<p class="${st.blankSetup?'bl-help':'bl-err'}">${esc(e.message)}</p>`;$('#beamSectionBadge').textContent='';$('#beamSelfWeightValue').textContent='';}
    $('#beamSectionView').innerHTML=html;
  }
  function renderStability() {
    const box=$('#beamSupportStatus');
    let m;
    try {m=readDraft();} catch(e) {box.className=st.blankSetup?'bl-stability':'bl-stability bad';box.textContent=st.blankSetup?'First enter length, material, mesh and section; then place supports.':e.message;return;}
    if(!m.supports.length&&!st.error){box.className='bl-stability';box.innerHTML='<b>No supports yet.</b> Place restraints before solving: for example, one Fixed support, or a pin and a roller at different stations. A free beam can translate and rotate; the software will not add supports automatically.';return;}
    const a=B.analyze(m);
    if(a.ok) {
      const s=a.stability;
      box.className='bl-stability ok';
      box.innerHTML=`<b class="bl-ok">Stable.</b> ${s.degree===0?'Statically determinate: equilibrium alone gives the reactions.':`Statically indeterminate to degree ${s.degree}: compatibility (deformation) is also needed.`} ${s.transverseRestraints} transverse reaction${s.transverseRestraints===1?'':'s'}, ${s.equations} equilibrium equation${s.equations===1?'':'s'}${s.hinges?` (including ${s.hinges} hinge condition${s.hinges>1?'s':''})`:''}.${s.axialRestraints>1?` Axial restraint is redundant (${s.axialRestraints} pins/clamps) but carries no force for these transverse loads.`:''}`;
    } else {
      box.className='bl-stability bad';
      box.innerHTML=`<b>${a.code==='mechanism'?'Mechanism':'Check inputs'}:</b> ${esc(a.error)}`;
    }
  }

  /* ------------------------------------------------------------- status */

  function statusState() {
    if(!st.solved) return st.error?'error':'pending';
    if(isCurrent()) return 'solved';
    return st.error?'error':'pending';
  }
  function renderStatus() {
    recordHistory();
    const state=statusState(), chip=$('#beamChip'), text=$('#beamRunText');
    chip.className=`bl-chip ${state==='solved'?'ok':state==='error'?'bad':'warn'}`;
    chip.textContent=state==='solved'?'Solved':state==='error'?'Not solved':'Pending';
    text.textContent=state==='solved'?'Results match the inputs.':state==='error'?`${st.error}${st.solved?' Results shown are for the last solved model.':''}`:
      (st.draftError?`${st.draftError} `:'')+(st.solved?'Inputs changed — press Solve. Results shown are for the last solved model.':'No analysis yet. Place enough supports for stability, add your loads, then press Solve.');
    if(st.blankSetup&&!st.solved&&!st.error)text.textContent='Enter length, material, mesh and section to define your beam. No analysis yet.';
    $('#beamSolve').dataset.pending=String(state!=='solved');
    $('#beamRevert').hidden=!(st.solved&&state!=='solved');
    const stale=state!=='solved';
    $('.bl-results').dataset.stale=String(stale);
    $('#beamKpis').dataset.stale=String(stale);
    const banner=$('#beamStale');
    banner.hidden=!stale||!st.solved;
    banner.innerHTML=stale?`<span aria-hidden="true">⚠</span><span><b>${state==='error'?'Not solved.':'Not up to date.'}</b> These results belong to the last solved model, not to the inputs now on screen. ${state==='error'?'Fix the problem shown in the status bar, or revert.':'Press Solve to update them.'}</span>`:'';
    for(const id of ['#beamDownload','#beamShare','#beamCsv','#beamCsvReactions','#beamPrintBtn','#beamSaveA','#beamSaveB','#beamEqualMassBtn','#beamRefine']) {const b=$(id);if(b)b.disabled=stale||!st.solved;}
    $$('[data-export], [data-png]',host).forEach(b=>{b.disabled=stale||!st.solved;});
    for(const id of ['#beamExportStatus','#beamDiagExportStatus']) $(id).textContent=stale&&st.solved?'Exports are disabled until the current inputs are solved.':$(id).dataset.msg||'';
    if(window.BeamStrengthUI)window.BeamStrengthUI.refresh();
  }

  function message(text){st.message=text;$('#beamStatus').textContent=text;}

  /* ------------------------------------------------------------- solving */

  function solve(note) {
    let draft;
    try {draft=readDraft();} catch(e) {st.error=e.message;st.mechanism=null;renderStatus();renderStability();return false;}
    let result;
    try {result=B.solve({...draft,modes:true});}
    catch(e) {st.error=e.message;st.mechanism=e.mechanism||null;st.model=stripRows(draft);renderStatus();renderStability();renderPicture();renderNotice();return false;}
    st.solved={model:Study.modelFromInput(result.input),result};
    st.model=clone(st.solved.model);st.error='';st.mechanism=null;st.draftError='';st.cache={};
    st.cut.x=Math.min(Math.max(0,st.cut.x),st.model.length);st.cut.note='';
    renderInputs(st.model);
    renderAll();
    const unloaded=!st.solved.model.loads.length&&!st.solved.model.selfWeight;
    message(note||(result.warnings.length?result.warnings.join(' '):unloaded?'Solved with no load: all results are zero.':'Solved. Predict the next change before editing.'));
    return true;
  }
  const stripRows=m=>({...m,supports:m.supports.map(s=>({x:s.x,kind:s.kind}))});
  let autoTimer=0;
  function draftChanged() {
    st.error='';st.mechanism=null;message('');
    try {const d=readDraft();st.model=stripRows(d);st.draftError='';} catch(e) {st.draftError=e.message;}
    renderStability();renderPicture();renderStatus();renderNotice();
    if(st.autoSolve&&!st.draftError) {clearTimeout(autoTimer);autoTimer=setTimeout(()=>{if(!isCurrent())solve();},250);}
  }
  function revert() {if(!st.solved)return;st.model=clone(st.solved.model);st.error='';st.draftError='';st.editLoad=null;renderInputs(st.model);renderPicture();renderStatus();renderNotice();message('Inputs reverted to the last solved model.');}

  /* -------------------------------------------------------- beam picture */

  function width(el,fallback=760){const w=el&&el.clientWidth;return w>0?w:fallback;}
  // Draw the draft (DOM order, with row indices for dragging) whenever it is drawable.
  function drawnModel(){
    try {
      const d=readDraft();
      B.normalize({...d,supports:d.supports.map(s=>({x:s.x,kind:s.kind})),_transverseOnly:true,
        hinges:d.hinges.filter(h=>h>0&&h<d.length)});
      st.blankSetup=false;
      return {model:d,current:isCurrent()};
    } catch(e) {
      if(e.code==='mechanism') {try {const d=readDraft();st.blankSetup=false;return {model:d,current:false};} catch(x) {}}
      return {model:st.solved?st.solved.model:BASE,current:false,invalid:true};
    }
  }
  let selection=null;
  function selectionFrom(el) {
    const item=el.closest('[data-load-handle], [data-support-index], [data-hinge-index]');
    if(!item||!$('#beamPicture').contains(item))return null;
    if(item.hasAttribute('data-load-handle'))return {type:'load',index:+item.dataset.loadHandle};
    if(item.hasAttribute('data-hinge-index'))return {type:'hinge',index:+item.dataset.hingeIndex};
    return {type:'support',index:+item.dataset.supportIndex};
  }
  function decorateSelection() {
    const items=$$('#beamPicture [data-load-handle], #beamPicture [data-support-index], #beamPicture [data-hinge-index]');
    items.forEach(el=>{
      const s=selectionFrom(el),on=!!(selection&&s&&s.type===selection.type&&s.index===selection.index);
      el.setAttribute('tabindex','0');el.setAttribute('role','button');
      el.setAttribute('aria-label',`${s.type} ${s.index+1}; select, then Delete to remove`);
      el.setAttribute('aria-pressed',String(on));
      el.style.cursor='pointer';el.style.filter=on?'drop-shadow(0 0 4px #e28b00) drop-shadow(0 0 2px #e28b00)':'';
    });
    $('#beamDeleteSelected').disabled=!selection||st.drawnInvalid;
    $('#beamSelection').textContent=selection?`Selected ${selection.type} ${selection.index+1}. Delete removes this item; end supports become free.`:'Select a load, support or hinge; press Delete to remove it.';
    renderEditorActions();
  }
  function renderEditorActions(){
    const i=selection?.type==='load'?selection.index:st.editorLoad;
    $('#beamEditorDelete').disabled=i===null||!st.model.loads[i];
    $('#beamEditorDelete').textContent=i!==null&&st.model.loads[i]?`Delete load ${i+1}`:'Delete this load';
  }
  function deleteSelection() {
    if(!selection||st.drawnInvalid||st.drag)return;
    const s=selection;
    if(s.type==='load'){
      if(!st.model.loads[s.index])return;
      st.model.loads.splice(s.index,1);st.editLoad=null;showGraphicEditor(false);renderLoadList();syncLoadForm();
    }else if(s.type==='hinge'){
      const row=hingeRows()[s.index];if(!row)return;const list=row.parentElement;row.remove();relabelRows(list,'hinge');
    }else{
      const support=st.drawn.supports[s.index];if(!support)return;
      if(support.x===0)$('#beamleftSupport').value='free';
      else if(support.x===st.drawn.length)$('#beamrightSupport').value='free';
      else {const row=interiorRows()[support.row];if(!row)return;const list=row.parentElement;row.remove();relabelRows(list,'support');}
    }
    selection=null;st.editorLoad=null;draftChanged();message('Selected item removed. Press Solve to update results (or enable auto-solve).');
  }
  function clearLoads() {
    if(!st.model.loads.length&&!$('#beamSelfWeight').checked){message('There are no applied loads to clear. Supports are unchanged.');return;}
    if(!window.confirm('Clear all applied loads, including self-weight? Supports and geometry will be retained.'))return;
    cancelPlacement();
    selection=null;showGraphicEditor(false);replaceLoads([]);$('#beamSelfWeight').checked=false;draftChanged();
    message('All loads cleared; supports and geometry retained. Press Solve to update results.');
  }
  function clearSupports() {
    if($('#beamleftSupport').value==='free'&&$('#beamrightSupport').value==='free'&&!interiorRows().length){message('There are no supports to clear. Loads and geometry are unchanged.');return;}
    if(!window.confirm('Clear all end and interior supports? Loads, geometry and internal hinges will be retained. The unrestrained beam cannot be solved until you add supports.'))return;
    cancelPlacement();selection=null;
    $('#beamleftSupport').value='free';$('#beamrightSupport').value='free';
    $('#beamInteriorList').innerHTML='';
    draftChanged();
    message('All supports cleared. Loads, geometry and internal hinges retained. Place supports to make the beam stable before solving.');
  }
  function renderPicture(ghost) {
    const pic=$('#beamPicture'), {model,current,invalid}=drawnModel(), r=st.solved&&st.solved.result;
    st.drawn=model;st.drawnInvalid=!!invalid;
    $('#beamModelTitle').textContent='Supports';$('#beamModelSub').hidden=true;
    if(invalid&&!st.solved){
      pic.innerHTML='<div class="bl-empty-model" role="status"><b>Define your beam first</b><p>Enter length, elastic modulus, density and mesh count; choose a section and enter its dimensions. Then place supports and loads. No default beam dimensions or material are being analysed.</p></div>';
      $('#beamPictureNote').textContent='No configured model yet. Empty fields are not treated as zero or replaced with assumed values.';
      decorateSelection();return;
    }
    const sw=current&&r&&r.selfWeight.enabled?{q:r.selfWeight.q}:(!current&&model.selfWeight?{q:SEC.selfWeightLine(SEC.properties(model.section),model.density,B.GRAVITY)}:null);
    pic.innerHTML=D.beamSchematic(model,{width:width(pic)-2,result:current?r:null,showDeflection:current&&st.showDeflection,
      cut:cutTab()&&current?{x:st.cut.x}:null,ghost,selfWeight:sw,interactive:true,loadPreview:st.graphicPreview,loadScale:$('#beamLoadScale').value,
      label:`Physical beam with supports and applied loads${current?'':' (edited inputs, not solved yet)'}`});
    decorateSelection();positionBeamEditor();
    if(st.placing) pic.dataset.placing=st.placing; else delete pic.dataset.placing;
    const svg=pic.querySelector('svg'), factor=svg&&svg.dataset.exaggeration;
    $('#beamPictureNote').textContent=invalid?'Some inputs are invalid, so the picture shows the last valid model.':
      current&&!model.loads.length&&!model.selfWeight?'Physical beam with its supports (green). No load is applied.':
      current?`Physical beam: supports (green) and applied loads (purple). This is not a free-body diagram — see Solution.${factor&&st.showDeflection?` Dashed blue: deflected shape drawn at ${factor} × true scale.`:''}`:
      'Showing your edited inputs — not solved yet. Press Solve to update the results.';
    $('#beamPictureNote').textContent+=$('#beamLoadScale').value==='independent'?' Independent load heights show shape only; they do NOT compare force magnitudes.':' Shared intensity scale: a much smaller intensity can look flat; choose independent heights to inspect its shape.';
    const sup=model.supports, left=(sup.find(s=>s.x===0)||{kind:'free'}).kind, right=(sup.find(s=>s.x===model.length)||{kind:'free'}).kind, interior=sup.filter(s=>s.x>0&&s.x<model.length).length;
    $('#beamModelTitle').title=`${left} / ${right}${interior?` + ${interior} interior supports`:''}`;
    if(window.BeamStrengthUI)window.BeamStrengthUI.updatePicture();
  }

  function svgX(evt) {
    const svg=$('#beamPicture svg');if(!svg)return null;
    const box=svg.getBoundingClientRect();if(!box.width)return null;
    const W=+svg.dataset.w,x0=+svg.dataset.x0,x1=+svg.dataset.x1,L=+svg.dataset.length;
    const u=(evt.clientX-box.left)/box.width*W;
    return Math.max(0,Math.min(L,(u-x0)/(x1-x0)*L));
  }
  function snap(x,L) {
    const raw=L/90,p=10**Math.floor(Math.log10(raw)),step=[1,2,5,10].map(k=>k*p).find(s=>s>=raw)||10*p;
    let s=Math.round(x/step)*step;
    const stations=[0,L,...st.model.loads.flatMap(v=>LD.isDist(v)?LD.span(v):[v.position])];
    for(const t of stations) if(Math.abs(t-x)<L*0.012) s=t;
    return Math.max(0,Math.min(L,Number(s.toPrecision(10))));
  }
  const endSupports=()=>($('#beamleftSupport').value!=='free')+($('#beamrightSupport').value!=='free');
  const supportLimitReached=()=>interiorRows().length+endSupports()>=B.LIMITS.supports;
  function placeAt(x) {
    if(st.placing&&st.placing.startsWith('load:')) {
      const kind=st.placing.slice(5);
      if(kind==='point'||kind==='moment') prepareGraphicLoad(kind,x,x);
      else message('Drag from the start to the end of the loaded interval (or enter exact start/end in Loads).');
      return;
    }
    const L=st.model.length, eps=L*1e-9;
    if(st.placing==='hinge') {
      if(x<=eps||x>=L-eps) {message('A hinge must be inside the span, not at an end.');return;}
      if(hingeRows().length>=B.LIMITS.hinges) {message(`At most ${B.LIMITS.hinges} hinges.`);return;}
      addRow('hinge',x);
    } else if(x<=eps||x>=L-eps) {
      const end=$(x<=eps?'#beamleftSupport':'#beamrightSupport');
      if(end.value==='free'&&supportLimitReached()) {message(`At most ${B.LIMITS.supports} supports.`);return;}
      end.value=st.placing;
    }
    else {
      const row=interiorRows().find(r=>Math.abs(Number(r.querySelector('[data-field="x"]').value)-x)<=eps);
      if(row) row.querySelector('[data-field="kind"]').value=st.placing;
      else if(supportLimitReached()) {message(`At most ${B.LIMITS.supports} supports.`);return;}
      else addRow('support',{x,kind:st.placing});
    }
    draftChanged();
    message(`${st.placing[0].toUpperCase()+st.placing.slice(1)} placed at x = ${fmt(x)} mm. ${st.autoSolve?'':'Press Solve when ready.'}`);
  }
  function setPlacing(kind) {
    if(st.drawnInvalid&&!st.solved){message('First complete Length, material & mesh and Cross-section on the left. No default dimensions are used.');return;}
    if(!$('#beamLoadEditor').hidden)$('#beamLoadEditorClose').click();
    st.drag=null;st.graphicPreview=null;
    st.placing=st.placing===kind?null:kind;
    $$('[data-place]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.place===st.placing)));
    renderPicture();
    if(st.placing) message(st.placing.startsWith('load:')?'Point force/couple: click a station. Distributed load: drag an interval. Enter values in the compact box beside the selection, then press Enter. No load is applied until confirmed. Esc cancels.':`Click the beam to place a ${st.placing}. Press Esc or the button again to stop.`);
  }
  function prepareGraphicLoad(kind,a,b) {
    st.editorLoad=null;selection=null;
    showGraphicEditor(true);
    st.editLoad=null;
    $('#beamLoadKind').value=kind;
    $('#beamLoadA').value=Math.min(a,b);$('#beamLoadB').value=Math.max(a,b);
    for(const id of ['beamP','beamC','beamQ0','beamQ1','beamCurveValue']) $('#'+id).value='';
    st.graphicPreview={start:Math.min(a,b),end:Math.max(a,b)};
    st.placing=null;$$('[data-place]').forEach(btn=>btn.setAttribute('aria-pressed','false'));
    syncLoadForm();renderPicture();
    const field=kind==='point'?'beamP':kind==='moment'?'beamC':kind==='triangle'?'beamQ1':kind==='elliptic'||kind==='parabolic'?'beamCurveValue':'beamQ0';
    const input=$('#'+field), details=input.closest('details');if(details)details.open=true;
    input.focus({preventScroll:true});
    $('#beamGraphicHelp').textContent=`Selected ${kind} at ${fmt(Math.min(a,b))}${a===b?'':`–${fmt(Math.max(a,b))}`} mm. Enter magnitude (+ down / clockwise; − up / counter-clockwise), then Add load & solve. This blue selection is not an applied load.`;
  }

  /* ---------------------------------------------------------- KPIs etc. */

  function renderKpis() {
    const r=st.solved.result, sw=r.selfWeight.enabled?` (incl. self-weight ${f(r.selfWeight.total)} N)`:'';
    $('#beamKpis').innerHTML=[['Maximum |v|',f(r.maxima.deflection,4)+' mm'],['Maximum |σ|',f(r.maxima.bendingStress)+' MPa'],['Total applied force',f(r.resultant)+' N',sw],
      ['Maximum |τ|',f(r.maxima.shearStress,4)+' MPa'],['First frequency f₁',(r.modes[0]?f(r.modes[0].frequencyHz,2):'—')+' Hz'],['Beam mass',f(r.massG,2)+' g']]
      .map(([n,v,s=''])=>`<div>${n}<b>${v}</b>${s?`<small>${esc(s)}</small>`:''}</div>`).join('');
  }
  function renderReactions() {
    const r=st.solved.result, L=r.input.length;
    const rows=r.reactions.map((q,i)=>{
      const s=r.stations.find(t=>Math.abs(t.x-q.x)<=L*1e-10)||{};
      const th=s.thetaLeft!==null&&s.thetaRight!==null&&s.thetaLeft!==undefined&&Math.abs(s.thetaLeft-s.thetaRight)>1e-12?`${f(s.thetaLeft,8)} | ${f(s.thetaRight,8)}`:f(s.thetaRight??s.thetaLeft??0,8);
      return `<tr><td>${D.supportName(i)} · ${q.kind} · x = ${plain(q.x)} mm</td><td class="num">${f(q.force,6)} N</td><td class="num">${q.kind==='fixed'?`${f(q.moment,6)} N·mm`:'0 (rotation free)'}</td><td class="num">${f(s.v??0,6)} mm</td><td class="num">${th} rad</td></tr>`;
    }).join('');
    $('#beamReactions').innerHTML=`<h3>Support reactions and motion</h3><div class="bl-tablewrap"><table class="bl-table"><tr><th>Support</th><th class="num">R<sub>y</sub> (N, ↓ +)</th><th class="num">C (N·mm, ↻ +)</th><th class="num">v (mm, ↓ +)</th><th class="num">θ = dv/dx (rad, ↻ +)</th></tr>${rows||''}</table></div>
      <p class="bl-help">One sign convention throughout the lab, also for hand equations: reaction force R<sub>y</sub> positive downward, reaction couple C positive clockwise, like the applied loads. A negative R<sub>y</sub> pushes the beam up; a negative C turns it counter-clockwise. A pin or roller transmits no couple (C = 0) and leaves the rotation free, so θ there is generally not zero. ΣF residual = ${r.equilibrium.force.toExponential(2)} N; ΣM residual = ${r.equilibrium.moment.toExponential(2)} N·mm.</p>
      <p class="bl-help">These reactions are <b>external</b> forces on the beam. The shear V in the plots is an <b>internal</b> force on the faces of a cut, with its own sign convention; the next table links the two.</p>`;
    renderReactionShear();
  }
  // Reaction (external) versus internal V and M beside each support: equilibrium of a thin slice around the
  // support gives V(x⁺) − V(x⁻) = −(R + P) and M(x⁺) − M(x⁻) = +(C + C0), in the app's signs (↓ +, ↻ +), where
  // R, C are the reaction force and couple and P, C0 point actions applied at the same station. At x = 0 that
  // is V(0⁺) = −R and M(0⁺) = +C; at x = L, V(L⁻) = +R and M(L⁻) = −C.
  function reactionShear(r) {
    const L=r.input.length, eps=L*1e-10;
    return r.reactions.map((q,i)=>{
      const left=q.x>0?cleanField(B.fieldAt(r,q.x,'left'),r):null, right=q.x<L?cleanField(B.fieldAt(r,q.x,'right'),r):null;
      const at=v=>Math.abs(v.position-q.x)<=eps, P=r.loadsApplied.filter(v=>v.kind==='point'&&at(v)).reduce((s,v)=>s+v.force,0);
      const C0=r.loadsApplied.filter(v=>v.kind==='moment'&&at(v)).reduce((s,v)=>s+v.moment,0);
      const Vl=left?left.V:0, Vr=right?right.V:0, Ml=left?left.M:0, Mr=right?right.M:0;
      return {i,name:D.supportName(i),q,left,right,P,C0,dV:Vr-Vl,dM:Mr-Ml,expV:-(q.force+P),expM:q.moment+C0};
    });
  }
  /** Equilibrium of the thin slice at one support, written out with its numbers (app signs). */
  function sliceEquations(s,r) {
    const n=s.name, L=r.input.length, lim=side=>side==='left'?(s.q.x===L?'L⁻':'x⁻'):(s.q.x===0?'0⁺':'x⁺');
    const line=(terms,unit,scale)=>{
      const sym=terms.map(([t,k],i)=>`${i?(k>0?' + ':' − '):(k>0?'':'−')}${t}`).join('');
      const num=terms.map(([,k,v],i)=>`${i?(k>0?' + ':' − '):(k>0?'':'−')}(${D.signed(v,6)})`).join('');
      const sum=terms.reduce((a,[,k,v])=>a+k*v,0), ok=Math.abs(sum)<=1e-7*scale+1e-12;
      return `${sym} = ${num} = ${ok?'0':fmt(sum)} ${unit} ${ok?'<span class="bl-ok">✓</span>':'✗'}`;
    };
    const f=[[`R<sub>${n}</sub>`,1,s.q.force]];
    if(s.P) f.push(['P',1,s.P]);
    if(s.left) f.push([`V(${lim('left')})`,-1,s.left.V]);
    if(s.right) f.push([`V(${lim('right')})`,1,s.right.V]);
    let out=`<span class="bl-eqline"><span class="lbl">Forces (↓ +)</span>${line(f,'N',Math.abs(s.q.force)+Math.abs(s.P)+r.maxima.shear)}</span>`;
    if(s.q.kind==='fixed'||s.C0) {
      const m=[];
      if(s.q.kind==='fixed') m.push([`C<sub>${n}</sub>`,1,s.q.moment]);
      if(s.C0) m.push(['C',1,s.C0]);
      if(s.left) m.push([`M(${lim('left')})`,1,s.left.M]);
      if(s.right) m.push([`M(${lim('right')})`,-1,s.right.M]);
      out+=`<span class="bl-eqline"><span class="lbl">Couples (↻ +)</span>${line(m,'N·mm',Math.abs(s.q.moment)+Math.abs(s.C0)+r.maxima.moment)}</span>`;
    } else out+=`<span class="bl-eqline">${s.q.x===0||s.q.x===L?`No couple acts at a ${s.q.kind}, so M(${s.q.x===0?'0⁺':'L⁻'}) = 0.`:`No couple acts at a ${s.q.kind}: M is continuous there.`}</span>`;
    return `<span class="bl-eq bl-eq-left bl-slice-eq">${out}</span>`;
  }
  function renderReactionShear() {
    const r=st.solved.result, L=r.input.length, rows=reactionShear(r);
    const okV=s=>Math.abs(s.dV-s.expV)<=1e-7*(Math.abs(s.q.force)+Math.abs(s.P)+r.maxima.shear)+1e-12;
    const okM=s=>Math.abs(s.dM-s.expM)<=1e-7*(Math.abs(s.q.moment)+Math.abs(s.C0)+r.maxima.moment)+1e-12;
    const dir=(v,pos,neg)=>Math.abs(v)<1e-13?'':` (${fmt(Math.abs(v),6)} ${v>0?pos:neg})`;
    const side=fx=>fx?`V = ${D.signed(fx.V,6)} N<br>M = ${D.signed(fx.M,6)} N·mm`:'V = 0, M = 0<br>(outside the beam)';
    const body=rows.map(s=>{
      const n=s.name, moment=s.q.kind==='fixed'||Math.abs(s.C0)>0, Rn=`R<sub>${n}</sub>`, Cn=`C<sub>${n}</sub>`;
      const vRule=s.P?`−(${Rn} + P), P = ${fmt(s.P,6)} N applied here`:`−${Rn}`, mRule=s.C0?`+(${Cn} + C), C = ${fmt(s.C0,6)} N·mm applied here`:`+${Cn}`;
      return `<tr data-support="${n}"><td>${n} · ${s.q.kind}<br>x = ${plain(s.q.x)} mm</td>
        <td>${Rn} = ${D.signed(s.q.force,6)} N${dir(s.q.force,'N ↓','N ↑')}${s.q.kind==='fixed'?`<br>${Cn} = ${D.signed(s.q.moment,6)} N·mm${dir(s.q.moment,'N·mm ↻','N·mm ↺')}`:''}</td>
        <td>${side(s.left)}</td><td>${side(s.right)}</td>
        <td><span class="bl-nowrap">ΔV = ${D.signed(s.dV,6)} N</span> <span class="bl-nowrap">= ${vRule} ${okV(s)?'<span class="bl-ok">✓</span>':'✗'}</span>${moment?`<br><span class="bl-nowrap">ΔM = ${D.signed(s.dM,6)} N·mm</span> <span class="bl-nowrap">= ${mRule} ${okM(s)?'<span class="bl-ok">✓</span>':'✗'}</span>`:''}</td></tr>`;
    }).join('');
    const fw=Math.min(440,Math.max(340,width($('#beamReactionShear'))));
    const slices=rows.map(s=>`<figure class="bl-figure bl-slicefig" data-support="${s.name}">${D.supportSlice({name:s.name,kind:s.q.kind,x:s.q.x,end:s.q.x===0?'left':s.q.x===L?'right':null,
      R:s.q.force,C:s.q.moment,P:s.P,C0:s.C0,left:s.left&&{V:s.left.V,M:s.left.M},right:s.right&&{V:s.right.V,M:s.right.M}},{width:fw})}<figcaption>${sliceEquations(s,r)}</figcaption></figure>`).join('');
    $('#beamReactionShear').innerHTML=rows.length?`<h3>Reaction (external) and internal V, M beside each support</h3>
      <div class="bl-tablewrap"><table class="bl-table bl-rvtable"><tr><th>Support</th><th>Reaction on the beam</th><th>Just left, x⁻</th><th>Just right, x⁺</th><th>Jump ΔV = V(x⁺) − V(x⁻), ΔM = M(x⁺) − M(x⁻)</th></tr>${body}</table></div>
      <p class="bl-help">A reaction is the force R (and at a clamp the couple C) that a support applies to the beam. V and M act on the two faces of a cut, as an equal and opposite pair. Equilibrium of a thin slice around a support gives V(x⁺) − V(x⁻) = −R and M(x⁺) − M(x⁻) = +C (app signs: force ↓ +, couple ↻ +). So at a left end V(0⁺) = −R and M(0⁺) = +C; at a right end V(L⁻) = +R and M(L⁻) = −C.</p>
      <details class="bl-reveal bl-slices" open><summary class="bl-btn bl-btn-sm">Thin slices at the supports: why V and M are not the reactions</summary>
        <p class="bl-help"><b>Where are these faces?</b> At a support station x = xₛ, the faces approach xₛ − ε and xₛ + ε as ε → 0 mm. Each face is ε from the support; their separation is 2ε → 0 (one ε at a beam end). The drawing is exaggerated, not a finite section length. For values at actual distances, enter those numerical x coordinates in the station table or Cut &amp; section.</p>
        <p class="bl-help">Each slice is cut out just left and just right of its support. Green: the reaction acting on the slice. Orange: the internal V and M on its cut faces, in their actual directions. The slice's left face is the face of the part to its right, where V &gt; 0 acts ↑ and M &gt; 0 acts ↻; its right face is the face of the part to its left, where V &gt; 0 acts ↓ and M &gt; 0 acts ↺. That is why, at a left end, V(0⁺) has the opposite sign to R while M(0⁺) has the same sign as C, and the other way round at a right end.</p>
        <div class="bl-slicegrid">${slices}</div></details>`:'';
  }
  const CHART_KEYS=['shear','moment','deflection','rotation','stressTop','shearStressMax'];
  function chartWidth(container) {
    const w=width(container), cols=(window.getComputedStyle?getComputedStyle(container).gridTemplateColumns||'':'').split(' ').filter(Boolean).length||1;
    return Math.max(300,(w-(cols-1)*18)/cols);
  }
  // Field of fieldAt() shown by each chart, its symbol, and the size used to tell a real jump from round-off.
  const FIELD={shear:'V',moment:'M',deflection:'v',rotation:'theta',stressTop:'stressTop',shearStressMax:'tauMax'};
  const SYMBOL={shear:'V',moment:'M',deflection:'v',rotation:'θ',stressTop:'σ',shearStressMax:'τ'};
  const SCALE={V:'shear',M:'moment',v:'deflection',theta:'rotation',stressTop:'bendingStress',tauMax:'shearStress'};
  const CHART_KEY={shear:"V &gt; 0 acts ↓ on the left part's cut face and ↑ on the right part's. It is an internal force, not a reaction. V = dM/dx.",
    moment:"M &gt; 0 is sagging (top in compression): ↺ on the left part's cut face, ↻ on the right part's."};
  const differs=(r,k,a,b)=>{const d=Math.abs(a-b);return d>1e-13&&d>1e-9*Math.max(r.maxima[SCALE[k]]||0,Math.abs(a),Math.abs(b));};
  function chartMarks(c,key) {
    const k=FIELD[key], s=SYMBOL[key];
    return c.left&&c.right&&differs(c.r,k,c.left[k],c.right[k])?[{label:`${s}(x⁻)`,value:c.left[k]},{label:`${s}(x⁺)`,value:c.right[k]}]:[{label:`${s}(x)`,value:c.at[k]}];
  }
  /** Beam station under the pointer on a chart, and the size of one screen pixel in mm. */
  function chartX(fig,e) {
    const svg=fig.querySelector('svg'), b=svg&&svg.getBoundingClientRect();if(!b||!b.width)return null;
    const W=+svg.dataset.w,x0=+svg.dataset.x0,x1=+svg.dataset.x1,L=+svg.dataset.length;
    return {x:Math.max(0,Math.min(L,((e.clientX-b.left)/b.width*W-x0)/(x1-x0)*L)),mmPerPx:L/((x1-x0)*b.width/W)};
  }
  const QUICK=[[0,'x = 0'],[0.25,'L/4'],[0.5,'L/2'],[0.75,'3L/4'],[1,'x = L']];
  /** A clicked station: a key station or a quarter point within 6 px, otherwise rounded to about L/1000. */
  function snapStation(x,mmPerPx=0) {
    const r=st.solved.result, L=r.input.length, tol=Math.max(6*mmPerPx,L*1e-9);
    let best=null;
    for(const t of [...r.stations.map(s=>s.x),...QUICK.map(([q])=>q*L)]) if(Math.abs(t-x)<=tol&&(best===null||Math.abs(t-x)<Math.abs(best-x))) best=t;
    if(best!==null) return best;
    const raw=L/1000, p=10**Math.floor(Math.log10(raw)), step=[1,2,5,10].map(k=>k*p).find(s=>s>=raw);
    return Math.min(L,Math.max(0,Number((Math.round(x/step)*step).toPrecision(10))));
  }
  function renderCharts() {
    const r=st.solved.result, box=$('#beamCharts'), w=chartWidth(box), sup=r.input.supports.map(s=>s.x), c=cutInfo(), L=r.input.length;
    const off=statusState()!=='solved';
    box.innerHTML=CHART_KEYS.map((k,i)=>`<figure data-beam-chart="${i}" data-key="${k}">${D.chart(r,k,{width:w,supports:sup,cut:{x:c.x,values:chartMarks(c,k)}})}<figcaption>${CHART_KEY[k]?`<span class="bl-chart-key">${CHART_KEY[k]}</span> `:''}<span class="bl-chart-hover" aria-live="polite"></span>
      <span class="bl-chart-tools"><button type="button" class="bl-btn bl-btn-sm" data-png="${k}"${off?' disabled':''} aria-label="Download the ${D.CHARTS[k].title} plot as a PNG image">Download Chart Image (PNG)</button></span></figcaption></figure>`).join('');
    box.querySelectorAll('[data-beam-chart]').forEach(fig=>{
      const key=fig.dataset.key, meta=D.CHARTS[key], out=fig.querySelector('.bl-chart-hover');
      // Values under the pointer are evaluated at that x (not read from the plotted samples).
      fig.addEventListener('pointermove',e=>{const p=chartX(fig,e);if(!p)return;const v=cleanField(B.fieldAt(r,p.x,p.x>=L?'left':'right'),r)[FIELD[key]];
        out.textContent=`${meta.title}: x = ${fmt(p.x)} mm → ${fmt(v,6)} ${meta.unit} (${key==='deflection'||key==='rotation'?'Euler–Bernoulli finite element':'exact'}). Click to read every value there.`;});
      fig.addEventListener('click',e=>{if(e.target.closest('button'))return;const p=chartX(fig,e);if(p)setCut(snapStation(p.x,p.mmPerPx));});
    });
  }
  function renderStressMap() {$('#beamStressMap').innerHTML=D.stressMap(st.solved.result,{width:width($('#beamStressMap'))});}

  /* ------------------------------------------- plot images (PNG) and station table */

  const SIGN_TEXT={
    shear:"Sign convention: V > 0 acts down on the left part's cut face and up on the right part's face (V = dM/dx, dV/dx = −q with q down +). Support reactions are external forces, not V: across a support V changes by −R.",
    moment:"Sign convention: M > 0 is sagging (top fibre in compression); it acts counter-clockwise on the left part's cut face and clockwise on the right part's face.",
    deflection:'Sign convention: v > 0 is downward and is plotted downward.',
    rotation:'Sign convention: θ = dv/dx > 0 is clockwise.',
    stressTop:'σ > 0 is tension. Homogeneous: σ = −Mz/I. Bonded layers: σᵢ = −(Eᵢ/E₁)M(z−zNA)/Itrans; shared strain, generally different stresses.',
    shearStressMax:'Magnitude |τ|max = k |V| / A at the neutral axis (k depends on the cross-section).'};
  function modelLines(m,r) {
    const sup=m.supports.map((s,i)=>`${D.supportName(i)} ${s.kind} at x = ${plain(s.x)} mm`).join(', ')||'none';
    return [`Model: L = ${plain(m.length)} mm · ${SEC.describe(m.section)} · E = ${plain(m.E)} MPa · EI = ${fmt(r.EI,6)} N·mm² · supports: ${sup}${m.hinges.length?` · hinges at x = ${m.hinges.map(plain).join(', ')} mm`:''}`,
      `Loads (force and q down +, couple clockwise +): ${m.loads.length?m.loads.map(v=>Study.describeLoad(v)).join('; '):'none'}${m.selfWeight?`; self-weight ${fmt(r.selfWeight.q)} N/mm`:''}`];
  }
  /** The standalone image of one plot, exactly as the PNG download contains it. */
  function plotImage(key) {
    const r=st.solved.result, m=st.solved.model, c=cutInfo(), meta=D.CHARTS[key], marks=chartMarks(c,key);
    return D.chartImage(r,key,{title:`${meta.title} (${meta.unit})`,lines:[...modelLines(m,r),SIGN_TEXT[key]],supports:r.input.supports.map(s=>s.x),
      station:{x:c.x,values:marks},notes:[`Curve: values at the plotted sample points (mesh nodes and quarter points; both limits at a jump). Orange marker: station x = ${fmt(c.x,6)} mm, exact ${marks.map(q=>`${q.label} = ${fmt(q.value,6)} ${meta.unit}`).join(', ')}.`,
        `Exact values at any x: station readout or station table. MIE 446 Beam Virtual Lab · Euler–Bernoulli beam model · ${new Date().toISOString().slice(0,10)}.`]});
  }
  /** Draw the plot's SVG on a white canvas at 2× and return a PNG blob. */
  function rasterize(img,scale=2) {
    return new Promise((resolve,reject)=>{
      const canvas=document.createElement('canvas'), g=canvas.getContext&&canvas.getContext('2d');
      if(!g||typeof Image==='undefined'){reject(new Error('this browser cannot draw images'));return;}
      const im=new Image();
      im.onload=()=>{try{canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);
        g.fillStyle='#ffffff';g.fillRect(0,0,canvas.width,canvas.height);g.drawImage(im,0,0,canvas.width,canvas.height);
        canvas.toBlob(b=>b&&b.size?resolve(b):reject(new Error('the image is empty')),'image/png');}catch(e){reject(e);}};
      im.onerror=()=>reject(new Error('the plot could not be drawn'));
      im.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(img.svg);
    });
  }
  async function chartPng(key) {
    if(!guard()) return;
    const img=plotImage(key);
    try {
      const blob=await rasterize(img);
      downloadBlob(`MIE446-beam-${key}.png`,blob);
      exportStatus(`${D.CHARTS[key].title} saved as PNG (${img.width*2} × ${img.height*2} px): plot with title, model and loads, axes with units and the sign convention, on a white background.`);
    } catch(e) {exportStatus(`The PNG could not be made here (${e.message}). Use Report (print or PDF) instead.`);}
  }
  // Station table: exact values at listed x (default: 0, L/4, L/2, 3L/4, L and every key station).
  function stationList() {
    const r=st.solved.result, L=r.input.length;
    const own=(st.stationList||[]).filter(x=>x>=0&&x<=L);
    return own.length?own:[...new Set([...QUICK.map(([q])=>q*L),...r.stations.map(s=>s.x)])].sort((a,b)=>a-b);
  }
  function parseStations(text,L) {
    const tokens=String(text).split(/[\s,;]+/).filter(Boolean);
    if(!tokens.length) return {error:'List one or more stations, for example 200, 205.'};
    if(tokens.length>200) return {error:'Use at most 200 stations.'};
    const xs=[];
    for(const t of tokens) {
      const v=Number(t);
      if(!Number.isFinite(v)) return {error:`“${t}” is not a number.`};
      if(v<0||v>L) return {error:`x = ${t} mm is not on the beam (0 to ${plain(L)} mm).`};
      xs.push(v);
    }
    return {xs};
  }
  function renderStationTable() {
    if(!st.solved) return;
    const r=st.solved.result, xs=stationList(), rows=Study.stationRows(r,xs), inp=$('#beamStationList');
    if(document.activeElement!==inp) inp.value=xs.map(plain).join(', ');
    $('#beamStationTable').innerHTML=`<tr><th class="num">x (mm)</th><th>Side</th><th class="num">V (N)</th><th class="num">M (N·mm)</th><th class="num">v (mm)</th><th class="num">θ (rad)</th><th class="num">σ top / bottom (MPa)</th><th class="num">τ<sub>max</sub> (MPa)</th><th>v, θ</th></tr>`+
      rows.map(q=>`<tr data-x="${q.x}" data-side="${q.side}"><td class="num">${fmt(q.x,6)}</td><td>${q.side==='left'?'x⁻ (left)':q.side==='right'?'x⁺ (right)':''}</td><td class="num">${D.signed(q.V,6)}</td><td class="num">${D.signed(q.M,6)}</td><td class="num">${D.signed(q.v,6)}</td><td class="num">${D.signed(q.theta,6)}</td><td class="num">${D.signed(q.stressTop,6)} / ${D.signed(q.stressBottom,6)}</td><td class="num">${fmt(q.tauMax,6)}</td><td>${q.source==='FE node'?'node':'interp.'}</td></tr>`).join('');
  }
  function applyStationList() {
    if(!st.solved) return;
    const err=$('#beamStationListError'), res=parseStations($('#beamStationList').value,st.solved.model.length);
    if(res.error) {err.textContent=res.error;err.hidden=false;return;}
    err.hidden=true;st.stationList=res.xs;renderStationTable();
  }
  function exportAction(kind) {
    if(!guard()) return;
    const r=st.solved.result;
    if(kind==='stations') {
      // Stations typed but not yet shown are used too; an invalid list is reported and nothing is saved.
      const box=$('#beamStationList');
      if(box.value.trim()!==stationList().map(plain).join(', ')) {
        const res=parseStations(box.value,r.input.length);
        if(res.error) {$('#beamStationListError').textContent=res.error;$('#beamStationListError').hidden=false;exportStatus(`Station table not saved: ${res.error}`);return;}
        st.stationList=res.xs;$('#beamStationListError').hidden=true;renderStationTable();
      }
      const n=Study.stationRows(r,stationList()).length;download('MIE446-beam-stations.csv',Study.stationsCsv(r,stationList()),'text/csv');exportStatus(`Station table saved as CSV (${n} rows): exact values at the listed x, with x⁻ and x⁺ rows at jumps. Columns carry their units.`);}
    else if(kind==='samples') {download('MIE446-beam-plot-samples.csv',Study.resultsCsv(r),'text/csv');exportStatus('Plot samples saved as CSV: the points used to draw the plots (duplicate x rows are the left and right limits at a jump). For values at a chosen x use the station table.');}
    else if(kind==='reactions') {download('MIE446-beam-reactions.csv',Study.reactionsCsv(r),'text/csv');exportStatus('Reactions saved as CSV (force ↓ +, couple ↻ +).');}
    else if(kind==='print') printReport();
  }

  /* ------------------------------------------------- exact station readout */

  function renderStation() {
    if(!st.solved) return;
    const c=cutInfo(), r=c.r, L=c.L, x=c.x, eps=L*1e-10, a=c.at;
    const num=$('#beamStationX');num.min='0';num.max=String(L);if(document.activeElement!==num)num.value=Number(x.toPrecision(10));
    $('#beamStationQuick').innerHTML=QUICK.map(([q,t])=>`<button type="button" class="bl-btn bl-btn-sm" data-station-frac="${q}"${Math.abs(q*L-x)<=eps?' aria-current="true"':''} aria-label="Go to ${q===0||q===1?t:`x = ${t}`} (${plain(q*L)} mm)">${t}</button>`).join('');
    const interior=r.stations.filter(s=>s.x>eps&&s.x<L-eps);
    $('#beamStationSnaps').innerHTML=interior.length?`<span class="bl-help">Stations with a jump or a load boundary:</span>${interior.map(s=>`<button type="button" class="bl-btn bl-btn-sm" data-cut-to="${s.x}"${Math.abs(s.x-x)<=eps?' aria-current="true"':''}>${plain(s.x)} mm · ${s.kinds.length?s.kinds.join(', '):'load boundary'}</button>`).join('')}`:'';
    $('#beamStationLimitField').hidden=!c.jump;
    $$('[data-cut-limit]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.cutLimit===c.limit)));
    const name=(QUICK.find(([q])=>q>0&&q<1&&Math.abs(q*L-x)<=eps)||[])[1];
    const end=x<=eps?'left end: values just inside the beam, at x = 0⁺':x>=L-eps?'right end: values just inside the beam, at x = L⁻':'';
    $('#beamStationRead').textContent=`${st.cut.note?st.cut.note+' ':''}Station x = ${fmt(x,6)} mm${name?` = ${name}`:''}${end?` (${end})`:''}${c.jump?`: a jump occurs here. Both limits are listed; the ${c.limit==='left'?'left limit x⁻':'right limit x⁺'} is used for the figure, the plot markers and Cut & section.`:'.'}`;
    // v and θ: Euler–Bernoulli FE. Nodal values equal the beam-theory solution for this constant-EI beam; between
    // nodes the cubic Hermite interpolation is exact unless a line load acts on that element.
    const node=r.nodes.some(n=>Math.abs(n-x)<=eps);
    let e=0;while(e<r.nodes.length-2&&r.nodes[e+1]<x)e++;
    const n0=r.nodes[e], n1=r.nodes[e+1], lineLoad=r.loadsApplied.some(v=>LD.isDist(v)&&LD.span(v)[0]<n1-eps&&LD.span(v)[1]>n0+eps);
    const fe=node?'Euler–Bernoulli finite element: value at a mesh node (equal to the beam-theory solution)':
      `Euler–Bernoulli finite element: cubic Hermite interpolation between the nodes at ${fmt(n0,6)} and ${fmt(n1,6)} mm (${lineLoad?'very close, not exact, under the line load on this element':'exact here: no line load acts on this element'})`;
    const both=k=>c.jump&&c.left&&c.right&&differs(r,k,c.left[k],c.right[k]);
    const sgn=(v,pos,neg,zero)=>v>0?pos:v<0?neg:zero;
    const card=(k,label,unit,meaning,source)=>{
      const val=v=>`${D.signed(v,6)} ${unit}`;
      const value=both(k)?`<span class="bl-stat-lim${c.limit==='left'?' is-sel':''}" data-limit="left">x⁻: ${val(c.left[k])}</span><span class="bl-stat-lim${c.limit==='right'?' is-sel':''}" data-limit="right">x⁺: ${val(c.right[k])}</span>`:val(a[k]);
      return `<div class="bl-stat" data-q="${k}"><span class="bl-stat-k">${label}</span><b class="bl-stat-v">${value}</b><span class="bl-stat-m">${meaning(a[k])}</span><span class="bl-stat-s">${source}</span></div>`;
    };
    $('#beamStationCards').innerHTML=
      card('V','Shear force V','N',v=>sgn(v,"↓ on the left part's cut face, ↑ on the right part's","↑ on the left part's cut face, ↓ on the right part's",'no shear at this cut'),'Exact: equilibrium of the part left of x, with the solved reactions')+
      card('M','Bending moment M','N·mm',v=>sgn(v,'sagging: top in compression','hogging: top in tension','no bending at this cut'),'Exact: moments about x of the same part')+
      card('v','Deflection v (+ down)','mm',v=>sgn(v,'downward','upward','no deflection'),fe)+
      card('theta','Rotation θ = dv/dx (+ clockwise)','rad',v=>sgn(v,'clockwise','counter-clockwise','no rotation'),fe);
    $('#beamStationMore').innerHTML=`${c.jump?`At ${c.limit==='left'?'x⁻':'x⁺'}: `:''}curvature κ = −M/EI = ${fmt(a.curvature,6)} mm⁻¹ · σ top = ${fmt(a.stressTop,6)} MPa, σ bottom = ${fmt(a.stressBottom,6)} MPa (tension +) · τ<sub>max</sub> = ${fmt(a.tauMax,6)} MPa at the neutral axis. They follow from the exact V and M at this x; nothing here is read from the plotted samples.`;
    $('#beamStationFaces').innerHTML=D.cutFaces({x,V:a.V,M:a.M,limit:c.limit,jump:!!c.jump},{width:width($('#beamStationFaces'),380)})+
      '<figcaption>The internal V and M at this station, in their actual directions on the two faces of the cut. They are not reactions: a reaction acts on the beam at a support.</figcaption>';
    $('#beamSignKey').innerHTML=signKey(r);
  }
  /** Sign key beside the readout: internal V, M versus external reactions, with this model's end-support relation. */
  function signKey(r) {
    const L=r.input.length, rows=reactionShear(r), ends=rows.filter(s=>s.q.x===0||s.q.x===L), pick=ends.length?ends:rows.slice(0,1);
    const size=(v,unit,pos,neg)=>Math.abs(v)<1e-13?'zero':`${fmt(Math.abs(v),6)} ${unit} ${v>0?pos:neg}`;
    const here=s=>{
      const n=s.name, R=`R<sub>${n}</sub>`, Cn=`C<sub>${n}</sub>`, fixed=s.q.kind==='fixed', P=s.P?' + P':'', C=s.C0?' + C':'';
      const reaction=`${R} = ${D.signed(s.q.force,6)} N (${size(s.q.force,'N','↓','↑')})`;
      const couple=fixed?`${Cn} = ${D.signed(s.q.moment,6)} N·mm (${size(s.q.moment,'N·mm','↻','↺')})`:'';
      if(s.q.x===0) return `support ${n} at x = 0: ${reaction}, so V(0⁺) = ${P?`−(${R}${P})`:`−${R}`} = <b>${D.signed(s.right.V,6)} N</b>${fixed?`; ${couple}, so M(0⁺) = ${C?`+(${Cn}${C})`:`+${Cn}`} = <b>${D.signed(s.right.M,6)} N·mm</b>`:''}`;
      if(s.q.x===L) return `support ${n} at x = L: ${reaction}, so V(L⁻) = ${P?`+(${R}${P})`:`+${R}`} = <b>${D.signed(s.left.V,6)} N</b>${fixed?`; ${couple}, so M(L⁻) = ${C?`−(${Cn}${C})`:`−${Cn}`} = <b>${D.signed(s.left.M,6)} N·mm</b>`:''}`;
      return `support ${n} at x = ${plain(s.q.x)} mm: ${reaction}, so V jumps there by ${P?`−(${R}${P})`:`−${R}`} = <b>${D.signed(s.dV,6)} N</b>`;
    };
    return `<h4>Reading the signs</h4><ul class="bl-keylist">
      <li><b>V and M are internal.</b> They act on both faces of a cut as an equal and opposite pair (figure). V &gt; 0 acts ↓ on the left part's face and ↑ on the right part's; M &gt; 0 (sagging) acts ↺ on the left part's face and ↻ on the right part's.</li>
      <li><b>V = dM/dx and dV/dx = −q</b> (q + down): V is positive where M increases with x, and a downward line load makes V decrease.</li>
      <li><b>A reaction is external</b>: the force R (and couple C) that a support applies to the beam, listed above with force ↓ + and couple ↻ +. It is not V or M. Across a support V changes by −R and M by +C (see the thin slices above).</li>
      <li><b>Here</b>, ${pick.map(here).join('; ')}.</li>
      <li>A text that takes V &gt; 0 as ↑ on the left part's face reports every V with the opposite sign for the same physical forces: compare the arrows, not only the signs.</li></ul>`;
  }
  function renderTheory() {
    const m=st.solved.model, L=m.length, left=(m.supports.find(s=>s.x===0)||{kind:'free'}).kind, right=(m.supports.find(s=>s.x===L)||{kind:'free'}).kind;
    const interior=m.supports.filter(s=>s.x>0&&s.x<L);
    $('#beamTheory').innerHTML=`<h3>Beam · ${left} / ${right}${interior.length?` + ${interior.length} interior support${interior.length>1?'s':''}`:''}${m.hinges.length?` + ${m.hinges.length} hinge${m.hinges.length>1?'s':''}`:''}</h3>
      <p><b>Left:</b> ${DESCRIBE[left]}.</p>${interior.map(s=>`<p><b>Interior ${s.kind} at x = ${plain(s.x)} mm:</b> ${DESCRIBE[s.kind]}.</p>`).join('')}
      ${m.hinges.map(h=>`<p><b>Hinge at x = ${plain(h)} mm:</b> v continuous; the two sides may rotate differently; M = 0 there.</p>`).join('')}<p><b>Right:</b> ${DESCRIBE[right]}.</p>
      <p>Equilibrium supplies ΣF = 0 and ΣM = 0 (plus M = 0 at each hinge). When there are more reaction unknowns, the solver also imposes the displacement/rotation conditions above using EI v⁗ = q. A clamp can carry a couple; a pin or roller cannot.</p>
      <p><b>Zero displacement is not zero stress.</b> Stress depends on internal moment, not displacement. A restrained end may carry large bending stress while v = 0. A free end has zero reaction, not necessarily zero displacement.</p>`;
  }
  function renderNotice() {
    const box=$('#beamNotice');let html='';
    if(!st.solved) html+=`<div class="bl-notice" role="status" id="beamSetup"><b>Build your own beam.</b><p>No default supports or loads are applied. Choose a support icon and click its station, then use the Loads tools. The stability panel explains any missing restraints. Open <b>User manual · Quick guide</b> above for step-by-step instructions. No analysis results are available until a stable model is solved.</p></div>`;
    if(st.mechanism&&st.mechanism.kind==='transverse'&&!isCurrent()) {
      try {const d=stripRows(readDraft());html+=`<div class="bl-notice bad"><p><b>Mechanism — not solved.</b> ${esc(st.error)}</p>${D.mechanismSketch(d,st.mechanism,{width:width(box)-28})}</div>`;} catch(e) {}
    } else if(st.error&&/must lie on the beam|0 ≤ x|beam length/.test(st.error)&&st.solved) {
      html+=`<div class="bl-notice bad"><p><b>Not solved.</b> ${esc(st.error)}</p><button type="button" class="bl-btn bl-btn-sm" id="beamScaleSpan">Scale all positions to the new span</button></div>`;
    }
    if(st.solved&&isCurrent()&&!st.solved.model.loads.length&&!st.solved.model.selfWeight)
      html+=`<div class="bl-notice" role="status" id="beamNoLoad"><b>No load defined. Add your own load.</b><p>With no load, every reaction, displacement, moment and stress is zero. Use <b>4 · Loads</b> to add a point force, a couple or a distributed load, or choose an example in <b>5 · Examples &amp; presets</b>.</p></div>`;
    if(st.solved&&isCurrent()) {
      const m=st.solved.model, at=x=>m.supports.some(s=>Math.abs(s.x-x)<=m.length*1e-10);
      if(m.loads.length&&!m.selfWeight&&m.loads.every(p=>p.kind==='point'&&Math.abs(p.force)>0&&at(p.position)))
        html+=`<div class="bl-notice" role="status"><b>Your loads act directly on restrained points.</b><p>Zero span deflection here is expected: the supports take the forces. No load was moved automatically.</p><button type="button" class="bl-btn bl-btn-primary" id="beamMoveCentre">Move these point loads to midspan</button></div>`;
    }
    box.innerHTML=html;
    const mc=$('#beamMoveCentre');if(mc)mc.onclick=()=>{replaceLoads(st.model.loads.map(p=>({...p,position:st.model.length/2})));solve();};
    const sc=$('#beamScaleSpan');if(sc)sc.onclick=scalePositions;
  }
  function scalePositions() {
    const L0=st.solved.model.length;let L1;
    try {L1=readNumber(geometryInput('length'),'Length L');} catch(e) {return;}
    const k=L1/L0;
    interiorRows().forEach(row=>{const i=row.querySelector('[data-field="x"]');i.value=Number((Number(i.value)*k).toPrecision(12));});
    hingeRows().forEach(row=>{const i=row.querySelector('[data-field="x"]');i.value=Number((Number(i.value)*k).toPrecision(12));});
    replaceLoads(st.model.loads.map(p=>p.kind==='table'?{...p,points:p.points.map(([x,w])=>[x*k,w])}:LD.isDist(p)?{...p,start:p.start*k,end:p.end*k}:{...p,position:p.position*k}));draftChanged();solve(`All positions scaled by ${fmt(k)} to the new span.`);
  }

  /* ----------------------------------------------------------------- cut */

  // Values below 1e-9 of the field's largest magnitude are round-off and shown as 0.
  function cleanField(f,r) {
    if(!f) return f;
    const z=(v,s)=>Math.abs(v)<=1e-9*Math.max(s,1e-300)?0:v, m=r.maxima, sTop=Math.max(...r.stressTop.map(Math.abs));
    return {...f,V:z(f.V,m.shear),M:z(f.M,m.moment),v:z(f.v,m.deflection),theta:z(f.theta,m.rotation),curvature:z(f.curvature,m.moment/r.EI),
      stressTop:z(f.stressTop,sTop),stressBottom:z(f.stressBottom,sTop),tauMax:z(f.tauMax,m.shearStress)};
  }
  function cutInfo() {
    const r=st.solved.result, L=r.input.length;
    const x=Math.min(L,Math.max(0,st.cut.x));
    const left=x>0?cleanField(B.fieldAt(r,x,'left'),r):null, right=x<L?cleanField(B.fieldAt(r,x,'right'),r):null;
    const tol=(a,b,s)=>Math.abs(a-b)>1e-9*Math.max(1,s);
    const jump=left&&right&&(tol(left.V,right.V,r.maxima.shear)||tol(left.M,right.M,r.maxima.moment)||tol(left.theta,right.theta,r.maxima.rotation));
    let limit=st.cut.limit;
    if(!left) limit='right'; else if(!right) limit='left';
    const at=limit==='left'?left:right;
    return {r,L,x,left,right,jump,limit,at};
  }
  function partSums(r, x, side, limit) {
    const L=r.input.length, eps=L*1e-10, atCut=a=>Math.abs(a-x)<=eps;
    const inside=a=>side==='left'?(a<x-eps||(atCut(a)&&limit==='right')):(a>x+eps||(atCut(a)&&limit==='left'));
    // Fabs, Mabs: sizes of the individual terms (no cancellation), the scale for the round-off tolerance.
    let F=0,Mc=0,Fabs=0,Mabs=0;const items=[];
    for(const v of r.loadsApplied) {
      if(LD.isProfile(v)) {
        const [lo,hi]=LD.span(v), s=side==='left'?lo:Math.max(lo,x), e=side==='left'?Math.min(hi,x):hi;
        if(e-s<=eps) continue;
        const part=LD.portion(v,s,e,x), W=part.W, Mabout=part.Mo;
        F+=W;Mc+=Mabout;items.push({label:`${v.kind==='table'?'table':v.kind}-load portion`,F:W,M:Mabout,xbar:part.xbar??(s+e)/2});
        const qmax=LD.peak(v);Fabs+=qmax*(e-s);Mabs+=qmax*(e-s)*Math.max(Math.abs(s-x),Math.abs(e-x));
      } else if(v.kind==='distributed') {
        const s=side==='left'?v.start:Math.max(v.start,x), e=side==='left'?Math.min(v.end,x):v.end;
        if(e-s<=eps) continue;
        const q=t=>v.qStart+(v.qEnd-v.qStart)*(t-v.start)/(v.end-v.start), q0=q(s), q1=q(e), h=e-s, W=h*(q0+q1)/2;
        const xbar=Math.abs(q0+q1)>1e-15?s+h*(q0+2*q1)/(3*(q0+q1)):(s+e)/2, Mabout=s*W+h*h*(q0+2*q1)/6-W*x;
        F+=W;Mc+=Mabout;items.push({label:v.selfWeight?'self-weight portion':'line-load portion',F:W,M:Mabout,xbar});
        const qmax=Math.max(Math.abs(q0),Math.abs(q1));Fabs+=qmax*h;Mabs+=qmax*h*Math.max(Math.abs(s-x),Math.abs(e-x));
      } else if(inside(v.position)) {
        if(v.kind==='point'){F+=v.force;Mc+=v.force*(v.position-x);items.push({label:'point force',F:v.force,M:v.force*(v.position-x)});Fabs+=Math.abs(v.force);Mabs+=Math.abs(v.force*(v.position-x));}
        else {Mc+=v.moment;items.push({label:'couple',F:0,M:v.moment});Mabs+=Math.abs(v.moment);}
      }
    }
    r.reactions.forEach((q,i)=>{if(inside(q.x)){F+=q.force;Mc+=q.force*(q.x-x)+q.moment;items.push({label:`reaction ${D.supportName(i)}`,F:q.force,M:q.force*(q.x-x)+q.moment});
      Fabs+=Math.abs(q.force);Mabs+=Math.abs(q.force*(q.x-x))+Math.abs(q.moment);}});
    return {F,M:Mc,Fabs,Mabs,items};
  }
  function renderCut() {
    if(!st.solved) return;
    const c=cutInfo(), r=c.r, L=c.L, side=st.cut.side, sides=side==='both'?['left','right']:[side];
    const range=$('#beamCut'), num=$('#beamCutX');
    range.max=L;range.step=Math.max(L/1000,0.001);range.value=c.x;if(document.activeElement!==num)num.value=Number(c.x.toPrecision(10));
    $$('[data-cut-side]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.cutSide===side)));
    $('#beamCutLimitField').hidden=!c.jump;
    $$('[data-cut-limit]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.cutLimit===c.limit)));
    const stations=r.stations;
    $('#beamCutSnaps').innerHTML=`<span class="bl-help">Go to:</span>`+stations.map(s=>`<button type="button" class="bl-btn bl-btn-sm" data-cut-to="${s.x}">${plain(s.x)}${s.kinds.length?` · ${s.kinds.join(', ')}`:''}</button>`).join('');
    const w=width($('#beamCutFbd'));
    // Both parts by default: the same V and M appear on the two cut faces with opposite arrows.
    $('#beamCutFbd').innerHTML=sides.map(s=>D.segmentFbd(st.solved.model,r,{x:c.x,side:s,limit:c.limit,V:c.at.V,M:c.at.M,jump:!!c.jump},{width:w})).join('')+
      (side==='both'?`<figcaption>Free bodies of the left part (top) and the right part (bottom), cut at the same x. The same V and M act on both cut faces in opposite directions: on the left part's face V &gt; 0 acts ↓ and M &gt; 0 (sagging) acts ↺; on the right part's face V &gt; 0 acts ↑ and M &gt; 0 acts ↻. Arrows show the actual directions, labels the signed values. Each support is replaced by its reaction, an external force (magnitude, actual direction).</figcaption>`
      :`<figcaption>Free body of the ${side} part. Supports are replaced by their reactions, labelled with their signed values (R ↓ +, C ↻ +) and drawn in their actual directions. V and M are drawn in their actual directions and labelled with their signed values: on this face V &gt; 0 acts ${side==='left'?'↓':'↑'} and M &gt; 0 (sagging) acts ${side==='left'?'↺':'↻'}.</figcaption>`);
    const lim=v=>v===null?'—':fmt(v);
    const pair=(k,unit)=>c.jump&&c.left&&c.right&&Math.abs(c.left[k]-c.right[k])>1e-9*Math.max(1,Math.abs(c.left[k]))?`${lim(c.left[k])} (x⁻) | ${lim(c.right[k])} (x⁺) ${unit}`:`${fmt(c.at[k])} ${unit}`;
    $('#beamCutRead').textContent=`Cut at x = ${fmt(c.x)} mm${c.jump?` — a jump occurs here; the free body uses the ${c.limit==='left'?'left limit x⁻':'right limit x⁺'}.`:'.'}`;
    $('#beamCutValues').innerHTML=`<h4>Values at the cut</h4><dl class="bl-props"><dt>Shear V</dt><dd>${pair('V','N')}</dd><dt>Moment M (sagging +)</dt><dd>${pair('M','N·mm')}</dd>
      <dt>Deflection v (+down)</dt><dd>${fmt(c.at.v)} mm</dd><dt>Rotation θ</dt><dd>${pair('theta','rad')}</dd><dt>Curvature κ = −M/EI</dt><dd>${fmt(c.at.curvature)} mm⁻¹</dd>
      <dt>σ top / bottom</dt><dd>${fmt(c.at.stressTop)} / ${fmt(c.at.stressBottom)} MPa</dd><dt>τ<sub>max</sub> (neutral axis)</dt><dd>${fmt(c.at.tauMax)} MPa</dd></dl>`;
    const V=c.at.V, M=c.at.M;
    const ok=(v,s)=>Math.abs(v)<=1e-7*s+1e-12;   // relative to the size of the terms (round-off only)
    const check=part=>{
      const sums=partSums(r,c.x,part,c.limit);
      const sF=part==='left'?sums.F+V:sums.F-V, sM=part==='left'?sums.M-M:sums.M+M, scaleF=sums.Fabs+Math.abs(V), scaleM=sums.Mabs+Math.abs(M);
      return `${sides.length>1?`<h5 class="bl-mini">${part==='left'?'Left part':'Right part'}</h5>`:''}<div class="bl-eq bl-eq-left"><span class="bl-eqline"><span class="lbl">ΣF</span>${fmt(sums.F)} (applied + reactions) ${part==='left'?'+':'−'} V(${fmt(V)}) = <span class="bl-nowrap">${fmt(sF)} N ${ok(sF,scaleF)?'✓':'✗'}</span></span>
      <span class="bl-eqline"><span class="lbl">ΣM about cut</span>${fmt(sums.M)} ${part==='left'?'−':'+'} M(${fmt(M)}) = <span class="bl-nowrap">${fmt(sM)} N·mm ${ok(sM,scaleM)?'✓':'✗'}</span></span></div>
      <p class="bl-help">${part==='left'?'On the left part, positive V acts downward and positive M counter-clockwise on the cut face.':'On the right part, positive V acts upward and positive M clockwise on the cut face.'} ${sums.items.length?`Acting on this part besides V and M: ${esc(sums.items.map(i=>i.label).join(', '))}.`:'No load or reaction acts on this part besides V and M.'}</p>`;
    };
    $('#beamCutCheck').innerHTML=`<h4>Check the free bod${sides.length>1?'ies':'y'} (app signs: ↓ +, ↻ +)</h4>${sides.map(check).join('')}`;
    const cw=chartWidth($('#beamCutCharts'));
    const marks=k=>c.jump&&c.left&&c.right?[{label:`${k}(x⁻)`,value:c.left[k==='V'?'V':'M']},{label:`${k}(x⁺)`,value:c.right[k==='V'?'V':'M']}]:[{label:`${k}(x)`,value:c.at[k==='V'?'V':'M']}];
    $('#beamCutCharts').innerHTML=`<figure>${D.chart(r,'shear',{width:cw,cut:{x:c.x,values:marks('V')},extremes:false})}</figure><figure>${D.chart(r,'moment',{width:cw,cut:{x:c.x,values:marks('M')},extremes:false})}</figure>`;
    const p=r.sectionProperties;
    $('#beamCutSection').innerHTML=D.sectionStress(r.section,p,M,V,{width:width($('#beamCutSection'))});
    $('#beamCutSectionNote').textContent=`${p.label}: σ(z) = −Mz/I is linear through the depth (T = tension, C = compression). τ(z) = VQ/(Ib) uses the total material width b(z)${['tube','box'].includes(p.shape)?'; where the cut crosses two walls, b is their sum':''}${['ibeam','box'].includes(p.shape)?'; the jump at the flange–web junction comes from the change in b':''}. Local buckling and clamp or contact stress concentrations are outside this beam model.`;
    if(p.shape==='layered')$('#beamCutSectionNote').textContent='Perfectly bonded layers: axial strain is continuous; σᵢ=−(Eᵢ/E₁)M(z−zNA)/Itrans is piecewise linear and can jump at the interface. The figure checks both sides of the bond. Interface qₛ=VQtrans/Itrans and τ=qₛ/b are elastic transfer demands, not adhesive failure predictions.';
  }
  /** Move the single cut station; every view that shows it (readout, plot markers, picture, Cut & section) follows. */
  function setCut(x,note='',limit) {if(!st.solved)return;st.cut.x=Math.min(Math.max(0,x),st.solved.model.length);st.cut.note=note;if(limit==='left'||limit==='right')st.cut.limit=limit;refreshCut();}
  function refreshCut() {if(st.tab==='cut')renderCut();if(st.tab==='diagrams'){renderStation();renderCharts();}renderPicture();}
  function applyStationInput() {
    if(!st.solved) return;
    const text=String($('#beamStationX').value).trim(), v=text===''?NaN:Number(text), L=st.solved.model.length;
    if(!Number.isFinite(v)) {st.cut.note=`Type a number for x, from 0 to ${plain(L)} mm.`;renderStation();return;}
    setCut(v,v<0||v>L?`x = ${plain(v)} mm is not on the beam (0 to ${plain(L)} mm), so the nearest end is shown.`:'');
  }

  /* ------------------------------------------------------------ solution */

  function assessedCase() {return '';}
  function renderSolution() {
    if(!st.solved) return;
    const r=st.solved.result;
    if(st.cache.solution&&st.cache.solutionFor===r) return;
    let html;
    try {html=Sol.render(st.solved.model,r,{width:width($('#beamSolution')),assessed:assessedCase(st.solved.model)});}
    catch(e) {html=`<p class="bl-err">The worked solution could not be built: ${esc(e.message)}</p>`;}
    $('#beamSolution').innerHTML=html;st.cache.solution=true;st.cache.solutionFor=r;
  }
  function refine() {
    if(!st.solved) return;
    try {
      const base=st.solved.model;
      $('#beamConvergence').innerHTML='<div class="bl-tablewrap"><table class="bl-table"><tr><th>Requested elements</th><th class="num">Max |v| (mm)</th><th class="num">Max |M| (N·mm)</th><th class="num">f₁ (Hz)</th></tr>'+[10,20,40].map(elements=>{
        const q=B.solve({...base,elements});return `<tr><td>${elements} (+ load, support and hinge stations)</td><td class="num">${f(q.maxima.deflection,6)}</td><td class="num">${f(q.maxima.moment,4)}</td><td class="num">${q.modes[0]?f(q.modes[0].frequencyHz,4):'—'}</td></tr>`;}).join('')+'</table></div><p class="bl-help">For a constant-EI beam the nodal values are already exact; the maxima may still move slightly because they are sampled between nodes, and f₁ converges from above.</p>';
    } catch(e) {message(e.message);}
  }

  /* --------------------------------------------------------------- modes */

  function renderModeButtons() {
    const r=st.solved.result;
    if(st.mode>=r.modes.length) st.mode=0;
    if(!r.modes.length) {
      $('#beamModeButtons').innerHTML='<p class="bl-help">No bending mode: every displacement and rotation is restrained, so this model has nothing left to vibrate.</p>';
      $('#beamModeTable').innerHTML='';$('#beamAnimate').disabled=true;$('#beamAnimateNote').textContent='';
      return;
    }
    $('#beamModeButtons').innerHTML=r.modes.map((m,i)=>`<button type="button" class="bl-btn" data-beam-mode="${i}" aria-pressed="${i===st.mode}">Mode ${i+1}: ${f(m.frequencyHz,2)} Hz</button>`).join('');
    $('#beamModeButtons').querySelectorAll('button').forEach(b=>b.onclick=()=>{st.mode=+b.dataset.beamMode;renderModeButtons();renderMode();});
    $('#beamModeTable').innerHTML=`<div class="bl-tablewrap"><table class="bl-table"><tr><th>Mode</th><th class="num">f (Hz)</th><th class="num">Relative residual</th></tr>${r.modes.map((m,i)=>`<tr><td>${i+1}</td><td class="num">${f(m.frequencyHz,4)}</td><td class="num">${m.relativeResidual.toExponential(1)}</td></tr>`).join('')}</table></div>`;
    $('#beamAnimate').disabled=reducedMotion();
    $('#beamAnimateNote').textContent=reducedMotion()?'Animation is off because your system asks for reduced motion.':'';
  }
  function renderMode() {
    if(!st.solved) return;
    const r=st.solved.result, m=r.modes[st.mode];
    $('#beamModePicture').innerHTML=m?D.modeShape(st.solved.model,m,{width:width($('#beamModePicture')),index:st.mode,phase:st.animated?st.phase:undefined}):'';
  }

  /* ------------------------------------------------------------- compare */

  function snapshot(label) {
    if(!st.solved||!isCurrent()) return;
    st.compare[label]={label,model:clone(st.solved.model),result:st.solved.result,savedAt:new Date().toISOString()};
    renderCompare();message(`Saved the current solved study as ${label}.`);
  }
  function renderCompare() {
    const box=$('#beamCompare'), A=st.compare.A, Bs=st.compare.B;
    if(!A&&!Bs) {box.innerHTML='<p class="bl-help">Save two solved studies as A and B, changing one thing between them (span, section, supports or loads). Both keep their complete inputs and results.</p>';return;}
    if(!A||!Bs) {const s=A||Bs;box.innerHTML=`<p>Saved <b>${s.label}</b>: ${esc(SEC.describe(s.model.section))}, L = ${fmt(s.model.length)} mm, ${s.model.supports.map(q=>q.kind).join('/')}. Save the other one to compare.</p>${restoreButtons()}`;wireRestore();return;}
    const ra=A.result, rb=Bs.result, diff=Study.diffModels(A.model,Bs.model);
    // Differences below 1e-9 of the magnitude are round-off and shown as 0.
    const row=(name,a,b,unit,d=4)=>{let delta=b-a;if(Math.abs(delta)<=1e-9*Math.max(Math.abs(a),Math.abs(b)))delta=0;
      const pct=Math.abs(a)>1e-12?` (${delta>0?'+':''}${fmt(100*delta/Math.abs(a),3)} %)`:'';
      return `<tr><td>${name}</td><td class="num">${fmt(a,d)} ${unit}</td><td class="num">${fmt(b,d)} ${unit}</td><td class="num">${delta>0?'+':''}${fmt(delta,d)}${pct}</td></tr>`;};
    const sameSupports=JSON.stringify(A.model.supports)===JSON.stringify(Bs.model.supports);
    const reactions=sameSupports?ra.reactions.map((q,i)=>row(`R<sub>y</sub> at ${D.supportName(i)} (↓ +)`,q.force,rb.reactions[i].force,'N')+(q.kind==='fixed'?row(`C at ${D.supportName(i)} (↻ +)`,q.moment,rb.reactions[i].moment,'N·mm'):'')).join('')
      :`<tr><td>Reactions</td><td>${ra.reactions.map((q,i)=>`${D.supportName(i)}: ${fmt(q.force)} N${q.kind==='fixed'?`, ${fmt(q.moment)} N·mm`:''}`).join('<br>')}</td><td>${rb.reactions.map((q,i)=>`${D.supportName(i)}: ${fmt(q.force)} N${q.kind==='fixed'?`, ${fmt(q.moment)} N·mm`:''}`).join('<br>')}</td><td>supports differ</td></tr>`;
    const cols=window.matchMedia&&window.matchMedia('(max-width: 1180px)').matches?1:2, full=width(box), w=Math.max(300,(full-(cols-1)*18)/cols);
    const series=key=>[{result:ra,key,cls:'bl-curve',label:'A'},{result:rb,key,cls:'bl-curve-b',label:'B'}];
    const domain=key=>{const all=[...ra[key],...rb[key],0];return [Math.min(...all),Math.max(...all)];};
    const legend=[{label:'A',cls:'bl-curve'},{label:'B',cls:'bl-curve-b'}];
    const scale=Math.max(ra.maxima.bendingStress,rb.maxima.bendingStress,1e-12);
    box.innerHTML=`${restoreButtons()}
      ${diff.loadsDiffer?`<div class="bl-callout warn"><b>The loads differ between A and B${diff.selfWeightChanges?' (self-weight changes with the section, density or span)':''}.</b> Differences in stress or deflection mix the effect of loading with the effect of stiffness; change one thing at a time for a fair comparison.</div>`:''}
      <h3>What changed</h3>${diff.changes.length?`<div class="bl-tablewrap"><table class="bl-table"><tr><th>Input</th><th>A</th><th>B</th></tr>${diff.changes.map(c=>`<tr><td class="bl-changed">${esc(c.label)}</td><td>${esc(c.a)}</td><td>${esc(c.b)}</td></tr>`).join('')}</table></div>`:'<p>No input differs: A and B are the same study.</p>'}
      <h3>Results side by side</h3><div class="bl-tablewrap"><table class="bl-table"><tr><th>Quantity</th><th class="num">A</th><th class="num">B</th><th class="num">B − A</th></tr>
      ${row('Beam mass',ra.massG,rb.massG,'g')}${row('Max |v|',ra.maxima.deflection,rb.maxima.deflection,'mm')}${row('Max |σ| (bending)',ra.maxima.bendingStress,rb.maxima.bendingStress,'MPa')}
      ${row('Max |τ| (shear)',ra.maxima.shearStress,rb.maxima.shearStress,'MPa')}${row('First frequency f₁',ra.modes[0]?ra.modes[0].frequencyHz:NaN,rb.modes[0]?rb.modes[0].frequencyHz:NaN,'Hz')}
      ${row('Max |M|',ra.maxima.moment,rb.maxima.moment,'N·mm')}${row('Max |V|',ra.maxima.shear,rb.maxima.shear,'N')}${reactions}</table></div>
      <h3>Same axes</h3><div class="bl-charts">${['shear','moment','deflection'].map(k=>`<figure>${D.chart(ra,k,{width:w,series:series(k),yDomain:domain(k),legend,extremes:false,noFill:true})}</figure>`).join('')}</div>
      <h3>Same stress colour scale (±${fmt(scale)} MPa)</h3>${D.stressMap(ra,{width:full,scale,title:`A · bending stress (scale ±${fmt(scale)} MPa)`})}${D.stressMap(rb,{width:full,scale,title:`B · bending stress (same scale)`})}
      <p class="bl-help">Interpretation: for the same loads and supports, deflection scales with 1/(EI) and bending stress with c/I; mass with ρA. Wing A/B comparison is not part of this Beam workspace.</p>`;
    wireRestore();
  }
  const restoreButtons=()=>`<div class="bl-row">${st.compare.A?'<button type="button" class="bl-btn bl-btn-sm" id="beamRestoreA">Load A into the editor</button>':''}${st.compare.B?'<button type="button" class="bl-btn bl-btn-sm" id="beamRestoreB">Load B into the editor</button>':''}</div>`;
  function wireRestore() {
    for(const k of ['A','B']) {const b=$(`#beamRestore${k}`);if(b)b.onclick=()=>{st.model=clone(st.compare[k].model);st.editLoad=null;renderInputs(st.model);solve(`Study ${k} loaded into the editor and solved.`);};}
  }
  function equalMass() {
    if(!st.solved) return;
    const base=st.solved.model, r0=st.solved.result;
    if(base.section.shape==='layered'){$('#beamEqualMass').innerHTML='<p class="bl-help">Different layer densities make equal area different from equal mass. Use independent A/B studies and compare the reported masses; the homogeneous same-area shortcut is disabled for bonded layers.</p>';return;}
    const rows=[{name:'Your section',rule:SEC.describe(base.section),section:base.section,result:r0}];
    for(const c of SEC.equalMassCandidates(r0.area)) {
      try {rows.push({...c,result:B.solve({...base,section:c.section})});} catch(e) {rows.push({...c,error:e.message});}
    }
    $('#beamEqualMass').innerHTML=`<div class="bl-tablewrap"><table class="bl-table"><tr><th>Shape (same area A = ${fmt(r0.area)} mm²)</th><th class="num">I (mm⁴)</th><th class="num">Max |v| (mm)</th><th class="num">Max |σ| (MPa)</th><th class="num">Max |τ| (MPa)</th><th class="num">f₁ (Hz)</th><th></th></tr>
      ${rows.map((q,i)=>q.error?`<tr><td>${esc(q.name)}</td><td colspan="6" class="bl-err">${esc(q.error)}</td></tr>`:`<tr class="${i===0?'hl':''}"><td><b>${esc(q.name)}</b><br><span class="bl-help">${esc(i===0?q.rule:`${q.rule} · ${SEC.describe(q.section)}`)}</span></td><td class="num">${fmt(q.result.I)}</td><td class="num">${fmt(q.result.maxima.deflection)}</td><td class="num">${fmt(q.result.maxima.bendingStress)}</td><td class="num">${fmt(q.result.maxima.shearStress)}</td><td class="num">${q.result.modes[0]?fmt(q.result.modes[0].frequencyHz):'—'}</td><td>${i===0?'':`<button type="button" class="bl-btn bl-btn-sm" data-use-section="${i}" aria-label="Use the ${esc(q.name.toLowerCase())}">Use</button>`}</td></tr>`).join('')}</table></div>
      <p class="bl-help">All rows have the same area, so the same mass (${fmt(r0.massG)} g) and self-weight. Deeper material far from the neutral axis raises I. Thin walls (tube, box, I) can buckle locally before these nominal stresses are reached; that is not checked here.</p>`;
    $$('[data-use-section]').forEach(b=>b.onclick=()=>{const q=rows[+b.dataset.useSection];$('#beamShape').value=q.section.shape;renderSectionFields(q.section);renderSectionView();draftChanged();solve(`Section changed to the equal-mass ${q.name.toLowerCase()}.`);});
  }

  /* -------------------------------------------------- report and export */

  function exportStatus(text){for(const id of ['#beamExportStatus','#beamDiagExportStatus','#beamFileStatus']){const s=$(id);s.dataset.msg=text;s.textContent=text;}}
  function guard() {
    if(!st.solved||!isCurrent()) {exportStatus('Solve the current inputs before exporting; nothing was exported.');return false;}
    return true;
  }
  function download(name,text,type) {downloadBlob(name,new Blob([text],{type}));}
  function downloadBlob(name,blob) {
    const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.append(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href),1000);
  }
  function compareForExport(){const c={};for(const k of ['A','B'])if(st.compare[k])c[k]={label:k,model:st.compare[k].model};return Object.keys(c).length?c:null;}
  function exportText(){const text=Study.exportStudy({result:st.solved.result,notes:$('#beamExplain').value,compare:compareForExport()});if(!window.BeamStrengthUI)return text;const doc=JSON.parse(text);doc.strength=window.BeamStrengthUI.exportConfig();return JSON.stringify(doc,null,2);}
  function portableText(){
    if(isCurrent())return exportText();
    const text=Study.exportDraft({model:stripRows(readDraft()),notes:$('#beamExplain').value,compare:compareForExport()});
    if(!window.BeamStrengthUI)return text;const doc=JSON.parse(text);doc.strength=window.BeamStrengthUI.exportConfig();return JSON.stringify(doc,null,2);
  }
  let beamFileReadTicket=0,beamActiveRead=null;
  function cancelBeamFileRead(){
    beamFileReadTicket++;const active=beamActiveRead;beamActiveRead=null;active?.cancel?.();
    try{active?.reader?.abort();}catch{}
    $('#beamOpenJson').disabled=false;$('#beamImport').disabled=false;
  }
  function beamInputStamp(){const fields=root=>[...root.querySelectorAll('input,select,textarea')].filter(e=>e.type!=='file').map(e=>[e.id||e.name,e.value,e.checked]);try{return canonical(readDraft())+'|'+$('#beamExplain').value+'|'+JSON.stringify(window.BeamStrengthUI?.exportConfig())+'|'+JSON.stringify([fields($('#beamLoadForm')),fields($('#beamLoadEditor'))]);}catch{return JSON.stringify(fields(host));}}
  function importText(text) {
    cancelBeamFileRead();
    let doc,strength;
    try {doc=Study.parseStudy(text);if(window.BeamStrengthUI&&typeof BeamStrength!=='undefined')strength=BeamStrength.normalize(JSON.parse(text).strength??{});} catch(e) {exportStatus(`Import refused: ${e.message} Your current study is unchanged.`);return false;}
    if(doc.draft){
      clearTimeout(autoTimer);st.model=clone(doc.model);st.error='';st.draftError='';st.mechanism=null;st.placing=null;st.drag=null;st.editLoad=null;st.editorLoad=null;st.graphicPreview=null;selection=null;st.cache={};
      showGraphicEditor(false);renderInputs(st.model);$('#beamExplain').value=doc.notes;st.compare={A:null,B:null};
      if(doc.compare)for(const k of ['A','B'])if(doc.compare[k])try{st.compare[k]={label:k,model:doc.compare[k].model,result:B.solve({...doc.compare[k].model,modes:true}),savedAt:''};}catch(e){}
      if(window.BeamStrengthUI)window.BeamStrengthUI.importConfig(strength);
      renderAll();renderCompare();renderNotice();message('Working draft opened. Check supports and loads, then Solve. Any previous results remain marked out of date.');exportStatus('Draft JSON opened. Inputs are editable; no stored results were accepted. Undo restores the previous model.');return true;
    }
    // All or nothing: the model must solve here before anything on the page is replaced.
    try {B.solve({...doc.model,modes:false});} catch(e) {exportStatus(`Import refused: ${e.message} Your current study is unchanged.`);return false;}
    const snapshots={};
    if(doc.compare) for(const k of ['A','B']) if(doc.compare[k]) {
      try {snapshots[k]={label:k,model:doc.compare[k].model,result:B.solve({...doc.compare[k].model,modes:true}),savedAt:''};} catch(e) {}
    }
    st.model=clone(doc.model);st.editLoad=null;renderInputs(st.model);
    $('#beamExplain').value=doc.notes;
    st.compare={A:snapshots.A||null,B:snapshots.B||null};
    const solved=solve(`Study imported (file version ${doc.version}${doc.legacy?', converted from the earlier study record':''}) and solved again on this page.`);
    renderCompare();
    if(!solved) {exportStatus(`The imported study could not be solved here: ${st.error}`);return false;}
    if(window.BeamStrengthUI)window.BeamStrengthUI.importConfig(strength);
    exportStatus(`Imported study (version ${doc.version}). Results were recomputed, not read from the file.`);
    return true;
  }

  function printReport() {
    if(!guard()) return;
    const m=st.solved.model, r=st.solved.result, W=700, p=r.sectionProperties, date=new Date().toLocaleString();
    const reactions=r.reactions.map((q,i)=>{const s=r.stations.find(t=>Math.abs(t.x-q.x)<=m.length*1e-10)||{};return `<tr><td>${D.supportName(i)}</td><td>${q.kind}</td><td class="num">${plain(q.x)}</td><td class="num">${fmt(q.force,5)}</td><td class="num">${q.kind==='fixed'?fmt(q.moment,5):'0 (rotation free)'}</td><td class="num">${fmt(s.v??0,4)}</td><td class="num">${fmt(s.thetaRight??s.thetaLeft??0,4)}</td></tr>`;}).join('');
    $('#beamPrint').innerHTML=`<div class="bl-print"><h1>MIE 446 Beam Virtual Lab · study report</h1><p>${esc(date)} · engine ${esc(B.VERSION)} · units mm, N, MPa</p>
      <section><h2>Model</h2><p>L = ${fmt(m.length)} mm · ${esc(SEC.describe(m.section))} · E = ${fmt(m.E)} MPa · ρ = ${fmt(m.density)} g/cm³ · ${r.dofs.elements} elements · self-weight ${m.selfWeight?`included (${fmt(r.selfWeight.q)} N/mm)`:'not included'}</p>
        <p>A = ${fmt(p.A)} mm², I = ${fmt(p.I)} mm⁴, c = ${fmt(p.c)} mm, S = ${fmt(p.S)} mm³, mass ${fmt(r.massG)} g</p>
        <figure>${D.beamSchematic(m,{width:W,selfWeight:r.selfWeight.enabled?{q:r.selfWeight.q}:null,label:'Input schematic: physical supports and applied loads'})}<figcaption>Input schematic (physical supports and loads).</figcaption></figure>
        <figure>${D.freeBody(m,r,{width:W,mode:'solved',label:'Free-body diagram with solved reactions'})}<figcaption>Free-body diagram: supports replaced by the solved reactions (drawn in their actual directions).</figcaption></figure></section>
      <section><h2>Supports and loads</h2><table class="bl-table"><tr><th>Support</th><th>Type</th><th class="num">x (mm)</th><th class="num">R<sub>y</sub> (N, ↓ +)</th><th class="num">C (N·mm, ↻ +)</th><th class="num">v (mm, ↓ +)</th><th class="num">θ (rad, ↻ +)</th></tr>${reactions}</table>
        <p>Hinges: ${m.hinges.length?m.hinges.map(h=>`${fmt(h)} mm`).join(', '):'none'}. Loads: ${m.loads.length?m.loads.map(v=>esc(Study.describeLoad(v))).join('; '):'none'}.</p>
        <p>ΣF residual ${r.equilibrium.force.toExponential(2)} N; ΣM residual ${r.equilibrium.moment.toExponential(2)} N·mm. Stability: ${r.stability.degree===0?'statically determinate':`statically indeterminate to degree ${r.stability.degree}`}.</p></section>
      <section><h2>Results</h2><p>Max |v| = ${fmt(r.maxima.deflection)} mm at x = ${fmt(r.extremes.deflection.x)} mm · max |M| = ${fmt(r.maxima.moment)} N·mm at x = ${fmt(r.extremes.moment.x)} mm · max |σ| = ${fmt(r.maxima.bendingStress)} MPa · max |τ| = ${fmt(r.maxima.shearStress)} MPa · f₁ = ${r.modes[0]?fmt(r.modes[0].frequencyHz):'—'} Hz</p>
        <div class="bl-print-grid">${['shear','moment','deflection','stressTop'].map(k=>`<figure>${D.chart(r,k,{width:340,height:180,supports:r.input.supports.map(s=>s.x)})}</figure>`).join('')}</div>
        ${D.stressMap(r,{width:W})}</section>
      <section><h2>Values at the listed stations</h2><table class="bl-table"><tr><th class="num">x (mm)</th><th>Side</th><th class="num">V (N)</th><th class="num">M (N·mm)</th><th class="num">v (mm)</th><th class="num">θ (rad)</th><th class="num">σ top (MPa)</th></tr>${Study.stationRows(r,stationList()).map(q=>`<tr><td class="num">${fmt(q.x,6)}</td><td>${q.side==='left'?'x⁻':q.side==='right'?'x⁺':''}</td><td class="num">${fmt(q.V,6)}</td><td class="num">${fmt(q.M,6)}</td><td class="num">${fmt(q.v,6)}</td><td class="num">${fmt(q.theta,6)}</td><td class="num">${fmt(q.stressTop,6)}</td></tr>`).join('')}</table>
        <p>V and M are exact (equilibrium at each x); v and θ come from the Euler–Bernoulli finite element. Signs: forces, q and v ↓ +; couples, reaction couples C and θ ↻ +; V &gt; 0 acts ↓ on the left part's cut face and ↑ on the right part's; M &gt; 0 is sagging. Reactions are external: V(0⁺) = −R and M(0⁺) = +C at a left end, V(L⁻) = +R and M(L⁻) = −C at a right end.</p></section>
      <section><h2>Assumptions and limitations</h2><ul>${r.assumptions.map(a=>`<li>${esc(a)}</li>`).join('')}${r.warnings.map(a=>`<li>${esc(a)}</li>`).join('')}<li>Nominal beam stresses only: local buckling, clamp/contact concentrations, holes and printing defects are not modelled. Not an airworthiness or failure certification.</li></ul></section>
      ${window.BeamStrengthUI?window.BeamStrengthUI.reportHTML():''}
      ${$('#beamExplain').value.trim()?`<section><h2>Notes</h2><div class="bl-notes-print">${esc(Study.cleanText($('#beamExplain').value,4000))}</div></section>`:''}</div>`;
    // The class only changes @media print rules; it is removed after the dialog closes.
    document.body.classList.add('beam-printing');
    const done=()=>{document.body.classList.remove('beam-printing');window.removeEventListener('afterprint',done);};
    window.addEventListener('afterprint',done);
    setTimeout(done,120000);
    if(typeof window.print==='function') window.print();
    exportStatus('Report sent to the print dialog. Choose “Save as PDF” there to keep a PDF.');
  }

  /* ---------------------------------------------------------- render all */

  function renderAll() {
    // Panels computed for an earlier solve (equal-mass table, share link, export message) no longer apply.
    $('#beamEqualMass').innerHTML='';
    const box=$('#beamShareBox');box.value='';box.hidden=true;
    $('#beamExportStatus').dataset.msg='';$('#beamDiagExportStatus').dataset.msg='';
    renderStatus();renderPicture();
    if(!st.solved) return;
    renderKpis();renderReactions();renderCharts();renderStressMap();renderStation();renderStationTable();renderTheory();renderNotice();renderModeButtons();renderMode();
    if(st.tab==='cut') renderCut();
    if(st.tab==='solution') renderSolution(); else st.cache.solution=false;
    renderCompare();
    $('#beamConvergence').innerHTML='';
    host.querySelectorAll('[data-stage]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.stage==='beam')));
  }

  /* ------------------------------------------------------------- loads */

  function syncLoadForm() {
    if(st.editLoad!==null&&!(st.editLoad<st.model.loads.length)) st.editLoad=null;
    const k=$('#beamLoadKind').value, point=k==='point'||k==='moment', curve=k==='elliptic'||k==='parabolic';
    const show=(id,on)=>{$(`#${id}Field`).hidden=!on;};
    show('beamLoadB',!point);show('beamP',k==='point');show('beamC',k==='moment');
    show('beamQ0',['rectangle','triangle-root','trapezoid'].includes(k));show('beamQ1',['triangle','trapezoid'].includes(k));
    show('beamCurveShape',curve);show('beamCurveBasis',curve);show('beamCurveValue',curve);
    const total=$('#beamCurveBasis').value==='total';
    $('#beamCurveValueLabel').textContent=total?'Total force F (+ down)':'Peak intensity w₀ (+ down)';
    $('#beamCurveValueField').querySelector('.bl-unit').textContent=total?'N':'N/mm';
    $('#beamLoadALabel').textContent=point?'Position x':curve?'Start a':'Start';
    if($('#beamLoadBLabel')) $('#beamLoadBLabel').textContent=curve?'End b':'End';
    curveLaw();
    renderLoadPreview();
    $('#beamQ0Label').textContent=k==='rectangle'?'q (uniform)':'q at start';
    $('#beamLoadSubmit').textContent=st.editLoad===null?'Add load & solve':`Update load ${st.editLoad+1} & solve`;
    $('#beamLoadCancel').hidden=st.editLoad===null;
    $('#beamLoadEditor').dataset.kind=k;positionBeamEditor();
  }
  /** Live law, F ↔ w₀ conversion and centroid for the curved-load form (no rounding of what is applied). */
  function curveLaw() {
    const k=$('#beamLoadKind').value, out=$('#beamCurveLaw');
    if(k!=='elliptic'&&k!=='parabolic') {out.hidden=true;return;}
    const shape=$('#beamCurveShape').value, basis=$('#beamCurveBasis').value;
    let extra='';
    try {
      const a=Number($('#beamLoadA').value), b=Number($('#beamLoadB').value), v=Number($('#beamCurveValue').value);
      if([a,b,v].every(Number.isFinite)&&b>a&&String($('#beamCurveValue').value).trim()!=='') {
        const n=LP.normalizeCurve({kind:k,start:a,end:b,shape,[basis]:v},{min:-Infinity,max:Infinity,lengthUnit:'mm'}), xbar=a+LP.CENTROID[k][shape]*(b-a);
        extra=` With ℓ = ${plain(b-a)} mm: ${basis==='total'?`w₀ = ${plain(n.peak)} N/mm`:`F = ${plain(n.total)} N`}; resultant at x̄ = ${plain(xbar)} mm; moment of the load about x = 0: ${plain(n.total*xbar)} N·mm (clockwise +).`;
      }
    } catch(e) {}
    out.innerHTML=`${esc(CURVE_LAW[k][shape])}. ${esc(CURVE_F[k])}; ${esc(CENTROID_TEXT[k][shape])}.${esc(extra)} <span class="bl-help">Integrated exactly (not split into straight segments).</span>`;
    out.hidden=false;
  }
  function loadFromForm() {
    const k=$('#beamLoadKind').value, n=(id,label)=>readNumber($(id),label);
    const L=Number(geometryInput('length').value)||st.model.length;
    let load;
    if(k==='point') load={kind:'point',position:n('#beamLoadA','Position x'),force:n('#beamP','Force P')};
    else if(k==='moment') load={kind:'moment',position:n('#beamLoadA','Position x'),moment:n('#beamC','Couple C')};
    else if(k==='elliptic'||k==='parabolic') {
      const basis=$('#beamCurveBasis').value;
      load={kind:k,start:n('#beamLoadA','Start a'),end:n('#beamLoadB','End b'),shape:$('#beamCurveShape').value,
        [basis]:n('#beamCurveValue',basis==='total'?'Total force F':'Peak intensity w₀')};
    } else {
      const a=n('#beamLoadA','Start'),b=n('#beamLoadB','End'),q0=k==='triangle'?0:n('#beamQ0','q at start'),q1=k==='triangle-root'?0:k==='rectangle'?q0:n('#beamQ1','q at end');
      load={kind:'distributed',start:a,end:b,qStart:q0,qEnd:q1};
    }
    const at=LD.isDist(load)?[load.start,load.end]:[load.position];
    if(at.some(x=>x<0||x>L)) throw new Error(`Loads must lie on the beam (0 to ${plain(L)} mm).`);
    if(LD.isDist(load)&&!(load.end>load.start)) throw new Error('A distributed load needs start < end.');
    return load;
  }
  function previewLoad(p,others=[]) {
    try {
      const peak=q=>{if(q.kind==='point'||q.kind==='moment')return 0;const v=['elliptic','parabolic'].includes(q.kind)?LP.normalizeCurve(q,{min:-Infinity,max:Infinity,lengthUnit:'mm'}):q;return v.kind==='distributed'?Math.max(Math.abs(v.qStart),Math.abs(v.qEnd)):v.kind==='table'?Math.max(...v.points.map(r=>Math.abs(r[1]))):Math.abs(v.peak);};
      return LP.previewFigure(p,{positive:'down',scalePeak:$('#beamLoadScale').value==='common'?Math.max(...others.map(peak),peak(p)):null});
    } catch(e){return `<p class="bl-help">${esc(e.message)}</p>`;}
  }
  function renderLoadPreview() {let p;try{p=loadFromForm();}catch(e){$('#beamLoadPreview').textContent='Enter complete parameters to preview the load (not applied until confirmed).';return;}$('#beamLoadPreview').innerHTML='<b>Live input preview — not applied until confirmed</b>'+previewLoad(p,st.model.loads);}
  function submitLoad(e) {
    if(e) e.preventDefault();
    const err=$('#beamLoadError');err.hidden=true;
    if(st.blankSetup){err.textContent='Complete length, material, mesh and cross-section before applying a load.';err.hidden=false;return;}
    let load;
    try {load=loadFromForm();} catch(x) {err.textContent=x.message;err.hidden=false;return;}
    if(st.editLoad!==null&&!(st.editLoad<st.model.loads.length)) st.editLoad=null;
    if(st.editLoad===null&&st.model.loads.length>=MAX_LOADS) {err.textContent=`Use at most ${MAX_LOADS} loads.`;err.hidden=false;return;}
    const appliedIndex=st.editLoad===null?st.model.loads.length:st.editLoad;
    if(st.editLoad===null) st.model.loads.push(load); else st.model.loads[st.editLoad]=load;
    const wasGraphic=!$('#beamLoadEditor').hidden;
    st.editLoad=null;st.graphicPreview=null;renderLoadList();syncLoadForm();solve();
    st.editorLoad=appliedIndex;selection={type:'load',index:appliedIndex};decorateSelection();
    if(wasGraphic){showGraphicEditor(false);$('#beamStopPlacing').focus({preventScroll:true});}
    $('#beamGraphicHelp').textContent='Load registered. Click its purple numbered handle to edit; drag it to move. Use Delete load in the editor, or press Delete outside a text field to remove the selected item. Choose another load tool to add a new load.';
  }
  function editLoad(i) {
    const p=st.model.loads[i];st.editLoad=i;st.editorLoad=i;selection={type:'load',index:i};
    if(p.kind==='point'){$('#beamLoadKind').value='point';$('#beamLoadA').value=p.position;$('#beamP').value=p.force;}
    else if(p.kind==='moment'){$('#beamLoadKind').value='moment';$('#beamLoadA').value=p.position;$('#beamC').value=p.moment;}
    else if(p.kind==='table'){st.editLoad=null;openCsv(i);return;}
    else if(p.kind==='elliptic'||p.kind==='parabolic'){$('#beamLoadKind').value=p.kind;$('#beamLoadA').value=p.start;$('#beamLoadB').value=p.end;$('#beamCurveShape').value=p.shape;
      const basis=Object.prototype.hasOwnProperty.call(p,'total')?'total':'peak';$('#beamCurveBasis').value=basis;$('#beamCurveValue').value=p[basis];}
    else {$('#beamLoadKind').value=p.qStart===p.qEnd?'rectangle':p.qStart===0?'triangle':p.qEnd===0?'triangle-root':'trapezoid';$('#beamLoadA').value=p.start;$('#beamLoadB').value=p.end;$('#beamQ0').value=p.qStart;$('#beamQ1').value=p.qEnd;}
    renderLoadList();syncLoadForm();showGraphicEditor(true);positionBeamEditor();
    const input=$(p.kind==='point'?'#beamP':p.kind==='moment'?'#beamC':p.kind==='elliptic'||p.kind==='parabolic'?'#beamCurveValue':p.qStart===0?'#beamQ1':'#beamQ0');input.focus({preventScroll:true});input.select();
  }
  /* ---------------------------------------------------- CSV line-load table */
  // A table is previewed and validated together with the whole current model before anything changes.
  st.csv={text:'',filename:'',sha256:'',candidate:null,editIndex:null,previewText:null};
  const csvFromTable=p=>`x_mm,w_N_per_mm\n${p.points.map(r=>`${r[0]},${r[1]}`).join('\n')}\n`;
  function openCsv(editIndex=null) {
    const box=$('#beamCsvBox');box.open=true;st.csv.editIndex=editIndex;
    if(editIndex!==null) {const p=st.model.loads[editIndex];$('#beamCsvText').value=csvFromTable(p);st.csv.fromFile=$('#beamCsvText').value;st.csv.filename=p.source&&p.source.filename||'';st.csv.sha256=p.source&&p.source.sha256||'';previewCsv();}
    $('#beamCsvMode').querySelectorAll('input').forEach(i=>{i.disabled=editIndex!==null;});
    box.scrollIntoView&&box.scrollIntoView({block:'nearest'});
  }
  async function sha256Hex(text) {
    try {
      if(!(window.crypto&&crypto.subtle&&window.TextEncoder)) return '';
      const d=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));
      return [...new Uint8Array(d)].map(b=>b.toString(16).padStart(2,'0')).join('');
    } catch(e) {return '';}
  }
  function csvMode(){const r=$('#beamCsvMode input:checked');return st.csv.editIndex!==null?'edit':r?r.value:'add';}
  function csvCandidateLoads(table) {
    const mode=csvMode(), now=clone(st.model.loads);
    if(mode==='edit') {now[st.csv.editIndex]=table;return now;}
    return mode==='replace'?[table]:[...now,table];
  }
  function previewCsv() {
    const out=$('#beamCsvResult'), apply=$('#beamCsvApply'), text=$('#beamCsvText').value;
    apply.disabled=true;st.csv.candidate=null;st.csv.previewText=null;$('#beamCsvMode').hidden=true;
    let L;
    try {L=readNumber(geometryInput('length'),'Length L');} catch(e) {out.innerHTML=`<p class="bl-err">${esc(e.message)}</p>`;return;}
    const res=LP.parseCsv(text,{workspace:'beam',min:0,max:L,ref:0});
    if(!res.ok) {out.innerHTML=`<div class="bl-callout warn"><b>Not imported — the table has ${res.errors.length} problem${res.errors.length>1?'s':''}.</b><ul>${res.errors.slice(0,12).map(e=>`<li>${esc(e)}</li>`).join('')}</ul><p class="bl-help">Your loads are unchanged.</p></div>`;return;}
    const table={kind:'table',points:res.rows,source:{filename:st.csv.filename||'pasted table',rows:res.rows.length,...(st.csv.sha256?{sha256:st.csv.sha256}:{})}};
    const loads=csvCandidateLoads(table);
    let problem='';
    if(loads.length>MAX_LOADS) problem=`This would make ${loads.length} loads; the limit is ${MAX_LOADS}. Choose “Replace” or remove a load.`;
    else {
      try {const d=readDraft();B.normalize({...d,supports:d.supports.map(q=>({x:q.x,kind:q.kind})),loads,_transverseOnly:true});}
      catch(e) {problem=e.message;}
    }
    const t=res.stats, rows=res.rows.map(r=>`<tr><td class="num">${esc(plain(r[0]))}</td><td class="num">${esc(plain(r[1]))}</td></tr>`).join('');
    out.innerHTML=`<div class="bl-csv-preview"><p><b>Preview: ${t.rows} rows, ${t.segments} linear segments</b> from ${esc(table.source.filename)}${st.csv.sha256?` (SHA-256 ${esc(st.csv.sha256.slice(0,12))}…)`:''}.</p>
      ${D.tablePreview?D.tablePreview(res.rows,{width:Math.min(width(out,340),520)}):''}
      <dl class="bl-props"><dt>Total force F = ∫w dx</dt><dd>${esc(plain(t.total))} N (${t.total>0?'↓':t.total<0?'↑':'zero'})</dd>
        <dt>Resultant location x̄</dt><dd>${t.centroid===null?'undefined (zero net force: the table acts as a couple)':`${esc(plain(t.centroid))} mm`}</dd>
        <dt>Moment about x = 0</dt><dd>${esc(plain(t.momentAboutRef))} N·mm (clockwise +)</dd>
        <dt>Range</dt><dd>x = ${esc(plain(t.start))}–${esc(plain(t.end))} mm; w = ${esc(plain(t.wMin))} to ${esc(plain(t.wMax))} N/mm</dd></dl>
      ${res.warnings.length?`<ul class="bl-help">${res.warnings.map(w=>`<li>${esc(w)}</li>`).join('')}</ul>`:''}
      <details><summary>Rows (x mm, w N/mm)</summary><div class="bl-tablewrap"><table class="bl-table"><tr><th>x (mm)</th><th>w (N/mm, + down)</th></tr>${rows}</table></div></details>
      ${problem?`<p class="bl-err">Cannot apply: ${esc(problem)} Your loads are unchanged.</p>`:`<p class="bl-help">${st.csv.editIndex!==null?`Apply replaces table load ${st.csv.editIndex+1} only.`:'Choose how to apply it, then press Apply. Until then nothing changes.'}</p>`}</div>`;
    if(problem) return;
    st.csv.candidate=table;st.csv.previewText=text;$('#beamCsvMode').hidden=st.csv.editIndex!==null;apply.disabled=false;
  }
  function applyCsv() {
    if(!st.csv.candidate||st.csv.previewText!==$('#beamCsvText').value) {previewCsv();return;}
    const loads=csvCandidateLoads(st.csv.candidate);
    try {const d=readDraft();B.normalize({...d,supports:d.supports.map(q=>({x:q.x,kind:q.kind})),loads,_transverseOnly:true});}
    catch(e) {$('#beamCsvResult').insertAdjacentHTML('beforeend',`<p class="bl-err">Cannot apply: ${esc(e.message)}</p>`);return;}
    const n=st.csv.candidate.points.length, mode=csvMode();
    replaceLoads(loads);closeCsv();
    solve(`Line-load table applied (${n} rows, ${mode==='replace'?'all previous loads replaced':mode==='edit'?'table updated':'added to the current loads'}).`);
  }
  function closeCsv() {st.csv={text:'',filename:'',sha256:'',candidate:null,editIndex:null,previewText:null};$('#beamCsvText').value='';$('#beamCsvFile').value='';$('#beamCsvResult').innerHTML='';$('#beamCsvMode').hidden=true;$('#beamCsvApply').disabled=true;$('#beamCsvBox').open=false;
    // the next table is added again unless the user chooses Replace for it (Replace is never remembered)
    const add=$('#beamCsvMode input[value="add"]');if(add)add.checked=true;$('#beamCsvMode').querySelectorAll('input').forEach(i=>{i.disabled=false;});}

  /** Replace the applied loads programmatically; an edit in progress no longer refers to them. */
  function replaceLoads(loads) {selection=null;st.editorLoad=null;st.model.loads=loads;st.editLoad=null;$('#beamLoadError').hidden=true;renderLoadList();syncLoadForm();}
  function fillFormFromSingleLoad() {
    if(st.model.loads.length!==1||st.model.loads[0].kind!=='distributed') return;
    const p=st.model.loads[0];
    $('#beamLoadA').value=p.start;$('#beamLoadB').value=p.end;$('#beamQ0').value=p.qStart;$('#beamQ1').value=p.qEnd;
    $('#beamLoadKind').value=p.qStart===0?'triangle':p.qEnd===0?'triangle-root':p.qStart===p.qEnd?'rectangle':'trapezoid';
    syncLoadForm();
  }

  /* -------------------------------------------------------------- tabs */

  function openTab(name,focus=false) {
    st.tab=name;
    $$('.bl-tabs [role="tab"]').forEach(b=>{const on=b.dataset.tab===name;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;if(on&&focus)b.focus();});
    $$('.bl-results [role="tabpanel"]').forEach(p=>{p.hidden=p.id!==`beamTab-${name}`;});
    if(name==='cut') renderCut();
    if(name==='diagrams'&&st.solved) {renderStation();renderCharts();}
    if(name==='solution') renderSolution();
    if(name==='modes') renderMode();
    if(name==='learn'&&!$('#beamSigns').innerHTML) $('#beamSigns').innerHTML=`<h3>Sign conventions</h3>${D.signConventions({width:width($('#beamSigns'))})}<p class="bl-help">These are the only signs used in this lab — in the equations of the Solution tab, the tables, the free-body diagrams, the CSV files and the report: every external force (applied load or support reaction R<sub>y</sub>) and v positive downward, every external couple (applied or reaction couple C), moment of a force and θ positive clockwise. A negative reaction acts upward or counter-clockwise.</p>
      <p class="bl-help">“Left face” and “right face” above are the faces of a small element: its left face is the cut face of the part to the right of a cut. Internal V and M are not reactions. Across a support V changes by −R and M by the reaction couple C (app signs), so at a left-end support V(0⁺) = −R and M(0⁺) = +C.</p>`;
    if(name==='compare') renderCompare();
    renderPicture();
  }

  /* ------------------------------------------------------------- wiring */

  $('#beamSolve').onclick=()=>solve();
  $('#beamNavToggle').onclick=e=>{const open=$('#beamNav').classList.toggle('is-open');e.currentTarget.setAttribute('aria-expanded',String(open));};
  $('#beamRevert').onclick=revert;
  $('#beamAutoSolve').onchange=e=>{st.autoSolve=e.target.checked;if(st.autoSolve&&!isCurrent())solve();};
  $('#beamGeometry').onsubmit=e=>{e.preventDefault();solve();};
  host.querySelector('.bl-side').addEventListener('input',e=>{if(e.target.closest('#beamLoadForm')||e.target.id==='beamAutoSolve'||e.target.id==='beamShape')return;if(e.target.dataset.sec!==undefined||e.target.id==='beamShape'||e.target.closest('#beamGeometry'))renderSectionView();draftChanged();});
  host.querySelector('.bl-side').addEventListener('change',e=>{if(e.target.closest('#beamLoadForm')||e.target.id==='beamAutoSolve')return;if(e.target.dataset.field==='kind')draftChanged();});
  $('#beamShape').onchange=()=>{
    const shape=$('#beamShape').value;let depth=10,w=20;
    if(!SEC.SHAPES[shape]){renderSectionFields({shape});renderSectionView();draftChanged();return;}
    try {const p=SEC.properties(st.model.section);depth=p.depth;w=p.width;} catch(e) {}
    const t=Math.max(Math.min(w,depth)/8,0.1), dims={rectangle:{width:w,height:depth},layered:{width:w,height:depth,topThickness:depth/2,modulusRatio:2,densityRatio:1},circle:{diameter:depth},tube:{outerDiameter:depth,thickness:Number((depth/10).toPrecision(3))},
      box:{width:w,height:depth,thickness:Number(t.toPrecision(3))},ibeam:{flangeWidth:w,height:depth,flangeThickness:Number((depth/8).toPrecision(3)),webThickness:Number(Math.min(w/8,depth/4).toPrecision(3))}}[shape];
    renderSectionFields({shape,...dims});if(st.blankSetup)$$('#beamSectionFields [data-sec]').forEach(el=>el.value='');renderSectionView();draftChanged();
  };
  const rowValues=type=>(type==='support'?interiorRows():hingeRows()).map(r=>Number(r.querySelector('[data-field="x"]').value));
  function freeSpot(taken) {
    let L=st.model.length;try{L=readNumber(geometryInput('length'),'Length L');}catch(e){}
    return [0.5,0.25,0.75,0.375,0.625,0.125,0.875].map(k=>Number((L*k).toPrecision(10))).find(v=>!taken.some(t=>Math.abs(t-v)<1e-9))??Number((L/3).toPrecision(10));
  }
  $('#beamAddSupport').onclick=()=>{
    if(st.blankSetup){message('Define length, material, mesh and section first.');return;}
    if(supportLimitReached()){message(`At most ${B.LIMITS.supports} supports.`);return;}
    addRow('support',{x:freeSpot(rowValues('support')),kind:'roller'});draftChanged();
  };
  $('#beamAddHinge').onclick=()=>{
    if(st.blankSetup){message('Define length, material, mesh and section first.');return;}
    if(hingeRows().length>=B.LIMITS.hinges){message(`At most ${B.LIMITS.hinges} hinges.`);return;}
    addRow('hinge',freeSpot([...rowValues('hinge'),...rowValues('support')]));draftChanged();
  };
  host.querySelector('.bl-side').addEventListener('click',e=>{
    const rm=e.target.closest('[data-remove-row]'), de=e.target.closest('[data-delete-load]'), ed=e.target.closest('[data-edit-load]');
    if(rm){selection=null;const row=rm.closest('[data-row]'),list=row.parentElement,type=row.dataset.row;row.remove();relabelRows(list,type);draftChanged();}
    if(de){selection=null;st.editorLoad=null;const i=+de.dataset.deleteLoad;st.model.loads.splice(i,1);if(st.editLoad!==null){st.editLoad=null;syncLoadForm();}renderLoadList();draftChanged();}
    if(ed) editLoad(+ed.dataset.editLoad);
  });
  $('#beamLoadKind').onchange=syncLoadForm;
  $('#beamCurveShape').onchange=syncLoadForm;
  // Switching between F and w0 keeps the same load: the entered value is converted, not reinterpreted.
  $('#beamCurveBasis').dataset.prev='total';
  let curveMemo=null;   // switching back without editing restores exactly what was typed
  $('#beamCurveBasis').onchange=e=>{
    const prev=e.target.dataset.prev, next=e.target.value;e.target.dataset.prev=next;
    try {
      const k=$('#beamLoadKind').value,a=Number($('#beamLoadA').value),b=Number($('#beamLoadB').value),raw=$('#beamCurveValue').value,v=Number(raw),shape=$('#beamCurveShape').value;
      const key=JSON.stringify([k,a,b,shape]);
      if(curveMemo&&curveMemo.key===key&&curveMemo.basis===next&&curveMemo.shown===raw) $('#beamCurveValue').value=curveMemo.raw;
      else if(String(raw).trim()!==''&&[a,b,v].every(Number.isFinite)&&b>a) {
        const nrm=LP.normalizeCurve({kind:k,start:a,end:b,shape,[prev]:v},{min:-Infinity,max:Infinity,lengthUnit:'mm'});
        const shown=String(Number(nrm[next].toPrecision(12)));
        curveMemo={key,basis:prev,raw,shown};$('#beamCurveValue').value=shown;
      }
    } catch(x) {}
    syncLoadForm();
  };
  $('#beamCsvTemplate').onclick=()=>download('beam_line_load_template.csv',LP.csvTemplate('beam'),'text/csv');
  $('#beamPowerPreview').onclick=()=>{try{const n=k=>readNumber($('#beamPower'+k),k);const p=LP.powerTable({start:n('A'),end:n('B'),total:n('F'),exponent:n('N'),shape:$('#beamPowerShape').value});$('#beamCsvText').value='x_mm,w_N_per_mm\n'+p.points.map(r=>r.join(',')).join('\n');previewCsv();}catch(e){$('#beamCsvResult').textContent=e.message;}};
  $('#beamCsvPreview').onclick=previewCsv;
  $('#beamCsvApply').onclick=applyCsv;
  $('#beamCsvCancel').onclick=closeCsv;
  $('#beamCsvMode').addEventListener('change',previewCsv);
  // Editing the text after choosing a file makes it a different table: drop the file name and hash.
  $('#beamCsvText').addEventListener('input',()=>{$('#beamCsvApply').disabled=true;if(st.csv.fromFile!==$('#beamCsvText').value){st.csv.filename='';st.csv.sha256='';}});
  $('#beamCsvFile').onchange=async e=>{
    const file=e.target.files&&e.target.files[0];if(!file) return;
    if(file.size>LP.LIMITS.csvBytes){$('#beamCsvResult').innerHTML=`<p class="bl-err">The file is larger than ${LP.LIMITS.csvBytes/1000} kB; a load table needs at most ${LP.LIMITS.tableRows} rows. Your loads are unchanged.</p>`;return;}
    const text=await file.text();
    // the hash is of the file's own bytes; the text area shows them with its line breaks normalised to LF
    $('#beamCsvText').value=text;st.csv.fromFile=$('#beamCsvText').value;st.csv.filename=String(file.name).slice(0,120);st.csv.sha256=await sha256Hex(text);
    previewCsv();
  };
  $('#beamLoadForm').addEventListener('input',()=>{curveLaw();renderLoadPreview();positionBeamEditor();});
  $('#beamLoadScale').onchange=()=>{renderPicture();renderLoadList();renderLoadPreview();};
  const applyLoad=e=>{submitLoad(e);positionBeamEditor();};
  $('#beamLoadForm').onsubmit=applyLoad;
  $('#beamLoadForm').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.matches('input')){e.preventDefault();if(!e.repeat)applyLoad(e);}if(e.key==='Escape'&&!$('#beamLoadEditor').hidden){e.preventDefault();e.stopPropagation();$('#beamLoadEditorClose').click();}});
  $('#beamLoadCancel').onclick=()=>{if(!$('#beamLoadEditor').hidden){$('#beamLoadEditorClose').click();return;}st.editLoad=null;renderLoadList();syncLoadForm();};
  $('#beamSelfWeight').onchange=()=>{renderSectionView();draftChanged();};
  $('#beamClear').onclick=clearLoads;
  $('#beamClearPicture').onclick=clearLoads;
  $('#beamClearSupports').onclick=clearSupports;
  $('#beamDeleteSelected').onclick=deleteSelection;
  $('#beamEditorClear').onclick=clearLoads;
  $('#beamEditorDelete').onclick=()=>{const i=selection?.type==='load'?selection.index:st.editorLoad;if(i===null||!st.model.loads[i])return;selection={type:'load',index:i};st.graphicPreview=null;deleteSelection();};
  host.querySelectorAll('[data-beam-preset]').forEach(b=>b.onclick=()=>{
    const name=b.dataset.beamPreset;st.model=presetModel(name);st.editLoad=null;renderInputs(st.model);fillFormFromSingleLoad();
    solve('Lecture 03 example loaded: all previous loads replaced; 450 × 20 × 10 mm, E = 2000 MPa.');
    host.querySelectorAll('[data-stage]').forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.stage==='beam')));
  });
  host.querySelectorAll('[data-stage]').forEach(b=>b.onclick=()=>{
    const s=b.dataset.stage;
    if(s==='beam') {host.querySelectorAll('[data-stage]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));}
    else if(document.documentElement.dataset.wingReady==='true') window.dispatchEvent(new CustomEvent('wing-learning-stage',{detail:s}));
    else {const msg=$('#beamStatus');msg.textContent='The 3-D workspace is not ready. It needs WebGL and an internet connection to load its graphics libraries. Reload when connected; the beam lessons still work.';if(msg.scrollIntoView)msg.scrollIntoView({block:'center'});}
  });
  // Tabs: click and arrow-key roving focus.
  const tabs=$$('.bl-tabs [role="tab"]');
  tabs.forEach((b,i)=>{b.onclick=()=>openTab(b.dataset.tab);b.onkeydown=e=>{
    const k=e.key, j=k==='ArrowRight'?(i+1)%tabs.length:k==='ArrowLeft'?(i-1+tabs.length)%tabs.length:k==='Home'?0:k==='End'?tabs.length-1:-1;
    if(j>=0){e.preventDefault();openTab(tabs[j].dataset.tab,true);}};});
  // Placement tools and dragging on the picture.
  host.querySelectorAll('[data-place]').forEach(b=>b.onclick=()=>setPlacing(b.dataset.place));
  function cancelPlacement() {if(st.drag&&st.drag.type==='load')st.model.loads[st.drag.index]=st.drag.original;st.placing=null;st.drag=null;st.graphicPreview=null;$$('[data-place]').forEach(b=>b.setAttribute('aria-pressed','false'));renderLoadList();renderPicture();renderStatus();message('Placement cancelled. Existing loads are unchanged.');}
  $('#beamStopPlacing').onclick=cancelPlacement;
  $('#beamShowDefl').onclick=e=>{st.showDeflection=!st.showDeflection;e.currentTarget.setAttribute('aria-pressed',String(st.showDeflection));renderPicture();};
  document.addEventListener('keydown',e=>{
    if(!host.hidden&&(e.ctrlKey||e.metaKey)&&!e.altKey&&!e.target.closest('input,textarea,select,[contenteditable],[role="textbox"]')&&['z','y'].includes(e.key.toLowerCase())){
      e.preventDefault();travelHistory(e.key.toLowerCase()==='y'||e.shiftKey?1:-1);return;
    }
    if(e.key==='Escape'&&(st.placing||st.drag||st.graphicPreview))cancelPlacement();
    if(e.key!=='Delete'||e.ctrlKey||e.altKey||e.metaKey||host.hidden)return;
    if(!host.contains(e.target)&&e.target!==document.body&&e.target!==document.documentElement)return;
    if(e.target.closest('input,textarea,select,[contenteditable="true"],[role="textbox"]'))return;
    if(selection){e.preventDefault();deleteSelection();}
  });
  const pic=$('#beamPicture');
  let pending=false;
  const frame=fn=>{if(pending)return;pending=true;raf(()=>{pending=false;fn();});};
  pic.addEventListener('pointerdown',e=>{
    if(e.button!==undefined&&e.button!==0)return;
    if(!st.placing){selection=selectionFrom(e.target);decorateSelection();if(selection&&e.target.closest('[tabindex]'))e.target.closest('[tabindex]').focus();}
    const loadHandle=e.target.closest('[data-load-handle]');
    if(st.placing&&st.placing.startsWith('load:')&&!['load:point','load:moment'].includes(st.placing)) {
      const x=svgX(e);if(x===null||st.drawnInvalid)return;
      st.drag={type:'load-range',start:snap(x,st.drawn.length),kind:st.placing.slice(5)};
      st.graphicPreview={start:st.drag.start,end:st.drag.start};
      if(pic.setPointerCapture)try{pic.setPointerCapture(e.pointerId);}catch(z){}e.preventDefault();return;
    }
    if(!st.placing&&loadHandle) {
      if(st.drawnInvalid){message('Fix invalid inputs before moving a load.');return;}
      const x=svgX(e),index=+loadHandle.dataset.loadHandle;
      if(x===null||!st.model.loads[index])return;
      st.drag={type:'load',index,start:x,original:clone(st.model.loads[index]),moved:false};
      if(pic.setPointerCapture)try{pic.setPointerCapture(e.pointerId);}catch(z){}e.preventDefault();return;
    }
    const drag=e.target.closest('[data-draggable]');
    if(st.placing) return;
    if(drag&&!e.target.closest('.bl-ghost')) {
      // The fallback picture (invalid inputs) shows the solved model, whose rows differ from the inputs.
      if(st.drawnInvalid) {message('Fix the invalid input first: the picture shows the last valid model.');return;}
      const svg=pic.querySelector('svg');
      if(drag.dataset.draggable==='hinge') st.drag={type:'hinge',index:+drag.dataset.hingeIndex};
      else {const s=st.drawn&&st.drawn.supports[+drag.dataset.supportIndex];st.drag={type:'support',index:s&&s.row>=0?s.row:-1};}
      if(!(st.drag.index>=0)){st.drag=null;return;}
      if(pic.setPointerCapture)try{pic.setPointerCapture(e.pointerId);}catch(x){}
      e.preventDefault();return;
    }
    if(cutTab()&&st.solved&&isCurrent()) {st.drag={type:'cut'};const x=svgX(e);if(x!==null){setCut(x);if(window.BeamStrengthUI)window.BeamStrengthUI.inspectAt(x);}if(pic.setPointerCapture)try{pic.setPointerCapture(e.pointerId);}catch(z){}}
  });
  pic.addEventListener('pointermove',e=>{
    if(st.drag&&st.drag.type==='load-range') {const x=svgX(e);if(x!==null){st.graphicPreview={start:Math.min(st.drag.start,snap(x,st.drawn.length)),end:Math.max(st.drag.start,snap(x,st.drawn.length))};frame(()=>renderPicture());}return;}
    if(st.drag&&st.drag.type==='load') {
      const x=svgX(e);if(x===null)return;
      const d=st.drag,p=d.original,L=st.drawn.length;
      let delta=snap(x,L)-snap(d.start,L);
      const a=p.kind==='table'?p.points[0][0]:LD.isDist(p)?p.start:p.position;
      const b=p.kind==='table'?p.points.at(-1)[0]:LD.isDist(p)?p.end:p.position;
      delta=Math.max(-a,Math.min(L-b,delta));d.moved=Math.abs(delta)>L*1e-10;
      const q=clone(p);
      if(p.kind==='table'){q.points=q.points.map(([s,w])=>[s+delta,w]);delete q.source;}
      else if(LD.isDist(p)){q.start+=delta;q.end+=delta;}else q.position+=delta;
      st.model.loads[d.index]=q;renderLoadList();frame(()=>{renderPicture();renderStatus();});return;
    }
    if(st.placing&&st.placing.startsWith('load:')) {const x=svgX(e);if(x!==null){st.graphicPreview={start:snap(x,st.drawn.length),end:snap(x,st.drawn.length)};frame(()=>renderPicture());}return;}
    if(st.placing) {const x=svgX(e);if(x!==null)frame(()=>renderPicture({x:snap(x,st.model.length),kind:st.placing}));return;}
    if(!st.drag) return;
    const x=svgX(e);if(x===null)return;
    if(st.drag.type==='cut') {const drag=st.drag;frame(()=>{if(st.drag===drag)setCut(x);});return;}
    const L=st.model.length, sx=Math.min(L*0.995,Math.max(L*0.005,snap(x,L)));
    const rows=st.drag.type==='hinge'?hingeRows():interiorRows(), input=rows[st.drag.index]&&rows[st.drag.index].querySelector('[data-field="x"]');
    if(input){input.value=sx;frame(()=>{renderPicture();renderStatus();});}
  });
  const endDrag=e=>{if(!st.drag)return;const d=st.drag;st.drag=null;
    if(d.type==='cut'){const x=svgX(e);if(x!==null)setCut(x);return;}
    if(d.type==='load-range'){const x=svgX(e);st.suppressPlaceClick=true;if(x!==null&&Math.abs(snap(x,st.drawn.length)-d.start)>st.drawn.length*1e-9)prepareGraphicLoad(d.kind,d.start,snap(x,st.drawn.length));else {st.graphicPreview=null;renderPicture();message('Choose a non-zero interval by dragging along the beam.');}return;}
    if(d.type==='load'){st.suppressPlaceClick=true;if(d.moved){draftChanged();message('Load moved. Press Solve to update results (or enable auto-solve).');const selected=pic.querySelector(`[data-load-handle="${d.index}"]`);if(selected)selected.focus();}else editLoad(d.index);return;}
    if(d.type!=='cut'){draftChanged();const selected=selection&&pic.querySelector(selection.type==='hinge'?`[data-hinge-index="${selection.index}"]`:`[data-support-index="${selection.index}"]`);if(selected)selected.focus();}};
  pic.addEventListener('pointerup',endDrag);
  pic.addEventListener('pointercancel',()=>{if(st.drag&&st.drag.type==='load')st.model.loads[st.drag.index]=st.drag.original;st.drag=null;st.graphicPreview=null;renderLoadList();renderPicture();renderStatus();});
  pic.addEventListener('focusin',e=>{const s=selectionFrom(e.target);if(s){selection=s;decorateSelection();}});
  pic.addEventListener('dblclick',e=>{const s=selectionFrom(e.target);if(s&&s.type==='load')editLoad(s.index);});
  pic.addEventListener('keydown',e=>{const s=selectionFrom(e.target);if(s&&(e.key==='Enter'||e.key===' ')){e.preventDefault();selection=s;decorateSelection();if(s.type==='load')editLoad(s.index);}});
  pic.addEventListener('click',e=>{if(st.suppressPlaceClick){st.suppressPlaceClick=false;return;}if(!st.placing){const s=selectionFrom(e.target);if(s){selection=s;decorateSelection();e.target.closest('[tabindex]')?.focus();if(s.type==='load')editLoad(s.index);else if(!$('#beamLoadEditor').hidden)$('#beamLoadEditorClose').click();}return;}const x=svgX(e);if(x!==null)placeAt(snap(x,st.model.length));});
  // Cut controls.
  $('#beamCut').oninput=e=>setCut(+e.target.value);
  $('#beamCutX').onchange=e=>{const v=Number(e.target.value);if(Number.isFinite(v))setCut(v);};
  host.querySelectorAll('[data-cut-side]').forEach(b=>b.onclick=()=>{st.cut.side=b.dataset.cutSide;renderCut();});
  host.querySelectorAll('[data-cut-limit]').forEach(b=>b.onclick=()=>{st.cut.limit=b.dataset.cutLimit;refreshCut();});
  $('#beamCutSnaps').onclick=e=>{const b=e.target.closest('[data-cut-to]');if(b)setCut(+b.dataset.cutTo);};
  // Station readout (Diagrams): typed x (Enter or change), quarter points and key stations.
  $('#beamStationForm').onsubmit=e=>{e.preventDefault();applyStationInput();};
  $('#beamStationX').onchange=applyStationInput;
  $('#beamStationQuick').onclick=e=>{const b=e.target.closest('[data-station-frac]');if(b&&st.solved)setCut(+b.dataset.stationFrac*st.solved.model.length);};
  $('#beamStationSnaps').onclick=e=>{const b=e.target.closest('[data-cut-to]');if(b)setCut(+b.dataset.cutTo);};
  // Modes, verification, compare, export.
  $('#beamAnimate').onclick=()=>{st.animated=!st.animated;$('#beamAnimate').textContent=st.animated?'Pause mode':'Animate mode';renderMode();};
  setInterval(()=>{if(st.animated&&!host.hidden&&st.tab==='modes'&&!reducedMotion()){st.phase+=.18;renderMode();}},80);
  $('#beamRefine').onclick=refine;
  $('#beamSaveA').onclick=()=>snapshot('A');$('#beamSaveB').onclick=()=>snapshot('B');
  $('#beamClearAB').onclick=()=>{st.compare={A:null,B:null};renderCompare();};
  $('#beamEqualMassBtn').onclick=equalMass;
  $('#beamDownload').onclick=()=>{if(!guard())return;download('MIE446-beam-study.json',exportText(),'application/json');exportStatus('Study saved as MIE446-beam-study.json (versioned JSON).');};
  $('#beamSaveJson').onclick=()=>{try{const text=portableText();download('MIE446-beam-study.json',text,'application/json');exportStatus(JSON.parse(text).state==='draft'?'Current inputs saved as JSON (working draft, not a solved result).':'Current study saved as JSON. Inputs will be validated and results recomputed when opened.');}catch(e){exportStatus('JSON not saved: '+e.message+' Correct the invalid input first.');}};
  $('#beamCsv').onclick=()=>exportAction('samples');
  $('#beamCsvReactions').onclick=()=>exportAction('reactions');
  // Downloads offered on the Diagrams tab (and the station table) use the same guarded actions.
  host.addEventListener('click',e=>{const b=e.target.closest('[data-export]');if(b&&!b.disabled)exportAction(b.dataset.export);
    const t=e.target.closest('[data-open-tab]');if(t)openTab(t.dataset.openTab,true);});
  $('#beamCharts').addEventListener('click',e=>{const b=e.target.closest('[data-png]');if(b&&!b.disabled)chartPng(b.dataset.png);});
  $('#beamStationListForm').onsubmit=e=>{e.preventDefault();applyStationList();};
  $('#beamStationAdd').onclick=()=>{if(!st.solved)return;st.stationList=[...stationList(),st.cut.x];$('#beamStationListError').hidden=true;renderStationTable();};
  $('#beamStationReset').onclick=()=>{st.stationList=null;$('#beamStationListError').hidden=true;renderStationTable();};
  $('#beamGuideOpen').onclick=()=>{openTab('learn');const h=$('#beamGuideTitle');if(h.scrollIntoView)h.scrollIntoView({block:'start'});h.focus();};
  $('#beamImport').onclick=()=>$('#beamImportFile').click();
  $('#beamOpenJson').onclick=()=>$('#beamImportFile').click();
  $('#beamImportFile').addEventListener('cancel',()=>{cancelBeamFileRead();exportStatus('Open cancelled. Your current beam study is unchanged.');});
  $('#beamImportFile').onchange=async e=>{
    const file=e.target.files&&e.target.files[0];e.target.value='';
    if(!file) return;
    cancelBeamFileRead();const ticket=beamFileReadTicket,stamp=beamInputStamp();
    if(file.size>Study.LIMITS.fileBytes){$('#beamOpenJson').disabled=false;$('#beamImport').disabled=false;exportStatus('Import refused: the file is too large to be a beam study.');return;}
    $('#beamOpenJson').disabled=true;$('#beamImport').disabled=true;exportStatus('Reading '+file.name+'…');
    try {const text=typeof file.text==='function'?await file.text():await new Promise((resolve,reject)=>{const active=beamActiveRead={cancel:()=>resolve(null)},reader=active.reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('The file could not be read.'));reader.onabort=()=>resolve(null);reader.readAsText(file);});if(ticket===beamFileReadTicket&&text!==null){beamActiveRead=null;if(stamp!==beamInputStamp())exportStatus('Open cancelled: beam inputs changed while the file was being read. Your new edits are kept; select the file again to replace them.');else importText(text);}} catch(x) {if(ticket===beamFileReadTicket)exportStatus(`Import refused: ${x.message} Your current study is unchanged.`);}finally{if(ticket===beamFileReadTicket){beamActiveRead=null;$('#beamOpenJson').disabled=false;$('#beamImport').disabled=false;}}
  };
  $('#beamShare').onclick=async()=>{
    if(!guard()) return;
    let url;
    try {url=Study.shareUrl(st.solved.model,window.location.href);} catch(x) {exportStatus(x.message);return;}
    const box=$('#beamShareBox');box.value=url;box.hidden=false;
    try {await navigator.clipboard.writeText(url);exportStatus('Share link copied. It opens this exact model, solved again (results are recomputed, notes are not included).');}
    catch(x) {box.select&&box.select();exportStatus('Copy the link from the box below (clipboard not available here).');}
  };
  $('#beamPrintBtn').onclick=printReport;
  let resizeTimer=0;
  window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(host.hidden)return;renderPicture();if(st.solved){renderCharts();renderStressMap();renderStation();renderMode();if(st.tab==='cut')renderCut();if(st.tab==='compare')renderCompare();if(st.tab==='solution'){st.cache.solution=false;renderSolution();}}},150);});

  /* ---------------------------------------------------------- start-up */

  // Independent open-channel section calculator. It does not silently replace the solved beam.
  $('#beamTab-cut').insertAdjacentHTML('beforeend',`<section class="bl-box" id="beamFlowLab"><h3>Shear flow &amp; shear centre</h3><p>Shear flow qₛ is longitudinal force per unit member length (N/mm), not applied line load q(x), and not shear stress τ (N/mm²). For a homogeneous open thin wall: qₛ=VQ/I and τ=qₛ/t. For two bonded materials use the transformed Q and I; the interface flow is shown in the two-material stress view.</p><p>Rectangle, circle, tube, box and symmetric I-section have their shear centre at the centroid by double symmetry. The vertical-symmetry plane prevents torsion from vertical shear in the bonded rectangle, but this solver does not compute its full shear-centre position for arbitrary loading.</p><h4>Open-channel example · separate section calculator</h4><p>Uniform isotropic wall; h and b are <b>midline</b> dimensions. This is not an additional channel beam or torsional FE model. Corners, thickness offsets, warping restraint and closed-cell redundant flows are not solved. No load is added to your beam by these fields.</p><div class="bl-grid2">${[['bfH','Midline web height h','40'],['bfB','Flange midline width b','20'],['bfT','Wall thickness t','1'],['bfV','Shear V (N, upward +)','10'],['bfY','Force-line y from web (mm)','0']].map(([id,label,val])=>`<label class="bl-field"><span>${label}</span><input id="${id}" type="number" step="any" value="${val}"></label>`).join('')}</div><button class="bl-btn" type="button" id="bfUseCut">Use |V| at the current beam cut</button><div id="bfResult" aria-live="polite"></div><p class="bl-help">Theory: <a href="https://ocw.mit.edu/courses/16-20-structural-mechanics-fall-2002/13881c48c7c4654e4b5b689cb6987803_unit14.pdf" target="_blank" rel="noopener noreferrer">MIT 16.20: beam shear and shear centre</a>. Open-channel values below use thin-wall force and moment equilibrium, not a universal closed-section formula.</p></section>`);
  function renderFlowLab(){
    try{
      const get=id=>readNumber($('#'+id),id),c=SEC.channelFlow({height:get('bfH'),width:get('bfB'),thickness:get('bfT')},get('bfV')),yF=get('bfY'),s=Math.min(140/c.h,100/c.b),wx=170,cy=125,yt=cy-c.h*s/2,yb=cy+c.h*s/2,sc=wx+c.shearCentreY*s,g=wx+c.centroidY*s;
      $('#bfResult').innerHTML=`<svg viewBox="0 0 420 250" role="img" aria-label="Open channel with shear centre outside the web, centroid, force and shear-flow directions" style="width:100%;max-width:600px"><path d="M${wx+c.b*s} ${yt}H${wx}V${yb}H${wx+c.b*s}" fill="none" stroke="#145d85" stroke-width="10"/><path d="M60 ${cy}H320" stroke="#71879b" stroke-dasharray="5 4"/><circle cx="${sc}" cy="${cy}" r="5" fill="#bf3d42"/><circle cx="${g}" cy="${cy}" r="4" fill="#16836b"/><g font-family="system-ui" font-size="13" fill="currentColor"><text x="${sc-8}" y="${cy+23}">S</text><text x="${g-3}" y="${cy-10}">G</text><text x="${wx+10}" y="${yt-16}">${c.V>=0?'→':'←'} flange flow</text><text x="${wx+10}" y="${yb+27}">${c.V>=0?'←':'→'} flange flow</text><text x="${wx-28}" y="${cy-25}">${c.V>=0?'↑':'↓'}</text><text x="12" y="22">S: shear centre · G: area centroid</text><text x="12" y="239">Web y=0; flanges extend toward +y</text></g><path d="M${sc} ${cy+65}V${cy+10}m-5 9 5-9 5 9" fill="none" stroke="#bf3d42" stroke-width="2"/></svg><dl class="bl-props"><dt>Thin-wall I</dt><dd>${fmt(c.I)} mm⁴</dd><dt>Centroid yG from web</dt><dd>${fmt(c.centroidY)} mm</dd><dt>Shear centre yS from web</dt><dd>${fmt(c.shearCentreY)} mm (outside)</dd><dt>Offset S−G</dt><dd>${fmt(c.offsetFromCentroid)} mm</dd><dt>Maximum web flow |qₛ|</dt><dd>${fmt(Math.abs(c.qWeb(0)))} N/mm</dd><dt>Maximum |τ|</dt><dd>${fmt(c.tauMax)} MPa</dd><dt>Torque if applied at yF</dt><dd>${fmt(c.V*(yF-c.shearCentreY))} N·mm</dd></dl><p>I=th³/12+2tb(h/2)². e=th²b²/(4I), yS=−e. A flange has resultant Ff=Vthb²/(4I); Ff h = V e locates S by torque equilibrium. qₛ,flange(s)=Vths/(2I), where s runs from the free edge toward the web. qₛ,web(z)=Vt[bh/2+(h²/4−z²)/2]/I. At free edges qₛ=0. Along each wall τ=qₛ/t.</p><p class="bl-help">The red arrow illustrates applying shear through S (no eccentric-shear torque). The torque number instead uses your entered yF=${fmt(yF)} mm: T=V(yF−yS). No twist angle is calculated in this section example.</p>`;
      const forceArrow=$('#bfResult svg path[stroke="#bf3d42"]');
      if(c.V<0)forceArrow.setAttribute('transform',`translate(0 ${2*cy}) scale(1 -1)`);
      if(c.V===0){forceArrow.style.display='none';$('#bfResult svg').querySelectorAll('text').forEach(t=>{if(t.textContent.includes('flange flow'))t.textContent='qₛ = 0';if(t.textContent==='↑'||t.textContent==='↓')t.textContent='';});}
    }catch(e){$('#bfResult').innerHTML='<p class="bl-err">'+esc(e.message)+'</p>';}
  }
  $('#beamFlowLab').addEventListener('input',renderFlowLab);
  for(const id of ['bfH','bfB','bfT'])$('#'+id).closest('label').querySelector('span').textContent+=' (mm)';
  $('#bfUseCut').onclick=()=>{if(!st.solved||statusState()!=='solved'){$('#bfResult').innerHTML='<p class="bl-err">Solve the current beam first.</p>';return;}$('#bfV').value=Math.abs(B.fieldAt(st.solved.result,st.cut.x).V);renderFlowLab();};
  renderFlowLab();
  $('#beamTab-learn').insertAdjacentHTML('beforeend','<section class="bl-box"><h3>Two materials: compatibility before stress</h3><p>The bonded two-material rectangle has lower material 1 and upper material 2. The E and density inputs define material 1; E₂/E₁ and ρ₂/ρ₁ define material 2. Upper thickness h₂ is measured down from the top surface. Both materials are individually linear isotropic; this is not a fibre-composite laminate model.</p><p><b>Compatibility:</b> perfect bonding makes the axial strain continuous across the interface and preserves plane sections. <b>Axial equilibrium:</b> with no applied axial force, ∫σ dA=0, so zNA=Σ(EᵢAᵢzᵢ)/Σ(EᵢAᵢ). <b>Bending:</b> D=Σ Eᵢ[Iᵢ,c+Aᵢ(zᵢ−zNA)²]=E₁Itrans. Thus εx=−M(z−zNA)/D and σᵢ=Eᵢεx. The strain is continuous, but stress generally jumps when E changes.</p><p><b>Shear transfer:</b> define Qtrans(z)=∫above (Eᵢ/E₁)(z′−zNA)dA. Then qₛ=VQtrans/Itrans and τ=qₛ/b for this rectangular two-layer section. At the bond this is the longitudinal shear transferred per unit beam length. It is an average elastic demand, not a prediction of adhesive peel stress or debonding strength. V and M come from the same beam equilibrium as before; curvature uses the composite D, while mass and self-weight use ΣρᵢAᵢ. Unequal densities make equal area different from equal mass.</p><p><b>Limits:</b> straight prismatic layers, perfect bond and small deflection; no slip, delamination, adhesive failure, temperature strain, plasticity or anisotropic laminate coupling. The shear-centre example in Cut &amp; section is a separate open-channel calculation, not an added torsional degree of freedom.</p><p>Reference: <a href="https://ocw.mit.edu/courses/1-050-solid-mechanics-fall-2004/resources/emech9_04/" target="_blank" rel="noopener noreferrer">MIT Solid Mechanics: composite beams, compatibility, constitutive relations and shear</a>.</p></section>');

  renderInputs(st.model);
  fillFormFromSingleLoad();
  if(st.model.supports.length) solve();
  else {draftChanged();message('Initial beam: 450 mm, rectangular section 20 × 10 mm. Edit its dimensions and material on the left; then place supports, add loads and Solve. No load or support is applied automatically.');}
  if(lectureCase) message('Lecture 03 example loaded and solved. Dimensions: '+st.model.length+' × '+st.model.section.width+' × '+st.model.section.height+' mm; E = '+st.model.E+' MPa. Previous loads replaced.');
  else if(startMessage) message(startMessage);
  if(!hasInitialStudy)$$('.bl-input[data-invalid]',host).forEach(el=>el.dataset.invalid='false');
  host.querySelectorAll('[data-stage]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.stage==='beam')));
  // readStation(): the exact values at the current cut station (both limits at a jump), as the readout shows them.
  const readStation=()=>{if(!st.solved)return null;const c=cutInfo();return {x:c.x,limit:c.limit,jump:!!c.jump,left:c.left,right:c.right,at:c.at};};
  window.BeamLab={version:B.VERSION,state:()=>st,solve,importText,exportText:()=>exportText(),portableText,openTab,setCut,readStation,plotImage,snapshot,revert};
})();
