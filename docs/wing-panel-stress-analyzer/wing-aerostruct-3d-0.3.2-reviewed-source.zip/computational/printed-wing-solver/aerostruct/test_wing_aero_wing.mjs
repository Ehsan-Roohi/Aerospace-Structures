// Wing-pipeline checks of wing_aero_panel.js on Wing Lab geometry (WingGeometry/WingAirfoils):
// mirror-image half wing versus an explicitly meshed full span, translation and rotation invariance,
// symmetry of lift, stagnation bound, near-elliptic loading of an elliptic planform, and mesh-
// convergence receipts for every planform the geometry module supports, including the two course
// fixtures. Receipts print measured values; assertions are acceptance bounds, not accuracy claims.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync, existsSync } from 'node:fs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js'), E = require('../web/engine.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const fixture = name => { const dir = process.env.WING_FIXTURES_DIR ? new URL(`file://${process.env.WING_FIXTURES_DIR}/`) : new URL('../../../tests/fixtures/', import.meta.url), url = new URL(name, dir); return existsSync(url) ? JSON.parse(readFileSync(url, 'utf8')) : null; };

// 1. Mirror image versus explicit full span (same discrete problem: must agree to round-off).
{
  const geo = { semiSpan: 300, rootChord: 140, tipChord: 80, naca: '2412', sweepDeg: 15, dihedralDeg: 6, sweepReferenceFraction: 0.25 };
  const wm = W.wingMesh(W.aeroGeometry(geo), { chordPanels: 10, spanPanels: 6 }), S = wm.S, n = S.count;
  const half = W.unitSolutions(S, { image: true, wake: wm.wake, farField: Infinity, solver: 'lu' });
  const nodes = wm.S.nodes, nn = nodes.length / 3, full = new Float64Array(2 * nodes.length);
  full.set(nodes); for (let i = 0; i < nn; i++) { full[3 * (nn + i)] = nodes[3 * i]; full[3 * (nn + i) + 1] = -nodes[3 * i + 1]; full[3 * (nn + i) + 2] = nodes[3 * i + 2]; }
  const quads = new Int32Array(8 * n); quads.set(wm.S.quads);
  for (let k = 0; k < n; k++) for (let q = 0; q < 4; q++) quads[4 * (n + k) + q] = nn + wm.S.quads[4 * k + 3 - q];
  const SF = W.buildSurface(full, quads), w = wm.wake, m = w.count, fw = { count: 2 * m, a: new Float64Array(6 * m), b: new Float64Array(6 * m), dir: w.dir, kuttaWidth: w.kuttaWidth, kuttaPanels: new Int32Array(2 * m * w.kuttaWidth), kuttaWeights: new Float64Array(2 * m * w.kuttaWidth) };
  fw.a.set(w.a); fw.b.set(w.b); fw.kuttaPanels.set(w.kuttaPanels); fw.kuttaWeights.set(w.kuttaWeights);
  for (let j = 0; j < m; j++) {
    for (const [dst, src] of [[fw.a, w.b], [fw.b, w.a]]) { dst[3 * (m + j)] = src[3 * j]; dst[3 * (m + j) + 1] = -src[3 * j + 1]; dst[3 * (m + j) + 2] = src[3 * j + 2]; }
    for (let q = 0; q < w.kuttaWidth; q++) { fw.kuttaPanels[(m + j) * w.kuttaWidth + q] = n + w.kuttaPanels[j * w.kuttaWidth + q]; fw.kuttaWeights[(m + j) * w.kuttaWidth + q] = w.kuttaWeights[j * w.kuttaWidth + q]; }
  }
  const fs = W.unitSolutions(SF, { image: false, wake: fw, farField: Infinity, solver: 'lu' });
  let d = 0, s = 0; for (let k = 0; k < n; k++) { d = Math.max(d, Math.abs(fs.muz[k] - half.muz[k]), Math.abs(fs.mux[k] - half.mux[k]), Math.abs(fs.muz[n + k] - half.muz[k])); s = Math.max(s, Math.abs(half.muz[k])); }
  log(`image half-wing vs explicit full span (${n} + ${n} panels, sweep 15, dihedral 6): max doublet difference ${(d / s).toExponential(2)} (relative)`);
  ok(d / s < 1e-10, 'mirror image identical to the explicit full-span discretization');
}
// 2. Translation and rotation invariance.
{
  const base = { semiSpan: 250, rootChord: 120, tipChord: 90, naca: '0012' }, mesh = { chordPanels: 12, spanPanels: 8 };
  const a = W.solve(base, { alphaDeg: 5, speed: 12 }, mesh);
  const rot = { ...base, twistEnabled: true, twistReferenceFraction: 0.4, stations: [{ eta: 0, airfoil: '0012', incidenceDeg: 5 }, { eta: 1, airfoil: '0012', incidenceDeg: 5 }] };
  const b = W.solve(rot, { alphaDeg: 0, speed: 12 }, mesh);
  // the wake leaves along body x in both models; in the rotated model the body x is the freestream
  const dl = Math.abs(a.coefficients.CL - b.coefficients.CL) / a.coefficients.CL;
  log(`alpha 5 deg vs geometric incidence 5 deg at alpha 0: CL ${a.coefficients.CL.toFixed(5)} vs ${b.coefficients.CL.toFixed(5)} (relative ${dl.toExponential(2)}; differs only through the body-axis wake direction)`);
  // body-axis wake: the two models differ by the wake direction only (0.19% with a flat tip cap, 0.20% with the rounded tip)
  ok(dl < 3e-3, 'incidence rotation equals angle of attack to within the wake-direction modelling');
  const shifted = W.solve({ ...base, sweepDeg: 0 }, { alphaDeg: 5, speed: 12 }, mesh); // identical geometry: deterministic
  ok(Math.abs(shifted.coefficients.CL - a.coefficients.CL) < 1e-12, 'repeatable solution');
  const m1 = W.prepare(base, mesh), S = m1.wm.S;
  // translate every node and wake point: same unit solutions
  const tr = [37, 0, -11], nodes = Float64Array.from(S.nodes, (v, i) => v + tr[i % 3]), S2 = W.buildSurface(nodes, S.quads);
  const wake = { ...m1.wm.wake, a: Float64Array.from(m1.wm.wake.a, (v, i) => v + tr[i % 3]), b: Float64Array.from(m1.wm.wake.b, (v, i) => v + tr[i % 3]) };
  const u1 = W.unitSolutions(S, { image: true, wake: m1.wm.wake, solver: 'lu' }), u2 = W.unitSolutions(S2, { image: true, wake, solver: 'lu' });
  let d = 0; for (let k = 0; k < S.count; k++) d = Math.max(d, Math.abs(u1.muz[k] - u2.muz[k]));
  ok(d < 1e-10 * Math.max(...u1.muz.map(Math.abs)), 'translation invariance (x, z)');
}
// 3. Symmetric section: zero lift at zero incidence, odd lift in alpha; stagnation bound.
{
  const m = W.prepare({ semiSpan: 300, rootChord: 150, tipChord: 100, naca: '0012' }, { chordPanels: 16, spanPanels: 12 });
  const z = W.evaluate(m, { alphaDeg: 0 }), p = W.evaluate(m, { alphaDeg: 6 }), q = W.evaluate(m, { alphaDeg: -6 });
  ok(Math.abs(z.coefficients.CL) < 1e-12 && Math.abs(z.coefficients.Cm) < 1e-12, 'symmetric section: no lift or moment at zero incidence');
  ok(Math.abs(p.coefficients.CL + q.coefficients.CL) < 1e-12, 'lift odd in alpha');
  ok(Math.abs(p.coefficients.CDiTrefftz - q.coefficients.CDiTrefftz) < 1e-12 * p.coefficients.CDiTrefftz, 'induced drag even in alpha');
  ok(p.diagnostics.maxCp <= 1.02, `stagnation bound: max Cp ${p.diagnostics.maxCp.toFixed(4)}`);
}
// 4. Receipts: every supported planform at three mesh levels.
const GEOMETRIES = [
  ['rectangular NACA 0012, AR 6', { semiSpan: 600, rootChord: 200, tipChord: 200, naca: '0012' }],
  ['tapered NACA 2412 (course default)', { semiSpan: 450, rootChord: 160, tipChord: 100, naca: '2412' }],
  ['elliptic closed tip NACA 0012', { planform: 'elliptic', semiSpan: 450, rootChord: 160, tipChord: 0, naca: '0012' }],
  ['elliptic open tip NACA 2412', { planform: 'elliptic', semiSpan: 450, rootChord: 160, tipChord: 60, naca: '2412' }],
  ['delta closed tip NACA 0008', { planform: 'delta', semiSpan: 250, rootChord: 300, tipChord: 0, naca: '0008' }],
  ['swept 20, dihedral 5, twisted, 2412 -> 23012 -> Clark Y DAT', { semiSpan: 400, rootChord: 160, tipChord: 90, sweepDeg: 20, dihedralDeg: 5, sweepReferenceFraction: 0.25, twistEnabled: true, twistReferenceFraction: 0.25,
    stations: [{ eta: 0, airfoil: { kind: 'naca4', code: '2412' }, incidenceDeg: 2 }, { eta: 0.45, airfoil: { kind: 'naca5', code: '23012' }, incidenceDeg: 0 }, { eta: 1, airfoil: require('../web/wing_airfoils.js').preset('clarky'), incidenceDeg: -2 }] }],
];
const LEVELS = [{ chordPanels: 16, spanPanels: 8 }, { chordPanels: 32, spanPanels: 16 }, { chordPanels: 48, spanPanels: 24 }]; // single-mesh receipts (structural loads use the mesh sequences, test_wing_aero_admission.mjs)
for (const [name, geo] of GEOMETRIES) {
  const rows = LEVELS.map(mesh => { const t = Date.now(), r = W.solve(geo, { speed: 15, alphaDeg: 4 }, mesh); return { mesh, r, ms: Date.now() - t }; });
  log(`${name}:`);
  for (const { mesh, r, ms } of rows) { const c = r.coefficients; log(`   ${String(r.mesh.panels).padStart(4)} panels (${mesh.chordPanels}x2 x ${mesh.spanPanels}): CL ${c.CL.toFixed(4)}, CL_Trefftz ${c.CLTrefftz.toFixed(4)}, CDi ${c.CDiTrefftz.toFixed(5)}, e ${c.spanEfficiencyTrefftz.toFixed(3)}, Cm ${c.Cm.toFixed(4)}, max Cp ${r.diagnostics.maxCp.toFixed(3)}, ${ms} ms`); }
  const [, mid, fine] = rows.map(x => x.r.coefficients);
  ok(Math.abs(fine.CL - mid.CL) / Math.abs(fine.CL) < 0.03, `${name}: CL change between the two finer meshes < 3%`);
  ok(Math.abs(fine.CL - fine.CLTrefftz) / Math.abs(fine.CL) < 0.02, `${name}: pressure and Trefftz lift agree within 2% on the fine mesh`);
  ok(fine.spanEfficiencyTrefftz > 0.85 && fine.spanEfficiencyTrefftz < (geo.dihedralDeg ? 1.03 : 1.01), `${name}: planar span efficiency within physical bounds`);
  ok(rows.every(x => x.r.diagnostics.maxCp < 1.02), `${name}: Cp below the stagnation bound`);
  if (geo.planform === 'elliptic' && geo.tipChord === 0) ok(Math.abs(fine.spanEfficiencyTrefftz - 1) < 0.01, 'elliptic planform: e within 1% of 1');
  if (geo.planform === 'delta') ok(rows[0].r.warnings.some(w => /leading-edge vortex/.test(w)), 'delta planform warns about vortex lift');
}
// 5. The two course fixtures through WingEngine.makeGeometry (the app's own geometry normalisation).
for (const name of ['wing_lab_course_browser.json', 'wing_lab_one_piece_browser.json']) {
  const doc = fixture(name);
  if (!doc) { log(`fixture ${name} not found (set WING_FIXTURES_DIR); skipped`); continue; }
  const g = E.makeGeometry(doc.study.geometry), t = Date.now(), m = W.prepare(g, {}), r = W.evaluate(m, { speed: 15, density: 1.225, alphaDeg: 4 });
  const c = r.coefficients, sw = r.semiWing;
  log(`${name}: ${r.mesh.panels} panels in ${Date.now() - t} ms; CL ${c.CL.toFixed(4)}, CDi ${c.CDiTrefftz.toFixed(5)}, e ${c.spanEfficiencyTrefftz.toFixed(3)}, Cm(MAC/4) ${c.Cm.toFixed(4)}; semi-wing F = [${sw.force_N.map(v => v.toFixed(4)).join(', ')}] N, root moment = [${sw.momentAboutRootOrigin_Nmm.map(v => v.toFixed(1)).join(', ')}] N mm`);
  ok(c.CL > 0.3 && c.CL < 0.8 && r.warnings.some(w => /Reynolds/.test(w)), `${name}: plausible lift and the low-Reynolds warning`);
  const a = W.alphaForLift(m, { speed: 15 }, 2 * 0.2 * 9.81);
  log(`   angle for a 0.2 kg-per-side lift (both halves 3.924 N): ${a.alphaDeg.toFixed(3)} deg (residual ${a.residual_N.toExponential(1)} N)`);
  ok(Math.abs(a.residual_N) < 1e-8, 'lift-target angle solved');
}
// 6. Input guards: compressibility, sideslip, angle range, unknown fields.
for (const [flow, re] of [[{ speed: 120 }, /Mach/], [{ betaDeg: 2 }, /Sideslip/], [{ alphaDeg: 16 }, /Angle of attack/], [{ alphaDeg: 4, flaps: 1 }, /Unknown flow field/]]) {
  assert.throws(() => W.normalizeFlow(flow), re); checks++;
}
assert.throws(() => W.normalizeMesh({ chordPanels: 120 }), /integer from 6 to 96/); checks++;
assert.throws(() => W.normalizeMesh({ tipClosure: 'square' }), /flat or rounded/); checks++;
ok(W.DEFAULT_MESH.tipClosure === 'rounded', 'the rounded tip is the default closure');
assert.throws(() => W.aeroGeometry({ planform: 'linear', tipChord: 0 }), /zero tip chord/); checks++;
// the Mach guard cannot be bypassed through the speed of sound: it must be that of air
assert.throws(() => W.normalizeFlow({ speed: 200, speedOfSound: 1000 }), /Speed of sound in air.*290 and 360/); checks++;
// misnamed geometry fields are refused instead of silently falling back to defaults
for (const k of ['dihedral', 'sweep', 'span', 'twist', 'Dihedral', 'dihedral_deg', 'SemiSpan', 'sweepAngle']) { assert.throws(() => W.aeroGeometry({ [k]: 10 }), new RegExp(`Unknown geometry field "${k}"`)); checks++; }
ok(W.aeroGeometry(E.makeGeometry({ ...E.DEFAULT_GEOMETRY, sweepDeg: 10, dihedralDeg: 3 })).sweepDeg === 10, 'real Wing Lab geometry (makeGeometry output) is accepted');
{ const r = W.solve({ semiSpan: 450, rootChord: 160, tipChord: 1, naca: '2412' }, { alphaDeg: 4 }, { chordPanels: 16, spanPanels: 8 });
  ok(r.warnings.some(w => /tip panels become slivers/.test(w)), 'near-zero tip chord on a linear planform is flagged'); }
// 7. Tip closure. The flat tip cap (tipClosure 'flat', a diagnostic option) closes the surface but carries no
//    integrated load: its trailing corner is the potential-flow edge singularity where the tip vortex leaves the
//    wing, so the cap Cp and its (purely spanwise) force do not converge. The default rounded tip scales the section
//    thickness about the camber line by tau = sqrt(1 - ((y - y0) / l)^2) over the last l = half the tip thickness of
//    span, so the surface closes on itself, every panel pressure is integrated and the side force converges.
{
  const g = { semiSpan: 450, rootChord: 160, tipChord: 100, naca: '2412' }, flat = [], chord = [], span = [];
  for (const chordPanels of [16, 32, 48]) {
    const r = W.solve(g, { alphaDeg: 4 }, { chordPanels, spanPanels: 16, tipClosure: 'flat' }), P = r.panels, cap = r.semiWing.tipCap;
    let capForce = 0; for (let k = P.wingPanels; k < P.count; k++) capForce += Math.abs(P.force_N[3 * k]) + Math.abs(P.force_N[3 * k + 1]) + Math.abs(P.force_N[3 * k + 2]);
    flat.push({ chordPanels, cap, capForce, Fy: r.semiWing.force_N[1], minCp: r.diagnostics.minCp });
  }
  log(`flat tip cap (diagnostic), 16 strips: lowest cap Cp ${flat.map(x => x.cap.minCp.toFixed(0)).join(' / ')}, its unconverged side force ${flat.map(x => x.cap.unconvergedPressureForce_N[1].toFixed(3)).join(' / ')} N at 16/32/48 panels per surface; semi-wing Fy without the cap ${flat.map(x => x.Fy.toFixed(4)).join(' / ')} N`);
  ok(flat.every(x => x.cap && x.cap.integrated === false && x.capForce === 0), 'flat cap: cap panels carry no integrated force');
  ok(flat.every(x => Math.abs(x.cap.unconvergedPressureForce_N[0]) < 1e-12 && Math.abs(x.cap.unconvergedPressureForce_N[2]) < 1e-12), 'flat cap: its pressure force would be purely spanwise (sections in planes y = const)');
  ok(flat[2].cap.minCp < 10 * flat[0].cap.minCp && flat.every(x => x.minCp > -3), 'flat cap: cap Cp diverges under chordwise refinement while the wing-surface Cp stays bounded');
  ok(Math.abs(flat[2].cap.unconvergedPressureForce_N[1]) > Math.abs(flat[0].cap.unconvergedPressureForce_N[1]) * 1.15, 'flat cap: its side force grows under chordwise refinement (not convergent)');
  const fy = r => r.semiWing.force_N[1];
  for (const c of [16, 24, 32, 48]) chord.push(W.solve(g, { alphaDeg: 4 }, { chordPanels: c, spanPanels: 16 }));
  for (const s of [8, 12, 16, 24]) span.push(W.solve(g, { alphaDeg: 4 }, { chordPanels: 32, spanPanels: s }));
  log(`rounded tip (default): Fy ${chord.map(r => fy(r).toFixed(5)).join(' / ')} N at 16/24/32/48 panels per surface; ${span.map(r => fy(r).toFixed(5)).join(' / ')} N at 8/12/16/24 strips; rounding over the last ${chord[0].mesh.roundedTip.length_mm.toFixed(2)} mm of span`);
  ok(chord.concat(span).every(r => r.mesh.tipCapPanels === 0 && r.semiWing.tipCap === null && r.mesh.roundedTip && r.mesh.roundedTip.length_mm > 0), 'rounded tip: no cap panels, every panel is a wing-surface panel');
  ok(chord.concat(span).every(r => { const a = W.resultantOfPanels(r).force; return a.every((v, i) => Math.abs(v - r.semiWing.force_N[i]) < 1e-12 * Math.max(1, Math.abs(v))); }), 'rounded tip: the semi-wing force is the sum of ALL panel pressures');
  const d = arr => arr.slice(1).map((r, i) => Math.abs(fy(r) - fy(arr[i])));
  ok(d(chord)[2] < d(chord)[0] && d(span)[2] < d(span)[0], `rounded tip: side-force changes shrink under refinement (chordwise ${d(chord).map(v => v.toExponential(1)).join(', ')}; spanwise ${d(span).map(v => v.toExponential(1)).join(', ')})`);
  ok(Math.abs(fy(chord[3]) - fy(span[3])) < 0.05 * Math.abs(fy(chord[3])), 'rounded tip: the side force agrees between the chordwise- and spanwise-refined meshes within 5%');
  const ff = flat[1], rr = chord[2];
  log(`64 x 16 panels: side force Fy ${ff.Fy.toFixed(4)} N with the flat cap excluded vs ${fy(rr).toFixed(4)} N with the rounded tip; Fz ${W.solve(g, { alphaDeg: 4 }, { tipClosure: 'flat' }).semiWing.force_N[2].toFixed(5)} vs ${rr.semiWing.force_N[2].toFixed(5)} N`);
}
console.log(`test_wing_aero_wing: ${checks} checks passed`);
