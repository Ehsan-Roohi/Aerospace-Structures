// Wing AeroStruct BUILT site in a REAL browser (Chromium via Playwright; WebGL by SwiftShader), served over HTTP so
// the aerodynamic Web Worker runs exactly as it would on the separate AeroStruct website.
// At 390, 768 and 1440 px, on the editable course study (bonded seams, spars, no rods): the page loads with no
// errors; the aerodynamics section opens inside the input column; the Standard mesh sequence runs in the Worker (one
// progress message per mesh, no main-thread fallback); results render without NaN and without horizontal overflow;
// a second angle reuses the seven cached influence systems; applying the Standard load runs the admission test, which
// does not resolve the near-zero torque about this structure's axis (no floor); its twist bound is negligible, so the
// coupled result is shown with torque and twist withheld and those views disabled. At 1440 px the Fine sequence is
// then admitted (torque still not resolved, twist withheld) and the spatial beam carries all six components of the
// load. Storage stays under the AeroStruct keys and the Truss link stays inside the AeroStruct site.
//   PLAYWRIGHT_MODULE=/path/to/node_modules/playwright/index.mjs WING_THREE_DIR=/path/to/three@0.128.0 \
//   node computational/printed-wing-solver/aerostruct/test_aerostruct_browser.mjs [screenshot-dir]
// three.js comes from the CDN unless WING_THREE_DIR (or BEAM_THREE_DIR) points at a local three@0.128.0 package.
// Build site-aerostruct first (build_wing_aerostruct.py).
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync, mkdirSync, readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';
import path from 'node:path';
const here = path.dirname(fileURLToPath(import.meta.url)), site = path.resolve(here, '../../../site-aerostruct');
if (!existsSync(path.join(site, 'index.html'))) { console.log('test_aerostruct_browser: build site-aerostruct first (build_wing_aerostruct.py)'); process.exit(1); }
const fixtureText = readFileSync(path.resolve(here, '../../../tests/fixtures/wing_lab_editable_browser.json'), 'utf8');
// PLAYWRIGHT_MODULE first; then ESM resolution; then CommonJS resolution (which also honours NODE_PATH)
const loadPlaywright = async () => { if (process.env.PLAYWRIGHT_MODULE) return import(process.env.PLAYWRIGHT_MODULE); try { return await import('playwright'); } catch { return createRequire(import.meta.url)('playwright'); } };
const { chromium } = await loadPlaywright();
const three = process.env.WING_THREE_DIR || process.env.BEAM_THREE_DIR;
const shots = process.argv[2] || path.join(tmpdir(), 'wing-aerostruct-shots'); mkdirSync(shots, { recursive: true });
const failures = [], notes = [];
let checks = 0;
const check = (cond, msg) => { checks++; if (!cond) failures.push(msg); };
const log = (...a) => console.log('  ', ...a);

// static server for site-aerostruct (read-only)
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.wasm': 'application/wasm', '.txt': 'text/plain; charset=utf-8' };
const served = [];
const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  let rel = decodeURIComponent(url.pathname); if (rel.endsWith('/')) rel += 'index.html';
  const file = path.resolve(site, '.' + rel);
  served.push(rel);
  if (!file.startsWith(site + path.sep)) { res.writeHead(403).end(); return; }
  try { const body = await readFile(file); res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' }).end(body); }
  catch { res.writeHead(404, { 'content-type': 'text/plain' }).end('not found'); }
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}/`;

const browser = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader'] });
async function context(width, height) {
  const ctx = await browser.newContext({ viewport: { width, height }, colorScheme: 'light', deviceScaleFactor: 1 });
  if (three) await ctx.route(/three\.min\.js|OrbitControls\.js/, route => {
    const u = route.request().url();
    if (!/cdnjs\.cloudflare\.com|cdn\.jsdelivr\.net/.test(u)) return route.continue();
    return route.fulfill({ path: path.join(three, /OrbitControls/.test(u) ? 'examples/js/controls/OrbitControls.js' : 'build/three.min.js'), contentType: 'text/javascript' });
  });
  return ctx;
}
// visible elements that stick out of a box (viewport, or a column), ignoring horizontal scrollers and closed disclosures
const overflowProbe = ({ root, box }) => {
  const R = box ? document.querySelector(box).getBoundingClientRect() : { left: 0, right: document.documentElement.clientWidth };
  const scroller = el => { for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) { if (box && p === document.querySelector(box)) return false; const s = getComputedStyle(p).overflowX; if (s === 'auto' || s === 'scroll' || s === 'hidden') return true; } return false; };
  const bad = [];
  for (const el of document.querySelectorAll(root + ' *')) {
    if (!el.getClientRects().length) continue;
    const shut = el.closest('details:not([open])'); if (shut && !el.closest('summary')) continue;
    const r = el.getBoundingClientRect();
    if (r.width > 0 && (r.right > R.right + 1 || r.left < R.left - 1) && !scroller(el)) bad.push(`${el.tagName.toLowerCase()}#${el.id}.${String(el.className.baseVal ?? el.className).split(' ')[0]} ${Math.round(r.left)}-${Math.round(r.right)} (box ${Math.round(R.left)}-${Math.round(R.right)})`);
  }
  return { doc: document.documentElement.scrollWidth, vw: document.documentElement.clientWidth, bad: bad.slice(0, 8) };
};
const solvedWing = page => page.waitForFunction(() => window.WingLabUI && window.WingLabUI.result() && !window.WingLabUI.isRunning() && !window.WingLabUI.isStale() && /Solved/.test(document.querySelector('#stateChip').textContent), null, { timeout: 180000 });
const settledWing = page => page.waitForFunction(() => window.WingLabUI && !window.WingLabUI.isRunning(), null, { timeout: 180000 });
const aeroSolved = (page, re, timeout = 180000) => page.waitForFunction(src => new RegExp(src).test(document.querySelector('#aeroStatus')?.textContent || ''), re.source, { timeout });
const closeErrorDialog = page => page.evaluate(() => { const d = document.querySelector('dialog[open]'); const b = d && d.querySelector('#wingErrorClose'); if (b) b.click(); else if (d) d.close(); });

for (const [width, height] of [[390, 844], [768, 1024], [1440, 900]]) {
  const tag = `${width}px`, ctx = await context(width, height), page = await ctx.newPage(), errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error' && !/ERR_|Failed to load resource/.test(m.text())) errors.push(m.text()); });
  page.on('dialog', d => d.accept());
  const resp = await page.goto(base + 'index.html', { waitUntil: 'load' });
  check(resp && resp.status() === 200, `${tag}: index.html served`);
  const ready = await page.waitForFunction(() => document.documentElement.dataset.wingReady === 'true', null, { timeout: 30000 }).then(() => true, () => false);
  if (!ready) { notes.push(`${tag}: WebGL workspace not tested (three.js did not load; set WING_THREE_DIR or allow the CDN)`); await ctx.close(); continue; }
  check(/Wing AeroStruct/.test(await page.title()), `${tag}: the page identifies itself as Wing AeroStruct`);
  await page.$eval('[data-stage="wing"]', b => b.click());
  await solvedWing(page);
  // open the editable course study through the page's own file path (preview, then Apply)
  await page.evaluate(t => window.WingLabUI.studyFiles().openText(t, 'wing_lab_editable_browser.json'), fixtureText);
  await page.waitForFunction(() => [...document.querySelectorAll('#wingStudyFiles button')].some(b => /^Apply/.test(b.textContent) && !b.disabled), null, { timeout: 30000 });
  await page.evaluate(() => [...document.querySelectorAll('#wingStudyFiles button')].find(b => /^Apply/.test(b.textContent)).click());
  await page.waitForTimeout(100); await page.evaluate(() => window.WingLabUI.solve()); await solvedWing(page);
  check(await page.evaluate(() => window.WingLabUI.state().assembly.seamsBonded && !window.WingLabUI.state().geometry.rodFractions.length), `${tag}: editable course study opened`);
  if (!await page.isVisible('#wingSide')) await page.click('#inputsBtn');
  check(await page.isVisible('#wingSide'), `${tag}: input column visible`);
  await page.$eval('#wlAero > summary', s => s.scrollIntoView({ block: 'start' }));
  await page.click('#wlAero > summary');
  check(await page.$eval('#wlAero', d => d.open && !!d.closest('#wingSide')) && await page.isVisible('#aeroRun'), `${tag}: aerodynamics section opens inside the input column`);
  // record every status text, to see the Worker progress messages and catch a silent main-thread fallback
  await page.evaluate(() => { window.__aeroStatus = []; const s = document.querySelector('#aeroStatus'); new MutationObserver(() => window.__aeroStatus.push(s.textContent)).observe(s, { childList: true, characterData: true, subtree: true }); });
  await page.fill('#aeroV', '15'); await page.fill('#aeroAlpha', '4');
  const t0 = Date.now();
  await page.click('#aeroRun');
  await aeroSolved(page, /^Solved the standard sequence/);
  const firstMs = Date.now() - t0, statuses = await page.evaluate(() => window.__aeroStatus);
  const workerUrls = page.workers().map(w => w.url());
  log(`${tag}: ${await page.textContent('#aeroStatus')} (wall ${firstMs} ms)`);
  check(workerUrls.some(u => /wing-aero\/wing_aero_worker\.js/.test(u)), `${tag}: the aerodynamic Worker is running (${workerUrls.join(', ') || 'no workers'})`);
  check(!statuses.some(s => /Worker unavailable/.test(s)) && [1, 2, 3, 4, 5, 6, 7].every(k => statuses.some(s => new RegExp(`^Mesh ${k} of 7`).test(s))), `${tag}: the seven meshes were solved in the Worker with progress messages, no main-thread fallback`);
  check(served.some(p => /^\/wing-aero\/aero_bundle\.js$/.test(p)), `${tag}: the Worker loaded wing-aero/aero_bundle.js from the AeroStruct site`);
  const resultsText = await page.textContent('#aeroResults');
  check(!/NaN|undefined|Infinity/.test(resultsText) && /±/.test(resultsText) && await page.$$eval('#aeroResults svg', s => s.length) >= 2 && await page.isVisible('#aeroResults table'), `${tag}: extrapolated results with uncertainty and two figures, no NaN/undefined`);
  // layout: no horizontal page scroll; nothing outside the viewport; the aerodynamic block stays inside the input column
  await page.$eval('#aeroResults', el => el.scrollIntoView({ block: 'start' }));
  for (const d of await page.$$('#aeroResults details')) await d.evaluate(el => { el.open = true; });
  const o = await page.evaluate(overflowProbe, { root: '#app' });
  check(o.doc <= o.vw, `${tag}: page scrolls horizontally (${o.doc} > ${o.vw})`);
  check(!o.bad.length, `${tag}: elements outside the viewport: ${o.bad.join('; ')}`);
  const col = await page.evaluate(overflowProbe, { root: '#wlAero', box: '#wingSide' });
  check(!col.bad.length, `${tag}: aerodynamic elements wider than the input column: ${col.bad.join('; ')}`);
  // second angle: seven cached influence systems, no new linear solve
  await page.fill('#aeroAlpha', '6');
  const t1 = Date.now(); await page.click('#aeroRun');
  await aeroSolved(page, /^Solved the standard sequence.*influence systems reused/);
  const secondMs = Date.now() - t1;
  log(`${tag}: second angle ${secondMs} ms (cached) vs first ${firstMs} ms`);
  check(secondMs < firstMs, `${tag}: a new angle reuses the cached influence systems and is faster (${secondMs} vs ${firstMs} ms)`);
  await page.fill('#aeroAlpha', '4'); await page.click('#aeroRun'); await aeroSolved(page, /^Solved the standard sequence.*influence systems reused/);
  // apply the Standard load: the torque about this structure's axis is not resolved (no floor) but its twist bound is
  // aerodynamically negligible, so the coupled result is shown with torque and twist withheld
  await page.click('#aeroApply'); await page.waitForTimeout(100); await solvedWing(page);
  const s1 = await page.evaluate(() => { const a = window.WingLabUI.aero().admission, sel = document.querySelector('#wingMoreResults'), opt = v => [...sel.options].find(o => o.value === v);
    return { admitted: a?.admitted, claims: a?.claims, statuses: a?.rows.filter(r => r.kind === 'torque').map(r => r.status), twist: a?.twist?.status, bound: a?.twist?.maxBound, stale: window.WingLabUI.isStale(), box: document.querySelector('#aeroAdmission').textContent, rows: document.querySelectorAll('#aeroAdmission tbody tr').length,
      twistOption: opt('twist').disabled, torqueOption: opt('torque').disabled, record: document.querySelector('#wingAeroLoadResult')?.textContent || '',
      reactionTorque: !!document.querySelector('#wingRootTorqueWithheld'), cutMoment: /Cut bending moment Mx \/ My \/ Mz \(torque about the beam axis removed/.test(document.querySelector('#wingSpatialCharts')?.textContent || '') }; });
  log(`${tag}: Standard load applied: ${s1.admitted ? 'admitted' : 'NOT admitted'}; torque ${s1.claims?.torque}, twist ${s1.claims?.twist} (${s1.twist}, bound ${(s1.bound * 180 / Math.PI).toExponential(2)} deg); cuts: ${(s1.statuses || []).join(', ')}`);
  check(s1.admitted === true && !s1.stale && s1.claims.twist === 'withheld' && s1.claims.torque === 'withheld' && /admitted with torque and twist withheld/.test(s1.box) && s1.rows === 9, `${tag}: Standard load admitted with torque and twist withheld; admission table of 9 checks`);
  check(s1.twistOption && s1.torqueOption && /torque and twist withheld/.test(s1.record), `${tag}: twist and torque views disabled; the results record says they are withheld`);
  check(s1.reactionTorque && s1.cutMoment, `${tag}: root reactions and cut moments shown without their unresolved torque component (marked withheld)`);
  const col2 = await page.evaluate(overflowProbe, { root: '#wlAero', box: '#wingSide' });
  check(!col2.bad.length, `${tag}: admission table fits the input column: ${col2.bad.join('; ')}`);
  { // picture of the input column with the admission table (a tall viewport for the shot only)
    await page.setViewportSize({ width, height: 2600 });
    await page.$eval('#wingSide', side => { side.scrollTop = document.querySelector('#wlAero').offsetTop - 8; });
    await page.waitForTimeout(250);
    const box = await page.$eval('#wingSide', el => { const r = el.getBoundingClientRect(); return { x: Math.max(0, r.left), y: Math.max(0, r.top), width: Math.min(r.width, document.documentElement.clientWidth), height: Math.min(r.height, 2600 - Math.max(0, r.top)) }; });
    await page.screenshot({ path: path.join(shots, `aerostruct_standard_${width}.png`), clip: box });
    await page.setViewportSize({ width, height });
  }
  if (width === 1440) { // Fine sequence in the Worker: admitted, six-component load in the spatial beam
    await page.selectOption('#aeroSequence', 'fine');
    const tf = Date.now(); await page.click('#aeroRun');
    await aeroSolved(page, /^Solved the fine sequence/, 300000);
    log(`${tag}: Fine sequence in the Worker: ${Date.now() - tf} ms`);
    await page.click('#aeroApply'); await page.waitForTimeout(100); await solvedWing(page);
    const s2 = await page.evaluate(() => { const r = window.WingLabUI.result(), a = r.analysis3D, st = a.aeroLoad.strips, sum = st.reduce((t, x) => t.map((v, i) => v + x[2 + i]), [0, 0, 0, 0, 0, 0]), P = a.nodes[0]; const M = [sum[3] - (P[1] * sum[2] - P[2] * sum[1]), sum[4] - (P[2] * sum[0] - P[0] * sum[2]), sum[5] - (P[0] * sum[1] - P[1] * sum[0])];
      return { admitted: r.aeroAdmission?.admitted, claims: r.aeroAdmission?.claims, torque: r.aeroAdmission?.rows[0], dF: Math.max(...[0, 1, 2].map(i => Math.abs(a.appliedWrench.force[i] - sum[i]))), dM: Math.max(...[0, 1, 2].map(i => Math.abs(a.appliedWrench.momentAboutRoot[i] - M[i]))), strips: st.length, record: !!document.querySelector('#wingAeroLoadResult'), note: !!document.querySelector('#wingTwistWithheldNote') }; });
    log(`${tag}: Fine load admitted: ${s2.admitted} (torque ${s2.claims?.torque}, twist ${s2.claims?.twist}); root torque ${s2.torque?.value.toFixed(3)} ± ${s2.torque?.uncertainty.toFixed(3)} N mm (${(100 * s2.torque?.relative).toFixed(0)}% of |T|: ${s2.torque?.status}); ${s2.strips} strips; six-component difference ${s2.dF.toExponential(1)} N, ${s2.dM.toExponential(1)} N mm`);
    check(s2.admitted === true && s2.dF < 1e-12 && s2.dM < 1e-9 && s2.record, `${tag}: Fine load admitted; the spatial beam carries all six components; results record shown`);
    check(s2.claims.twist === 'withheld' && s2.torque.status === 'magnitude not resolved' && s2.note, `${tag}: Fine: root torque reported as not resolved, twist withheld in the results (bound stated)`);
    await page.setViewportSize({ width, height: 2600 });
    await page.$eval('#wingSide', side => { side.scrollTop = document.querySelector('#wlAero').offsetTop - 8; });
    await page.waitForTimeout(250);
    const box = await page.$eval('#wingSide', el => { const r = el.getBoundingClientRect(); return { x: Math.max(0, r.left), y: Math.max(0, r.top), width: Math.min(r.width, document.documentElement.clientWidth), height: Math.min(r.height, 2600 - Math.max(0, r.top)) }; });
    await page.screenshot({ path: path.join(shots, `aerostruct_fine_${width}.png`), clip: box });
    await page.setViewportSize({ width, height });
    await page.screenshot({ path: path.join(shots, `aerostruct_fine_workspace_${width}.png`) });
    // the structural results record with the withheld torque: root reactions and cut moments without the torque component
    await page.locator('#wingSpatialResults .wing-geometry-grid').screenshot({ path: path.join(shots, `aerostruct_fine_reactions_${width}.png`) });
    const fits = await page.$$eval('#wingSpatialResults .wing-geometry-grid > div', divs => divs.map(d => ({ fits: d.scrollWidth <= d.clientWidth + 1, text: d.querySelector('h3')?.textContent || '' })));
    check(fits.length === 2 && fits.every(f => f.fits) && await page.$eval('#wingRootTorqueWithheld td', td => getComputedStyle(td).whiteSpace === 'normal'), `${tag}: the reaction and tip tables with their withheld rows fit their columns (${fits.map(f => `${f.text}: ${f.fits ? 'fits' : 'overflows'}`).join('; ')})`);
  }
  await page.waitForTimeout(300);
  const keys = await page.evaluate(() => Object.keys(localStorage));
  check(keys.includes('wing-aerostruct:printed-study:v1') && !keys.some(k => /^winglab/.test(k)), `${tag}: storage only under wing-aerostruct keys (${keys.join(', ')})`);
  check(!errors.length, `${tag}: no page errors: ${errors.slice(0, 3).join(' | ')}`);
  await ctx.close();
}
// a run in which three.js never loaded tested nothing: say so plainly instead of reporting page errors
if (notes.length === 3) {
  await browser.close(); server.close();
  for (const n of notes) console.log('NOTE', n);
  console.log('test_aerostruct_browser: NOT RUN: three.js r128 could not be loaded (set WING_THREE_DIR to a local three@0.128.0 package or allow the CDN)');
  process.exit(1);
}
// links stay inside the separate site: Truss and back to the AeroStruct page
{
  const ctx = await context(1440, 900), page = await ctx.newPage(), errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto(base + 'index.html', { waitUntil: 'load' });
  const [truss] = await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.click('a.workspace-link[href="truss-lab.html"]')]);
  check(truss && truss.status() === 200 && page.url() === base + 'truss-lab.html', `Truss link opens the copy inside the AeroStruct site (${page.url()}, ${truss && truss.status()})`);
  const [back] = await Promise.all([page.waitForNavigation({ waitUntil: 'load' }), page.click('a[href="wing-lab.html"]')]);
  check(back && back.status() === 200 && /Wing AeroStruct/.test(await page.title()), `the Truss Lab's Wing link returns to the AeroStruct page (${page.url()})`);
  const build = await (await fetch(base + 'BUILD.json')).json();
  check(build.product === 'MIE 446 Wing AeroStruct' && build.version === '0.3.0-dev' && /not published/.test(build.status), 'BUILD.json describes an unpublished Wing AeroStruct development build');
  check(!errors.length, `link navigation without page errors: ${errors.slice(0, 2).join(' | ')}`);
  await ctx.close();
}
await browser.close(); server.close();
for (const n of notes) console.log('NOTE', n);
for (const f of failures) console.log('FAIL', f);
if (failures.length) { console.log(`test_aerostruct_browser: ${failures.length} of ${checks} checks failed; screenshots in ${shots}`); process.exit(1); }
console.log(`test_aerostruct_browser: ${checks} checks passed in Chromium (${three ? 'local three.js r128' : 'CDN three.js'}); screenshots in ${shots}`);
