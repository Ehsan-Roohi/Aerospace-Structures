// Independent reference tools for the Wing AeroStruct panel-method tests. Nothing here calls the solver's
// kernels: brute-force surface quadrature, analytic closed-body potential flow (sphere; Lamb's
// ellipsoid via Carlson's R_D), the exact Joukowski conformal-map solution, thin-airfoil theory,
// a Glauert lifting-line solver and a thin-wing vortex-lattice method. Used only by test_wing_aero_*.mjs.

/** Gauss-Legendre nodes/weights on [0,1] (Golub-Welsch-free Newton iteration). */
export function gauss01(n) {
  const x = [], w = [];
  for (let i = 0; i < n; i++) {
    let z = Math.cos(Math.PI * (i + 0.75) / (n + 0.5)), pp = 1, z1;
    do { let p1 = 1, p2 = 0; for (let j = 1; j <= n; j++) { const p3 = p2; p2 = p1; p1 = ((2 * j - 1) * z * p2 - (j - 1) * p3) / j; } pp = n * (z * p1 - p2) / (z * z - 1); z1 = z; z = z1 - p1 / pp; } while (Math.abs(z - z1) > 1e-15);
    x.push((1 - z) / 2); w.push(1 / ((1 - z * z) * pp * pp));
  }
  return { x, w };
}
/** Brute-force (1/4pi) integral of 1/r and of n.(P-Q)/r^3 over a planar quad given in 3-D, by
 *  bilinear mapping and recursive 2x2 subdivision with a 12x12 Gauss rule per cell. */
export function bruteQuad(v, P, depth = 4) {
  const G = gauss01(12);
  const n = (() => { const d1 = v[2].map((c, i) => c - v[0][i]), d2 = v[3].map((c, i) => c - v[1][i]); const c = [d1[1] * d2[2] - d1[2] * d2[1], d1[2] * d2[0] - d1[0] * d2[2], d1[0] * d2[1] - d1[1] * d2[0]], l = Math.hypot(...c); return c.map(x => x / l); })();
  const X = (u, t) => [0, 1, 2].map(i => (1 - u) * (1 - t) * v[0][i] + u * (1 - t) * v[1][i] + u * t * v[2][i] + (1 - u) * t * v[3][i]);
  // vector area element Xu x Xt (local normal times Jacobian): exact for warped bilinear patches
  const J = (u, t) => { const du = [0, 1, 2].map(i => (1 - t) * (v[1][i] - v[0][i]) + t * (v[2][i] - v[3][i])), dt = [0, 1, 2].map(i => (1 - u) * (v[3][i] - v[0][i]) + u * (v[2][i] - v[1][i])); return [du[1] * dt[2] - du[2] * dt[1], du[2] * dt[0] - du[0] * dt[2], du[0] * dt[1] - du[1] * dt[0]]; };
  let S = 0, D = 0;
  // adaptive: split a cell while its size exceeds a quarter of its distance to P (max 16 levels)
  const cell = (u0, u1, t0, t1, d) => {
    const c = X((u0 + u1) / 2, (t0 + t1) / 2), p0 = X(u0, t0), p1 = X(u1, t1), p2 = X(u1, t0), p3 = X(u0, t1);
    const size = Math.max(Math.hypot(p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]), Math.hypot(p3[0] - p2[0], p3[1] - p2[1], p3[2] - p2[2]));
    const dist = Math.hypot(P[0] - c[0], P[1] - c[1], P[2] - c[2]);
    if (d > 0 || (size > 0.25 * dist && d > -16)) { const um = (u0 + u1) / 2, tm = (t0 + t1) / 2; cell(u0, um, t0, tm, d - 1); cell(um, u1, t0, tm, d - 1); cell(u0, um, tm, t1, d - 1); cell(um, u1, tm, t1, d - 1); return; }
    for (let a = 0; a < G.x.length; a++) for (let b = 0; b < G.x.length; b++) {
      const u = u0 + (u1 - u0) * G.x[a], t = t0 + (t1 - t0) * G.x[b], q = X(u, t), dA = J(u, t), wgt = G.w[a] * G.w[b] * (u1 - u0) * (t1 - t0);
      const d0 = P[0] - q[0], d1 = P[1] - q[1], d2 = P[2] - q[2], r = Math.hypot(d0, d1, d2);
      S += wgt * Math.hypot(...dA) / r; D += wgt * (d0 * dA[0] + d1 * dA[1] + d2 * dA[2]) / r ** 3;
    }
  };
  cell(0, 1, 0, 1, depth);
  return { source: S / (4 * Math.PI), doublet: D / (4 * Math.PI) };
}
/** (1/4pi) integral dS/r over a planar convex polygon for an in-plane point inside it, by polar
 *  integration about the point (radial integral exact; angular Gauss 64 per edge). */
export function inPlaneSource(poly2d, p) {
  const G = gauss01(64); let s = 0;
  for (let e = 0; e < poly2d.length; e++) {
    const a = poly2d[e], b = poly2d[(e + 1) % poly2d.length];
    const ta = Math.atan2(a[1] - p[1], a[0] - p[0]); let tb = Math.atan2(b[1] - p[1], b[0] - p[0]); if (tb < ta) tb += 2 * Math.PI;
    for (let k = 0; k < G.x.length; k++) {
      const th = ta + (tb - ta) * G.x[k], d = [Math.cos(th), Math.sin(th)];
      // ray p + r d hits edge a-b: solve p + r d = a + s (b - a)
      const ex = b[0] - a[0], ey = b[1] - a[1], det = d[0] * (-ey) - d[1] * (-ex), rx = a[0] - p[0], ry = a[1] - p[1];
      const r = (rx * (-ey) - ry * (-ex)) / det;
      s += G.w[k] * (tb - ta) * r;
    }
  }
  return s / (4 * Math.PI);
}

/** UV ellipsoid mesh, poles on the y axis, quads counter-clockwise about the outward normal. */
export function ellipsoidMesh(a, b, c, nLon, nLat, edgeClustering = 0) {
  const nodes = [];
  // azimuth phi = s - k sin(2 s)/2 clusters points at the x extremes (phi = 0, pi) for thin bodies
  for (let j = 0; j <= nLat; j++) { const th = Math.PI * j / nLat; for (let i = 0; i <= nLon; i++) { const sv = 2 * Math.PI * i / nLon, ph = sv - edgeClustering * Math.sin(2 * sv) / 2; nodes.push(a * Math.sin(th) * Math.cos(ph), b * Math.cos(th), c * Math.sin(th) * Math.sin(ph)); } }
  const id = (i, j) => j * (nLon + 1) + i, q = [];
  for (let j = 0; j < nLat; j++) for (let i = 0; i < nLon; i++) q.push(id(i, j), id(i + 1, j), id(i + 1, j + 1), id(i, j + 1));
  return { nodes: Float64Array.from(nodes), quads: Int32Array.from(q), layout: { patches: [{ ni: nLon, nj: nLat, index: (i, j) => j * nLon + i, iMode: 'wrap', jMode: 'open' }] } };
}
/** Carlson's symmetric elliptic integral R_D(x, y, z) (duplication algorithm; Carlson 1995). */
export function carlsonRD(x, y, z) {
  let sum = 0, fac = 1;
  for (let it = 0; it < 200; it++) {
    const sx = Math.sqrt(x), sy = Math.sqrt(y), sz = Math.sqrt(z), lam = sx * (sy + sz) + sy * sz;
    sum += fac / (sz * (z + lam)); fac /= 4; x = (x + lam) / 4; y = (y + lam) / 4; z = (z + lam) / 4;
    const ave = (x + y + 3 * z) / 5, dx = (ave - x) / ave, dy = (ave - y) / ave, dz = (ave - z) / ave;
    if (Math.max(Math.abs(dx), Math.abs(dy), Math.abs(dz)) < 1e-4) {
      const ea = dx * dy, eb = dz * dz, ec = ea - eb, ed = ea - 6 * eb, ee = ed + ec + ec;
      return 3 * sum + fac * (1 + ed * (-3 / 14 + 9 / 88 * ed - 4.5 / 26 * dz * ee) + dz * (ee / 6 + dz * (-9 / 22 * ec + 3 / 26 * dz * ea))) / (ave * Math.sqrt(ave));
    }
  }
  throw new Error('R_D did not converge');
}
/** Lamb's ellipsoid coefficient alpha0 for the semi-axis a along the flow (Hydrodynamics sec. 114). */
export const lambAlpha = (a, b, c) => (2 / 3) * a * b * c * carlsonRD(b * b, c * c, a * a);

/** Exact Karman-Trefftz airfoil (Joukowski when teAngleDeg = 0): circle of centre (-ex, ey) through
 *  zeta = b, map (z - n b)/(z + n b) = ((zeta - b)/(zeta + b))^n with n = 2 - tau/pi. The circle flow
 *  with the Kutta condition at zeta = b gives the exact surface velocity |dW/dzeta| / |dz/dzeta|. */
export function karmanTrefftz({ b = 1, ex = 0.09, ey = 0, teAngleDeg = 0 } = {}) {
  const n = 2 - teAngleDeg / 180, zc = [-ex, ey], a = Math.hypot(b + ex, ey), beta = Math.atan2(ey, b + ex);
  const mul = (p, q) => [p[0] * q[0] - p[1] * q[1], p[0] * q[1] + p[1] * q[0]], div = (p, q) => { const d = q[0] * q[0] + q[1] * q[1]; return [(p[0] * q[0] + p[1] * q[1]) / d, (p[1] * q[0] - p[0] * q[1]) / d]; };
  const zeta = th => [zc[0] + a * Math.cos(th), zc[1] + a * Math.sin(th)];
  const wOf = th => { const z = zeta(th); return div([z[0] - b, z[1]], [z[0] + b, z[1]]); };
  // continuous branch of w^p: the image circle passes through w = 0, so arg(w) stays within pi/2 of
  // the direction of its centre (found from three image points)
  const circ = (() => { const P = [0.7, 2.1, 3.9].map(t => wOf(-beta + t)), [A, B, C] = P, d = 2 * (A[0] * (B[1] - C[1]) + B[0] * (C[1] - A[1]) + C[0] * (A[1] - B[1])); const ux = ((A[0] ** 2 + A[1] ** 2) * (B[1] - C[1]) + (B[0] ** 2 + B[1] ** 2) * (C[1] - A[1]) + (C[0] ** 2 + C[1] ** 2) * (A[1] - B[1])) / d, uy = ((A[0] ** 2 + A[1] ** 2) * (C[0] - B[0]) + (B[0] ** 2 + B[1] ** 2) * (A[0] - C[0]) + (C[0] ** 2 + C[1] ** 2) * (B[0] - A[0])) / d; return Math.atan2(uy, ux); })();
  const pw = (w, p) => { const r = Math.hypot(w[0], w[1]); if (r === 0) return [0, 0]; const rel = Math.atan2(w[1] * Math.cos(circ) - w[0] * Math.sin(circ), w[0] * Math.cos(circ) + w[1] * Math.sin(circ)), ang = (circ + rel) * p, m = r ** p; return [m * Math.cos(ang), m * Math.sin(ang)]; };
  const map = th => { const wn = pw(wOf(th), n), q = div([1 + wn[0], wn[1]], [1 - wn[0], -wn[1]]); return [n * b * q[0], n * b * q[1]]; };
  const dzdzeta = th => { const w = wOf(th), z = zeta(th), wn = pw(w, n), wn1 = pw(w, n - 1), om = [1 - wn[0], -wn[1]], zb = [z[0] + b, z[1]]; const den = mul(mul(om, om), mul(zb, zb)), num = [4 * n * n * b * b * wn1[0], 4 * n * n * b * b * wn1[1]], v = div(num, den); return Math.hypot(v[0], v[1]); };
  let xmin = Infinity, thLE = 0;
  for (let k = 1; k < 20000; k++) { const th = -beta + 2 * Math.PI * k / 20000, p = map(th); if (p[0] < xmin) { xmin = p[0]; thLE = th; } }
  for (let it = 0; it < 80; it++) { const h = 1e-6, f = th => map(th)[0], d1 = (f(thLE + h) - f(thLE - h)) / (2 * h), d2 = (f(thLE + h) - 2 * f(thLE) + f(thLE - h)) / (h * h); if (!(Math.abs(d2) > 0)) break; const step = d1 / d2; thLE -= step; if (Math.abs(step) < 1e-13) break; }
  const LE = map(thLE), TE = [n * b, 0], chordVec = [TE[0] - LE[0], TE[1] - LE[1]], chord = Math.hypot(...chordVec), chordAngle = Math.atan2(chordVec[1], chordVec[0]);
  const toLocal = p => { const dx = p[0] - LE[0], dy = p[1] - LE[1], c = Math.cos(chordAngle), s2 = Math.sin(chordAngle); return [(dx * c + dy * s2) / chord, (-dx * s2 + dy * c) / chord]; };
  const cpAt = (th, alpha) => { const al = alpha + chordAngle, tang = 2 * Math.sin(th - al) + 2 * Math.sin(al + beta); return 1 - (tang / dzdzeta(th)) ** 2; };
  const thTE = -beta;
  const thicknessRatio = (() => { let t = 0; for (let k = 1; k < 2000; k++) { const p1 = toLocal(map(thTE - Math.PI * k / 2000)), p2 = toLocal(map(thTE + Math.PI * k / 2000)); t = Math.max(t, Math.abs(p2[1] - p1[1])); } return t; })();
  return { n, a, b, beta, chord, chordAngle, map, toLocal, cpAt, liftSlope2D: 8 * Math.PI * a / chord, zeroLiftAngle: -(beta + chordAngle), thTE, thLE, thicknessRatio };
}
export const joukowski = opts => karmanTrefftz({ ...opts, teAngleDeg: 0 });
/** Section loop (lower TE -> LE -> upper TE, unit chord) at uniform circle-angle steps; exact points.
 *  (The conformal map already clusters points at the trailing edge; no additional clustering.) */
export function conformalLoop(J, nHalf) {
  const pts = [], params = [];
  const span = ((J.thTE - J.thLE) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) || 2 * Math.PI; // clockwise TE -> LE
  for (let i = 0; i <= nHalf; i++) { const th = J.thTE - span * i / nHalf; params.push(th); pts.push(J.toLocal(J.map(th))); }
  const span2 = 2 * Math.PI - span;
  for (let i = 1; i <= nHalf; i++) { const th = J.thTE - span - span2 * i / nHalf; params.push(th); pts.push(J.toLocal(J.map(th))); } // continuous angle (no 2 pi jump at the LE)
  pts[0] = [1, 0]; pts[2 * nHalf] = [1, 0]; pts[nHalf] = [0, 0];
  return { pts, params };
}
export const joukowskiLoop = conformalLoop;
/** Same exact contour sampled at x/c = (1 - cos(pi i/nHalf))/2 on each surface (the spacing
 *  WingAirfoils.surfaces uses), by bisection on the circle angle; x is monotonic on each surface. */
export function conformalLoopCosine(J, nHalf) {
  const span = ((J.thTE - J.thLE) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) || 2 * Math.PI, span2 = 2 * Math.PI - span;
  const at = th => J.toLocal(J.map(th));
  const solve = (thA, thB, x) => { // x(thA) = 1 (TE) ... x(thB) = 0 (LE), monotone in between
    let lo = thA, hi = thB;
    for (let k = 0; k < 100; k++) { const m = (lo + hi) / 2; if (at(m)[0] > x) lo = m; else hi = m; }
    return (lo + hi) / 2;
  };
  const pts = [], params = [];
  for (let i = 0; i <= nHalf; i++) { const x = 0.5 * (1 - Math.cos(Math.PI * (nHalf - i) / nHalf)), th = i === 0 ? J.thTE : i === nHalf ? J.thTE - span : solve(J.thTE, J.thTE - span, x); params.push(th); pts.push(at(th)); }
  for (let i = 1; i <= nHalf; i++) { const x = 0.5 * (1 - Math.cos(Math.PI * i / nHalf)), th = i === nHalf ? J.thTE - 2 * Math.PI : solve(J.thTE - 2 * Math.PI, J.thTE - span, x); params.push(th); pts.push(at(th)); }
  pts[0] = [1, 0]; pts[2 * nHalf] = [1, 0]; pts[nHalf] = [0, 0];
  return { pts, params };
}

/** Thin-airfoil zero-lift angle (rad) of a camber line dz/dx(x), 0 <= x <= 1. */
export function thinAirfoilZeroLift(slope) {
  const G = gauss01(400); let s = 0;
  for (let k = 0; k < G.x.length; k++) { const th = Math.PI * G.x[k], x = (1 - Math.cos(th)) / 2; s += G.w[k] * Math.PI * slope(x) * (Math.cos(th) - 1); }
  return -s / Math.PI;
}
/** Glauert lifting-line solution for an unswept wing: chord c(eta), section slope a0, alpha (rad),
 *  semi-span L. Returns CL, CDi and span efficiency for odd sine terms (N terms). */
export function liftingLine({ chord, semiSpan, a0, alpha, alphaL0 = 0, N = 40, area }) {
  const b = 2 * semiSpan, th = Array.from({ length: N }, (_, k) => (k + 0.5) * Math.PI / (2 * N)); // (0, pi/2)
  const n = Array.from({ length: N }, (_, k) => 2 * k + 1);
  const A = th.map(t => { const c = chord(semiSpan * Math.cos(t)), mu = c * a0 / (4 * b); return n.map(m => Math.sin(m * t) * (1 + mu * m / Math.sin(t))); });
  const rhs = th.map(t => { const c = chord(semiSpan * Math.cos(t)), mu = c * a0 / (4 * b); return mu * (alpha - alphaL0); });
  // dense Gaussian elimination
  const M = A.map((r, i) => [...r, rhs[i]]);
  for (let k = 0; k < N; k++) { let p = k; for (let i = k + 1; i < N; i++) if (Math.abs(M[i][k]) > Math.abs(M[p][k])) p = i; [M[k], M[p]] = [M[p], M[k]]; for (let i = k + 1; i < N; i++) { const f = M[i][k] / M[k][k]; for (let j = k; j <= N; j++) M[i][j] -= f * M[k][j]; } }
  const x = new Array(N).fill(0); for (let i = N - 1; i >= 0; i--) { let s = M[i][N]; for (let j = i + 1; j < N; j++) s -= M[i][j] * x[j]; x[i] = s / M[i][i]; }
  const AR = b * b / area, CL = Math.PI * AR * x[0], delta = n.slice(1).reduce((s, m, i) => s + m * (x[i + 1] / x[0]) ** 2, 0);
  return { CL, CDi: CL * CL / (Math.PI * AR) * (1 + delta), e: 1 / (1 + delta), AR };
}

/** Closest point on the ellipsoid (x/a)^2 + (y/b)^2 + (z/c)^2 = 1 to P (bisection on the Lagrange multiplier). */
export function closestOnEllipsoid(P, ax) {
  const f = t => ax.reduce((s, a, i) => s + (a * P[i] / (a * a + t)) ** 2, 0) - 1;
  const inside = f(0) < 0; let lo = inside ? -(Math.min(...ax) ** 2) * (1 - 1e-15) : 0, hi = inside ? 0 : 1;
  if (!inside) while (f(hi) > 0) hi *= 2;
  for (let k = 0; k < 200; k++) { const m = (lo + hi) / 2; if ((f(m) > 0) === true) lo = m; else hi = m; }
  const t = (lo + hi) / 2; return ax.map((a, i) => a * a * P[i] / (a * a + t));
}

/** Thin-wing vortex-lattice method for a flat rectangular wing (an independent discretization: horseshoe
 *  vortices with the bound leg on each panel's quarter-chord line, trailing legs to +infinity along x,
 *  collocation at the panel three-quarter chord; e.g. Bertin & Cummings, Aerodynamics for Engineers, ch. 7;
 *  Katz & Plotkin ch. 12). Cosine spanwise spacing, uniform chordwise panels, symmetric half-wing with
 *  its mirror image. Returns the lift-curve slope dCL/dalpha per radian. */
export function vortexLatticeSlope({ semiSpan, chord, nc = 12, ns = 32 }) {
  const ys = Array.from({ length: ns + 1 }, (_, j) => semiSpan * Math.sin(Math.PI / 2 * j / ns)); // root -> tip, tip-clustered
  const panels = [];
  for (let j = 0; j < ns; j++) for (let i = 0; i < nc; i++) {
    const xb = chord * (i + 0.25) / nc, xc = chord * (i + 0.75) / nc;
    panels.push({ A: [xb, ys[j]], B: [xb, ys[j + 1]], C: [xc, 0.5 * (ys[j] + ys[j + 1])], dy: ys[j + 1] - ys[j] });
  }
  const FOUR_PI = 4 * Math.PI;
  const segment = (P, A, B) => { // z-velocity at P (in the wing plane) from a unit vortex A -> B
    const r1x = P[0] - A[0], r1y = P[1] - A[1], r2x = P[0] - B[0], r2y = P[1] - B[1], r0x = B[0] - A[0], r0y = B[1] - A[1];
    const cross = r1x * r2y - r1y * r2x, l1 = Math.hypot(r1x, r1y), l2 = Math.hypot(r2x, r2y);
    if (Math.abs(cross) < 1e-12 * (l1 * l2 + 1e-300)) return 0;
    return (r0x * (r1x / l1 - r2x / l2) + r0y * (r1y / l1 - r2y / l2)) / (FOUR_PI * cross);
  };
  const trailing = (P, X) => { const dx = P[0] - X[0], dy = P[1] - X[1]; if (Math.abs(dy) < 1e-12) return 0; return (1 + dx / Math.hypot(dx, dy)) / (FOUR_PI * dy); }; // unit vortex X -> +infinity
  const horseshoe = (P, A, B) => -trailing(P, A) + segment(P, A, B) + trailing(P, B);
  const n = panels.length, M = Array.from({ length: n }, () => new Float64Array(n + 1));
  for (let i = 0; i < n; i++) {
    const P = panels[i].C;
    for (let k = 0; k < n; k++) {
      const { A, B } = panels[k];
      M[i][k] = horseshoe(P, A, B) + horseshoe(P, [B[0], -B[1]], [A[0], -A[1]]); // + mirror image (left half)
    }
    M[i][n] = -1; // flow tangency at unit angle of attack and unit speed: w_induced = -alpha
  }
  for (let c = 0; c < n; c++) { // Gaussian elimination with partial pivoting
    let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    [M[c], M[p]] = [M[p], M[c]];
    for (let r = c + 1; r < n; r++) { const f = M[r][c] / M[c][c]; if (f) for (let q = c; q <= n; q++) M[r][q] -= f * M[c][q]; }
  }
  const G = new Float64Array(n);
  for (let r = n - 1; r >= 0; r--) { let s = M[r][n]; for (let q = r + 1; q < n; q++) s -= M[r][q] * G[q]; G[r] = s / M[r][r]; }
  const lift = 2 * panels.reduce((s, p, k) => s + G[k] * p.dy, 0); // both halves, per unit rho V^2 alpha
  return 2 * lift / (2 * semiSpan * chord);                          // CL = L / (q S) with q = 1/2
}
