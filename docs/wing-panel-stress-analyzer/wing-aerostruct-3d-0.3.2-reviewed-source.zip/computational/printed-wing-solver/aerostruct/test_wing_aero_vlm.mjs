// Wing AeroStruct panel method vs an INDEPENDENT thin-wing vortex-lattice method (aero_test_support.mjs), on the
// course's typical planform: a rectangular wing of aspect ratio 6 (rounded aerodynamic tips, the default).
//   1. The vortex lattice converges first order in the spanwise count; its Richardson limit is the thin-wing
//      reference lift slope.
//   2. Panel-method lift slopes of NACA 0006, 0009, 0012 and 0015 wings (Trefftz plane, 32 x 2 x 24 panels),
//      extrapolated linearly to zero thickness, must reproduce that thin-wing slope (within 2%).
//   3. The thickness effect must lie in the band expected from 2-D potential flow (dln a/d(t/c) about 0.77,
//      Abbott & von Doenhoff) scaled by the 3-D lifting-line sensitivity 1/(1 + a0 (1 + tau)/(pi A)) about 0.72.
//   4. For t/c >= 9% the pressure-integrated and Trefftz lift slopes agree within 1%.
//   node computational/printed-wing-solver/aerostruct/test_wing_aero_vlm.mjs
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { vortexLatticeSlope } from './aero_test_support.mjs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const semiSpan = 600, chord = 200, alpha = 4 * Math.PI / 180; // AR = (2 x 600)^2 / (1200 x 200) = 6
// 1. thin-wing reference
const v48 = vortexLatticeSlope({ semiSpan, chord, nc: 8, ns: 48 }), v96 = vortexLatticeSlope({ semiSpan, chord, nc: 8, ns: 96 }), v48c = vortexLatticeSlope({ semiSpan, chord, nc: 16, ns: 48 });
const thin = 2 * v96 - v48; // first-order Richardson extrapolation in 1/ns
log(`vortex lattice, rectangular AR 6: ${v48.toFixed(4)} (8x48), ${v48c.toFixed(4)} (16x48), ${v96.toFixed(4)} (8x96) /rad; Richardson limit ${thin.toFixed(4)} /rad`);
ok(Math.abs(v48c - v48) < 2e-3 * v48, 'vortex lattice: chordwise count converged (8 vs 16 rows)');
ok(v48 > v96 && (v48 - v96) / v48 < 0.01, 'vortex lattice: monotone first-order spanwise convergence, last step below 1%');
// 2. and 4. panel method, four thicknesses
const rows = [];
for (const naca of ['0006', '0009', '0012', '0015']) {
  const t0 = Date.now(), r = W.solve({ semiSpan, rootChord: chord, tipChord: chord, naca }, { alphaDeg: 4 }, { chordPanels: 32, spanPanels: 24 });
  const row = { tc: Number(naca) / 100, p: r.coefficients.CL / alpha, t: r.coefficients.CLTrefftz / alpha, panels: r.mesh.panels, ms: Date.now() - t0 };
  rows.push(row);
  log(`NACA ${naca}: ${row.panels} panels, lift slope pressure ${row.p.toFixed(4)} / Trefftz ${row.t.toFixed(4)} /rad (${(100 * (row.p / row.t - 1)).toFixed(2)}%), ${row.ms} ms`);
  if (row.tc >= 0.09) ok(Math.abs(row.p / row.t - 1) < 0.01, `NACA ${naca}: pressure and Trefftz lift slopes agree within 1%`);
}
const fit = key => { const n = rows.length, sx = rows.reduce((s, r) => s + r.tc, 0), sy = rows.reduce((s, r) => s + r[key], 0), sxx = rows.reduce((s, r) => s + r.tc * r.tc, 0), sxy = rows.reduce((s, r) => s + r.tc * r[key], 0); const b = (n * sxy - sx * sy) / (n * sxx - sx * sx); return { a: (sy - b * sx) / n, b }; };
const ft = fit('t'), fp = fit('p');
log(`zero-thickness intercept: Trefftz ${ft.a.toFixed(4)} /rad (${(100 * (ft.a / thin - 1)).toFixed(2)}% vs vortex lattice), pressure ${fp.a.toFixed(4)} /rad (${(100 * (fp.a / thin - 1)).toFixed(2)}%)`);
ok(Math.abs(ft.a / thin - 1) < 0.02, `thin-wing limit of the panel method matches the independent vortex lattice within 2% (${(100 * (ft.a / thin - 1)).toFixed(2)}%)`);
// 3. thickness effect
const dlog = ft.b / ft.a, nominal = 0.77 / (1 + 2 * Math.PI * 1.17 / (Math.PI * 6));
log(`thickness effect d ln(CL_alpha)/d(t/c) = ${dlog.toFixed(3)} (expected about ${nominal.toFixed(3)}); NACA 0012 / thin = ${(rows[2].t / thin).toFixed(4)}`);
ok(dlog > 0.44 && dlog < 0.67, 'thickness raises the lift slope by the amount expected from 2-D potential flow and lifting-line sensitivity');
console.log(`test_wing_aero_vlm: ${checks} checks passed`);
