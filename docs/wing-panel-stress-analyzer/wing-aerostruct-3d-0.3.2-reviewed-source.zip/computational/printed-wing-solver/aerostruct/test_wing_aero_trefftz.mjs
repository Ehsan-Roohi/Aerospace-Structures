// Trefftz-plane induced drag against the classical elliptic-loading result (independent analytic
// reference): Gamma(y) = Gamma0 sqrt(1 - (2y/b)^2) gives L/(rho V) = pi b Gamma0 / 4 and
// D/(rho/2) = pi Gamma0^2 / 4 for the whole wing (b = 1, Gamma0 = 1 here). The reconstruction used
// by the solver must improve on the first-order midpoint rule and converge with the strip count.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const exact = Math.PI / 4;
const strips = (N, spacing) => {
  const trace = [], mu = [];
  for (let j = 0; j <= N; j++) { const t = j / N; trace.push([spacing === 'sine' ? 0.5 * Math.sin(Math.PI / 2 * t) : 0.5 * t, 0]); }
  for (let j = 0; j < N; j++) { const ym = (trace[j][0] + trace[j + 1][0]) / 2; mu.push(Math.sqrt(1 - (2 * ym) ** 2)); }
  return { trace, mu };
};
for (const spacing of ['sine', 'uniform']) {
  const errs = [];
  for (const N of [8, 16, 24, 48]) {
    const { trace, mu } = strips(N, spacing), mid = W.trefftzMidpoint(trace, mu), rec = W.trefftz(trace, mu);
    const eMid = 100 * (mid.dragOverHalfRho / exact - 1), eRec = 100 * (rec.dragOverHalfRho / exact - 1), eLift = 100 * (rec.liftOverRhoV / exact - 1);
    errs.push(Math.abs(eRec));
    log(`${spacing} ${String(N).padStart(2)} strips: drag error midpoint ${eMid.toFixed(3)}%, reconstructed ${eRec.toFixed(3)}%; lift error ${eLift.toFixed(3)}%`);
    ok(Math.abs(eRec) < Math.abs(eMid), 'reconstruction improves on the midpoint rule');
    if (N >= 16) ok(Math.abs(eRec) < 0.5, 'reconstructed induced drag within 0.5% for >= 16 strips');
    if (N >= 16) ok(Math.abs(eLift) < 0.2, 'Trefftz lift within 0.2% for >= 16 strips');
  }
  if (spacing === 'sine') ok(errs.every((e, i) => i === 0 || e < errs[i - 1]), 'sine-spaced reconstruction error decreases monotonically');
}
// Dihedral consistency: a straight V-shaped trace (dihedral angle G) with elliptic loading along its
// own length s gives the same drag as the planar trace with the same s-loading only when G = 0; the
// lift is the y-projection. Check the lift projection exactly and that drag is finite and positive.
{
  const N = 24, G = 10 * Math.PI / 180, { trace, mu } = strips(N, 'sine');
  const vTrace = trace.map(([y]) => [y * Math.cos(G), y * Math.sin(G)]), r = W.trefftz(vTrace, mu), r0 = W.trefftz(trace, mu);
  log(`dihedral 10 deg: lift/planar ${(r.liftOverRhoV / r0.liftOverRhoV).toFixed(6)} (cos G = ${Math.cos(G).toFixed(6)}), drag/planar ${(r.dragOverHalfRho / r0.dragOverHalfRho).toFixed(4)}`);
  ok(Math.abs(r.liftOverRhoV / r0.liftOverRhoV - Math.cos(G)) < 1e-12, 'lift is the projection of the loading on the y axis');
  ok(r.dragOverHalfRho > 0 && Number.isFinite(r.dragOverHalfRho), 'dihedral trace drag finite and positive');
}
console.log(`test_wing_aero_trefftz: ${checks} checks passed`);
