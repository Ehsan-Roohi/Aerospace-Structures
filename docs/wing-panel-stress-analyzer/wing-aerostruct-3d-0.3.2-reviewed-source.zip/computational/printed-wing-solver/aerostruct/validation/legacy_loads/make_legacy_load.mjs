// Provenance of validation/legacy_loads/: writes a v4 study file with an applied aerodynamic load (Standard sequence)
// USING THE OLD CODE, and the old code's own
// delivered load / coefficients / admission method for it, so the new reader can be checked against them.
// Usage: node make_legacy.mjs <old aerostruct dir> <tag>
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync } from 'node:fs';
const [dir, tag] = process.argv.slice(2), require = createRequire(import.meta.url);
const W = require(dir + '/wing_aero_panel.js'), IO = require(dir + '/wing_study_io.js'), E = require(dir + '/engine.js'), UI = require(dir + '/wing_aero_ui.js');
const fixture = readFileSync('/home/claude/tipfix/tree_wake/tests/fixtures/wing_lab_editable_browser.json', 'utf8'), base = IO.importPrintedStudy(fixture, E).state, g = E.makeGeometry(base.geometry);
IO.setAeroGeometryKey(x => IO.sha256(W.geometryKey(x)));
const seq = W.runSequence(g, { speed: 15, alphaDeg: 4 }, 'standard'), record = UI.recordFromSequence(seq, IO.sha256(W.geometryKey(g)));
const state = { ...base, load: { ...base.load, kind: 'custom', items: [] }, aerodynamics: { speed: 15, density: 1.225, alphaDeg: 4, sequence: 'standard' }, aeroLoad: record };
const text = IO.exportPrintedStudy(state, E, { savedAt: '2026-10-29T00:00:00.000Z' });
const comb = UI.delivered(W, g, IO.importPrintedStudy(text, E).state.aeroLoad, []);
const cuts = [{ y: 0, root: true, reference: [50, 0, 0], normal: [0, 1, 0] }, { y: 150, reference: [55, 150, 0], normal: [0, 1, 0] }];
const q = 0.5 * 1.225 * 15 ** 2, adm = W.admission(g, { sequence: 'standard', levels: record.levels, flow: { ...record.flow, dynamicPressure_Pa: q }, reference: W.references(W.aeroGeometry(g)) }, comb, cuts);
writeFileSync(`legacy_v4_${tag}_standard.json`, text);
writeFileSync(`legacy_v4_${tag}_standard_expected.json`, JSON.stringify({ writer: `${tag} (WingAeroPanel ${W.VERSION})`, levels: record.levels.length, strips: comb.strips, weights: comb.weights,
  coefficients: Object.fromEntries(Object.entries(comb.coefficients).map(([k, e]) => [k, { value: e.value, uncertainty: e.uncertainty }])),
  torques: adm.rows.filter(r => r.kind === 'torque').map(r => ({ y: r.y, value: r.value, uncertainty: r.uncertainty })) }));
console.log(`${tag}: v4 file ${(text.length / 1024).toFixed(1)} KiB, ${record.levels.length} meshes, ${comb.strips.length} delivered strips, WingAeroPanel ${W.VERSION}`);
