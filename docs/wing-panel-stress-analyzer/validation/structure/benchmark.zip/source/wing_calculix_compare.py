"""Actual CalculiX C3D10 IP tensor versus current nominal beam field.

No affine stress fit, nodal extrapolation, straight-sided tetrahedron assumption,
or cross-section integration is used. Four-point volume weights give band/IP
statistics, not exact section resultants. mm, N, MPa. Private optional QA only.
"""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import numpy as np

EDGES=[(0,1),(1,2),(0,2),(0,3),(1,3),(2,3)]
def write(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def fields(xyz,tet,u):
    # Standard C3D10 four-point tetrahedron rule, barycentric dominant nodes1–4.
    a=(5+3*np.sqrt(5))/20;b=(5-np.sqrt(5))/20
    lam=np.full((4,4),b);np.fill_diagonal(lam,a)
    base=np.array([[-1,-1,-1],[1,0,0],[0,1,0],[0,0,1]])
    N=np.column_stack([lam*(2*lam-1),*[4*lam[:,i]*lam[:,j] for i,j in EDGES]])
    grad=np.stack([np.vstack([(4*l[i]-1)*base[i] for i in range(4)]+[4*(l[i]*base[j]+l[j]*base[i]) for i,j in EDGES]) for l in lam])
    xe=xyz[tet];ue=u[tet]
    points=np.einsum('qn,eni->eqi',N,xe)
    J=np.einsum('eni,qnj->eqij',xe,grad)
    det=np.linalg.det(J)
    if np.any(det<=0):raise RuntimeError('Nonpositive curved-tet Jacobian at stress integration point')
    physical=np.einsum('qnj,eqjk->eqnk',grad,np.linalg.inv(J))
    du=np.einsum('eni,eqnj->eqij',ue,physical);eps=(du+du.swapaxes(2,3))/2
    mu=2000/(2*1.35);la=2000*.35/(1.35*.3)
    stress=2*mu*eps+la*np.trace(eps,axis1=2,axis2=3)[...,None,None]*np.eye(3)
    # One last printed decimal unit (conservative versus half-unit rounding),
    # seven significant digits in .dat displacement scientific notation.
    err=np.where(ue!=0,10.**(np.floor(np.log10(np.maximum(abs(ue),1e-300)))-6),0)
    du_bound=np.einsum('eni,eqnj->eqij',err,abs(physical))
    eps_bound=(du_bound+du_bound.swapaxes(2,3))/2
    stress_bound=2*mu*eps_bound+la*np.trace(eps_bound,axis1=2,axis2=3)[...,None,None]*np.eye(3)
    return points,det/24,eps,stress,stress_bound

def compare(out,h,channel):
    stem=f'ccx-h{h:g}-{channel}';data=np.load(out/f'{stem}-solution.npz');records=data['stress']
    p,w,eps,recovered,rounding_bound=fields(data['xyz'],data['tetrahedra'],data['u'])
    ids=records[:,:2].astype(int)-1
    if len(set(map(tuple,ids)))!=len(ids):raise RuntimeError('Duplicate stress IP records')
    raw=np.zeros((*w.shape,3,3));s=records[:,2:]
    for k,(i,j) in enumerate([(0,0),(1,1),(2,2),(0,1),(0,2),(1,2)]):raw[ids[:,0],ids[:,1],i,j]=s[:,k];raw[ids[:,0],ids[:,1],j,i]=s[:,k]
    # Rounded displacement-derived values only validate IP ordering and geometry;
    # all actual comparison stresses below remain the solver's own printed S.
    relative=np.linalg.norm(raw-recovered)/max(np.linalg.norm(raw),1e-30)
    permutations=sorted((float(np.linalg.norm(raw-recovered[:,perm])),perm) for perm in itertools.permutations(range(4)))
    if permutations[0][1]!=(0,1,2,3):raise RuntimeError('Standard C3D10 IP ordering is not the best displacement reconstruction match')
    stress_rounding=np.where(raw!=0,10.**(np.floor(np.log10(np.maximum(abs(raw),1e-300)))-6),0)
    rounding_ratio=float(np.max(abs(raw-recovered)/np.maximum(rounding_bound+stress_rounding,1e-20)))
    if rounding_ratio>1:raise RuntimeError(f'Reconstruction difference exceeds conservative printed-U/S rounding bound: {rounding_ratio}')
    all_points=p.reshape(-1,3);all_indices=np.arange(len(all_points))
    # One rotating IP in every eighth element avoids always selecting IP1.
    fullspan_all=((all_indices//4)%8==0)&(all_indices%4==((all_indices//4)//8)%4)
    selected=fullspan_all|np.any(abs(all_points[:,1,None]-np.array([110.,130.,190.]))<=2,axis=1)
    indices=all_indices[selected];flat=all_points[selected];wf=w.ravel()[selected];tensor=raw.reshape(-1,3,3)[selected]
    query=out/f'{stem}-ip-positions.json';write(query,flat.tolist())
    beam_path=out/f'{stem}-ip-beam-reference.json'
    helper=Path(__file__).with_name('wing_calculix_point_reference.mjs')
    subprocess.run(['node',str(helper),str(out/'slender-study.json'),str(out/f'{stem}-report.json'),str(query),str(beam_path),channel],check=True)
    beam=json.loads(beam_path.read_text());rows=beam['points'];ok=np.array([r['resolved'] for r in rows]);normal=np.array([r.get('normal',[0,0,0]) for r in rows]);nominal=np.array([r.get('value',0) for r in rows]);station=np.array([r.get('station',-1) for r in rows]);solid=np.einsum('ni,nij,nj->n',normal,tensor,normal)
    def metrics(mask):
        mask=mask&ok;n=int(mask.sum())
        if not n:return {'count':0}
        weights=wf[mask];actual=solid[mask];pred=nominal[mask];delta=pred-actual
        rms=lambda z:float(np.sqrt(np.dot(weights,z*z)/weights.sum()))
        ar=rms(actual)
        return dict(count=n,station_min_mm=float(station[mask].min()),station_max_mm=float(station[mask].max()),solid_rms_MPa=ar,beam_rms_MPa=rms(pred),raw_difference_rms_MPa=rms(delta),raw_difference_relative_rms=rms(delta)/max(ar,1e-12),solid_min_MPa=float(actual.min()),solid_max_MPa=float(actual.max()),beam_min_MPa=float(pred.min()),beam_max_MPa=float(pred.max()),max_absolute_raw_difference_MPa=float(np.max(abs(delta))))
    # Fixed before comparison: actual normal-axis station windows, not root/rib
    # trimming selected after viewing error. Report every bin, including sparse.
    bins=[]
    for lo in np.arange(0,240,10):bins.append({'range_mm':[float(lo),float(lo+10)],**metrics((station>=lo)&(station<lo+10))})
    bands=[{'centre_mm':y,'half_width_mm':2.,**metrics(abs(station-y)<=2)} for y in [110.,130.,190.]]
    ribs=np.array([80.,160.]);near=np.min(abs(station[:,None]-ribs),axis=1)<=3
    fullspan_sample=fullspan_all[selected]
    regions={'root_0_20mm':metrics(fullspan_sample&(station>=0)&(station<20)),'rib_within3mm':metrics(fullspan_sample&near),'tip_220_240mm':metrics(fullspan_sample&(station>=220)&(station<=240)),'interior_20_220_excluding_ribs3mm':metrics(fullspan_sample&(station>=20)&(station<220)&~near)}
    # sigma:epsilon is independently integrated from CCX stresses and the full
    # isoparametric gradient of printed u, NOT merely renamed external work/2.
    energy=float(.5*np.sum(w*np.einsum('eqij,eqij->eq',raw,eps)))
    ccx=json.loads((out/f'{stem}-report.json').read_text());external=ccx['energy_from_external_work_Nmm']
    report=dict(format='mie446-ccx-ip-stress-comparison',mesh_h_mm=h,channel=channel,scope='Raw signed solid sigma_ss at actual C3D10 IP physical locations versus beam normal stress at same point and normal; no fitted stress field. Volume-IP bands are not complete plane cuts or stress-resultant validation.',quadratic_geometry=True,total_ip_count=len(all_points),matched_sample_count=len(flat),sampling='All IPs in aircraft-y110/130/190 +/-2mm bands plus one rotating IP in every eighth element in original element/IP order. Actual sample counts/ranges are reported; no complete section or global-maximum claim.',resolved_ip_count=int(ok.sum()),unresolved_ip_count=int((~ok).sum()),ip_ordering_reconstruction_relative_l2=relative,ip_ordering_next_best_residual_ratio=permutations[1][0]/permutations[0][0],reconstruction_max_print_rounding_bound_ratio=rounding_ratio,independent_stress_strain_energy_Nmm=energy,external_work_half_Nmm=external,energy_relative_difference=abs(energy-external)/max(abs(external),1e-30),text_rounding='S and U from seven-significant-digit CCX text; reconstruction/energy include that rounding.',integration='Four C3D10 stress IPs with isoparametric detJ/24 weights; band quadrature is not an exact geometrical cut.',region_sampling='Regions use only one rotating IP in every eighth full-span element, excluding extra targeted-band enrichment to avoid oversampling quiet bands.',regions=regions,bands=bands,profiles=bins,beam_convergence=beam['reference']['convergence'],admission='Diagnostic comparison only; no mesh-convergence or beam-agreement pass inferred from one mesh.',source_sha256=hashlib.sha256((out/f'{stem}-solution.npz').read_bytes()).hexdigest())
    np.savez(out/f'{stem}-ip-comparison.npz',ip_indices=indices,fullspan_sample=fullspan_sample,positions=flat,weights=wf,station=station,normal=normal,solid_normal=solid,beam_normal=nominal,resolved=ok)
    write(out/f'{stem}-stress-comparison.json',report)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,1,figsize=(11,8),layout='constrained',sharex=True)
    for ax,key,title in [(axes[0],'solid','Signed nominal-direction normal stress at actual IPs'),(axes[1],'difference','Raw beam minus solid stress; no affine fit')]:
        values=solid if key=='solid' else nominal-solid
        ax.scatter(station[ok],values[ok],s=1,alpha=.18,color='#256c9d',label='Actual solid IP coverage' if key=='solid' else 'Matched-point difference')
        if key=='solid':ax.scatter(station[ok],nominal[ok],s=1,alpha=.12,color='#c14432',label='Beam at same physical IP')
        for y in [80,160]:ax.axvline(y,color='gray',ls=':',lw=.8)
        ax.axhline(0,color='black',lw=.6);ax.set(title=title,ylabel='MPa');ax.legend(markerscale=4)
    axes[-1].set_xlabel('Beam normal-foot station (mm); rib centres dotted')
    fig.suptitle(f'CalculiX C3D10 h={h:g} mm, {channel}: raw sampled field, not a cross-section maximum')
    fig.savefig(out/f'{stem}-stress-profiles.png',dpi=180);plt.close(fig)
    print(json.dumps({k:report[k] for k in ['total_ip_count','resolved_ip_count','ip_ordering_reconstruction_relative_l2','energy_relative_difference','bands']}),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--h',type=float,required=True);ap.add_argument('--channel',choices=['uniform','torque'],default='uniform');a=ap.parse_args();compare(a.out,a.h,a.channel)
