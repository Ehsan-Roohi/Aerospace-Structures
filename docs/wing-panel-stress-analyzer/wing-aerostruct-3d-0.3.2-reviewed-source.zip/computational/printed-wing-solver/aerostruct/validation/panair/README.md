# PANAIR reference data (`panair_reference_rect0012.json`)

Numbers produced by running PANAIR A502 on the exact nodes of this solver's own mesh. No PANAIR code is in this
repository. The data are used by `test_wing_aero_external_acceptance.mjs` (sections 3 and 4).

## Program

* PANAIR A502 (Boeing / NASA higher-order panel method; banner "ht2 (12 feb 92) boeing ver i00"), `panair.f90` from
  PDAS (Public Domain Aeronautical Software), `panair.zip` sha256
  `43ca4b8f31feadb1260460fb584c0a13d2049790f0879fa8acfa857629e74036`, `panair.f90` sha256
  `98a710c30599e894fc663e72304b7d42c49e9e696b5a5873c06212c820172481`.
* Built with GNU Fortran 13.3.0: `gfortran -fallow-argument-mismatch -O2 panair.f90`.
* Build check: the PDAS sample decks (swb, ellip, nac6, vss, vbc, vepd, ppbc, btac) were rerun and compared number by
  number with the official PDAS outputs. Surface flow and forces are identical (btac: 1e-5 print round-off); the only
  differences are CPU-time rows, the banner, and singularity-parameter bookkeeping lines of swb's composite-panel case.
  -O0 and -O2 give identical Cp on the 32 x 24 wing deck.

## Wing and decks

* The wing is rectangular, NACA 0012, chord 200 mm, semi-span 600 mm (AR 6), with the rounded closed tip. Alpha is 4 deg
  and Mach is 0.
* Nodes: the published mesh generator's own nodes for chordPanels x spanPanels = 32 x 24 and 64 x 48 (default sine span
  spacing, automatic tip-rounding strips), written in millimetres with 5 decimals, i.e. exactly as stored.
* Deck layout: the right half wing with the xz symmetry plane. There are two kt = 1 networks, upper (TE -> LE) and lower
  (LE -> TE); the leading edge, trailing edge and closed tip fold are network abutments. The trailing wake is kt = 18
  from the upper trailing edge, along +x (the solver's default wake direction), ending at x = 4200 mm, where PANAIR's
  semi-infinite filaments begin. There is a Trefftz-plane analysis.
* sha256 of each deck (`wing.inp`), output (`panair.out`) and exported mesh is stored in the JSON under
  `meshes.<mesh>.files`.

## Contents per mesh

* `controlPoints`: one row per wing panel, in the solver's panel order (strip j, chordwise i; k = j * ni + i). Each row
  is PANAIR's control point (mm) and its Cp (second-order Cp, equal to the isentropic Cp at M = 0; 4 decimals as
  printed).
* `config`: PANAIR's integrated full-configuration CL, CDi (pressure), forces and moments (My about x = 50 mm, on
  sref = 240000 mm^2 and cref = 200 mm).
* `trefftz`: PANAIR's Trefftz-plane CL, CDi and span efficiency.
* `rays`: Cp at fixed planform points (x, y) = (200 - d sin phi, 600 - d cos phi), on each surface. The value is linear
  interpolation over a Delaunay triangulation of that surface's control points (planform projection).
* `stations`: section cl at fixed span stations. Each strip's value is PANAIR's Cp times the solver panel's area vector,
  summed over the strip; the station value is linear in y between strip centres.

## Known PANAIR limitation on these wings (why only these two meshes)

On several other meshes of the same wing, PANAIR's solution is defective at the closed tip's corners. It prints
"*** probable error *** two cp's in the following abutment intersection share common abutment ends", and the corner
panel's velocity reaches hundreds of times the free stream:

* 48 x 32: leading-edge corner Cp about -1.1e4.
* 96 x 64: trailing-edge corner Cp overflows the printout; Trefftz e = 0.59.
* Karman-Trefftz wing of AR 20 (evidence package): 40, 56 and 64 chordwise with the split layout.

That defect is PANAIR's, not this wing's, and those runs are not used. 32 x 24 and 64 x 48 print the same message, but
their corner values and totals are regular (Trefftz e = 0.984 on both).
