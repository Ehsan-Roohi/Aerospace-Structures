"""Export the admitted quadratic wing mesh to independent CalculiX C3D10.

scikit-fem is used only for geometry indexing and consistent surface integration,
not stiffness assembly or solution. CalculiX solves the three-dimensional solid.
Units: mm, N, MPa. All external files stay in the specified QA output directory.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import numpy as np


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def prepare(out, h, channel):
    from skfem import MeshTet2, Basis, FacetBasis, ElementTetP2, ElementVector, LinearForm, asm
    name=f'h{h:g}'; data=np.load(out/f'{name}-mesh.npz')
    admission=json.loads((out/f'{name}-volume-admission.json').read_text())
    if not admission['geometry_admitted']:raise RuntimeError('Mesh geometry not admitted')
    mesh=MeshTet2(data['points'].T,data['tetrahedra'].T)
    basis=Basis(mesh,ElementVector(ElementTetP2()),intorder=6)
    xyz=basis.doflocs[:,::3].T
    desired=np.array([[0,0,0],[1,0,0],[0,1,0],[0,0,1],
                      [.5,0,0],[.5,.5,0],[0,.5,0],[0,0,.5],[.5,0,.5],[0,.5,.5]])
    ref=ElementTetP2().doflocs
    perm=np.array([np.argmin(np.linalg.norm(ref-v,axis=1)) for v in desired])
    assert np.max(np.abs(ref[perm]-desired))<1e-14
    tet=(basis.element_dofs[::3]//3).T[:,perm]
    assert np.allclose(xyz[tet[:,:4]],mesh.p[:,mesh.t].transpose(2,1,0))
    tip=mesh.facets_satisfying(lambda x:np.isclose(x[1],240,atol=1e-7),boundaries_only=True)
    root=np.flatnonzero(np.isclose(xyz[:,1],0,atol=1e-7))
    fb=FacetBasis(mesh,basis.elem,facets=tip,intorder=6)
    q=fb.global_coordinates(); area=float(fb.dx.sum())
    centre=np.einsum('ifq,fq->i',q,fb.dx)/area
    inertia=float(np.einsum('fq,fq->',(q[0]-centre[0])**2,fb.dx))
    @LinearForm
    def surface(v,w):
        return (2/area if channel=='uniform' else -50/inertia*(w.x[0]-centre[0]))*v[2]
    force=asm(surface,fb); F=force.reshape(-1,3).sum(axis=0)
    moment=np.cross(xyz,force.reshape(-1,3)).sum(axis=0)
    targetF=np.array([0.,0.,2.]) if channel=='uniform' else np.zeros(3)
    targetM=np.cross(centre,targetF) if channel=='uniform' else np.array([0.,50.,0.])
    assert np.linalg.norm(F-targetF)<1e-10 and np.linalg.norm(moment-targetM)<1e-8
    stem=f'ccx-{name}-{channel}'; deck=out/f'{stem}.inp'
    with deck.open('w',encoding='ascii',newline='\n') as f:
        f.write('*HEADING\nMIE446 independent 3D solid comparison; mm N MPa\n*NODE,NSET=ALLN\n')
        for i,p in enumerate(xyz,1):f.write(f'{i},'+','.join(f'{v:.12g}' for v in p)+'\n')
        f.write('*ELEMENT,TYPE=C3D10,ELSET=SOLID\n')
        for i,t in enumerate(tet,1):f.write(f'{i},'+','.join(str(v+1) for v in t)+'\n')
        f.write('*NSET,NSET=ROOT\n')
        for start in range(0,len(root),12):f.write(','.join(str(i+1) for i in root[start:start+12])+'\n')
        f.write('*MATERIAL,NAME=PLA\n*ELASTIC\n2000,0.35\n*SOLID SECTION,ELSET=SOLID,MATERIAL=PLA\n*BOUNDARY\nROOT,1,3,0\n*STEP\n*STATIC\n*CLOAD\n')
        for dof in np.flatnonzero(force):f.write(f'{dof//3+1},{dof%3+1},{force[dof]:.12g}\n')
        f.write('*NODE PRINT,NSET=ALLN\nU\n*NODE PRINT,NSET=ROOT,TOTALS=YES\nRF\n*EL PRINT,ELSET=SOLID\nS\n*NODE FILE\nU\n*EL FILE\nS\n*END STEP\n')
    report=dict(stem=stem,load_channel='uniform_tip_2N' if channel=='uniform' else 'pure_tip_My_50Nmm',
                nodes=len(xyz),elements=len(tet),dofs=3*len(xyz),tip_area_mm2=area,
                tip_centroid_mm=centre.tolist(),force_N=F.tolist(),applied_moment_Nmm=moment.tolist(),
                requested_force_N=targetF.tolist(),requested_moment_Nmm=targetM.tolist(),
                mesh_sha256=hashlib.sha256((out/f'{name}-mesh.npz').read_bytes()).hexdigest(),
                deck_sha256=hashlib.sha256(deck.read_bytes()).hexdigest(),
                node_order='C3D10 vertices 1,2,3,4 then edges12,23,13,14,24,34; matched by reference coordinates',
                material=dict(E_MPa=2000,nu=.35),root='all translations on actual y=0 material face',
                surface_integration='consistent quadratic nodal forces; 6th-degree face quadrature')
    np.savez(out/f'{stem}-input.npz',xyz=xyz,tetrahedra=tet,force=force,root=root)
    write(out/f'{stem}-input.json',report)
    print(json.dumps(report),flush=True)
    return stem


def parse(out, stem):
    data=np.load(out/f'{stem}-input.npz');xyz=data['xyz'];force=data['force'];root=data['root']
    u=np.full_like(xyz,np.nan);reaction=np.zeros_like(xyz);stresses=[];kind=None
    for line in (out/f'{stem}.dat').read_text().splitlines():
        low=line.lower()
        if 'displacements (' in low:kind='u';continue
        if 'forces (' in low:kind='rf';continue
        if 'stresses (' in low:kind='s';continue
        parts=line.split()
        try:
            if kind=='u' and len(parts)==4:u[int(parts[0])-1]=list(map(float,parts[1:]))
            elif kind=='rf' and len(parts)==4:reaction[int(parts[0])-1]=list(map(float,parts[1:]))
            elif kind=='s' and len(parts)==8:stresses.append([int(parts[0]),int(parts[1]),*map(float,parts[2:])])
        except ValueError:continue
    if not np.all(np.isfinite(u)):raise RuntimeError('Incomplete CalculiX displacement output')
    if len(stresses)!=4*len(data['tetrahedra']):raise RuntimeError('Missing C3D10 integration-point stresses')
    inp=json.loads((out/f'{stem}-input.json').read_text())
    F=force.reshape(-1,3).sum(axis=0);M=np.cross(xyz,force.reshape(-1,3)).sum(axis=0)
    R=reaction[root].sum(axis=0);RM=np.cross(xyz[root],reaction[root]).sum(axis=0)
    work=float(force@u.ravel());scale=max(np.linalg.norm(F),2.);mscale=max(np.linalg.norm(M),50.)
    report={**inp,'solver':'CalculiX 2.23, C3D10 solid, static linear isotropic elasticity',
            'reaction_N':R.tolist(),'reaction_moment_Nmm':RM.tolist(),
            'force_balance_relative':float(np.linalg.norm(F+R)/scale),
            'moment_balance_relative':float(np.linalg.norm(M+RM)/mscale),
            'work_Nmm':work,'energy_from_external_work_Nmm':work/2,
            'generalized_displacement_mm':work/2 if stem.endswith('uniform') else None,
            'compliance_mm_per_N':work/4 if stem.endswith('uniform') else None,
            'theta_work_rad':work/50 if stem.endswith('torque') else None,
            'stress_records':len(stresses),'dat_sha256':hashlib.sha256((out/f'{stem}.dat').read_bytes()).hexdigest(),
            'output_precision_note':'CCX text output rounded to seven significant digits; do not interpret text-rounding residual as solver tolerance'}
    assert report['force_balance_relative']<1e-5 and report['moment_balance_relative']<1e-5,report
    np.savez(out/f'{stem}-solution.npz',xyz=xyz,tetrahedra=data['tetrahedra'],u=u,force=force,reaction=reaction,stress=np.array(stresses))
    write(out/f'{stem}-report.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','solve','parse']);p.add_argument('--out',type=Path,required=True);p.add_argument('--h',type=float,required=True);p.add_argument('--channel',choices=['uniform','torque'],default='uniform');p.add_argument('--ccx',type=Path)
    a=p.parse_args();stem=f'ccx-h{a.h:g}-{a.channel}'
    if a.stage=='prepare':prepare(a.out,a.h,a.channel)
    elif a.stage=='parse':parse(a.out,stem)
    else:
        with (a.out/f'{stem}-solver.log').open('w') as log:r=subprocess.run([str(a.ccx),'-i',stem],cwd=a.out,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
        if r.returncode:raise RuntimeError(f'CalculiX exit {r.returncode}: see {stem}-solver.log')
        print(f'CalculiX completed {stem}',flush=True)
