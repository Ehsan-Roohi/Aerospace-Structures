// Non-lifting closed bodies against exact potential flow (no wake, no image): sphere and Lamb's
// ellipsoids (Hydrodynamics, sec. 114). On an ellipsoid with semi-axis a along the stream the surface
// potential is K U x with K = 2/(2 - alpha0), so the solved doublet (= surface perturbation potential
// in the internal-Dirichlet formulation) must equal (K - 1) U x and Cp = 1 - K^2 (1 - n_x^2).
// alpha0 is evaluated independently with Carlson's R_D. Also: zero net force (d'Alembert).
// Pointwise Cp near the 1:3:0.12 body's edges (curvature radius 0.014, smaller than one panel) is
// reported but not used as a pass criterion; the Cp criterion uses the region |n_x| < 0.5.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { ellipsoidMesh, lambAlpha, closestOnEllipsoid } from './aero_test_support.mjs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);

// Lamb coefficients: sphere 2/3; alpha0 + beta0 + gamma0 = 2.
ok(Math.abs(lambAlpha(1, 1, 1) - 2 / 3) < 1e-13, 'sphere alpha0 = 2/3');
for (const [a, b, c] of [[2, 1, 1], [1, 3, 0.12], [1, 0.5, 0.3]]) ok(Math.abs(lambAlpha(a, b, c) + lambAlpha(b, c, a) + lambAlpha(c, a, b) - 2) < 1e-12, 'Lamb sum rule');

function body(a, b, c, nLon, nLat, clustering = 0) {
  const m = ellipsoidMesh(a, b, c, nLon, nLat, clustering), S = W.buildSurface(m.nodes, m.quads);
  const t0 = Date.now(), sol = W.unitSolutions(S, { image: false, farField: 6, solver: 'lu' }), U = W.surfaceVelocity(S, m.layout, sol.mux, [1, 0, 0]);
  const K = 2 / (2 - lambAlpha(a, b, c));
  let muErr = 0, muScale = 0, mu2 = 0, cpErr2 = 0, cpErrMax = 0, area = 0, areaAll = 0, smooth2 = 0, smoothA = 0, F = [0, 0, 0];
  for (let k = 0; k < S.count; k++) {
    const x = S.PC[3 * k], y = S.PC[3 * k + 1], z = S.PC[3 * k + 2], A = S.PA[k];
    // closest exact-surface point to the centroid, and the exact unit normal there
    const X = closestOnEllipsoid([x, y, z], [a, b, c]), g = [X[0] / a ** 2, X[1] / b ** 2, X[2] / c ** 2], gl = Math.hypot(...g), nx = g[0] / gl;
    const em = Math.abs(sol.mux[k] - (K - 1) * X[0]); muErr = Math.max(muErr, em); muScale = Math.max(muScale, Math.abs((K - 1) * X[0])); mu2 += A * em * em; areaAll += A;
    const cp = 1 - (U[3 * k] ** 2 + U[3 * k + 1] ** 2 + U[3 * k + 2] ** 2), ex = 1 - K * K * (1 - nx * nx), lat = Math.floor(k / nLon);
    if (lat > 0 && lat < nLat - 1) { cpErr2 += A * (cp - ex) ** 2; area += A; cpErrMax = Math.max(cpErrMax, Math.abs(cp - ex)); if (Math.abs(nx) < 0.5) { smooth2 += A * (cp - ex) ** 2; smoothA += A; } }
    for (let d = 0; d < 3; d++) F[d] += -cp * A * S.PN[3 * k + d];
  }
  return { n: S.count, K, muRel: muErr / muScale, muRms: Math.sqrt(mu2 / areaAll) / muScale, cpRms: Math.sqrt(cpErr2 / area), cpSmoothRms: Math.sqrt(smooth2 / smoothA), cpMax: cpErrMax, force: Math.hypot(...F), ms: Date.now() - t0, residual: sol.relativeResidual };
}
const cases = [
  ['sphere', 1, 1, 1, [[16, 8], [32, 16], [48, 24]]],
  ['prolate 2:1:1 (axial flow)', 2, 1, 1, [[16, 8], [32, 16], [48, 24]]],
  ['wing-like 1:3:0.12 (chordwise flow)', 1, 3, 0.12, [[24, 12], [40, 20], [56, 28]]],
];
for (const [name, a, b, c, levels, clustering = 0] of cases) {
  const rows = levels.map(([nLon, nLat]) => ({ nLon, nLat, ...body(a, b, c, nLon, nLat, clustering) }));
  log(`${name}: K = ${rows[0].K.toFixed(6)}`);
  for (const r of rows) log(`  ${r.nLon}x${r.nLat} (${r.n} panels): doublet error max ${r.muRel.toExponential(2)}, area-RMS ${r.muRms.toExponential(2)} (relative to max|mu|), Cp RMS error ${r.cpRms.toExponential(2)} (max ${r.cpMax.toExponential(2)}, pole rows excluded; ${r.cpSmoothRms.toExponential(2)} where |n_x| < 0.5), |net force|/q = ${r.force.toExponential(1)}, ${r.ms} ms`);
  const orders = rows.slice(1).map((r, i) => Math.log(rows[i].muRms / r.muRms) / Math.log(r.nLon / rows[i].nLon));
  log(`  observed order of the area-RMS doublet error: ${orders.map(o => o.toFixed(2)).join(', ')}`);
  for (const r of rows) { ok(r.force < 1e-10, `${name}: d'Alembert zero net force`); ok(r.residual < 1e-12, `${name}: linear residual`); }
  ok(orders.every(o => o > 1.5), `${name}: area-RMS doublet error converges at better than first order`);
  ok(rows.at(-1).muRel < 0.01 && rows.at(-1).muRms < 0.003, `${name}: finest doublet error (max < 1%, area-RMS < 0.3%)`);
  ok(rows.at(-1).cpSmoothRms < 0.01, `${name}: finest Cp RMS error < 0.01 away from edges sharper than the panels`);
  ok(rows.at(-1).cpRms < rows[0].cpRms, `${name}: Cp error decreases with refinement`);
}
console.log(`test_wing_aero_closed_bodies: ${checks} checks passed`);
