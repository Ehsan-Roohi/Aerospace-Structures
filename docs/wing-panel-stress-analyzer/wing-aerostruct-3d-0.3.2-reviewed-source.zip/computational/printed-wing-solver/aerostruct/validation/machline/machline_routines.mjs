// JavaScript port of MachLine panel routines (incompressible case, M = 0), for cross-checking the Wing AeroStruct 3-D
// tensor-quadratic recovery and load integration. Source: MachLine, github.com/usuaero/MachLine, commit d62befa,
// src/panel.f90 and src/flow.f90. Ported (same algorithm, same equations, same variable roles) - line references:
//   geometry        panel_calc_normal (265), panel_calc_area (284), panel_calc_centroid (315),
//                   panel_calc_g_to_ls_transform (403; M = 0: B = 1, s = 1, r = 1, C_mat_g = B_mat_g = I, nu_g = n_g,
//                   J = 1, A_ls_to_g = transpose(A_g_to_ls))
//   S_mu, S_mu_inv  panel_calc_M_mu_transform (696-757; order 2: vertices then edge mid-points (i, i+1), columns
//                   1, x, y, x^2/2, x y, y^2/2)
//   C(i, j)         panel_calc_C_integrals (1118-1177; Ni = Nj = 3)
//   local coords    panel_get_local_coords_of_point (1685)
//   velocity jump   panel_get_velocity_jump (3443-3512): tangential jump from the doublet parameters (E&M Eq. N.1.11b),
//                   plus the source's normal jump s n / (nu . n)
//   velocity        panel_get_velocity (3515-3544): v = U (inner_flow + dv)
//   Cp              flow_get_C_P_inc (flow.f90 313): 1 - |v|^2 / U^2
//   Cp parameters   panel_get_quadratic_pressure_params (3547-3613): Cp at the 3 vertices and 3 edge mid-points,
//                   parameters = S_mu_inv Cp
//   average Cp      panel_get_avg_pressure_coef (3616-3686, order 2)
//   couple          panel_get_moment_about_centroid (3689-3755, order 2)
// What is NOT MachLine's here: the doublet and source values are supplied by the caller (Wing AeroStruct's solved P2
// doublet at the six nodes of each triangle and its per-triangle source), not MachLine's own vertex unknowns; and the
// option cOrder. With cOrder = 3 (MachLine's Ni = Nj = 3) the recursion of panel_calc_C_integrals never assigns
// C(i, j) with i + j = 3 (they need II(i + 1, j, i + 1) with i + 1 > Ni - j), yet panel_get_moment_about_centroid reads
// C(3,0), C(2,1), C(1,2), C(0,3): in MachLine they are unassigned memory, here they are 0. cOrder = 4 runs the same
// recursion one order further, which assigns them (checked against quadrature in test_wing_aero_machline_port.mjs).
// Used only by that validation test; the solver (wing_aero_panel.js) contains no MachLine code.
//
// MIT License
//
// Copyright (c) 2021 USU Aero Lab
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]], inner = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const norm2 = a => Math.hypot(a[0], a[1], a[2]), unit = a => mul(a, 1 / norm2(a));
const matvec = (M, v) => M.map(r => r.reduce((s, x, j) => s + x * v[j], 0));
const transpose = M => M[0].map((_, j) => M.map(r => r[j]));
function matinv(A) { // Gauss-Jordan with partial pivoting (MachLine's matinv: LU; the inverse is the same matrix)
  const n = A.length, M = A.map((r, i) => [...r, ...Array.from({ length: n }, (_, j) => (i === j ? 1 : 0))]);
  for (let c = 0; c < n; c++) {
    let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    [M[c], M[p]] = [M[p], M[c]]; const d = M[c][c]; for (let j = 0; j < 2 * n; j++) M[c][j] /= d;
    for (let r = 0; r < n; r++) if (r !== c) { const f = M[r][c]; if (f) for (let j = 0; j < 2 * n; j++) M[r][j] -= f * M[c][j]; }
  }
  return M.map(r => r.slice(n));
}
// A triangular MachLine panel (order 2), incompressible freestream along cHat with speed U.
export function machlinePanel(P, cHat, { cOrder = 3 } = {}) { // cOrder: MachLine's Ni = Nj (3 as in panel.f90; 4 fills the third moments)
  const P1 = P[0], P2 = P[1], P3 = P[2];
  const n_g = unit(cross(sub(P2, P1), sub(P3, P2)));                          // panel_calc_normal
  const A = 0.5 * norm2(cross(sub(P2, P1), sub(P3, P2)));                     // panel_calc_area
  const centr = mul(add(add(P1, P2), P3), 1 / 3);                            // panel_calc_centroid
  let v0 = Math.abs(Math.abs(inner(n_g, cHat)) - 1) < 1e-12 ? sub(P2, P1) : cross(n_g, cHat); // panel_calc_g_to_ls_transform
  v0 = unit(v0); const u0 = unit(cross(v0, n_g));
  const A_g_to_ls = [u0, v0, n_g], A_ls_to_g = transpose(A_g_to_ls), J = 1;
  const vls = P.map(p => matvec(A_g_to_ls.slice(0, 2), sub(p, centr)));      // vertices_ls
  // S_mu (panel_calc_M_mu_transform, order 2)
  const x = vls.map(v => v[0]), y = vls.map(v => v[1]);
  const X = [...x, ...[0, 1, 2].map(i => 0.5 * (x[i] + x[(i + 1) % 3]))], Y = [...y, ...[0, 1, 2].map(i => 0.5 * (y[i] + y[(i + 1) % 3]))];
  const S_mu = X.map((xi, r) => [1, xi, Y[r], 0.5 * xi * xi, xi * Y[r], 0.5 * Y[r] * Y[r]]);
  const S_mu_inv = matinv(S_mu);
  // C integrals (panel_calc_C_integrals, Ni = Nj = 3)
  const Ni = cOrder, Nj = cOrder, d_xi = [], d_eta = [];
  for (let k = 0; k < 3; k++) { const kn = (k + 1) % 3; d_xi[k] = vls[kn][0] - vls[k][0]; d_eta[k] = vls[kn][1] - vls[k][1]; }
  const II = Array.from({ length: Ni + 3 }, () => Array.from({ length: Nj + 1 }, () => Array.from({ length: Ni + 2 }, () => [0, 0, 0])));
  for (let i = 0; i <= Ni + 2; i++) II[i][0][0] = [1 / (i + 1), 1 / (i + 1), 1 / (i + 1)];
  for (let j = 1; j <= Nj; j++) for (let i = 0; i <= Ni - j; i++) II[i][j][0] = [0, 1, 2].map(e => vls[e][1] * II[i][j - 1][0][e] + d_eta[e] * II[i + 1][j - 1][0][e]);
  for (let j = 0; j <= Nj; j++) for (let k = 1; k <= Ni - j; k++) for (let i = Ni - j; i >= k; i--) II[i][j][k] = [0, 1, 2].map(e => vls[e][0] * II[i - 1][j][k - 1][e] + d_xi[e] * II[i][j][k - 1][e]);
  const C = Array.from({ length: Ni + 1 }, (_, i) => Array.from({ length: Nj + 1 }, (_, j) => [0, 1, 2].reduce((s, e) => s + d_eta[e] * II[i + 1][j][i + 1][e], 0) / (i + 1)));
  return { P, n_g, A, centr, A_g_to_ls, A_ls_to_g, J, vls, S_mu, S_mu_inv, C, cHat };
}
// panel_get_local_coords_of_point
export const localCoords = (pan, Pt) => matvec(pan.A_g_to_ls, sub(Pt, pan.centr));
// doublet parameters from the six node values (vertices, mid-points 12 23 31): T_mu = S_mu_inv for an order-2 panel
// whose doublet is given at its own vertices and mid-points (panel_calc_M_mu_transform, T_mu = S_mu_inv branch)
export const doubletParams = (pan, mu6) => matvec(pan.S_mu_inv, mu6);
// panel_get_velocity_jump (order 2, constant source sigma: sigma_dim = 1)
export function velocityJump(pan, muParams, sigma, point) {
  const Q = point ? localCoords(pan, point) : [0, 0, 0];
  let dv = [muParams[1] + muParams[3] * Q[0] + muParams[4] * Q[1], muParams[2] + muParams[4] * Q[0] + muParams[5] * Q[1], 0];
  dv = matvec(transpose(pan.A_g_to_ls), dv);
  const s_dir = mul(pan.n_g, 1 / inner(pan.n_g, pan.n_g)); // nu_g = n_g at M = 0
  return add(dv, mul(s_dir, sigma));
}
// panel_get_velocity: v = U (inner_flow + dv); Morino (Dirichlet, sources) inner_flow = c_hat (panel_solver.f90 357)
export const velocity = (pan, muParams, sigma, U, innerFlow, point) => mul(add(innerFlow, velocityJump(pan, muParams, sigma, point)), U);
export const cpInc = (v, U) => 1 - inner(v, v) / (U * U); // flow_get_C_P_inc
// panel_get_quadratic_pressure_params
export function quadraticPressureParams(pan, muParams, sigma, U, innerFlow) {
  const Cp = [];
  for (let i = 0; i < 3; i++) Cp[i] = cpInc(velocity(pan, muParams, sigma, U, innerFlow, pan.P[i]), U);
  for (let i = 0; i < 3; i++) Cp[i + 3] = cpInc(velocity(pan, muParams, sigma, U, innerFlow, mul(add(pan.P[i], pan.P[(i + 1) % 3]), 0.5)), U);
  return matvec(pan.S_mu_inv, Cp);
}
// panel_get_avg_pressure_coef (order 2)
export function avgPressureCoef(pan, Cpp) {
  const C = pan.C; const s = C[0][0] * Cpp[0] + C[1][0] * Cpp[1] + C[0][1] * Cpp[2] + 0.5 * C[2][0] * Cpp[3] + C[1][1] * Cpp[4] + 0.5 * C[0][2] * Cpp[5];
  return pan.J * s / pan.A;
}
// panel_get_moment_about_centroid (order 2): moment coefficient (units of length x area / reference area handled by caller)
export function momentAboutCentroid(pan, Cpp) {
  const C = pan.C;
  const m1 = C[1][0] * Cpp[0] + C[2][0] * Cpp[1] + C[1][1] * Cpp[2] + 0.5 * C[3][0] * Cpp[3] + C[2][1] * Cpp[4] + 0.5 * C[1][2] * Cpp[5];
  const m2 = C[0][1] * Cpp[0] + C[1][1] * Cpp[1] + C[0][2] * Cpp[2] + 0.5 * C[2][1] * Cpp[3] + C[1][2] * Cpp[4] + 0.5 * C[0][3] * Cpp[5];
  return mul(cross(pan.n_g, matvec(pan.A_ls_to_g, [m1, m2, 0])), pan.J);
}
// panel_solver_calc_forces_with_pressure: dC_f = -Cp_avg A n (per unit dynamic pressure)
export const forceOfPanel = (pan, CpAvg) => mul(pan.n_g, -CpAvg * pan.A);
