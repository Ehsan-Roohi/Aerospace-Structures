// EXTERNAL / ANALYTIC ACCEPTANCE EVIDENCE for the tensor-quadratic candidate (0.3.2-exp.3, UNVALIDATED). NEW FILE.
//
// It replaces nothing. The older suites (admission, surface_gradient, wing, conformal, twist, ...) are kept exactly as
// they are, failures included. Many of their failing checks pin numbers of the published constant-doublet method or
// compare with references computed by that method; those are regression pins, not physics. This file is the
// independent evidence: every check compares with an analytic solution or with an independent code (PANAIR A502), or
// tests convergence of a quantity defined at a FIXED physical place (not at a mesh-dependent panel). Each threshold
// is stated with its reason next to it.
//
//  1. Analytic closed body: the exact ellipsoid 100 : 300 : 20 mm (Lamb), built on the production mesh path (elliptic
//     planform, exact elliptic sections): control-point Cp, the doublet as the surface potential, d'Alembert.
//  2. Analytic lifting section: rectangular wings whose sections are EXACT Karman-Trefftz sections (t/c 0.13, 12 deg
//     trailing edge). Mid-span Cp against the exact 2-D Cp (aspect ratio 20). Mid-span section cm about c/4 against
//     the exact 2-D cm at the same section cl, at aspect ratios 20, 40 and 80: the finite-wing residual (the chordwise
//     variation of the downwash, an induced camber) is physical and falls as 1/AR^2; extrapolated in AR, the core's
//     section cm must meet the exact 2-D value.
//  3. The tip trailing-edge corner of the rectangular NACA 0012 AR 6 wing (c 200, semi-span 600 mm, rounded tip; the
//     PANAIR wing). The continuous surface has a sharp edge there (the tip-edge radius (t/2)^2/l goes to 0 at the
//     trailing edge), so the lifting cross-flow around it is expected to be singular, and the corner panel's Cp grows
//     as its control point approaches the edge. The corner panel's own Cp is NOT validated here: it is a pointwise
//     value at a mesh-dependent place next to the edge, and nothing below controls it. What supports a continuum
//     singularity rather than a discrete defect is convergence at FIXED places and over FIXED regions, together with
//     the analytic tip geometry: Cp at fixed planform points converges and PANAIR converges toward it; loads on fixed
//     corner boxes converge monotonically; section cl at fixed stations converges and agrees with PANAIR. Also tested,
//     as CONSISTENCY ONLY: no growth without lift (alpha 0), and the growing part scales as alpha^2. That shows the
//     growth comes from the lift-dependent velocity; it does not separate a physical singularity from a discrete
//     artifact, because any artifact of the (linear) solution's velocity would scale the same way.
//  4. Global coefficients against PANAIR on identical nodes (32 x 24 and 64 x 48): lift, Trefftz lift, induced drag,
//     span efficiency; pitching moment by ONE integration rule for both codes.
//  5. Self-convergence of lift, drag and moment on the uniform sequence 32 x 24, 48 x 36, 64 x 48; the six components
//     of the panel loads are conserved (strips, resultant).
//
// PANAIR data: validation/panair/panair_reference_rect0012.json (provenance in validation/panair/README.md). Runtime
// about 3 minutes (most of it the aspect-ratio-80 wing of section 2).
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js'), Geo = require('../web/wing_geometry.js');
const T = await import('./aero_test_support.mjs');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; console.log('   ok', m); };
const t0 = Date.now(), secs = () => ((Date.now() - t0) / 1000).toFixed(0) + ' s';
const LIM = { referenceLimits: { maxPanels: 100000, chordPanels: [6, 512], spanPanels: [4, 256] } };
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const e3 = x => x.toExponential(3), f4 = x => x.toFixed(4);

// ---------------------------------------------------------------- the solved surface field (no new physics)
// m.surface: the triangle table R of the panel splits (vertices X, normals N, areas, triangles per panel) and the
// recovered velocity at each triangle's vertices for unit free streams along x (Ux) and z (Uz). On each flat triangle
// the velocity is linear, so Cp = 1 - |v|^2 is quadratic; region integrals below are exact for it (polygon clipping in
// the triangle's parameter plane, degree-5 Dunavant rule).
const GP = [[1 / 3, 1 / 3, 1 / 3, 0.225]];
for (const [a, b, w] of [[0.059715871789770, 0.470142064105115, 0.132394152788506], [0.797426985353087, 0.101286507323456, 0.125939180544827]]) GP.push([a, b, b, w], [b, a, b, w], [b, b, a, w]);
function surfaceField(m, alphaDeg) {
  const R = m.surface.R, U = m.surface.Ux, Z = m.surface.Uz, al = alphaDeg * Math.PI / 180, ca = Math.cos(al), sa = Math.sin(al), nT = R.area.length;
  const V = new Float64Array(9 * nT); for (let j = 0; j < 9 * nT; j++) V[j] = ca * U[j] + sa * Z[j];
  const P = j => [0, 1, 2].map(i => [R.X[9 * j + 3 * i], R.X[9 * j + 3 * i + 1], R.X[9 * j + 3 * i + 2]]);
  const vel = (j, l) => [0, 1, 2].map(c => l[0] * V[9 * j + c] + l[1] * V[9 * j + 3 + c] + l[2] * V[9 * j + 6 + c]);
  const cp = (j, l) => { const v = vel(j, l); return 1 - dot(v, v); };
  return { R, nT, P, cp, N: j => [R.N[3 * j], R.N[3 * j + 1], R.N[3 * j + 2]], area: j => R.area[j] };
}
function clip(poly, a, b, c) {
  const out = [];
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i], q = poly[(i + 1) % poly.length], fp = a * p[0] + b * p[1] + c, fq = a * q[0] + b * q[1] + c;
    if (fp >= 0) out.push(p);
    if ((fp >= 0) !== (fq >= 0)) { const t = fp / (fp - fq); out.push([p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])]); }
  }
  return out;
}
// force (per unit dynamic pressure, mm^2) and moment about P0 on the surface region x0 <= x <= x1, y0 <= y <= y1
function regionLoad(F, [x0, x1, y0, y1], P0) {
  let Fo = [0, 0, 0], Mo = [0, 0, 0];
  for (let j = 0; j < F.nT; j++) {
    const Q = F.P(j), xs = [Q[0][0], Q[1][0], Q[2][0]], ys = [Q[0][1], Q[1][1], Q[2][1]];
    if (Math.max(...xs) < x0 || Math.min(...xs) > x1 || Math.max(...ys) < y0 || Math.min(...ys) > y1) continue;
    const e1 = sub(Q[1], Q[0]), e2 = sub(Q[2], Q[0]); let poly = [[0, 0], [1, 0], [0, 1]];
    for (const [a, b, c] of [[e1[0], e2[0], Q[0][0] - x0], [-e1[0], -e2[0], x1 - Q[0][0]], [e1[1], e2[1], Q[0][1] - y0], [-e1[1], -e2[1], y1 - Q[0][1]]]) if (poly.length) poly = clip(poly, a, b, c);
    if (poly.length < 3) continue;
    const n = F.N(j), J = 2 * F.area(j);
    for (let t = 1; t + 1 < poly.length; t++) {
      const A = poly[0], B = poly[t], C = poly[t + 1], aUV = 0.5 * Math.abs((B[0] - A[0]) * (C[1] - A[1]) - (C[0] - A[0]) * (B[1] - A[1]));
      if (!(aUV > 0)) continue;
      for (const [g0, g1, g2, w] of GP) {
        const u = g0 * A[0] + g1 * B[0] + g2 * C[0], v = g0 * A[1] + g1 * B[1] + g2 * C[1], X = add(Q[0], add(mul(e1, u), mul(e2, v))), f = mul(n, -F.cp(j, [1 - u - v, u, v]) * w * aUV * J);
        Fo = add(Fo, f); Mo = add(Mo, cross(sub(X, P0), f));
      }
    }
  }
  return { F: Fo, M: Mo };
}
// Cp at the surface point above (upper) or below (lower) the planform point (x, y)
function pointCp(F, x, y, side) {
  let best = null;
  for (let j = 0; j < F.nT; j++) {
    const Q = F.P(j), zc = (Q[0][2] + Q[1][2] + Q[2][2]) / 3; if (side === 'upper' ? zc < 0 : zc > 0) continue;
    const d = (Q[1][0] - Q[0][0]) * (Q[2][1] - Q[0][1]) - (Q[2][0] - Q[0][0]) * (Q[1][1] - Q[0][1]); if (Math.abs(d) < 1e-300) continue;
    const l1 = ((x - Q[0][0]) * (Q[2][1] - Q[0][1]) - (Q[2][0] - Q[0][0]) * (y - Q[0][1])) / d, l2 = ((Q[1][0] - Q[0][0]) * (y - Q[0][1]) - (x - Q[0][0]) * (Q[1][1] - Q[0][1])) / d, l = [1 - l1 - l2, l1, l2], mn = Math.min(...l);
    if (mn >= -1e-9 && (!best || mn > best.mn)) best = { j, l, mn };
  }
  return best ? F.cp(best.j, best.l) : null;
}
// the core's recovered Cp at a point X on (or within round-off of) panel k: its triangle with the largest smallest
// barycentric coordinate
function cpOnPanel(F, k, X) {
  let best = null;
  for (let j = F.R.first[k]; j < F.R.first[k + 1]; j++) {
    const Q = F.P(j), n = F.N(j), A2 = 2 * F.area(j), l = [0, 1, 2].map(i => dot(cross(sub(Q[(i + 1) % 3], X), sub(Q[(i + 2) % 3], X)), n) / A2), mn = Math.min(...l);
    if (!best || mn > best.mn) best = { j, l, mn };
  }
  return F.cp(best.j, best.l);
}

// ======================================================================= 1. exact ellipsoid (Lamb)
console.log('1. Exact ellipsoid 100 : 300 : 20 mm, flow along x (Lamb), tensor model on the production mesh path');
{
  const c0 = 200, s = 300, t = 0.2, a = c0 / 2, b = s, cz = t * c0 / 2, xm = c0 / 2, K = 2 / (2 - T.lambAlpha(a, b, cz));
  const geo = { naca: '0012', planform: 'elliptic', semiSpan: s, rootChord: c0, tipChord: 0 };
  const loop = g => (y, nHalf) => { const c = Geo.chordAt(g, y); if (!(c > 1e-9 * g.rootChord)) return null; const pts = [];
    for (let i = 0; i <= 2 * nHalf; i++) { const th = Math.PI * (i <= nHalf ? i : 2 * nHalf - i) / nHalf, sg = i <= nHalf ? -1 : 1; pts.push([c * (1 + Math.cos(th)) / 2, sg * t * c * Math.sin(th) / 2]); }
    return pts; };
  const exactCp = X => { const P = T.closestOnEllipsoid([X[0] - xm, X[1], X[2]], [a, b, cz]), g = [P[0] / a ** 2, P[1] / b ** 2, P[2] / cz ** 2], nx = g[0] / Math.hypot(...g); return 1 - K * K * (1 - nx * nx); };
  // exact Cp at the surface point above / below the planform point (x, y)
  const exactCpXY = (x, y, side) => { const r = Math.sqrt(1 - (y / b) ** 2), cx = (x - xm) / (a * r), X = [x - xm, y, (side === 'upper' ? 1 : -1) * cz * r * Math.sqrt(1 - cx * cx)], g = [X[0] / a ** 2, X[1] / b ** 2, X[2] / cz ** 2], nx = g[0] / Math.hypot(...g); return 1 - K * K * (1 - nx * nx); };
  // exact force per unit q on the tip region y >= y0: -int Cp n dA over P = (xm + a sin p cos f, b cos p, cz sin p sin f)
  const exactTipFy = y0 => {
    const p0 = Math.acos(y0 / b), G = T.gauss01(120), NF = 1200; let Fy = 0;
    for (let q = 0; q < G.x.length; q++) for (let f = 0; f < NF; f++) {
      const ps = p0 * G.x[q], ph = 2 * Math.PI * (f + 0.5) / NF, X = [a * Math.sin(ps) * Math.cos(ph), b * Math.cos(ps), cz * Math.sin(ps) * Math.sin(ph)];
      const n = cross([-a * Math.sin(ps) * Math.sin(ph), 0, cz * Math.sin(ps) * Math.cos(ph)], [a * Math.cos(ps) * Math.cos(ph), -b * Math.sin(ps), cz * Math.cos(ps) * Math.sin(ph)]), dA = Math.hypot(...n), sg = dot(n, [X[0] / a ** 2, X[1] / b ** 2, X[2] / cz ** 2]) > 0 ? 1 : -1;
      const nx = sg * n[0] / dA; Fy -= (1 - K * K * (1 - nx * nx)) * sg * n[1] * p0 * G.w[q] * 2 * Math.PI / NF;
    }
    return Fy;
  };
  const TIP = [290, 296], FyEx = TIP.map(exactTipFy), ETA = [0.9, 0.95, 0.98, 0.99, 0.995];
  const res = [];
  for (const [nc, ns] of [[16, 8], [32, 16]]) {
    const g = W.aeroGeometry(geo), m = W.prepare(geo, { chordPanels: nc, spanPanels: ns }, { ...LIM, sectionLoop: loop(g), sectionKey: `accept-ellipsoid-${nc}x${ns}` });
    const r = W.evaluate(m, { alphaDeg: 0, speed: 1, density: 1 }), S = m.wm.S, n = m.wm.wingPanels, ni = m.wm.ni, last = (m.wm.ns - 1) * ni, F = surfaceField(m, 0);
    let eIn = 0, e2 = 0, off = 0, eLast = 0;
    for (let k = 0; k < n; k++) {
      const X = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]], e = Math.abs(r.panels.cp[k] - exactCp(X)), cy = Geo.chordAt(g, X[1]);
      e2 += e * e; if (Math.abs(X[0] - xm) <= 0.8 * cy / 2 && X[1] <= 0.9 * s) eIn = Math.max(eIn, e); if (k >= last) eLast = Math.max(eLast, e);
      off += r.panels.mu[k] - (K - 1) * (X[0] - xm);
    }
    off /= n; let muErr = 0, muIn = 0;
    for (let k = 0; k < n; k++) {
      const e = Math.abs(r.panels.mu[k] - (K - 1) * (S.PC[3 * k] - xm) - off) / ((K - 1) * a); muErr = Math.max(muErr, e);
      if (Math.abs(S.PC[3 * k] - xm) <= 0.8 * Geo.chordAt(g, S.PC[3 * k + 1]) / 2 && S.PC[3 * k + 1] <= 0.9 * s) muIn = Math.max(muIn, e);
    }
    const ptErr = Math.max(...ETA.flatMap(eta => ['upper', 'lower'].map(side => Math.abs(pointCp(F, xm, eta * s, side) - exactCpXY(xm, eta * s, side)))));
    const tipErr = TIP.map((y0, q) => regionLoad(F, [-1e9, 1e9, y0, 1e9], [0, 0, 0]).F[1] / FyEx[q] - 1);
    res.push({ nc, ns, eIn, rms: Math.sqrt(e2 / n), eLast, muErr, muIn, ptErr, tipErr, CD: r.coefficients.CDpressure, CL: r.coefficients.CL });
    console.log(`   ${nc}x${ns}: control-point Cp error RMS ${e3(Math.sqrt(e2 / n))}, inner 80 % of each chord (eta <= 0.9) max ${e3(eIn)}, collapsed last strip max ${e3(eLast)}; fixed points at mid-chord, eta 0.9 ... 0.995: max ${e3(ptErr)}; tip-region side force (y >= ${TIP.join(', ')}): ${tipErr.map(e3).join(', ')} relative; doublet error / ((K-1) U a) max ${e3(muErr)} (inner region ${e3(muIn)}); CDp ${e3(r.coefficients.CDpressure)} (exact 0)`);
  }
  const [A, B] = res;
  // thresholds: Cp error of a second-order panel method on a 32 x 16 mesh of a 10 % thick body: 1e-3 away from the
  // strongly curved section ends and tip; elsewhere every FIXED quantity must converge
  ok(B.eIn < 1e-3, `ellipsoid 32x16: control-point Cp error ${e3(B.eIn)} < 1e-3 on the inner 80 % of each chord (eta <= 0.9)`);
  ok(B.rms < 0.6 * A.rms, `ellipsoid: control-point Cp RMS error falls 16x8 -> 32x16 (${e3(A.rms)} -> ${e3(B.rms)}, by at least 1/0.6)`);
  ok(B.ptErr < 0.7 * A.ptErr, `ellipsoid tip: Cp at fixed points (mid-chord, eta 0.9 ... 0.995, both surfaces) converges (max error ${e3(A.ptErr)} -> ${e3(B.ptErr)})`);
  ok(B.tipErr.every((e, q) => Math.abs(e) < 0.5 * Math.abs(A.tipErr[q])), `ellipsoid tip: side force on the fixed tip regions converges to Lamb's (relative error ${A.tipErr.map(e3).join(', ')} -> ${B.tipErr.map(e3).join(', ')}, at least halved)`);
  // NOT a convergent quantity (reported, not tested): the control-point Cp of the COLLAPSED last strip of a closed
  // elliptic tip. Its flat triangles approximate a cap whose normal turns by about 90 degrees inside the strip at every
  // refinement (the cap is self-similar under the square-root profile), so its control point always sits in the turn.
  console.log(`   NOT convergent (reported): collapsed last-strip control-point Cp error ${e3(A.eLast)} -> ${e3(B.eLast)}; fixed points and fixed regions there converge (above)`);
  // the solved doublet IS the surface perturbation potential (K - 1) U x up to a constant: same 1e-3 resolution on the
  // inner region; everywhere at least first-order convergence (the largest errors sit at the section ends and the tip)
  ok(B.muIn < 1e-3 && B.muErr < A.muErr / 1.7, `ellipsoid: doublet = exact surface potential (K-1) U x: inner-region error ${e3(B.muIn)} of (K-1) U a (< 1e-3); whole-surface max ${e3(A.muErr)} -> ${e3(B.muErr)} (falls by > 1.7)`);
  ok(Math.abs(B.CD) < 1e-3 && Math.abs(B.CD) < Math.abs(A.CD), `ellipsoid: d'Alembert, |CDp| ${e3(Math.abs(B.CD))} < 1e-3 and falling (16x8: ${e3(Math.abs(A.CD))})`);
  ok(Math.abs(B.CL) < 1e-9, `ellipsoid: no lift at alpha 0 (|CL| ${e3(Math.abs(B.CL))})`);
}
console.log(`   (${secs()})`);

// ======================================================================= 2. exact Karman-Trefftz sections
console.log('2. Rectangular wings with exact Karman-Trefftz sections (t/c 0.13, 12 deg trailing edge), alpha 4');
const KT = T.karmanTrefftz({ b: 1, ex: 0.075, ey: 0, teAngleDeg: 12 });
function ktWing(AR, nc, ns) {
  const geometry = { semiSpan: 50 * AR, rootChord: 100, tipChord: 100, naca: '0012' }, g = W.aeroGeometry(geometry);
  const loop = (y, nHalf) => { const c = Geo.chordAt(g, y); return c > 1e-9 ? T.conformalLoopCosine(KT, nHalf).pts.map(p => [p[0] * c, p[1] * c]) : null; };
  const m = W.prepare(geometry, { chordPanels: nc, spanPanels: ns, spanSpacing: 'cosine' }, { ...LIM, sectionLoop: loop, sectionKey: `accept-kt-${AR}-${nc}-${ns}` });
  return { m, r: W.evaluate(m, { alphaDeg: 4, speed: 10 }) };
}
// exact 2-D section coefficients at angle alpha to the chord (unit chord, cm about c/4, nose up positive): the exact Cp
// integrated over the exact contour (200000 segments; converged to 1e-9); exact cl also from Kutta-Joukowski
function exact2D(al, N = 200000) {
  const P = [], th = [];
  for (let k = 0; k <= N; k++) { const t = KT.thTE + 2 * Math.PI * k / N; th.push(t); P.push(k === 0 || k === N ? [1, 0] : KT.toLocal(KT.map(t))); }
  let area = 0; for (let k = 0; k < N; k++) area += P[k][0] * P[k + 1][1] - P[k + 1][0] * P[k][1];
  const sg = area > 0 ? 1 : -1; let Fx = 0, Fz = 0, My = 0;
  for (let k = 0; k < N; k++) {
    const cp = KT.cpAt(0.5 * (th[k] + th[k + 1]), al), dx = P[k + 1][0] - P[k][0], dz = P[k + 1][1] - P[k][1], nx = sg * dz, nz = -sg * dx, rx = 0.5 * (P[k][0] + P[k + 1][0]) - 0.25, rz = 0.5 * (P[k][1] + P[k + 1][1]);
    Fx -= cp * nx; Fz -= cp * nz; My -= cp * (rz * nx - rx * nz);
  }
  return { cl: -Fx * Math.sin(al) + Fz * Math.cos(al), cd: Fx * Math.cos(al) + Fz * Math.sin(al), cm: My, clKJ: KT.liftSlope2D * Math.sin(al + KT.chordAngle + KT.beta) / (8 * Math.PI * KT.a / KT.chord) * (8 * Math.PI * KT.a / KT.chord) };
}
const exactAtCl = cl => exact2D(Math.asin(cl / KT.liftSlope2D) - KT.chordAngle - KT.beta); // Kutta-Joukowski: cl = 8 pi a / c sin(alpha + chordAngle + beta)
{
  const e4 = exact2D(4 * Math.PI / 180);
  ok(Math.abs(e4.cl - e4.clKJ) < 1e-8 && Math.abs(e4.cd) < 1e-9, `exact 2-D reference: contour integral cl ${e4.cl.toFixed(9)} = Kutta-Joukowski ${e4.clKJ.toFixed(9)}, cd ${e3(e4.cd)} (exact 0)`);
  // 2a. mid-span control-point Cp against the exact 2-D Cp at the angle that gives the strip's circulation (AR 20)
  const rms = [];
  for (const nc of [16, 32]) {
    const { m, r } = ktWing(20, nc, 16), params = T.conformalLoopCosine(KT, nc).params, aEff = r.strips[0].clKuttaJoukowski / KT.liftSlope2D; let e2 = 0, cnt = 0;
    for (let i = 2; i < m.wm.ni - 2; i++) {
      const k = m.wm.index(i, 0), loc = Geo.inversePoint(m.geometry, [m.wm.S.PC[3 * k], m.wm.S.PC[3 * k + 1], m.wm.S.PC[3 * k + 2]]).map(v => v / 100);
      let lo = Math.min(params[i], params[i + 1]), hi = Math.max(params[i], params[i + 1]); const d = th => { const q = KT.toLocal(KT.map(th)); return (q[0] - loc[0]) ** 2 + (q[1] - loc[1]) ** 2; };
      for (let it = 0; it < 80; it++) { const m1 = lo + 0.382 * (hi - lo), m2 = lo + 0.618 * (hi - lo); if (d(m1) < d(m2)) hi = m2; else lo = m1; }
      const e = r.panels.cp[k] - KT.cpAt((lo + hi) / 2, aEff); e2 += e * e; cnt++;
    }
    rms.push(Math.sqrt(e2 / cnt));
    console.log(`   AR 20, ${nc} chordwise: mid-span control-point Cp RMS error against exact 2-D (circulation-matched angle ${(aEff * 180 / Math.PI).toFixed(4)} deg): ${e3(rms[rms.length - 1])}`);
  }
  const order = Math.log2(rms[0] / rms[1]);
  ok(rms[1] < 1.5e-2 && order >= 1.5, `KT mid-span Cp: RMS error ${e3(rms[1])} < 1.5e-2 at 32 chordwise panels, order ${order.toFixed(2)} >= 1.5 (16 -> 32)`);
  // 2b. mid-span section cm about c/4 against the exact 2-D cm at the same section cl
  const dcm = {};
  for (const AR of [20, 40, 80]) {
    const ts = Date.now(), { r } = ktWing(AR, 64, 16 * AR / 20), st = r.strips[0], q = r.flow.dynamicPressure_Pa * 1e-6, dy = st.y1 - st.y0, al = 4 * Math.PI / 180;
    const cl = (-st.force_N[0] * Math.sin(al) + st.force_N[2] * Math.cos(al)) / (q * st.chord * dy), cm = st.momentAboutQuarterChord_Nmm[1] / (q * st.chord * st.chord * dy), ex = exactAtCl(cl);
    dcm[AR] = cm - ex.cm;
    console.log(`   AR ${AR}, 64 chordwise x ${16 * AR / 20} spanwise (${r.mesh.panels} panels, ${((Date.now() - ts) / 1000).toFixed(0)} s): mid-span cl ${cl.toFixed(6)}, cm ${cm.toExponential(5)}; exact 2-D cm at this cl ${ex.cm.toExponential(5)}; difference ${e3(dcm[AR])}`);
  }
  const lim2D = (4 * dcm[80] - dcm[40]) / 3, ratio = (dcm[20] - dcm[40]) / (dcm[40] - dcm[80]);
  console.log(`   finite-wing residual falls as 1/AR^2: (d20 - d40) / (d40 - d80) = ${ratio.toFixed(2)} (pure 1/AR^2: 4); 2-D limit (4 d80 - d40) / 3 = ${e3(lim2D)}`);
  // the residual is the induced camber of a finite wing: positive (reflex: the downwash grows toward the trailing edge),
  // about cl / (8 AR^2); its fall with AR must be at least as fast as 1/AR^1.6 (ratio >= 3)
  ok(dcm[20] > 0 && dcm[40] > 0 && ratio >= 3, `KT section cm: the finite-wing residual is positive (nose up) and falls with aspect ratio as 1/AR^2 (ratio ${ratio.toFixed(2)} >= 3)`);
  // threshold: 1e-5 in cm is a centre-of-pressure shift of 2e-5 chords at cl 0.48
  ok(Math.abs(dcm[80]) < 1.5e-5, `KT section cm, AR 80: |cm - exact 2-D| ${e3(Math.abs(dcm[80]))} < 1.5e-5 (finite-wing residual included)`);
  ok(Math.abs(lim2D) < 1e-5, `KT section cm extrapolated to AR -> infinity: |cm - exact 2-D| ${e3(Math.abs(lim2D))} < 1e-5 at 64 chordwise panels`);
}
console.log(`   (${secs()})`);

// ======================================================================= 3. - 5. the PANAIR wing
const PAN = JSON.parse(readFileSync(new URL('./validation/panair/panair_reference_rect0012.json', import.meta.url), 'utf8'));
const RECT = { naca: '0012', semiSpan: 600, rootChord: 200, tipChord: 200 }, cR = 200, sR = 600, ALPHA = 4, aR = ALPHA * Math.PI / 180, eL = [-Math.sin(aR), 0, Math.cos(aR)];
const runs = {};
for (const mesh of ['32x24', '48x36', '64x48']) {
  const [nc, ns] = mesh.split('x').map(Number), ts = Date.now(), m = W.prepare(RECT, { chordPanels: nc, spanPanels: ns }, LIM), r = W.evaluate(m, { speed: 10, density: 1.225, alphaDeg: ALPHA });
  const r0 = W.evaluate(m, { speed: 10, density: 1.225, alphaDeg: 0 }), r2 = W.evaluate(m, { speed: 10, density: 1.225, alphaDeg: 2 }), F = surfaceField(m, ALPHA);
  runs[mesh] = { m, r, r0, r2, F };
  console.log(`   rectangular NACA 0012 AR 6, ${mesh} (${r.mesh.panels} panels, ${((Date.now() - ts) / 1000).toFixed(0)} s): CL ${r.coefficients.CL.toFixed(6)} CL Trefftz ${r.coefficients.CLTrefftz.toFixed(6)} CDi ${r.coefficients.CDiTrefftz.toFixed(7)} CDp ${r.coefficients.CDpressure.toFixed(7)} Cm ${r.coefficients.Cm.toExponential(4)}`);
}
console.log('3. Tip trailing-edge corner of the rectangular NACA 0012 AR 6 wing (sharp edge of the continuous surface)');
{
  for (const mesh of Object.keys(runs)) {
    const { m, r, r0, r2 } = runs[mesh], wm = m.wm, j = wm.ns - 1;
    for (const [i, side] of [[0, 'lower'], [wm.ni - 1, 'upper']]) {
      const k = j * wm.ni + i, c0 = r0.panels.cp[k], c2 = r2.panels.cp[k], c4 = r.panels.cp[k], d = Math.hypot(wm.S.PC[3 * k] - cR, wm.S.PC[3 * k + 1] - sR, wm.S.PC[3 * k + 2]), ratio = (c4 - c0) / (c2 - c0);
      // alpha 0: thickness flow only, no cross-flow around the edge: bounded (a stagnation-side value, 0 ... 0.3)
      ok(c0 > 0 && c0 < 0.3, `${mesh} ${side} corner panel (control point ${d.toFixed(3)} mm from the corner): alpha 0 Cp ${f4(c0)} in (0, 0.3) - no growth without lift`);
      // consistency only: the lift-dependent velocity is proportional to alpha, so its Cp part to alpha^2 (ratio 4,
      // +-10 %). A discrete artifact of the linear solution would scale the same way: this does NOT validate the panel.
      ok(ratio > 3.6 && ratio < 4.4, `${mesh} ${side} corner panel: (Cp(4) - Cp(0)) / (Cp(2) - Cp(0)) = ${ratio.toFixed(3)} in (3.6, 4.4): the growth is in the lift-dependent velocity (consistency only, not a validation of the corner value; Cp at alpha 4: ${c4.toFixed(2)})`);
    }
  }
  // fixed planform points on rays from the corner (phi from the trailing-edge line; d mm). Excluded: d < 2 mm, and
  // phi 75 at d 2 mm (0.5 mm from the tip edge): there pointwise Cp is not converged in either code.
  const pts = []; for (const side of ['upper', 'lower']) for (const phi of [15, 45, 75]) for (const d of [2, 4, 8, 16]) if (!(phi === 75 && d === 2)) pts.push({ side, phi, d });
  const panRay = (mesh, p) => PAN.meshes[mesh].rays.find(q => q.phi === p.phi && q.d === p.d && q.side === p.side).cp;
  let selfMax = 0, toward = 0, worst = '';
  for (const p of pts) {
    const x = cR - p.d * Math.sin(p.phi * Math.PI / 180), y = sR - p.d * Math.cos(p.phi * Math.PI / 180), c48 = pointCp(runs['48x36'].F, x, y, p.side), c64 = pointCp(runs['64x48'].F, x, y, p.side);
    const p32 = panRay('32x24', p), p64 = panRay('64x48', p), dSelf = Math.abs(c48 - c64);
    if (dSelf > selfMax) { selfMax = dSelf; worst = `${p.side} phi ${p.phi} d ${p.d}`; }
    if (Math.abs(p64 - c64) <= Math.max(Math.abs(p32 - c64), 0.005)) toward++;
    console.log(`   ${p.side} phi ${String(p.phi).padStart(2)} d ${String(p.d).padStart(2)} mm: core 48x36 ${f4(c48)} 64x48 ${f4(c64)} | PANAIR 32x24 ${f4(p32)} 64x48 ${f4(p64)}`);
  }
  // 0.02 in Cp: an engineering resolution for a pressure that is O(0.1 ... 1) here
  ok(selfMax < 0.02, `fixed corner points: core 48x36 -> 64x48 change <= ${f4(selfMax)} < 0.02 at all ${pts.length} points (largest: ${worst})`);
  ok(toward === pts.length, `fixed corner points: PANAIR 64x48 is closer to the core's 64x48 value than PANAIR 32x24 is (or within 0.005) at ${toward} of ${pts.length} points`);
  // loads on fixed corner boxes (x in [c - R, c], y in [s - R, s], both surfaces): monotone, converging
  for (const R of [1, 8, 32]) {
    const L = ['32x24', '48x36', '64x48'].map(mesh => dot(regionLoad(runs[mesh].F, [cR - R, cR + 1, sR - R, sR + 1], [cR, sR, 0]).F, eL)), q = (L[2] - L[1]) / (L[1] - L[0]);
    ok(L[1] > L[0] && L[2] > L[1] && q < 0.7, `corner box R ${R} mm: lift per unit q ${L.map(v => v.toFixed(4)).join(' -> ')} mm^2 (monotone, step ratio ${q.toFixed(3)} < 0.7: converging; integrable singularity)`);
  }
  // section cl at fixed stations: exact integral over a thin slab (half-width 0.02 mm)
  for (const eta of [0.5, 0.9, 0.95, 0.98, 0.99, 0.995]) {
    const y = eta * sR, h = 0.02, cl = mesh => dot(regionLoad(runs[mesh].F, [-1e9, 1e9, y - h, y + h], [cR / 4, y, 0]).F, eL) / (2 * h * cR);
    const c48 = cl('48x36'), c64 = cl('64x48'), p64 = PAN.meshes['64x48'].stations.find(q => q.eta === eta).cl;
    // 0.5 % mesh change, 1 % to PANAIR (whose own 32x24 -> 64x48 change reaches 0.4 % at these stations)
    ok(Math.abs(c48 / c64 - 1) < 5e-3 && Math.abs(c64 / p64 - 1) < 1e-2, `station eta ${eta}: cl 48x36 ${c48.toFixed(5)}, 64x48 ${c64.toFixed(5)} (change ${(100 * (c48 / c64 - 1)).toFixed(3)} % < 0.5 %); PANAIR 64x48 ${p64.toFixed(5)} (${(100 * (c64 / p64 - 1)).toFixed(3)} % < 1 %)`);
  }
}
console.log(`   (${secs()})`);

console.log('4. Global coefficients against PANAIR on identical nodes; pitching moment by one rule for both codes');
{
  const co = runs['64x48'].r.coefficients, pc = PAN.meshes['64x48'].config, pt = PAN.meshes['64x48'].trefftz, AR = 6;
  const eCore = co.CLTrefftz ** 2 / (Math.PI * AR * co.CDiTrefftz);
  for (const [name, a, b, tol] of [['CL (pressure)', co.CL, pc.CL, 2e-3], ['CL Trefftz', co.CLTrefftz, pt.CL, 2e-3], ['CDi Trefftz', co.CDiTrefftz, pt.CDi, 3e-3], ['span efficiency', eCore, pt.e, 3e-3]])
    ok(Math.abs(a / b - 1) < tol, `64x48 ${name}: core ${a.toPrecision(6)}, PANAIR ${b.toPrecision(6)} (${(100 * (a / b - 1)).toFixed(3)} %, < ${(100 * tol).toFixed(1)} %)`);
  // Cm about (50, 0, 0) on S c (semi-wing): core own; core and PANAIR by ONE rule (Cp at PANAIR's control point times
  // the solver panel's area vector, arm from that point; the core's Cp there from its recovered field)
  const den = 120000 * 200, aa = aR, out = {};
  for (const mesh of ['32x24', '64x48']) {
    const { m, r, F } = runs[mesh], S = m.wm.S, n = S.count, CP = PAN.meshes[mesh].controlPoints; let cc = 0, cpn = 0;
    assert.equal(CP.length, n, 'PANAIR control points match the solver panels');
    for (let k = 0; k < n; k++) {
      const X = [CP[k][0], CP[k][1], CP[k][2]], An = [S.PN[3 * k] * S.PA[k], S.PN[3 * k + 1] * S.PA[k], S.PN[3 * k + 2] * S.PA[k]], arm = sub(X, [50, 0, 0]);
      const my = cp => { const f = mul(An, -cp); return arm[2] * f[0] - arm[0] * f[2]; };
      cc += my(cpOnPanel(F, k, X)) / den; cpn += my(CP[k][3]) / den;
    }
    out[mesh] = { own: r.coefficients.Cm, cc, cpn };
    console.log(`   ${mesh}: core own Cm ${e3(r.coefficients.Cm)}; common rule: core ${e3(cc)}, PANAIR ${e3(cpn)}; integration rule (own - common) ${e3(r.coefficients.Cm - cc)}; solutions (core - PANAIR, common rule) ${e3(cc - cpn)}`);
  }
  const s1 = Math.abs(out['32x24'].cc - out['32x24'].cpn), s2 = Math.abs(out['64x48'].cc - out['64x48'].cpn), i1 = Math.abs(out['32x24'].own - out['32x24'].cc), i2 = Math.abs(out['64x48'].own - out['64x48'].cc);
  ok(s2 < 0.5 * s1, `Cm: the two codes' solutions converge toward each other (common rule, |core - PANAIR| ${e3(s1)} -> ${e3(s2)}, at least halved)`);
  ok(i2 < i1 / 3, `Cm: the common rule's own error is second order (core own - core common ${e3(i1)} -> ${e3(i2)}, falls by > 3 for h / 2)`);
}
console.log(`   (${secs()})`);

console.log('5. Self-convergence of lift, drag and moment (uniform sequence); conservation of the six components');
{
  const C = ['32x24', '48x36', '64x48'].map(k => runs[k].r.coefficients);
  for (const key of ['CL', 'CLTrefftz', 'CDpressure', 'Cm']) {
    const d1 = C[1][key] - C[0][key], d2 = C[2][key] - C[1][key];
    ok(Math.abs(d2) < 0.6 * Math.abs(d1) && Math.sign(d1) === Math.sign(d2), `${key}: ${C.map(c => c[key].toPrecision(6)).join(' -> ')} (monotone, steps ${e3(d1)} -> ${e3(d2)}: shrinking by more than 1/0.6)`);
  }
  const di = [C[1].CDiTrefftz - C[0].CDiTrefftz, C[2].CDiTrefftz - C[1].CDiTrefftz];
  ok(Math.max(...di.map(Math.abs)) < 3e-6, `CDi Trefftz: ${C.map(c => c.CDiTrefftz.toPrecision(6)).join(' -> ')} (steps ${di.map(e3).join(', ')} < 3e-6 = 0.06 %)`);
  // six components: panel forces and couples -> strip wrenches -> semi-wing resultant (exact by construction; checked)
  const { r, m } = runs['64x48'], S = m.wm.S, n = S.count, P0 = r.reference.momentPoint_mm; let F = [0, 0, 0], M = [0, 0, 0];
  for (let k = 0; k < n; k++) {
    const f = [r.panels.force_N[3 * k], r.panels.force_N[3 * k + 1], r.panels.force_N[3 * k + 2]], X = [S.PC[3 * k], S.PC[3 * k + 1], S.PC[3 * k + 2]];
    F = add(F, f); M = add(add(M, cross(sub(X, P0), f)), [r.panels.momentAboutCentroid_Nmm[3 * k], r.panels.momentAboutCentroid_Nmm[3 * k + 1], r.panels.momentAboutCentroid_Nmm[3 * k + 2]]);
  }
  const Fr = r.semiWing.force_N, Mr = r.semiWing.momentAboutReference_Nmm, sc = Math.hypot(...Fr), ms = Math.hypot(...Mr);
  ok(Math.hypot(...sub(F, Fr)) < 1e-9 * sc && Math.hypot(...sub(M, Mr)) < 1e-9 * Math.max(ms, sc * 200), `six components: the panel forces and couples sum to the semi-wing resultant (force ${e3(Math.hypot(...sub(F, Fr)))} N, moment ${e3(Math.hypot(...sub(M, Mr)))} N mm)`);
  let Fs = [0, 0, 0]; for (const st of r.strips) Fs = add(Fs, st.force_N);
  ok(Math.hypot(...sub(Fs, F)) < 1e-9 * sc, `six components: the strip forces sum to the resultant (${e3(Math.hypot(...sub(Fs, F)))} N); the full transfer chain is tested in test_wing_aero_transfer.mjs`);
}
console.log(`\nexternal / analytic acceptance: ${checks} checks passed (${secs()})`);
