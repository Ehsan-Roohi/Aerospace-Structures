// Wing AeroStruct aerodynamic UI (wing_aero_ui.js) in jsdom, driven like a user, with the real engines and a
// structural adapter that mirrors the page (wing_aerostruct_template.html). jsdom has no Worker, so the main-thread
// fallback runs the mesh sequence; the Worker itself is tested in test_wing_aero_worker.mjs.
//   MIE446_JSDOM_MODULE=/path/to/node_modules/jsdom node computational/printed-wing-solver/aerostruct/test_aerostruct_aero_ui.mjs
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import vm from 'node:vm';
const require = createRequire(import.meta.url), E = require('./engine.js'), IO = require('./wing_study_io.js'), W = require('./wing_aero_panel.js');
const { JSDOM } = require(process.env.MIE446_JSDOM_MODULE || 'jsdom');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const read = f => readFileSync(new URL(f, import.meta.url), 'utf8');
const dom = new JSDOM('<!doctype html><head></head><body><div id="host"></div></body>', { url: 'https://example.org/wing-aerostruct/', runScripts: 'outside-only' });
const w = dom.window, ctx = dom.getInternalVMContext();
for (const f of ['../web/wing_airfoils.js', '../web/wing_geometry.js', './wing_aero_panel.js', './wing_aero_ui.js']) vm.runInContext(read(f), ctx, { filename: f });
const UI = vm.runInContext('WingAeroUI', ctx), A = vm.runInContext('WingAeroPanel', ctx);
const $ = s => w.document.querySelector(s), tick = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, label, ms = 120000) => { const t = Date.now(); while (!fn()) { if (Date.now() - t > ms) throw new Error('timeout: ' + label); await tick(20); } };
const clean = html => !/NaN|undefined|Infinity/.test(html);
// state and adapter as in the page (editable course fixture: bonded seams, spars, no rods)
const fixture = IO.importPrintedStudy(readFileSync(new URL('../../../tests/fixtures/wing_lab_editable_browser.json', import.meta.url), 'utf8'), E).state;
const S = { geometry: { ...fixture.geometry }, assembly: { ...fixture.assembly }, load: { kind: 'custom', items: [], fos: 1.5, tipMass: 0 }, aerodynamics: null, aeroLoad: null };
const key = g => IO.sha256(A.geometryKey(g));
let saves = 0, blocked = '', applied = [], removed = 0, structureOk = true;
const adapter = {
  geometry: () => E.makeGeometry(S.geometry), disabled: () => blocked, settings: () => S.aerodynamics,
  saveSettings: v => { if (JSON.stringify(v) !== JSON.stringify(S.aerodynamics)) { S.aerodynamics = v; saves++; } },
  geometryKey: key,
  snapStations: () => { const g = E.makeGeometry(S.geometry); return [...E.ribStations(g), ...E.seams(g), ...(g.stations || []).map(s => s.eta * g.semiSpan), ...g.spars.map(s => s.length)]; },
  structure: () => { if (!structureOk) return { supported: false, message: 'This structure cannot take the aerodynamic load in the spatial beam: Remove external rods.' }; const g = E.makeGeometry(S.geometry), c = E.analysisCapability(g, { geometry: S.geometry, assembly: S.assembly, load: S.load, aeroLoad: { kind: 'aeroStrips', lineFraction: .25, strips: [[0, g.semiSpan, 0, 0, 0, 0, 0, 0]] } }); return { supported: c.supported, message: c.message }; },
  applied: () => S.aeroLoad, apply: rec => { applied.push(rec); S.aeroLoad = rec; }, remove: () => { removed++; S.aeroLoad = null; },
  workerURL: null, download: (name, text, mime) => downloads.push({ name, text, mime }),
};
const downloads = [];
const ui = UI.mount($('#host'), adapter);
ok($('#aeroV').value === '15' && $('#aeroRho').value === '1.225' && $('#aeroAlpha').value === '4' && $('#aeroSequence').value === 'standard', 'defaults shown (Standard sequence)');
ok($('#aeroApply').disabled && $('#aeroRemove').hidden, 'nothing to apply or remove before a solve');
const set = (id, v) => { $(id).value = String(v); $(id).dispatchEvent(new w.Event('input', { bubbles: true })); };
// 1. run the Standard sequence
set('#aeroV', 15); set('#aeroAlpha', 4);
const t0 = Date.now(); $('#aeroRun').click();
await until(() => /^Solved the standard sequence/.test($('#aeroStatus').textContent), 'Standard sequence');
log(`status: ${$('#aeroStatus').textContent} (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
ok(saves === 1 && S.aerodynamics.sequence === 'standard' && S.aerodynamics.alphaDeg === 4, 'settings saved with the sequence');
const html = $('#aeroResults').innerHTML;
ok(clean(html) && /±/.test(html) && /Pressure drag/.test(html) && /Global consistency/.test(html), 'extrapolated results with uncertainty and the consistency checks, no NaN or undefined');
ok($('#aeroResults').querySelectorAll('details table tbody tr').length === 7, 'the seven meshes of the sequence are listed');
ok($('#aeroResults svg.waefig') && $('#aeroCp svg'), 'spanwise force and chordwise Cp figures');
const cl = [...$('#aeroResults').querySelectorAll('tbody tr')].find(r => /pressure integral/.test(r.textContent)).children[1].textContent;
log(`CL (extrapolated ± U): ${cl}`);
ok(!$('#aeroApply').disabled, 'Apply is offered for a structure that takes six-component loads');
// 2. apply
$('#aeroApply').click();
ok(applied.length === 1 && applied[0].kind === 'panelSequence' && applied[0].levels.length === 7 && applied[0].geometrySha256 === key(E.makeGeometry(S.geometry)), 'Apply hands the page a record of the 7 solved meshes with the shape key');
ok(JSON.stringify(applied[0]) === JSON.stringify(UI.recordFromSequence(ui.result, applied[0].geometrySha256)), 'the record is exactly recordFromSequence of the solved sequence');
ok(/Aerodynamic load applied/.test($('#aeroStatus').textContent) && /Applied:/.test($('#aeroApplied').textContent) && !$('#aeroRemove').hidden, 'applied banner and Remove button');
// 3. the page's admission result is rendered
{
  const sg = E.makeGeometry(S.geometry), comb = UI.delivered(A, sg, S.aeroLoad, adapter.snapStations());
  const R = E.solve({ geometry: S.geometry, assembly: S.assembly, load: S.load, aeroLoad: UI.engineLoad(comb, S.aeroLoad.label) });
  const adm = UI.admit(A, sg, S.aeroLoad, comb, R);
  ui.showAdmission(adm);
  const box = $('#aeroAdmission').textContent;
  log(`admission (Standard): ${adm.admitted ? 'admitted' : 'NOT admitted'} (torque ${adm.claims.torque}, twist ${adm.claims.twist}); ${adm.rows.map(r => `${r.label} ${r.kind === 'twist' ? `${r.status}, bound ${(r.bound * 180 / Math.PI).toExponential(2)} deg, lift effect ${(100 * r.twist.liftEffect).toFixed(3)}%` : `${(100 * r.measure).toFixed(2)}%${r.status && !r.resolved ? ` (${r.status})` : ''}`}`).join('; ')}`);
  ok($('#aeroAdmission').querySelectorAll('tbody tr').length === adm.rows.length && /Root torque \(shear-centre axis\)/.test(box) && /Twist \(shear-centre axis\)/.test(box) && /One-way coupling/.test(box) && clean($('#aeroAdmission').innerHTML), 'admission table: one row per check, including the twist claim and the one-way coupling');
  ok(!/of the floor|\(floor\)|near-zero floor|q S c/.test(box) && /there is no absolute floor/.test(box), 'no absolute torque floor anywhere in the admission');
  ok(adm.admitted && adm.claims.twist === 'withheld' && /admitted with torque and twist withheld/.test(box) && /\|θ\| ≤/.test(box) && /not resolved/.test(box), 'near-zero torque on this structure: admitted with torque and twist withheld, the bound stated');
  ok($('#aeroAdmission').querySelectorAll('.wae-warnmark').length === adm.rows.filter(r => !r.resolved && r.admitted).length, 'unresolved (withheld) rows marked !, not ✓');
  ok(/^Admission test \(standard sequence\): admitted with torque and twist withheld\. See the table below\.$/.test($('#aeroStatus').textContent), `status line gives the outcome of the admission test: ${$('#aeroStatus').textContent}`);
  { const twistRow = [...$('#aeroAdmission').querySelectorAll('tbody tr')].find(tr => /Twist \(shear-centre axis\)/.test(tr.textContent)), oneWay = [...$('#aeroAdmission').querySelectorAll('tbody tr')].find(tr => /One-way coupling/.test(tr.textContent));
    const pct = v => `${Number((100 * v).toPrecision(2))}%`;
    ok(twistRow.textContent.includes(`lift effect ${pct(adm.twist.liftEffect)} (limit 1.0%)`) && oneWay.textContent.includes(`${pct(adm.twist.rigidWingEffect)} of lift (limit 2.0%)`) && !/lift effect 0\.0%|0\.0% of lift/.test($('#aeroAdmission').textContent), `small percentages keep two significant digits (${twistRow.children[2].textContent}; ${oneWay.children[2].textContent})`); }
  const residual = Math.max(...adm.rows.filter(r => r.kind === 'torque').map(r => Math.abs(r.transferResidual)));
  log(`engine cut torque of the delivered load against the admission torque: largest difference ${residual.toExponential(1)} N mm at the four cuts (Standard)`);
  ok(adm.rows.filter(r => r.kind === 'torque').every(r => Math.abs(r.transferResidual) < 1e-9 * Math.max(1, Math.abs(r.value))), `the beam cut torques equal the delivered torques (largest difference ${residual.toExponential(1)} N mm at the four cuts)`);
  // a low-GJ variant of the same structure: the same unresolved torque gives a twist bound that is not negligible
  const soft = { ...S.geometry, spars: S.geometry.spars.map(sp => ({ ...sp, material: { ...sp.material, E: 10 } })) };
  const Rs = E.solve({ geometry: soft, assembly: S.assembly, load: S.load, pla: { E: 10 }, aeroLoad: UI.engineLoad(comb, S.aeroLoad.label) }), admSoft = UI.admit(A, sg, S.aeroLoad, comb, Rs);
  ui.showAdmission(admSoft);
  const boxSoft = $('#aeroAdmission').textContent;
  log(`admission (Standard, low-GJ structure): ${admSoft.admitted ? 'admitted' : 'NOT admitted'}; twist bound lift effect ${(100 * admSoft.twist.liftEffect).toFixed(2)}%`);
  ok(!admSoft.admitted && admSoft.twist.status === 'unresolved' && /NOT admitted/.test(boxSoft) && /would change the lift by/.test(boxSoft) && /Run the Fine sequence/.test(boxSoft), 'low-GJ structure: the coupled result is withheld and the reason named');
  ok(/^Admission test \(standard sequence\): NOT admitted, the coupled result is withheld/.test($('#aeroStatus').textContent) && $('#aeroStatus .wae-err'), 'status line: NOT admitted, marked as an error');
  ui.showAdmission(null, 'The admission test needs the spatial-beam result.');
  ok(/needs the spatial-beam result/.test($('#aeroAdmission').textContent), 'an admission error is shown, not hidden');
}
// 4. CSV
$('#aeroCsv').click();
const csv = downloads.at(-1);
ok(csv && csv.mime === 'text/csv' && /^# MIE 446 Wing AeroStruct/.test(csv.text) && /y0_mm,y1_mm,Fx_N,Fy_N,Fz_N,Mx_Nmm,My_Nmm,Mz_Nmm/.test(csv.text) && /chordPanels,spanPanels,weight/.test(csv.text), 'CSV with the delivered strips and every mesh with its weight');
ok(csv.text.split('\n').filter(l => /^\d/.test(l)).length > 100 && !/NaN|undefined/.test(csv.text), 'CSV rows are numbers');
// 5. the wing changes: the solved sequence cannot be applied; the applied load is reported stale
S.geometry = { ...S.geometry, dihedralDeg: 3 }; ui.refresh();
ok($('#aeroApply').disabled && /shape changed/.test($('#aeroStatus').textContent) && /wing shape changed after this load was solved/.test($('#aeroApplied').textContent), 'geometry change: Apply disabled, the applied load flagged stale');
ui.apply(); ok(/Run the mesh sequence again/.test($('#aeroStatus').textContent) && applied.length === 1, 'apply after a geometry change is refused');
S.geometry = { ...fixture.geometry }; ui.refresh(); ok(!$('#aeroApply').disabled, 'back to the solved shape: Apply offered again');
// 6. a structure the spatial beam cannot take (for example rods): Apply disabled with the reason
structureOk = false; ui.refresh();
ok($('#aeroApply').disabled, 'unsupported structure: Apply disabled'); ui.apply(); ok(/Remove external rods/.test($('#aeroStatus').textContent), 'unsupported structure: the reason is shown');
structureOk = true; ui.refresh();
// 7. remove
$('#aeroRemove').click(); ok(removed === 1 && S.aeroLoad === null && $('#aeroApplied').innerHTML === '' && $('#aeroRemove').hidden, 'Remove clears the applied load');
// 8. target lift (on the extrapolated lift), cached models make it fast
set('#aeroTarget', 3.924); const t1 = Date.now(); $('#aeroRun').click();
await until(() => /^Solved the standard sequence/.test($('#aeroStatus').textContent) && Date.now() > t1, 'target-lift sequence');
const lift = ui.result.weights.reduce((t, x) => t + x.weight * ui.result.levels.find(l => l.chordPanels === x.chordPanels && l.spanPanels === x.spanPanels).liftN, 0);
log(`target lift 3.924 N: alpha ${$('#aeroAlpha').value} deg, extrapolated lift ${lift.toFixed(9)} N (${Date.now() - t1} ms with cached influence systems)`);
ok(Math.abs(lift - 3.924) < 1e-7 && Math.abs(+$('#aeroAlpha').value - ui.result.trim.alphaDeg) < 1e-3 && /influence systems reused/.test($('#aeroStatus').textContent), 'target lift met on the extrapolated lift; alpha field updated');
set('#aeroTarget', '');
// 9. input refusals before any work
for (const [id, v, re] of [['#aeroSound', 1000, /Speed of sound in air/], ['#aeroV', 150, /Mach/], ['#aeroRho', 'x', /Density: enter a finite number/]]) {
  const keep = $(id).value; set(id, v); $('#aeroRun').click(); await tick(20);
  ok(re.test($('#aeroStatus').textContent) && $('#aeroStatus .wae-err'), `refused: ${$('#aeroStatus').textContent}`); set(id, keep);
}
blocked = 'Create a wing first: this is an empty study.'; $('#aeroRun').click(); await tick(10); ok(/Create a wing first/.test($('#aeroStatus').textContent), 'blocked study refused'); blocked = '';
// 10. restored settings (undo or an opened study) fill the fields
S.aerodynamics = { speed: 12, density: 1.1, alphaDeg: 2, sequence: 'fine' }; ui.refresh();
ok($('#aeroV').value === '12' && $('#aeroRho').value === '1.1' && $('#aeroAlpha').value === '2' && $('#aeroSequence').value === 'fine', 'fields follow restored settings, including the sequence');
ui.destroy(); ok($('#host').innerHTML === '', 'destroy clears the panel');
console.log(`test_aerostruct_aero_ui: ${checks} checks passed`);
