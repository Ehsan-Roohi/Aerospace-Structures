// Mesh-sequence extrapolation, uncertainty and admission (wing_aero_panel.js):
//  1. weights: Lagrange extrapolation in 1/n, unit sum, exact for errors quadratic in 1/c and 1/s;
//  2. observed order (Celik et al. 2008 iteration with non-uniform ratios) recovers known orders exactly;
//  3. the uncertainty formula U = 1.25 x sum over directions of max(spread + stability, 0.5 |correction|), and
//     synthetic power laws with orders 0.6 to 2.5 in each direction: |estimate - exact| <= U for every case;
//  4. admission logic: torque error relative to |T| with no absolute floor, sign and opposite-sign meshes, the
//     twist claim with a synthetic structure (negligible, unresolved, resolved), the one-way coupling check, force,
//     bending and lift rows, transfer residual reporting;
//  5. validation against stored references from meshes up to about 11,000 panels (validation/reference_study.mjs;
//     the stored base-mesh resultant proves the references belong to this solver): Standard- and Fine-sequence
//     estimates of root and cut torques about three axes, root force and bending are within U, and every admitted
//     quantity's error (including the reference uncertainty and the estimated cross-term error) is within its
//     tolerance; the stored summary of all seven wings passes; the cross-term (separability) error is small against
//     U; the global loads are physically consistent (pressure versus Trefftz lift and drag).
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
const require = createRequire(import.meta.url), W = require('./wing_aero_panel.js'), E = require('./engine.js'), UI = require('./wing_aero_ui.js');
let checks = 0;
const ok = (v, m) => { assert.ok(v, m); checks++; };
const log = (...a) => console.log('  ', ...a);
const t0 = Date.now();
// 1. weights
for (const name of ['standard', 'fine']) {
  const w = W.sequenceWeights(name), sum = w.reduce((t, x) => t + x.weight, 0);
  ok(Math.abs(sum - 1) < 1e-12, `${name}: weights sum to one`);
  const exact = 1.234, Q = (c, s) => exact + 3 / c - 40 / c ** 2 + 0.5 / s + 7 / s ** 2;
  const est = W.sequenceEstimate(name, Q), viaWeights = w.reduce((t, x) => t + x.weight * Q(x.chordPanels, x.spanPanels), 0);
  ok(Math.abs(est.value - exact) < 1e-12 && Math.abs(viaWeights - exact) < 1e-12, `${name}: an error quadratic in 1/c and 1/s is removed exactly (${(est.value - exact).toExponential(1)})`);
  log(`${name}: meshes ${W.sequenceMeshes(name).map(m => `${2 * m.chordPanels}x${m.spanPanels}`).join(', ')}; weights ${w.map(x => `${2 * x.chordPanels}x${x.spanPanels}: ${x.weight.toFixed(3)}`).join(', ')}`);
}
// 2. observed order
for (const p of [0.8, 1.3, 2.0]) { const f = n => 2 + 0.7 * n ** -p, o = W.observedOrder(24, 32, 48, f(24), f(32), f(48), [0.1, 5]); ok(Math.abs(o.order - p) < 1e-9 && Math.abs(o.extrapolated - 2) < 1e-12, `observed order ${p} recovered (${o.order.toFixed(12)})`); }
{ const o = W.observedOrder(24, 32, 48, 1, 1.1, 1.05); ok(o.order === null && o.orderUsed === 1 && !o.monotone, 'oscillatory sequence: first order, flagged non-monotone'); }
{ const o = W.observedOrder(24, 32, 48, 3, 3, 3); ok(o.extrapolated === 3 && o.order === null, 'converged sequence: the finest value'); }
// 3. the uncertainty formula, then synthetic coverage
{
  const Q = (c, s) => 2 + 0.3 * (c / 16) ** -0.7 - 0.2 * (s / 8) ** -1.1, est = W.sequenceEstimate('fine', Q);
  const term = d => Math.max(est[d].spread + est[d].stability, 0.5 * Math.abs(est[d].quadratic - est[d].finest));
  ok(Math.abs(est.uncertainty - 1.25 * (term('chord') + term('span'))) < 1e-15 && W.ADMISSION.correctionFraction === 0.5 && W.ADMISSION.safetyFactor === 1.25,
    `U = 1.25 x sum of max(spread + stability, 0.5 |correction|) per direction (${est.uncertainty.toExponential(3)}; correction governs: chord ${est.chord.correctionGoverns}, span ${est.span.correctionGoverns})`);
  ok(est.chord.correction === est.chord.quadratic - est.chord.finest && est.span.term === term('span'), 'per-direction correction and term are reported');
}
{
  let worst = 0, n = 0;
  for (const pc of [0.6, 0.8, 1, 1.3, 1.7, 2.5]) for (const ps of [0.6, 0.9, 1, 1.5, 2.2]) for (const [a, b] of [[1, 1], [1, -1], [-2, 0.5], [0.3, -3]]) for (const name of ['standard', 'fine']) {
    const Q = (c, s) => 5 + a * (c / 16) ** -pc + b * (s / 8) ** -ps, est = W.sequenceEstimate(name, Q), err = Math.abs(est.value - 5);
    worst = Math.max(worst, err / est.uncertainty); n++;
  }
  log(`synthetic power laws (orders 0.6 to 2.5 per direction, ${n} cases): largest |estimate - exact| / U = ${worst.toFixed(3)}`);
  ok(worst <= 1, 'U covers the extrapolation error of every synthetic power law');
}
// 4. admission logic on synthetic sequences (exact strip loads + a mesh-dependent error)
{
  const g = W.aeroGeometry({ semiSpan: 300, rootChord: 120, tipChord: 80, naca: '0012' }), L = g.semiSpan;
  const lineAt = y => W.loadLinePoint(g, y), simpson = (fn, a, b, n = 200) => { const o = fn(a).map(() => 0); for (let k = 0; k <= n; k++) { const w = k === 0 || k === n ? 1 : k % 2 ? 4 : 2, v = fn(a + (b - a) * k / n); for (let i = 0; i < v.length; i++) o[i] += w * v[i]; } return o.map(v => v * (b - a) / (3 * n)); };
  const cross = (u, v) => [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
  // couple(m) is the extra pitching couple per unit span on mesh m (a function of the mesh, so it can change sign)
  const make = (couple, eps0) => ({ sequence: 'standard', flow: { dynamicPressure_Pa: 150 }, reference: W.references(g), levels: W.sequenceMeshes('standard').map(m => {
    const ys = W.spanStations(g, m.spanPanels, 'sine'), eps = eps0 * ((m.chordPanels / 16) ** -0.8 + (m.spanPanels / 8) ** -1.3), cm = typeof couple === 'function' ? couple(m) : couple * (1 + eps);
    return { ...m, roundedTip: null, coefficients: { CL: .5 + eps, CLTrefftz: .5 + eps, CDpressure: .01, CDiTrefftz: .01, Cm: 0 }, strips: ys.slice(1).map((y1, i) => { const y0 = ys[i], q = y => [0, 0, .02 * (1 - (y / L) ** 2) * (1 + eps)], F = simpson(q, y0, y1), M = simpson(y => cross(lineAt(y), q(y)).map((v, d) => v + (d === 1 ? cm : 0)), y0, y1); return [y0, y1, ...F, ...M]; }) };
  }) });
  const root = lineAt(0), tip = lineAt(L), e = tip.map((v, i) => v - root[i]), le = Math.hypot(...e), n = e.map(v => v / le);
  const cuts = [{ y: 0, root: true, reference: root, normal: n }, { y: L / 2, reference: lineAt(L / 2), normal: n }];
  // a synthetic structure: uniform torsional compliance k (rad per N mm per mm) and a twist proportional to it
  const torsion = (k, thetaTip) => ({ cuts: Array.from({ length: 16 }, (_, j) => ({ y: j * L / 16, root: j === 0, reference: lineAt(j * L / 16), normal: n })), elements: [{ y0: 0, y1: L, k }], twist: { y: [0, L], theta: [0, thetaTip] } });
  for (const [couple, label] of [[0, 'zero torque about the quarter-chord axis'], [-0.02, 'nose-down couple']]) {
    const seq = make(couple, 0.05), comb = W.combineSequence(g, seq, {}), adm = W.admission(g, seq, comb, cuts), T = adm.rows[0];
    log(`synthetic ${label}: root torque ${T.value.toFixed(4)} N mm ± ${T.uncertainty.toExponential(2)}; relative ${Number.isFinite(T.relative) ? (100 * T.relative).toFixed(3) + '%' : 'infinite'}; ${T.status}`);
    ok(!('torqueFloor_Nmm' in adm) && T.floorActive === undefined && T.relative === (T.value !== 0 ? T.uncertainty / Math.abs(T.value) : Infinity), `${label}: torque error relative to |T| itself, no absolute floor`);
    ok(T.resolved === (T.relative <= 0.10 && T.meshSignsAgree) && T.admitted === T.resolved, `${label}: without the structure a torque is admitted only if resolved`);
    ok(adm.rows.filter(r => r.kind === 'torque').length === 2 && adm.rows.some(r => r.kind === 'force') && adm.rows.some(r => r.kind === 'bending') && adm.rows.some(r => r.kind === 'liftConsistency') && adm.twist === null, `${label}: torque at every cut, root force, bending and lift consistency rows; no twist row without the structure`);
    ok(adm.admitted === adm.rows.every(r => r.admitted) && adm.failed.length === adm.rows.filter(r => !r.admitted).length, `${label}: overall decision is the conjunction`);
    if (couple === 0) ok(!T.resolved && !T.signResolved && T.status === 'sign not resolved' && !adm.admitted && adm.claims.twist === 'withheld', 'a near-zero torque is never admitted as resolved (no floor): sign not resolved, withheld');
    else ok(T.resolved && T.status === 'resolved' && adm.claims.torque === 'shown', 'a nose-down couple well above its uncertainty is resolved');
  }
  // opposite-sign meshes: the couple changes sign between coarse and fine meshes
  {
    // (a) every weighted mesh has the opposite sign of the extrapolated torque
    const flip = m => 0.004 - 0.25 / m.chordPanels; // negative on 16..48 panels, positive in the limit
    const seq = make(flip, 0.05), comb = W.combineSequence(g, seq, {}), adm = W.admission(g, seq, comb, cuts), T = adm.rows[0];
    log(`synthetic opposite-sign meshes (a): weighted mesh torques ${T.meshTorques.map(m => m.torque.toFixed(3)).join(', ')} N mm; delivered ${T.value.toFixed(3)} ± ${T.uncertainty.toFixed(3)}; ${T.status}`);
    ok(T.meshTorques.every(m => Math.sign(m.torque) === -Math.sign(T.value)) && !T.meshSignsAgree && !T.resolved && !T.signResolved && T.status === 'sign not resolved', 'extrapolation of the opposite sign to every mesh: never resolved, sign reported as not resolved');
    ok(T.uncertainty >= 0.625 * Math.abs(T.value), 'the correction term alone makes U at least 62.5% of |T| when the finest mesh disagrees in sign with the extrapolation');
    // (b) the weighted meshes themselves have both signs
    { const both = make(m => 0.0015 - 0.05 / m.chordPanels, 0.05), cb = W.combineSequence(g, both, {}), Tb = W.admission(g, both, cb, cuts).rows[0], signs = new Set(Tb.meshTorques.map(m => Math.sign(m.torque)));
      log(`synthetic opposite-sign meshes (b): weighted mesh torques ${Tb.meshTorques.map(m => m.torque.toFixed(3)).join(', ')} N mm; delivered ${Tb.value.toFixed(3)} ± ${Tb.uncertainty.toFixed(3)}; ${Tb.status}`);
      ok(signs.size === 2 && !Tb.meshSignsAgree && !Tb.resolved && Tb.status === 'sign not resolved', 'meshes of both signs: never resolved, sign reported as not resolved'); }
    // with a stiff structure the twist bound is negligible: admitted, torque and twist withheld
    const stiff = W.admission(g, seq, comb, cuts, { torsion: torsion(1e-10, 1e-7) }), tw = stiff.twist;
    ok(stiff.admitted && tw.status === 'negligible' && stiff.claims.torque === 'withheld' && stiff.claims.twist === 'withheld' && stiff.rows.find(r => r.kind === 'torque').admitted && !stiff.rows.find(r => r.kind === 'torque').resolved, `stiff structure: twist bound negligible (lift effect ${(100 * tw.liftEffect).toExponential(2)}%): admitted with torque and twist withheld`);
    // with a flexible structure the same unresolved torque gives a twist bound that is not negligible: refused
    const flexible = W.admission(g, seq, comb, cuts, { torsion: torsion(1e-4, 1e-3) });
    ok(!flexible.admitted && flexible.twist.status === 'unresolved' && flexible.failed.includes('Twist (shear-centre axis)'), `flexible structure: twist bound changes the lift by ${(100 * flexible.twist.liftEffect).toFixed(1)}% (> 1%): refused`);
    // the bound integral: uniform k and the upper envelope of U at 16 cuts
    const U = flexible.twist.cuts.map(c => c.U), envelope = U.reduce((t, u, j) => t + Math.max(u, U[j + 1] ?? 0) * (L / 16), 0) * 1e-4;
    ok(Math.abs(flexible.twist.tipDtheta - envelope) <= 1e-12 * envelope, `twist bound = integral of the upper envelope of U_T times the compliance (${flexible.twist.tipDtheta.toExponential(4)} rad)`);
    // lift effect: q 2 pi integral c (|theta| + dtheta) dy / |L|
    const q = 150e-6, CL = comb.coefficients.CL.value, Lsemi = Math.abs(CL) * q * W.references(g).semiArea_mm2;
    let I = 0; const N = 2000; for (let i = 0; i <= N; i++) { const y = L * i / N, w = i === 0 || i === N ? 0.5 : 1, th = 1e-3 * y / L, cuts16 = flexible.twist.cuts, j = Math.min(15, Math.floor(16 * y / L)); let d = 0; for (let k2 = 0; k2 < 16; k2++) { const a = cuts16[k2].y, b = Math.min(k2 < 15 ? cuts16[k2 + 1].y : L, y); if (b > a) d += Math.max(cuts16[k2].U, k2 < 15 ? cuts16[k2 + 1].U : 0) * 1e-4 * (b - a); } I += w * (120 - 40 * y / L) * (th + d); }
    const effect = q * 2 * Math.PI * I * (L / N) / Lsemi;
    ok(Math.abs(effect - flexible.twist.liftEffect) <= 0.01 * effect, `lift effect of the twist bound reproduced independently (${(100 * effect).toFixed(3)}% vs ${(100 * flexible.twist.liftEffect).toFixed(3)}%)`);
  }
  // a resolved torque on a stiff structure: twist shown; the same twist on a very flexible structure: one-way coupling fails
  {
    const seq = make(-0.02, 0.05), comb = W.combineSequence(g, seq, {});
    const shown = W.admission(g, seq, comb, cuts, { torsion: torsion(1e-9, -1e-4) });
    ok(shown.admitted && shown.twist.status === 'resolved' && shown.claims.twist === 'shown' && shown.claims.torque === 'shown' && shown.rows.find(r => r.kind === 'aeroelastic').admitted, `resolved torque, stiff structure: twist shown (tip dtheta ${(shown.twist.tipDtheta * 180 / Math.PI).toExponential(2)} deg against |theta| ${(1e-4 * 180 / Math.PI).toExponential(2)} deg)`);
    const loose = W.admission(g, seq, comb, cuts, { torsion: torsion(1e-9, -0.08) });
    const ae = loose.rows.find(r => r.kind === 'aeroelastic');
    ok(!loose.admitted && !ae.admitted && ae.value > 0.02 && loose.failed.includes(ae.label), `the same load with a twist that would change the lift by ${(100 * ae.value).toFixed(1)}%: refused (rigid-wing load inconsistent with the structure)`);
    // every torque resolved, but a twist so small that its uncertainty exceeds 10% of it: only the twist is withheld
    const tiny = W.admission(g, seq, comb, cuts, { torsion: torsion(1e-9, 1e-9) }), v = UI.admissionVerdict(tiny);
    log(`resolved torque, twist ${tiny.twist.status} (worst dtheta / |theta| ${tiny.twist.worstRelative.toExponential(2)}, lift effect ${(100 * tiny.twist.liftEffect).toExponential(2)}%): ${v.html.replace(/<[^>]+>/g, '')}`);
    ok(tiny.admitted && tiny.rows.filter(r => r.kind === 'torque').every(r => r.resolved && r.admitted) && tiny.twist.status === 'negligible' && tiny.claims.torque === 'shown' && tiny.claims.twist === 'withheld', 'resolved torque, unresolved but negligible twist: admitted, torque shown, twist withheld');
    ok(/^Aerodynamic load admitted with the twist withheld: every torque is resolved, but the twist is not resolved to 10% of itself/.test(v.html) && !/torque and twist withheld|not resolved \(\)/.test(v.html), 'its verdict names the twist only, not an unresolved torque');
    const rough = W.admission(g, seq, comb, cuts, { torsion: torsion(1e-4, 1e-9) }), vr = UI.admissionVerdict(rough);
    ok(!rough.admitted && rough.twist.status === 'unresolved' && rough.claims.torque === 'shown' && /The twist is not resolved to 10% of itself and its twist bound/.test(vr.html) && !/The torque about the shear-centre axis is not resolved/.test(vr.html), 'resolved torque on a flexible structure with an unresolved, non-negligible twist: refused, the reason names the twist');
  }
  // a tighter tolerance than the measure fails the row and the decision; the reasons are named
  const seq = make(-0.02, 0.05), comb = W.combineSequence(g, seq, {}), strict = W.admission(g, seq, comb, cuts, { settings: { torqueTolerance: 1e-9 } });
  ok(!strict.admitted && strict.failed.some(f => /Root torque/.test(f)), 'a torque above tolerance is not admitted and is named');
  const withCheck = W.admission(g, seq, comb, [{ ...cuts[0], structuralTorque: 1.0 }, cuts[1]]);
  ok(Math.abs(withCheck.rows[0].transferResidual - (1.0 - withCheck.rows[0].value)) < 1e-15, 'transfer residual reported against the structural torque');
  let refused = null; try { W.admission(g, seq, comb, [cuts[1]]); } catch (err) { refused = err.message; } ok(/root cut first/.test(refused), 'the root cut is required first');
}
// 5. validation against the stored fine-mesh references
const ref = JSON.parse(readFileSync(new URL('./validation/admission_reference.json', import.meta.url), 'utf8'));
const base = E.DEFAULT_GEOMETRY;
const CONFIGS = { course4: { g: { ...base }, flow: { speed: 15, alphaDeg: 4 } }, dihedral6: { g: { ...base, dihedralDeg: 6 }, flow: { speed: 15, alphaDeg: 4 } }, swept25: { g: { ...base, sweepDeg: 25, sweepReferenceFraction: 0.25 }, flow: { speed: 15, alphaDeg: 4 } } };
const tally = {};
for (const [name, cfg] of Object.entries(CONFIGS)) {
  const g = W.aeroGeometry(E.makeGeometry(cfg.g)), L = g.semiSpan, cache = new Map(), stored = ref.configs[name];
  const baseRes = W.solve(g, cfg.flow, { chordPanels: 32, spanPanels: 16 }, { cache }), baseRoot = W.stripWrenches(baseRes).reduce((t, r) => t.map((v, i) => v + r[2 + i]), [0, 0, 0, 0, 0, 0]);
  ok(baseRoot.every((v, i) => Math.abs(v - stored.baseRootWrench[i]) <= 1e-10 * Math.max(1, Math.abs(v))), `${name}: the stored references belong to this solver (base-mesh resultant reproduced)`);
  for (const sn of ['standard', 'fine']) {
    const t = tally[sn] ||= { cases: 0, worst: { r: 0 }, admitted: 0, crossWorst: 0 };
    const seq = W.runSequence(g, cfg.flow, sn, { cache }), comb = W.combineSequence(g, seq, {});
    const lc = comb.consistency.lift, dc = comb.consistency.drag;
    ok(lc.relativeDifference < 0.02 && Math.abs(dc.difference) < 0.05 * dc.trefftz, `${name}, ${sn}: extrapolated pressure lift ${lc.pressure.toFixed(4)} vs Trefftz ${lc.trefftz.toFixed(4)}, pressure drag ${dc.pressure.toFixed(5)} vs induced ${dc.trefftz.toFixed(5)}`);
    for (const f of [0.25, 0.35, 0.45]) {
      const a = W.loadLinePoint(g, 0, f), b = W.loadLinePoint(g, L, f), d = b.map((v, i) => v - a[i]), l = Math.hypot(...d), e = d.map(v => v / l);
      const cuts = [{ y: 0, root: true, reference: a, normal: e }, ...[0.25, 0.5, 0.75].map(u => ({ y: u * L, reference: a.map((v, k) => v + u * (b[k] - v)), normal: e }))];
      const adm = W.admission(g, seq, comb, cuts), truth = stored.axes[String(f)], cross = stored.separability.axes[String(f)], torques = adm.rows.filter(r => r.kind === 'torque');
      torques.forEach((r, i) => {
        const tr = truth[i], X = Math.max(...cross[i].crossTorque.map(Math.abs)), err = Math.abs(r.value - tr.T), ratio = err / r.uncertainty; t.cases++;
        if (ratio > t.worst.r) t.worst = { r: ratio, at: `${name} axis ${f} y ${tr.y}` };
        t.crossWorst = Math.max(t.crossWorst, X / r.uncertainty);
        ok(sn === 'standard' ? err + tr.uT <= r.uncertainty : err <= r.uncertainty, `${name}, ${sn}, ${f}c axis, torque at y = ${tr.y}: |${r.value.toFixed(4)} - ${tr.T.toFixed(4)}|${sn === 'standard' ? ` + ${tr.uT.toFixed(4)}` : ''} <= U ${r.uncertainty.toFixed(4)}`);
        if (r.resolved) { t.admitted++; ok((err + tr.uT + X) / Math.abs(r.value) <= r.tolerance, `${name}, ${sn}, ${f}c axis, y = ${tr.y}: resolved torque's error (with the reference uncertainty and the cross term) within 10% of |T|`); }
        if (r.signResolved) ok(Math.sign(r.value) === Math.sign(tr.T), `${name}, ${sn}, ${f}c axis, y = ${tr.y}: resolved sign equals the reference sign`);
      });
      for (const kind of ['force', 'bending']) { const r = adm.rows.find(x => x.kind === kind), tv = kind === 'force' ? truth[0].Fmag : truth[0].Bmag; ok(Math.abs(r.value - tv) <= r.uncertainty, `${name}, ${sn}, ${f}c axis: root ${kind} ${r.value.toFixed(4)} vs reference ${tv.toFixed(4)} within U ${r.uncertainty.toFixed(4)}`); }
    }
  }
}
for (const [sn, t] of Object.entries(tally)) log(`validation, ${sn}: ${t.cases} torque estimates (3 wings x 3 axes x 4 stations) within U${sn === 'standard' ? ' including the reference uncertainty' : ''}; largest |error|/U ${t.worst.r.toFixed(2)} (${t.worst.at}); ${t.admitted} resolved torques within 10% of |T|; largest cross-term estimate / U ${t.crossWorst.toFixed(2)}`);
ok(tally.fine.crossWorst < 0.5 && tally.standard.crossWorst < 0.2, 'the cross-term (separability) error estimates are small against U');
// the stored outcome of the full reference study (seven wings, both sequences)
{
  const sm = ref.summary, keys = ['standard', 'fine'].flatMap(sn => ['torque', 'force', 'bending'].map(k => `${sn}/${k}`));
  ok(sm && keys.every(k => sm[k] && sm[k].covered === sm[k].cases && sm[k].resolvedWithTrueErrorAboveTolerance === 0 && sm[k].resolvedWithStrictErrorAboveTolerance === 0), 'stored reference study: every estimate of both sequences within U, no resolved quantity above its tolerance');
  ok(['standard', 'fine'].every(sn => sm[`${sn}/torque`].signResolvedButWrong === 0 && sm[`${sn}/torque`].wrongSignFlagged === sm[`${sn}/torque`].wrongSignCases), 'stored reference study: every torque reported with a resolved sign has the reference sign; every estimate of the wrong sign is flagged');
  ok(sm.sequenceSignDisagreement && sm.sequenceSignDisagreement.bothFlagged === sm.sequenceSignDisagreement.cases, `stored reference study: the ${sm.sequenceSignDisagreement?.cases} torques whose Standard and Fine estimates have opposite signs are flagged sign-unresolved in both sequences`);
  log(`stored reference study (7 wings): ${keys.map(k => `${k} ${sm[k].covered}/${sm[k].cases} covered (largest |err|/U ${sm[k].maxRatio.toFixed(2)}), resolved ${sm[k].resolved}`).join('; ')}`);
}
console.log(`test_wing_aero_admission: ${checks} checks passed (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
